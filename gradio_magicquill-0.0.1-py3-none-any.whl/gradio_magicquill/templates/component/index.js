const {
  SvelteComponent: C0,
  assign: x0,
  create_slot: S0,
  detach: T0,
  element: E0,
  get_all_dirty_from_scope: k0,
  get_slot_changes: O0,
  get_spread_update: M0,
  init: P0,
  insert: A0,
  safe_not_equal: D0,
  set_dynamic_element_data: Ec,
  set_style: Fe,
  toggle_class: vn,
  transition_in: kh,
  transition_out: Oh,
  update_slot_base: L0
} = window.__gradio__svelte__internal;
function j0(t) {
  let e, n, a;
  const p = (
    /*#slots*/
    t[18].default
  ), g = S0(
    p,
    t,
    /*$$scope*/
    t[17],
    null
  );
  let _ = [
    { "data-testid": (
      /*test_id*/
      t[7]
    ) },
    { id: (
      /*elem_id*/
      t[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      t[3].join(" ") + " svelte-nl1om8"
    }
  ], w = {};
  for (let x = 0; x < _.length; x += 1)
    w = x0(w, _[x]);
  return {
    c() {
      e = E0(
        /*tag*/
        t[14]
      ), g && g.c(), Ec(
        /*tag*/
        t[14]
      )(e, w), vn(
        e,
        "hidden",
        /*visible*/
        t[10] === !1
      ), vn(
        e,
        "padded",
        /*padding*/
        t[6]
      ), vn(
        e,
        "border_focus",
        /*border_mode*/
        t[5] === "focus"
      ), vn(
        e,
        "border_contrast",
        /*border_mode*/
        t[5] === "contrast"
      ), vn(e, "hide-container", !/*explicit_call*/
      t[8] && !/*container*/
      t[9]), Fe(
        e,
        "height",
        /*get_dimension*/
        t[15](
          /*height*/
          t[0]
        )
      ), Fe(e, "width", typeof /*width*/
      t[1] == "number" ? `calc(min(${/*width*/
      t[1]}px, 100%))` : (
        /*get_dimension*/
        t[15](
          /*width*/
          t[1]
        )
      )), Fe(
        e,
        "border-style",
        /*variant*/
        t[4]
      ), Fe(
        e,
        "overflow",
        /*allow_overflow*/
        t[11] ? "visible" : "hidden"
      ), Fe(
        e,
        "flex-grow",
        /*scale*/
        t[12]
      ), Fe(e, "min-width", `calc(min(${/*min_width*/
      t[13]}px, 100%))`), Fe(e, "border-width", "var(--block-border-width)");
    },
    m(x, T) {
      A0(x, e, T), g && g.m(e, null), a = !0;
    },
    p(x, T) {
      g && g.p && (!a || T & /*$$scope*/
      131072) && L0(
        g,
        p,
        x,
        /*$$scope*/
        x[17],
        a ? O0(
          p,
          /*$$scope*/
          x[17],
          T,
          null
        ) : k0(
          /*$$scope*/
          x[17]
        ),
        null
      ), Ec(
        /*tag*/
        x[14]
      )(e, w = M0(_, [
        (!a || T & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          x[7]
        ) },
        (!a || T & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          x[2]
        ) },
        (!a || T & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        x[3].join(" ") + " svelte-nl1om8")) && { class: n }
      ])), vn(
        e,
        "hidden",
        /*visible*/
        x[10] === !1
      ), vn(
        e,
        "padded",
        /*padding*/
        x[6]
      ), vn(
        e,
        "border_focus",
        /*border_mode*/
        x[5] === "focus"
      ), vn(
        e,
        "border_contrast",
        /*border_mode*/
        x[5] === "contrast"
      ), vn(e, "hide-container", !/*explicit_call*/
      x[8] && !/*container*/
      x[9]), T & /*height*/
      1 && Fe(
        e,
        "height",
        /*get_dimension*/
        x[15](
          /*height*/
          x[0]
        )
      ), T & /*width*/
      2 && Fe(e, "width", typeof /*width*/
      x[1] == "number" ? `calc(min(${/*width*/
      x[1]}px, 100%))` : (
        /*get_dimension*/
        x[15](
          /*width*/
          x[1]
        )
      )), T & /*variant*/
      16 && Fe(
        e,
        "border-style",
        /*variant*/
        x[4]
      ), T & /*allow_overflow*/
      2048 && Fe(
        e,
        "overflow",
        /*allow_overflow*/
        x[11] ? "visible" : "hidden"
      ), T & /*scale*/
      4096 && Fe(
        e,
        "flex-grow",
        /*scale*/
        x[12]
      ), T & /*min_width*/
      8192 && Fe(e, "min-width", `calc(min(${/*min_width*/
      x[13]}px, 100%))`);
    },
    i(x) {
      a || (kh(g, x), a = !0);
    },
    o(x) {
      Oh(g, x), a = !1;
    },
    d(x) {
      x && T0(e), g && g.d(x);
    }
  };
}
function I0(t) {
  let e, n = (
    /*tag*/
    t[14] && j0(t)
  );
  return {
    c() {
      n && n.c();
    },
    m(a, p) {
      n && n.m(a, p), e = !0;
    },
    p(a, [p]) {
      /*tag*/
      a[14] && n.p(a, p);
    },
    i(a) {
      e || (kh(n, a), e = !0);
    },
    o(a) {
      Oh(n, a), e = !1;
    },
    d(a) {
      n && n.d(a);
    }
  };
}
function F0(t, e, n) {
  let { $$slots: a = {}, $$scope: p } = e, { height: g = void 0 } = e, { width: _ = void 0 } = e, { elem_id: w = "" } = e, { elem_classes: x = [] } = e, { variant: T = "solid" } = e, { border_mode: L = "base" } = e, { padding: X = !0 } = e, { type: G = "normal" } = e, { test_id: J = void 0 } = e, { explicit_call: et = !1 } = e, { container: rt = !0 } = e, { visible: vt = !0 } = e, { allow_overflow: Y = !0 } = e, { scale: j = null } = e, { min_width: P = 0 } = e, $ = G === "fieldset" ? "fieldset" : "div";
  const ht = (it) => {
    if (it !== void 0) {
      if (typeof it == "number")
        return it + "px";
      if (typeof it == "string")
        return it;
    }
  };
  return t.$$set = (it) => {
    "height" in it && n(0, g = it.height), "width" in it && n(1, _ = it.width), "elem_id" in it && n(2, w = it.elem_id), "elem_classes" in it && n(3, x = it.elem_classes), "variant" in it && n(4, T = it.variant), "border_mode" in it && n(5, L = it.border_mode), "padding" in it && n(6, X = it.padding), "type" in it && n(16, G = it.type), "test_id" in it && n(7, J = it.test_id), "explicit_call" in it && n(8, et = it.explicit_call), "container" in it && n(9, rt = it.container), "visible" in it && n(10, vt = it.visible), "allow_overflow" in it && n(11, Y = it.allow_overflow), "scale" in it && n(12, j = it.scale), "min_width" in it && n(13, P = it.min_width), "$$scope" in it && n(17, p = it.$$scope);
  }, [
    g,
    _,
    w,
    x,
    T,
    L,
    X,
    J,
    et,
    rt,
    vt,
    Y,
    j,
    P,
    $,
    ht,
    G,
    p,
    a
  ];
}
class R0 extends C0 {
  constructor(e) {
    super(), P0(this, e, F0, I0, D0, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: B0,
  append: Os,
  attr: An,
  bubble: N0,
  create_component: U0,
  destroy_component: z0,
  detach: Mh,
  element: Ms,
  init: W0,
  insert: Ph,
  listen: X0,
  mount_component: Y0,
  safe_not_equal: G0,
  set_data: H0,
  set_style: Di,
  space: V0,
  text: Z0,
  toggle_class: Oe,
  transition_in: q0,
  transition_out: K0
} = window.__gradio__svelte__internal;
function kc(t) {
  let e, n;
  return {
    c() {
      e = Ms("span"), n = Z0(
        /*label*/
        t[1]
      ), An(e, "class", "svelte-1lrphxw");
    },
    m(a, p) {
      Ph(a, e, p), Os(e, n);
    },
    p(a, p) {
      p & /*label*/
      2 && H0(
        n,
        /*label*/
        a[1]
      );
    },
    d(a) {
      a && Mh(e);
    }
  };
}
function Q0(t) {
  let e, n, a, p, g, _, w, x = (
    /*show_label*/
    t[2] && kc(t)
  );
  return p = new /*Icon*/
  t[0]({}), {
    c() {
      e = Ms("button"), x && x.c(), n = V0(), a = Ms("div"), U0(p.$$.fragment), An(a, "class", "svelte-1lrphxw"), Oe(
        a,
        "small",
        /*size*/
        t[4] === "small"
      ), Oe(
        a,
        "large",
        /*size*/
        t[4] === "large"
      ), Oe(
        a,
        "medium",
        /*size*/
        t[4] === "medium"
      ), e.disabled = /*disabled*/
      t[7], An(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), An(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), An(
        e,
        "title",
        /*label*/
        t[1]
      ), An(e, "class", "svelte-1lrphxw"), Oe(
        e,
        "pending",
        /*pending*/
        t[3]
      ), Oe(
        e,
        "padded",
        /*padded*/
        t[5]
      ), Oe(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), Oe(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), Di(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[12] ? (
        /*_color*/
        t[12]
      ) : "var(--block-label-text-color)"), Di(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      )), Di(
        e,
        "margin-left",
        /*offset*/
        t[11] + "px"
      );
    },
    m(T, L) {
      Ph(T, e, L), x && x.m(e, null), Os(e, n), Os(e, a), Y0(p, a, null), g = !0, _ || (w = X0(
        e,
        "click",
        /*click_handler*/
        t[14]
      ), _ = !0);
    },
    p(T, [L]) {
      /*show_label*/
      T[2] ? x ? x.p(T, L) : (x = kc(T), x.c(), x.m(e, n)) : x && (x.d(1), x = null), (!g || L & /*size*/
      16) && Oe(
        a,
        "small",
        /*size*/
        T[4] === "small"
      ), (!g || L & /*size*/
      16) && Oe(
        a,
        "large",
        /*size*/
        T[4] === "large"
      ), (!g || L & /*size*/
      16) && Oe(
        a,
        "medium",
        /*size*/
        T[4] === "medium"
      ), (!g || L & /*disabled*/
      128) && (e.disabled = /*disabled*/
      T[7]), (!g || L & /*label*/
      2) && An(
        e,
        "aria-label",
        /*label*/
        T[1]
      ), (!g || L & /*hasPopup*/
      256) && An(
        e,
        "aria-haspopup",
        /*hasPopup*/
        T[8]
      ), (!g || L & /*label*/
      2) && An(
        e,
        "title",
        /*label*/
        T[1]
      ), (!g || L & /*pending*/
      8) && Oe(
        e,
        "pending",
        /*pending*/
        T[3]
      ), (!g || L & /*padded*/
      32) && Oe(
        e,
        "padded",
        /*padded*/
        T[5]
      ), (!g || L & /*highlight*/
      64) && Oe(
        e,
        "highlight",
        /*highlight*/
        T[6]
      ), (!g || L & /*transparent*/
      512) && Oe(
        e,
        "transparent",
        /*transparent*/
        T[9]
      ), L & /*disabled, _color*/
      4224 && Di(e, "color", !/*disabled*/
      T[7] && /*_color*/
      T[12] ? (
        /*_color*/
        T[12]
      ) : "var(--block-label-text-color)"), L & /*disabled, background*/
      1152 && Di(e, "--bg-color", /*disabled*/
      T[7] ? "auto" : (
        /*background*/
        T[10]
      )), L & /*offset*/
      2048 && Di(
        e,
        "margin-left",
        /*offset*/
        T[11] + "px"
      );
    },
    i(T) {
      g || (q0(p.$$.fragment, T), g = !0);
    },
    o(T) {
      K0(p.$$.fragment, T), g = !1;
    },
    d(T) {
      T && Mh(e), x && x.d(), z0(p), _ = !1, w();
    }
  };
}
function J0(t, e, n) {
  let a, { Icon: p } = e, { label: g = "" } = e, { show_label: _ = !1 } = e, { pending: w = !1 } = e, { size: x = "small" } = e, { padded: T = !0 } = e, { highlight: L = !1 } = e, { disabled: X = !1 } = e, { hasPopup: G = !1 } = e, { color: J = "var(--block-label-text-color)" } = e, { transparent: et = !1 } = e, { background: rt = "var(--background-fill-primary)" } = e, { offset: vt = 0 } = e;
  function Y(j) {
    N0.call(this, t, j);
  }
  return t.$$set = (j) => {
    "Icon" in j && n(0, p = j.Icon), "label" in j && n(1, g = j.label), "show_label" in j && n(2, _ = j.show_label), "pending" in j && n(3, w = j.pending), "size" in j && n(4, x = j.size), "padded" in j && n(5, T = j.padded), "highlight" in j && n(6, L = j.highlight), "disabled" in j && n(7, X = j.disabled), "hasPopup" in j && n(8, G = j.hasPopup), "color" in j && n(13, J = j.color), "transparent" in j && n(9, et = j.transparent), "background" in j && n(10, rt = j.background), "offset" in j && n(11, vt = j.offset);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    8256 && n(12, a = L ? "var(--color-accent)" : J);
  }, [
    p,
    g,
    _,
    w,
    x,
    T,
    L,
    X,
    G,
    et,
    rt,
    vt,
    a,
    J,
    Y
  ];
}
class $0 extends B0 {
  constructor(e) {
    super(), W0(this, e, J0, Q0, G0, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      offset: 11
    });
  }
}
const {
  SvelteComponent: tp,
  append: Ha,
  attr: nn,
  detach: ep,
  init: np,
  insert: ip,
  noop: Va,
  safe_not_equal: rp,
  set_style: yn,
  svg_element: po
} = window.__gradio__svelte__internal;
function op(t) {
  let e, n, a, p;
  return {
    c() {
      e = po("svg"), n = po("g"), a = po("path"), p = po("path"), nn(a, "d", "M18,6L6.087,17.913"), yn(a, "fill", "none"), yn(a, "fill-rule", "nonzero"), yn(a, "stroke-width", "2px"), nn(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), nn(p, "d", "M4.364,4.364L19.636,19.636"), yn(p, "fill", "none"), yn(p, "fill-rule", "nonzero"), yn(p, "stroke-width", "2px"), nn(e, "width", "100%"), nn(e, "height", "100%"), nn(e, "viewBox", "0 0 24 24"), nn(e, "version", "1.1"), nn(e, "xmlns", "http://www.w3.org/2000/svg"), nn(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), nn(e, "xml:space", "preserve"), nn(e, "stroke", "currentColor"), yn(e, "fill-rule", "evenodd"), yn(e, "clip-rule", "evenodd"), yn(e, "stroke-linecap", "round"), yn(e, "stroke-linejoin", "round");
    },
    m(g, _) {
      ip(g, e, _), Ha(e, n), Ha(n, a), Ha(e, p);
    },
    p: Va,
    i: Va,
    o: Va,
    d(g) {
      g && ep(e);
    }
  };
}
class ap extends tp {
  constructor(e) {
    super(), np(this, e, null, op, rp, {});
  }
}
const sp = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Oc = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
sp.reduce(
  (t, { color: e, primary: n, secondary: a }) => ({
    ...t,
    [e]: {
      primary: Oc[e][n],
      secondary: Oc[e][a]
    }
  }),
  {}
);
function Ii(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let a = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + a;
}
function Uo() {
}
function lp(t, e) {
  return t != t ? e == e : t !== e || t && typeof t == "object" || typeof t == "function";
}
const Ah = typeof window < "u";
let Mc = Ah ? () => window.performance.now() : () => Date.now(), Dh = Ah ? (t) => requestAnimationFrame(t) : Uo;
const Zi = /* @__PURE__ */ new Set();
function Lh(t) {
  Zi.forEach((e) => {
    e.c(t) || (Zi.delete(e), e.f());
  }), Zi.size !== 0 && Dh(Lh);
}
function cp(t) {
  let e;
  return Zi.size === 0 && Dh(Lh), {
    promise: new Promise((n) => {
      Zi.add(e = { c: t, f: n });
    }),
    abort() {
      Zi.delete(e);
    }
  };
}
const Li = [];
function up(t, e = Uo) {
  let n;
  const a = /* @__PURE__ */ new Set();
  function p(w) {
    if (lp(t, w) && (t = w, n)) {
      const x = !Li.length;
      for (const T of a)
        T[1](), Li.push(T, t);
      if (x) {
        for (let T = 0; T < Li.length; T += 2)
          Li[T][0](Li[T + 1]);
        Li.length = 0;
      }
    }
  }
  function g(w) {
    p(w(t));
  }
  function _(w, x = Uo) {
    const T = [w, x];
    return a.add(T), a.size === 1 && (n = e(p, g) || Uo), w(t), () => {
      a.delete(T), a.size === 0 && n && (n(), n = null);
    };
  }
  return { set: p, update: g, subscribe: _ };
}
function Pc(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Ps(t, e, n, a) {
  if (typeof n == "number" || Pc(n)) {
    const p = a - n, g = (n - e) / (t.dt || 1 / 60), _ = t.opts.stiffness * p, w = t.opts.damping * g, x = (_ - w) * t.inv_mass, T = (g + x) * t.dt;
    return Math.abs(T) < t.opts.precision && Math.abs(p) < t.opts.precision ? a : (t.settled = !1, Pc(n) ? new Date(n.getTime() + T) : n + T);
  } else {
    if (Array.isArray(n))
      return n.map(
        (p, g) => Ps(t, e[g], n[g], a[g])
      );
    if (typeof n == "object") {
      const p = {};
      for (const g in n)
        p[g] = Ps(t, e[g], n[g], a[g]);
      return p;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Ac(t, e = {}) {
  const n = up(t), { stiffness: a = 0.15, damping: p = 0.8, precision: g = 0.01 } = e;
  let _, w, x, T = t, L = t, X = 1, G = 0, J = !1;
  function et(vt, Y = {}) {
    L = vt;
    const j = x = {};
    return t == null || Y.hard || rt.stiffness >= 1 && rt.damping >= 1 ? (J = !0, _ = Mc(), T = vt, n.set(t = L), Promise.resolve()) : (Y.soft && (G = 1 / ((Y.soft === !0 ? 0.5 : +Y.soft) * 60), X = 0), w || (_ = Mc(), J = !1, w = cp((P) => {
      if (J)
        return J = !1, w = null, !1;
      X = Math.min(X + G, 1);
      const $ = {
        inv_mass: X,
        opts: rt,
        settled: !0,
        dt: (P - _) * 60 / 1e3
      }, ht = Ps($, T, t, L);
      return _ = P, T = t, n.set(t = ht), $.settled && (w = null), !$.settled;
    })), new Promise((P) => {
      w.promise.then(() => {
        j === x && P();
      });
    }));
  }
  const rt = {
    set: et,
    update: (vt, Y) => et(vt(L, t), Y),
    subscribe: n.subscribe,
    stiffness: a,
    damping: p,
    precision: g
  };
  return rt;
}
const {
  SvelteComponent: hp,
  append: rn,
  attr: Bt,
  component_subscribe: Dc,
  detach: fp,
  element: dp,
  init: pp,
  insert: gp,
  noop: Lc,
  safe_not_equal: mp,
  set_style: go,
  svg_element: on,
  toggle_class: jc
} = window.__gradio__svelte__internal, { onMount: vp } = window.__gradio__svelte__internal;
function yp(t) {
  let e, n, a, p, g, _, w, x, T, L, X, G;
  return {
    c() {
      e = dp("div"), n = on("svg"), a = on("g"), p = on("path"), g = on("path"), _ = on("path"), w = on("path"), x = on("g"), T = on("path"), L = on("path"), X = on("path"), G = on("path"), Bt(p, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Bt(p, "fill", "#FF7C00"), Bt(p, "fill-opacity", "0.4"), Bt(p, "class", "svelte-43sxxs"), Bt(g, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Bt(g, "fill", "#FF7C00"), Bt(g, "class", "svelte-43sxxs"), Bt(_, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Bt(_, "fill", "#FF7C00"), Bt(_, "fill-opacity", "0.4"), Bt(_, "class", "svelte-43sxxs"), Bt(w, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Bt(w, "fill", "#FF7C00"), Bt(w, "class", "svelte-43sxxs"), go(a, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), Bt(T, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Bt(T, "fill", "#FF7C00"), Bt(T, "fill-opacity", "0.4"), Bt(T, "class", "svelte-43sxxs"), Bt(L, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Bt(L, "fill", "#FF7C00"), Bt(L, "class", "svelte-43sxxs"), Bt(X, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Bt(X, "fill", "#FF7C00"), Bt(X, "fill-opacity", "0.4"), Bt(X, "class", "svelte-43sxxs"), Bt(G, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Bt(G, "fill", "#FF7C00"), Bt(G, "class", "svelte-43sxxs"), go(x, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), Bt(n, "viewBox", "-1200 -1200 3000 3000"), Bt(n, "fill", "none"), Bt(n, "xmlns", "http://www.w3.org/2000/svg"), Bt(n, "class", "svelte-43sxxs"), Bt(e, "class", "svelte-43sxxs"), jc(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(J, et) {
      gp(J, e, et), rn(e, n), rn(n, a), rn(a, p), rn(a, g), rn(a, _), rn(a, w), rn(n, x), rn(x, T), rn(x, L), rn(x, X), rn(x, G);
    },
    p(J, [et]) {
      et & /*$top*/
      2 && go(a, "transform", "translate(" + /*$top*/
      J[1][0] + "px, " + /*$top*/
      J[1][1] + "px)"), et & /*$bottom*/
      4 && go(x, "transform", "translate(" + /*$bottom*/
      J[2][0] + "px, " + /*$bottom*/
      J[2][1] + "px)"), et & /*margin*/
      1 && jc(
        e,
        "margin",
        /*margin*/
        J[0]
      );
    },
    i: Lc,
    o: Lc,
    d(J) {
      J && fp(e);
    }
  };
}
function _p(t, e, n) {
  let a, p;
  var g = this && this.__awaiter || function(J, et, rt, vt) {
    function Y(j) {
      return j instanceof rt ? j : new rt(function(P) {
        P(j);
      });
    }
    return new (rt || (rt = Promise))(function(j, P) {
      function $(dt) {
        try {
          it(vt.next(dt));
        } catch (v) {
          P(v);
        }
      }
      function ht(dt) {
        try {
          it(vt.throw(dt));
        } catch (v) {
          P(v);
        }
      }
      function it(dt) {
        dt.done ? j(dt.value) : Y(dt.value).then($, ht);
      }
      it((vt = vt.apply(J, et || [])).next());
    });
  };
  let { margin: _ = !0 } = e;
  const w = Ac([0, 0]);
  Dc(t, w, (J) => n(1, a = J));
  const x = Ac([0, 0]);
  Dc(t, x, (J) => n(2, p = J));
  let T;
  function L() {
    return g(this, void 0, void 0, function* () {
      yield Promise.all([w.set([125, 140]), x.set([-125, -140])]), yield Promise.all([w.set([-125, 140]), x.set([125, -140])]), yield Promise.all([w.set([-125, 0]), x.set([125, -0])]), yield Promise.all([w.set([125, 0]), x.set([-125, 0])]);
    });
  }
  function X() {
    return g(this, void 0, void 0, function* () {
      yield L(), T || X();
    });
  }
  function G() {
    return g(this, void 0, void 0, function* () {
      yield Promise.all([w.set([125, 0]), x.set([-125, 0])]), X();
    });
  }
  return vp(() => (G(), () => T = !0)), t.$$set = (J) => {
    "margin" in J && n(0, _ = J.margin);
  }, [_, a, p, w, x];
}
class bp extends hp {
  constructor(e) {
    super(), pp(this, e, _p, yp, mp, { margin: 0 });
  }
}
const {
  SvelteComponent: wp,
  append: vi,
  attr: fn,
  binding_callbacks: Ic,
  check_outros: As,
  create_component: jh,
  create_slot: Ih,
  destroy_component: Fh,
  destroy_each: Rh,
  detach: At,
  element: Sn,
  empty: lr,
  ensure_array_like: ta,
  get_all_dirty_from_scope: Bh,
  get_slot_changes: Nh,
  group_outros: Ds,
  init: Cp,
  insert: Dt,
  mount_component: Uh,
  noop: Ls,
  safe_not_equal: xp,
  set_data: Je,
  set_style: qn,
  space: qe,
  text: Qt,
  toggle_class: He,
  transition_in: hn,
  transition_out: Tn,
  update_slot_base: zh
} = window.__gradio__svelte__internal, { tick: Sp } = window.__gradio__svelte__internal, { onDestroy: Tp } = window.__gradio__svelte__internal, { createEventDispatcher: Ep } = window.__gradio__svelte__internal, kp = (t) => ({}), Fc = (t) => ({}), Op = (t) => ({}), Rc = (t) => ({});
function Bc(t, e, n) {
  const a = t.slice();
  return a[41] = e[n], a[43] = n, a;
}
function Nc(t, e, n) {
  const a = t.slice();
  return a[41] = e[n], a;
}
function Mp(t) {
  let e, n, a, p, g = (
    /*i18n*/
    t[1]("common.error") + ""
  ), _, w, x;
  n = new $0({
    props: {
      Icon: ap,
      label: (
        /*i18n*/
        t[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    t[32]
  );
  const T = (
    /*#slots*/
    t[30].error
  ), L = Ih(
    T,
    t,
    /*$$scope*/
    t[29],
    Fc
  );
  return {
    c() {
      e = Sn("div"), jh(n.$$.fragment), a = qe(), p = Sn("span"), _ = Qt(g), w = qe(), L && L.c(), fn(e, "class", "clear-status svelte-v0wucf"), fn(p, "class", "error svelte-v0wucf");
    },
    m(X, G) {
      Dt(X, e, G), Uh(n, e, null), Dt(X, a, G), Dt(X, p, G), vi(p, _), Dt(X, w, G), L && L.m(X, G), x = !0;
    },
    p(X, G) {
      const J = {};
      G[0] & /*i18n*/
      2 && (J.label = /*i18n*/
      X[1]("common.clear")), n.$set(J), (!x || G[0] & /*i18n*/
      2) && g !== (g = /*i18n*/
      X[1]("common.error") + "") && Je(_, g), L && L.p && (!x || G[0] & /*$$scope*/
      536870912) && zh(
        L,
        T,
        X,
        /*$$scope*/
        X[29],
        x ? Nh(
          T,
          /*$$scope*/
          X[29],
          G,
          kp
        ) : Bh(
          /*$$scope*/
          X[29]
        ),
        Fc
      );
    },
    i(X) {
      x || (hn(n.$$.fragment, X), hn(L, X), x = !0);
    },
    o(X) {
      Tn(n.$$.fragment, X), Tn(L, X), x = !1;
    },
    d(X) {
      X && (At(e), At(a), At(p), At(w)), Fh(n), L && L.d(X);
    }
  };
}
function Pp(t) {
  let e, n, a, p, g, _, w, x, T, L = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && Uc(t)
  );
  function X(P, $) {
    if (
      /*progress*/
      P[7]
    ) return Lp;
    if (
      /*queue_position*/
      P[2] !== null && /*queue_size*/
      P[3] !== void 0 && /*queue_position*/
      P[2] >= 0
    ) return Dp;
    if (
      /*queue_position*/
      P[2] === 0
    ) return Ap;
  }
  let G = X(t), J = G && G(t), et = (
    /*timer*/
    t[5] && Xc(t)
  );
  const rt = [Rp, Fp], vt = [];
  function Y(P, $) {
    return (
      /*last_progress_level*/
      P[15] != null ? 0 : (
        /*show_progress*/
        P[6] === "full" ? 1 : -1
      )
    );
  }
  ~(g = Y(t)) && (_ = vt[g] = rt[g](t));
  let j = !/*timer*/
  t[5] && Kc(t);
  return {
    c() {
      L && L.c(), e = qe(), n = Sn("div"), J && J.c(), a = qe(), et && et.c(), p = qe(), _ && _.c(), w = qe(), j && j.c(), x = lr(), fn(n, "class", "progress-text svelte-v0wucf"), He(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), He(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(P, $) {
      L && L.m(P, $), Dt(P, e, $), Dt(P, n, $), J && J.m(n, null), vi(n, a), et && et.m(n, null), Dt(P, p, $), ~g && vt[g].m(P, $), Dt(P, w, $), j && j.m(P, $), Dt(P, x, $), T = !0;
    },
    p(P, $) {
      /*variant*/
      P[8] === "default" && /*show_eta_bar*/
      P[18] && /*show_progress*/
      P[6] === "full" ? L ? L.p(P, $) : (L = Uc(P), L.c(), L.m(e.parentNode, e)) : L && (L.d(1), L = null), G === (G = X(P)) && J ? J.p(P, $) : (J && J.d(1), J = G && G(P), J && (J.c(), J.m(n, a))), /*timer*/
      P[5] ? et ? et.p(P, $) : (et = Xc(P), et.c(), et.m(n, null)) : et && (et.d(1), et = null), (!T || $[0] & /*variant*/
      256) && He(
        n,
        "meta-text-center",
        /*variant*/
        P[8] === "center"
      ), (!T || $[0] & /*variant*/
      256) && He(
        n,
        "meta-text",
        /*variant*/
        P[8] === "default"
      );
      let ht = g;
      g = Y(P), g === ht ? ~g && vt[g].p(P, $) : (_ && (Ds(), Tn(vt[ht], 1, 1, () => {
        vt[ht] = null;
      }), As()), ~g ? (_ = vt[g], _ ? _.p(P, $) : (_ = vt[g] = rt[g](P), _.c()), hn(_, 1), _.m(w.parentNode, w)) : _ = null), /*timer*/
      P[5] ? j && (Ds(), Tn(j, 1, 1, () => {
        j = null;
      }), As()) : j ? (j.p(P, $), $[0] & /*timer*/
      32 && hn(j, 1)) : (j = Kc(P), j.c(), hn(j, 1), j.m(x.parentNode, x));
    },
    i(P) {
      T || (hn(_), hn(j), T = !0);
    },
    o(P) {
      Tn(_), Tn(j), T = !1;
    },
    d(P) {
      P && (At(e), At(n), At(p), At(w), At(x)), L && L.d(P), J && J.d(), et && et.d(), ~g && vt[g].d(P), j && j.d(P);
    }
  };
}
function Uc(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Sn("div"), fn(e, "class", "eta-bar svelte-v0wucf"), qn(e, "transform", n);
    },
    m(a, p) {
      Dt(a, e, p);
    },
    p(a, p) {
      p[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (a[17] || 0) * 100 - 100}%)`) && qn(e, "transform", n);
    },
    d(a) {
      a && At(e);
    }
  };
}
function Ap(t) {
  let e;
  return {
    c() {
      e = Qt("processing |");
    },
    m(n, a) {
      Dt(n, e, a);
    },
    p: Ls,
    d(n) {
      n && At(e);
    }
  };
}
function Dp(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), a, p, g, _;
  return {
    c() {
      e = Qt("queue: "), a = Qt(n), p = Qt("/"), g = Qt(
        /*queue_size*/
        t[3]
      ), _ = Qt(" |");
    },
    m(w, x) {
      Dt(w, e, x), Dt(w, a, x), Dt(w, p, x), Dt(w, g, x), Dt(w, _, x);
    },
    p(w, x) {
      x[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      w[2] + 1 + "") && Je(a, n), x[0] & /*queue_size*/
      8 && Je(
        g,
        /*queue_size*/
        w[3]
      );
    },
    d(w) {
      w && (At(e), At(a), At(p), At(g), At(_));
    }
  };
}
function Lp(t) {
  let e, n = ta(
    /*progress*/
    t[7]
  ), a = [];
  for (let p = 0; p < n.length; p += 1)
    a[p] = Wc(Nc(t, n, p));
  return {
    c() {
      for (let p = 0; p < a.length; p += 1)
        a[p].c();
      e = lr();
    },
    m(p, g) {
      for (let _ = 0; _ < a.length; _ += 1)
        a[_] && a[_].m(p, g);
      Dt(p, e, g);
    },
    p(p, g) {
      if (g[0] & /*progress*/
      128) {
        n = ta(
          /*progress*/
          p[7]
        );
        let _;
        for (_ = 0; _ < n.length; _ += 1) {
          const w = Nc(p, n, _);
          a[_] ? a[_].p(w, g) : (a[_] = Wc(w), a[_].c(), a[_].m(e.parentNode, e));
        }
        for (; _ < a.length; _ += 1)
          a[_].d(1);
        a.length = n.length;
      }
    },
    d(p) {
      p && At(e), Rh(a, p);
    }
  };
}
function zc(t) {
  let e, n = (
    /*p*/
    t[41].unit + ""
  ), a, p, g = " ", _;
  function w(L, X) {
    return (
      /*p*/
      L[41].length != null ? Ip : jp
    );
  }
  let x = w(t), T = x(t);
  return {
    c() {
      T.c(), e = qe(), a = Qt(n), p = Qt(" | "), _ = Qt(g);
    },
    m(L, X) {
      T.m(L, X), Dt(L, e, X), Dt(L, a, X), Dt(L, p, X), Dt(L, _, X);
    },
    p(L, X) {
      x === (x = w(L)) && T ? T.p(L, X) : (T.d(1), T = x(L), T && (T.c(), T.m(e.parentNode, e))), X[0] & /*progress*/
      128 && n !== (n = /*p*/
      L[41].unit + "") && Je(a, n);
    },
    d(L) {
      L && (At(e), At(a), At(p), At(_)), T.d(L);
    }
  };
}
function jp(t) {
  let e = Ii(
    /*p*/
    t[41].index || 0
  ) + "", n;
  return {
    c() {
      n = Qt(e);
    },
    m(a, p) {
      Dt(a, n, p);
    },
    p(a, p) {
      p[0] & /*progress*/
      128 && e !== (e = Ii(
        /*p*/
        a[41].index || 0
      ) + "") && Je(n, e);
    },
    d(a) {
      a && At(n);
    }
  };
}
function Ip(t) {
  let e = Ii(
    /*p*/
    t[41].index || 0
  ) + "", n, a, p = Ii(
    /*p*/
    t[41].length
  ) + "", g;
  return {
    c() {
      n = Qt(e), a = Qt("/"), g = Qt(p);
    },
    m(_, w) {
      Dt(_, n, w), Dt(_, a, w), Dt(_, g, w);
    },
    p(_, w) {
      w[0] & /*progress*/
      128 && e !== (e = Ii(
        /*p*/
        _[41].index || 0
      ) + "") && Je(n, e), w[0] & /*progress*/
      128 && p !== (p = Ii(
        /*p*/
        _[41].length
      ) + "") && Je(g, p);
    },
    d(_) {
      _ && (At(n), At(a), At(g));
    }
  };
}
function Wc(t) {
  let e, n = (
    /*p*/
    t[41].index != null && zc(t)
  );
  return {
    c() {
      n && n.c(), e = lr();
    },
    m(a, p) {
      n && n.m(a, p), Dt(a, e, p);
    },
    p(a, p) {
      /*p*/
      a[41].index != null ? n ? n.p(a, p) : (n = zc(a), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(a) {
      a && At(e), n && n.d(a);
    }
  };
}
function Xc(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), a, p;
  return {
    c() {
      e = Qt(
        /*formatted_timer*/
        t[20]
      ), a = Qt(n), p = Qt("s");
    },
    m(g, _) {
      Dt(g, e, _), Dt(g, a, _), Dt(g, p, _);
    },
    p(g, _) {
      _[0] & /*formatted_timer*/
      1048576 && Je(
        e,
        /*formatted_timer*/
        g[20]
      ), _[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      g[0] ? `/${/*formatted_eta*/
      g[19]}` : "") && Je(a, n);
    },
    d(g) {
      g && (At(e), At(a), At(p));
    }
  };
}
function Fp(t) {
  let e, n;
  return e = new bp({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      jh(e.$$.fragment);
    },
    m(a, p) {
      Uh(e, a, p), n = !0;
    },
    p(a, p) {
      const g = {};
      p[0] & /*variant*/
      256 && (g.margin = /*variant*/
      a[8] === "default"), e.$set(g);
    },
    i(a) {
      n || (hn(e.$$.fragment, a), n = !0);
    },
    o(a) {
      Tn(e.$$.fragment, a), n = !1;
    },
    d(a) {
      Fh(e, a);
    }
  };
}
function Rp(t) {
  let e, n, a, p, g, _ = `${/*last_progress_level*/
  t[15] * 100}%`, w = (
    /*progress*/
    t[7] != null && Yc(t)
  );
  return {
    c() {
      e = Sn("div"), n = Sn("div"), w && w.c(), a = qe(), p = Sn("div"), g = Sn("div"), fn(n, "class", "progress-level-inner svelte-v0wucf"), fn(g, "class", "progress-bar svelte-v0wucf"), qn(g, "width", _), fn(p, "class", "progress-bar-wrap svelte-v0wucf"), fn(e, "class", "progress-level svelte-v0wucf");
    },
    m(x, T) {
      Dt(x, e, T), vi(e, n), w && w.m(n, null), vi(e, a), vi(e, p), vi(p, g), t[31](g);
    },
    p(x, T) {
      /*progress*/
      x[7] != null ? w ? w.p(x, T) : (w = Yc(x), w.c(), w.m(n, null)) : w && (w.d(1), w = null), T[0] & /*last_progress_level*/
      32768 && _ !== (_ = `${/*last_progress_level*/
      x[15] * 100}%`) && qn(g, "width", _);
    },
    i: Ls,
    o: Ls,
    d(x) {
      x && At(e), w && w.d(), t[31](null);
    }
  };
}
function Yc(t) {
  let e, n = ta(
    /*progress*/
    t[7]
  ), a = [];
  for (let p = 0; p < n.length; p += 1)
    a[p] = qc(Bc(t, n, p));
  return {
    c() {
      for (let p = 0; p < a.length; p += 1)
        a[p].c();
      e = lr();
    },
    m(p, g) {
      for (let _ = 0; _ < a.length; _ += 1)
        a[_] && a[_].m(p, g);
      Dt(p, e, g);
    },
    p(p, g) {
      if (g[0] & /*progress_level, progress*/
      16512) {
        n = ta(
          /*progress*/
          p[7]
        );
        let _;
        for (_ = 0; _ < n.length; _ += 1) {
          const w = Bc(p, n, _);
          a[_] ? a[_].p(w, g) : (a[_] = qc(w), a[_].c(), a[_].m(e.parentNode, e));
        }
        for (; _ < a.length; _ += 1)
          a[_].d(1);
        a.length = n.length;
      }
    },
    d(p) {
      p && At(e), Rh(a, p);
    }
  };
}
function Gc(t) {
  let e, n, a, p, g = (
    /*i*/
    t[43] !== 0 && Bp()
  ), _ = (
    /*p*/
    t[41].desc != null && Hc(t)
  ), w = (
    /*p*/
    t[41].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[43]
    ] != null && Vc()
  ), x = (
    /*progress_level*/
    t[14] != null && Zc(t)
  );
  return {
    c() {
      g && g.c(), e = qe(), _ && _.c(), n = qe(), w && w.c(), a = qe(), x && x.c(), p = lr();
    },
    m(T, L) {
      g && g.m(T, L), Dt(T, e, L), _ && _.m(T, L), Dt(T, n, L), w && w.m(T, L), Dt(T, a, L), x && x.m(T, L), Dt(T, p, L);
    },
    p(T, L) {
      /*p*/
      T[41].desc != null ? _ ? _.p(T, L) : (_ = Hc(T), _.c(), _.m(n.parentNode, n)) : _ && (_.d(1), _ = null), /*p*/
      T[41].desc != null && /*progress_level*/
      T[14] && /*progress_level*/
      T[14][
        /*i*/
        T[43]
      ] != null ? w || (w = Vc(), w.c(), w.m(a.parentNode, a)) : w && (w.d(1), w = null), /*progress_level*/
      T[14] != null ? x ? x.p(T, L) : (x = Zc(T), x.c(), x.m(p.parentNode, p)) : x && (x.d(1), x = null);
    },
    d(T) {
      T && (At(e), At(n), At(a), At(p)), g && g.d(T), _ && _.d(T), w && w.d(T), x && x.d(T);
    }
  };
}
function Bp(t) {
  let e;
  return {
    c() {
      e = Qt(" /");
    },
    m(n, a) {
      Dt(n, e, a);
    },
    d(n) {
      n && At(e);
    }
  };
}
function Hc(t) {
  let e = (
    /*p*/
    t[41].desc + ""
  ), n;
  return {
    c() {
      n = Qt(e);
    },
    m(a, p) {
      Dt(a, n, p);
    },
    p(a, p) {
      p[0] & /*progress*/
      128 && e !== (e = /*p*/
      a[41].desc + "") && Je(n, e);
    },
    d(a) {
      a && At(n);
    }
  };
}
function Vc(t) {
  let e;
  return {
    c() {
      e = Qt("-");
    },
    m(n, a) {
      Dt(n, e, a);
    },
    d(n) {
      n && At(e);
    }
  };
}
function Zc(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[43]
  ] || 0)).toFixed(1) + "", n, a;
  return {
    c() {
      n = Qt(e), a = Qt("%");
    },
    m(p, g) {
      Dt(p, n, g), Dt(p, a, g);
    },
    p(p, g) {
      g[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (p[14][
        /*i*/
        p[43]
      ] || 0)).toFixed(1) + "") && Je(n, e);
    },
    d(p) {
      p && (At(n), At(a));
    }
  };
}
function qc(t) {
  let e, n = (
    /*p*/
    (t[41].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[43]
    ] != null) && Gc(t)
  );
  return {
    c() {
      n && n.c(), e = lr();
    },
    m(a, p) {
      n && n.m(a, p), Dt(a, e, p);
    },
    p(a, p) {
      /*p*/
      a[41].desc != null || /*progress_level*/
      a[14] && /*progress_level*/
      a[14][
        /*i*/
        a[43]
      ] != null ? n ? n.p(a, p) : (n = Gc(a), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(a) {
      a && At(e), n && n.d(a);
    }
  };
}
function Kc(t) {
  let e, n, a, p;
  const g = (
    /*#slots*/
    t[30]["additional-loading-text"]
  ), _ = Ih(
    g,
    t,
    /*$$scope*/
    t[29],
    Rc
  );
  return {
    c() {
      e = Sn("p"), n = Qt(
        /*loading_text*/
        t[9]
      ), a = qe(), _ && _.c(), fn(e, "class", "loading svelte-v0wucf");
    },
    m(w, x) {
      Dt(w, e, x), vi(e, n), Dt(w, a, x), _ && _.m(w, x), p = !0;
    },
    p(w, x) {
      (!p || x[0] & /*loading_text*/
      512) && Je(
        n,
        /*loading_text*/
        w[9]
      ), _ && _.p && (!p || x[0] & /*$$scope*/
      536870912) && zh(
        _,
        g,
        w,
        /*$$scope*/
        w[29],
        p ? Nh(
          g,
          /*$$scope*/
          w[29],
          x,
          Op
        ) : Bh(
          /*$$scope*/
          w[29]
        ),
        Rc
      );
    },
    i(w) {
      p || (hn(_, w), p = !0);
    },
    o(w) {
      Tn(_, w), p = !1;
    },
    d(w) {
      w && (At(e), At(a)), _ && _.d(w);
    }
  };
}
function Np(t) {
  let e, n, a, p, g;
  const _ = [Pp, Mp], w = [];
  function x(T, L) {
    return (
      /*status*/
      T[4] === "pending" ? 0 : (
        /*status*/
        T[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = x(t)) && (a = w[n] = _[n](t)), {
    c() {
      e = Sn("div"), a && a.c(), fn(e, "class", p = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-v0wucf"), He(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden"), He(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), He(
        e,
        "generating",
        /*status*/
        t[4] === "generating" && /*show_progress*/
        t[6] === "full"
      ), He(
        e,
        "border",
        /*border*/
        t[12]
      ), qn(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), qn(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(T, L) {
      Dt(T, e, L), ~n && w[n].m(e, null), t[33](e), g = !0;
    },
    p(T, L) {
      let X = n;
      n = x(T), n === X ? ~n && w[n].p(T, L) : (a && (Ds(), Tn(w[X], 1, 1, () => {
        w[X] = null;
      }), As()), ~n ? (a = w[n], a ? a.p(T, L) : (a = w[n] = _[n](T), a.c()), hn(a, 1), a.m(e, null)) : a = null), (!g || L[0] & /*variant, show_progress*/
      320 && p !== (p = "wrap " + /*variant*/
      T[8] + " " + /*show_progress*/
      T[6] + " svelte-v0wucf")) && fn(e, "class", p), (!g || L[0] & /*variant, show_progress, status, show_progress*/
      336) && He(e, "hide", !/*status*/
      T[4] || /*status*/
      T[4] === "complete" || /*show_progress*/
      T[6] === "hidden"), (!g || L[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && He(
        e,
        "translucent",
        /*variant*/
        T[8] === "center" && /*status*/
        (T[4] === "pending" || /*status*/
        T[4] === "error") || /*translucent*/
        T[11] || /*show_progress*/
        T[6] === "minimal"
      ), (!g || L[0] & /*variant, show_progress, status, show_progress*/
      336) && He(
        e,
        "generating",
        /*status*/
        T[4] === "generating" && /*show_progress*/
        T[6] === "full"
      ), (!g || L[0] & /*variant, show_progress, border*/
      4416) && He(
        e,
        "border",
        /*border*/
        T[12]
      ), L[0] & /*absolute*/
      1024 && qn(
        e,
        "position",
        /*absolute*/
        T[10] ? "absolute" : "static"
      ), L[0] & /*absolute*/
      1024 && qn(
        e,
        "padding",
        /*absolute*/
        T[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(T) {
      g || (hn(a), g = !0);
    },
    o(T) {
      Tn(a), g = !1;
    },
    d(T) {
      T && At(e), ~n && w[n].d(), t[33](null);
    }
  };
}
var Up = function(t, e, n, a) {
  function p(g) {
    return g instanceof n ? g : new n(function(_) {
      _(g);
    });
  }
  return new (n || (n = Promise))(function(g, _) {
    function w(L) {
      try {
        T(a.next(L));
      } catch (X) {
        _(X);
      }
    }
    function x(L) {
      try {
        T(a.throw(L));
      } catch (X) {
        _(X);
      }
    }
    function T(L) {
      L.done ? g(L.value) : p(L.value).then(w, x);
    }
    T((a = a.apply(t, e || [])).next());
  });
};
let mo = [], Za = !1;
function zp(t) {
  return Up(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (mo.push(e), !Za) Za = !0;
      else return;
      yield Sp(), requestAnimationFrame(() => {
        let a = [0, 0];
        for (let p = 0; p < mo.length; p++) {
          const _ = mo[p].getBoundingClientRect();
          (p === 0 || _.top + window.scrollY <= a[0]) && (a[0] = _.top + window.scrollY, a[1] = p);
        }
        window.scrollTo({ top: a[0] - 20, behavior: "smooth" }), Za = !1, mo = [];
      });
    }
  });
}
function Wp(t, e, n) {
  let a, { $$slots: p = {}, $$scope: g } = e;
  this && this.__awaiter;
  const _ = Ep();
  let { i18n: w } = e, { eta: x = null } = e, { queue_position: T } = e, { queue_size: L } = e, { status: X } = e, { scroll_to_output: G = !1 } = e, { timer: J = !0 } = e, { show_progress: et = "full" } = e, { message: rt = null } = e, { progress: vt = null } = e, { variant: Y = "default" } = e, { loading_text: j = "Loading..." } = e, { absolute: P = !0 } = e, { translucent: $ = !1 } = e, { border: ht = !1 } = e, { autoscroll: it } = e, dt, v = !1, Tt = 0, I = 0, Et = null, Xt = null, zt = 0, c = null, o, l = null, f = !0;
  const i = () => {
    n(0, x = n(27, Et = n(19, u = null))), n(25, Tt = performance.now()), n(26, I = 0), v = !0, r();
  };
  function r() {
    requestAnimationFrame(() => {
      n(26, I = (performance.now() - Tt) / 1e3), v && r();
    });
  }
  function s() {
    n(26, I = 0), n(0, x = n(27, Et = n(19, u = null))), v && (v = !1);
  }
  Tp(() => {
    v && s();
  });
  let u = null;
  function h(y) {
    Ic[y ? "unshift" : "push"](() => {
      l = y, n(16, l), n(7, vt), n(14, c), n(15, o);
    });
  }
  const d = () => {
    _("clear_status");
  };
  function m(y) {
    Ic[y ? "unshift" : "push"](() => {
      dt = y, n(13, dt);
    });
  }
  return t.$$set = (y) => {
    "i18n" in y && n(1, w = y.i18n), "eta" in y && n(0, x = y.eta), "queue_position" in y && n(2, T = y.queue_position), "queue_size" in y && n(3, L = y.queue_size), "status" in y && n(4, X = y.status), "scroll_to_output" in y && n(22, G = y.scroll_to_output), "timer" in y && n(5, J = y.timer), "show_progress" in y && n(6, et = y.show_progress), "message" in y && n(23, rt = y.message), "progress" in y && n(7, vt = y.progress), "variant" in y && n(8, Y = y.variant), "loading_text" in y && n(9, j = y.loading_text), "absolute" in y && n(10, P = y.absolute), "translucent" in y && n(11, $ = y.translucent), "border" in y && n(12, ht = y.border), "autoscroll" in y && n(24, it = y.autoscroll), "$$scope" in y && n(29, g = y.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (x === null && n(0, x = Et), x != null && Et !== x && (n(28, Xt = (performance.now() - Tt) / 1e3 + x), n(19, u = Xt.toFixed(1)), n(27, Et = x))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, zt = Xt === null || Xt <= 0 || !I ? null : Math.min(I / Xt, 1)), t.$$.dirty[0] & /*progress*/
    128 && vt != null && n(18, f = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (vt != null ? n(14, c = vt.map((y) => {
      if (y.index != null && y.length != null)
        return y.index / y.length;
      if (y.progress != null)
        return y.progress;
    })) : n(14, c = null), c ? (n(15, o = c[c.length - 1]), l && (o === 0 ? n(16, l.style.transition = "0", l) : n(16, l.style.transition = "150ms", l))) : n(15, o = void 0)), t.$$.dirty[0] & /*status*/
    16 && (X === "pending" ? i() : s()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && dt && G && (X === "pending" || X === "complete") && zp(dt, it), t.$$.dirty[0] & /*status, message*/
    8388624, t.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, a = I.toFixed(1));
  }, [
    x,
    w,
    T,
    L,
    X,
    J,
    et,
    vt,
    Y,
    j,
    P,
    $,
    ht,
    dt,
    c,
    o,
    l,
    zt,
    f,
    u,
    a,
    _,
    G,
    rt,
    it,
    Tt,
    I,
    Et,
    Xt,
    g,
    p,
    h,
    d,
    m
  ];
}
class Xp extends wp {
  constructor(e) {
    super(), Cp(
      this,
      e,
      Wp,
      Np,
      xp,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.1.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.6/LICENSE */
const {
  entries: Wh,
  setPrototypeOf: Qc,
  isFrozen: Yp,
  getPrototypeOf: Gp,
  getOwnPropertyDescriptor: Hp
} = Object;
let {
  freeze: Se,
  seal: $e,
  create: Xh
} = Object, {
  apply: js,
  construct: Is
} = typeof Reflect < "u" && Reflect;
Se || (Se = function(e) {
  return e;
});
$e || ($e = function(e) {
  return e;
});
js || (js = function(e, n, a) {
  return e.apply(n, a);
});
Is || (Is = function(e, n) {
  return new e(...n);
});
const vo = Ue(Array.prototype.forEach), Jc = Ue(Array.prototype.pop), mr = Ue(Array.prototype.push), zo = Ue(String.prototype.toLowerCase), qa = Ue(String.prototype.toString), $c = Ue(String.prototype.match), vr = Ue(String.prototype.replace), Vp = Ue(String.prototype.indexOf), Zp = Ue(String.prototype.trim), sn = Ue(Object.prototype.hasOwnProperty), we = Ue(RegExp.prototype.test), yr = qp(TypeError);
function Ue(t) {
  return function(e) {
    for (var n = arguments.length, a = new Array(n > 1 ? n - 1 : 0), p = 1; p < n; p++)
      a[p - 1] = arguments[p];
    return js(t, e, a);
  };
}
function qp(t) {
  return function() {
    for (var e = arguments.length, n = new Array(e), a = 0; a < e; a++)
      n[a] = arguments[a];
    return Is(t, n);
  };
}
function jt(t, e) {
  let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : zo;
  Qc && Qc(t, null);
  let a = e.length;
  for (; a--; ) {
    let p = e[a];
    if (typeof p == "string") {
      const g = n(p);
      g !== p && (Yp(e) || (e[a] = g), p = g);
    }
    t[p] = !0;
  }
  return t;
}
function Kp(t) {
  for (let e = 0; e < t.length; e++)
    sn(t, e) || (t[e] = null);
  return t;
}
function pi(t) {
  const e = Xh(null);
  for (const [n, a] of Wh(t))
    sn(t, n) && (Array.isArray(a) ? e[n] = Kp(a) : a && typeof a == "object" && a.constructor === Object ? e[n] = pi(a) : e[n] = a);
  return e;
}
function _r(t, e) {
  for (; t !== null; ) {
    const a = Hp(t, e);
    if (a) {
      if (a.get)
        return Ue(a.get);
      if (typeof a.value == "function")
        return Ue(a.value);
    }
    t = Gp(t);
  }
  function n() {
    return null;
  }
  return n;
}
const tu = Se(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Ka = Se(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Qa = Se(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Qp = Se(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ja = Se(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Jp = Se(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), eu = Se(["#text"]), nu = Se(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), $a = Se(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), iu = Se(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), yo = Se(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), $p = $e(/\{\{[\w\W]*|[\w\W]*\}\}/gm), tg = $e(/<%[\w\W]*|[\w\W]*%>/gm), eg = $e(/\${[\w\W]*}/gm), ng = $e(/^data-[\-\w.\u00B7-\uFFFF]/), ig = $e(/^aria-[\-\w]+$/), Yh = $e(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), rg = $e(/^(?:\w+script|data):/i), og = $e(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Gh = $e(/^html$/i), ag = $e(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ru = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: $p,
  ERB_EXPR: tg,
  TMPLIT_EXPR: eg,
  DATA_ATTR: ng,
  ARIA_ATTR: ig,
  IS_ALLOWED_URI: Yh,
  IS_SCRIPT_OR_DATA: rg,
  ATTR_WHITESPACE: og,
  DOCTYPE_NAME: Gh,
  CUSTOM_ELEMENT: ag
});
const br = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, sg = function() {
  return typeof window > "u" ? null : window;
}, lg = function(e, n) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let a = null;
  const p = "data-tt-policy-suffix";
  n && n.hasAttribute(p) && (a = n.getAttribute(p));
  const g = "dompurify" + (a ? "#" + a : "");
  try {
    return e.createPolicy(g, {
      createHTML(_) {
        return _;
      },
      createScriptURL(_) {
        return _;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + g + " could not be created."), null;
  }
};
function Hh() {
  let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : sg();
  const e = (Ct) => Hh(Ct);
  if (e.version = "3.1.6", e.removed = [], !t || !t.document || t.document.nodeType !== br.document)
    return e.isSupported = !1, e;
  let {
    document: n
  } = t;
  const a = n, p = a.currentScript, {
    DocumentFragment: g,
    HTMLTemplateElement: _,
    Node: w,
    Element: x,
    NodeFilter: T,
    NamedNodeMap: L = t.NamedNodeMap || t.MozNamedAttrMap,
    HTMLFormElement: X,
    DOMParser: G,
    trustedTypes: J
  } = t, et = x.prototype, rt = _r(et, "cloneNode"), vt = _r(et, "remove"), Y = _r(et, "nextSibling"), j = _r(et, "childNodes"), P = _r(et, "parentNode");
  if (typeof _ == "function") {
    const Ct = n.createElement("template");
    Ct.content && Ct.content.ownerDocument && (n = Ct.content.ownerDocument);
  }
  let $, ht = "";
  const {
    implementation: it,
    createNodeIterator: dt,
    createDocumentFragment: v,
    getElementsByTagName: Tt
  } = n, {
    importNode: I
  } = a;
  let Et = {};
  e.isSupported = typeof Wh == "function" && typeof P == "function" && it && it.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: Xt,
    ERB_EXPR: zt,
    TMPLIT_EXPR: c,
    DATA_ATTR: o,
    ARIA_ATTR: l,
    IS_SCRIPT_OR_DATA: f,
    ATTR_WHITESPACE: i,
    CUSTOM_ELEMENT: r
  } = ru;
  let {
    IS_ALLOWED_URI: s
  } = ru, u = null;
  const h = jt({}, [...tu, ...Ka, ...Qa, ...Ja, ...eu]);
  let d = null;
  const m = jt({}, [...nu, ...$a, ...iu, ...yo]);
  let y = Object.seal(Xh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), b = null, S = null, E = !0, A = !0, M = !1, C = !0, O = !1, N = !0, z = !1, W = !1, F = !1, k = !1, B = !1, Z = !1, K = !0, U = !1;
  const R = "user-content-";
  let H = !0, q = !1, Q = {}, nt = null;
  const gt = jt({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let ct = null;
  const ft = jt({}, ["audio", "video", "img", "source", "image", "track"]);
  let st = null;
  const lt = jt({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), at = "http://www.w3.org/1998/Math/MathML", yt = "http://www.w3.org/2000/svg", mt = "http://www.w3.org/1999/xhtml";
  let Mt = mt, Ot = !1, Lt = null;
  const re = jt({}, [at, yt, mt], qa);
  let Ut = null;
  const Ft = ["application/xhtml+xml", "text/html"], oe = "text/html";
  let Rt = null, te = null;
  const hi = n.createElement("form"), fr = function(V) {
    return V instanceof RegExp || V instanceof Function;
  }, dr = function() {
    let V = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(te && te === V)) {
      if ((!V || typeof V != "object") && (V = {}), V = pi(V), Ut = // eslint-disable-next-line unicorn/prefer-includes
      Ft.indexOf(V.PARSER_MEDIA_TYPE) === -1 ? oe : V.PARSER_MEDIA_TYPE, Rt = Ut === "application/xhtml+xml" ? qa : zo, u = sn(V, "ALLOWED_TAGS") ? jt({}, V.ALLOWED_TAGS, Rt) : h, d = sn(V, "ALLOWED_ATTR") ? jt({}, V.ALLOWED_ATTR, Rt) : m, Lt = sn(V, "ALLOWED_NAMESPACES") ? jt({}, V.ALLOWED_NAMESPACES, qa) : re, st = sn(V, "ADD_URI_SAFE_ATTR") ? jt(
        pi(lt),
        // eslint-disable-line indent
        V.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        Rt
        // eslint-disable-line indent
      ) : lt, ct = sn(V, "ADD_DATA_URI_TAGS") ? jt(
        pi(ft),
        // eslint-disable-line indent
        V.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        Rt
        // eslint-disable-line indent
      ) : ft, nt = sn(V, "FORBID_CONTENTS") ? jt({}, V.FORBID_CONTENTS, Rt) : gt, b = sn(V, "FORBID_TAGS") ? jt({}, V.FORBID_TAGS, Rt) : {}, S = sn(V, "FORBID_ATTR") ? jt({}, V.FORBID_ATTR, Rt) : {}, Q = sn(V, "USE_PROFILES") ? V.USE_PROFILES : !1, E = V.ALLOW_ARIA_ATTR !== !1, A = V.ALLOW_DATA_ATTR !== !1, M = V.ALLOW_UNKNOWN_PROTOCOLS || !1, C = V.ALLOW_SELF_CLOSE_IN_ATTR !== !1, O = V.SAFE_FOR_TEMPLATES || !1, N = V.SAFE_FOR_XML !== !1, z = V.WHOLE_DOCUMENT || !1, k = V.RETURN_DOM || !1, B = V.RETURN_DOM_FRAGMENT || !1, Z = V.RETURN_TRUSTED_TYPE || !1, F = V.FORCE_BODY || !1, K = V.SANITIZE_DOM !== !1, U = V.SANITIZE_NAMED_PROPS || !1, H = V.KEEP_CONTENT !== !1, q = V.IN_PLACE || !1, s = V.ALLOWED_URI_REGEXP || Yh, Mt = V.NAMESPACE || mt, y = V.CUSTOM_ELEMENT_HANDLING || {}, V.CUSTOM_ELEMENT_HANDLING && fr(V.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (y.tagNameCheck = V.CUSTOM_ELEMENT_HANDLING.tagNameCheck), V.CUSTOM_ELEMENT_HANDLING && fr(V.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (y.attributeNameCheck = V.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), V.CUSTOM_ELEMENT_HANDLING && typeof V.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (y.allowCustomizedBuiltInElements = V.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), O && (A = !1), B && (k = !0), Q && (u = jt({}, eu), d = [], Q.html === !0 && (jt(u, tu), jt(d, nu)), Q.svg === !0 && (jt(u, Ka), jt(d, $a), jt(d, yo)), Q.svgFilters === !0 && (jt(u, Qa), jt(d, $a), jt(d, yo)), Q.mathMl === !0 && (jt(u, Ja), jt(d, iu), jt(d, yo))), V.ADD_TAGS && (u === h && (u = pi(u)), jt(u, V.ADD_TAGS, Rt)), V.ADD_ATTR && (d === m && (d = pi(d)), jt(d, V.ADD_ATTR, Rt)), V.ADD_URI_SAFE_ATTR && jt(st, V.ADD_URI_SAFE_ATTR, Rt), V.FORBID_CONTENTS && (nt === gt && (nt = pi(nt)), jt(nt, V.FORBID_CONTENTS, Rt)), H && (u["#text"] = !0), z && jt(u, ["html", "head", "body"]), u.table && (jt(u, ["tbody"]), delete b.tbody), V.TRUSTED_TYPES_POLICY) {
        if (typeof V.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw yr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof V.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw yr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        $ = V.TRUSTED_TYPES_POLICY, ht = $.createHTML("");
      } else
        $ === void 0 && ($ = lg(J, p)), $ !== null && typeof ht == "string" && (ht = $.createHTML(""));
      Se && Se(V), te = V;
    }
  }, ho = jt({}, ["mi", "mo", "mn", "ms", "mtext"]), fi = jt({}, ["foreignobject", "annotation-xml"]), pr = jt({}, ["title", "style", "font", "a", "script"]), Pi = jt({}, [...Ka, ...Qa, ...Qp]), fo = jt({}, [...Ja, ...Jp]), On = function(V) {
    let pt = P(V);
    (!pt || !pt.tagName) && (pt = {
      namespaceURI: Mt,
      tagName: "template"
    });
    const wt = zo(V.tagName), Yt = zo(pt.tagName);
    return Lt[V.namespaceURI] ? V.namespaceURI === yt ? pt.namespaceURI === mt ? wt === "svg" : pt.namespaceURI === at ? wt === "svg" && (Yt === "annotation-xml" || ho[Yt]) : !!Pi[wt] : V.namespaceURI === at ? pt.namespaceURI === mt ? wt === "math" : pt.namespaceURI === yt ? wt === "math" && fi[Yt] : !!fo[wt] : V.namespaceURI === mt ? pt.namespaceURI === yt && !fi[Yt] || pt.namespaceURI === at && !ho[Yt] ? !1 : !fo[wt] && (pr[wt] || !Pi[wt]) : !!(Ut === "application/xhtml+xml" && Lt[V.namespaceURI]) : !1;
  }, Ye = function(V) {
    mr(e.removed, {
      element: V
    });
    try {
      P(V).removeChild(V);
    } catch {
      vt(V);
    }
  }, Xn = function(V, pt) {
    try {
      mr(e.removed, {
        attribute: pt.getAttributeNode(V),
        from: pt
      });
    } catch {
      mr(e.removed, {
        attribute: null,
        from: pt
      });
    }
    if (pt.removeAttribute(V), V === "is" && !d[V])
      if (k || B)
        try {
          Ye(pt);
        } catch {
        }
      else
        try {
          pt.setAttribute(V, "");
        } catch {
        }
  }, Ie = function(V) {
    let pt = null, wt = null;
    if (F)
      V = "<remove></remove>" + V;
    else {
      const he = $c(V, /^[\r\n\t ]+/);
      wt = he && he[0];
    }
    Ut === "application/xhtml+xml" && Mt === mt && (V = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + V + "</body></html>");
    const Yt = $ ? $.createHTML(V) : V;
    if (Mt === mt)
      try {
        pt = new G().parseFromString(Yt, Ut);
      } catch {
      }
    if (!pt || !pt.documentElement) {
      pt = it.createDocument(Mt, "template", null);
      try {
        pt.documentElement.innerHTML = Ot ? ht : Yt;
      } catch {
      }
    }
    const ge = pt.body || pt.documentElement;
    return V && wt && ge.insertBefore(n.createTextNode(wt), ge.childNodes[0] || null), Mt === mt ? Tt.call(pt, z ? "html" : "body")[0] : z ? pt.documentElement : ge;
  }, tt = function(V) {
    return dt.call(
      V.ownerDocument || V,
      V,
      // eslint-disable-next-line no-bitwise
      T.SHOW_ELEMENT | T.SHOW_COMMENT | T.SHOW_TEXT | T.SHOW_PROCESSING_INSTRUCTION | T.SHOW_CDATA_SECTION,
      null
    );
  }, _t = function(V) {
    return V instanceof X && (typeof V.nodeName != "string" || typeof V.textContent != "string" || typeof V.removeChild != "function" || !(V.attributes instanceof L) || typeof V.removeAttribute != "function" || typeof V.setAttribute != "function" || typeof V.namespaceURI != "string" || typeof V.insertBefore != "function" || typeof V.hasChildNodes != "function");
  }, kt = function(V) {
    return typeof w == "function" && V instanceof w;
  }, xt = function(V, pt, wt) {
    Et[V] && vo(Et[V], (Yt) => {
      Yt.call(e, pt, wt, te);
    });
  }, Pt = function(V) {
    let pt = null;
    if (xt("beforeSanitizeElements", V, null), _t(V))
      return Ye(V), !0;
    const wt = Rt(V.nodeName);
    if (xt("uponSanitizeElement", V, {
      tagName: wt,
      allowedTags: u
    }), V.hasChildNodes() && !kt(V.firstElementChild) && we(/<[/\w]/g, V.innerHTML) && we(/<[/\w]/g, V.textContent) || V.nodeType === br.progressingInstruction || N && V.nodeType === br.comment && we(/<[/\w]/g, V.data))
      return Ye(V), !0;
    if (!u[wt] || b[wt]) {
      if (!b[wt] && Ai(wt) && (y.tagNameCheck instanceof RegExp && we(y.tagNameCheck, wt) || y.tagNameCheck instanceof Function && y.tagNameCheck(wt)))
        return !1;
      if (H && !nt[wt]) {
        const Yt = P(V) || V.parentNode, ge = j(V) || V.childNodes;
        if (ge && Yt) {
          const he = ge.length;
          for (let ke = he - 1; ke >= 0; --ke) {
            const mn = rt(ge[ke], !0);
            mn.__removalCount = (V.__removalCount || 0) + 1, Yt.insertBefore(mn, Y(V));
          }
        }
      }
      return Ye(V), !0;
    }
    return V instanceof x && !On(V) || (wt === "noscript" || wt === "noembed" || wt === "noframes") && we(/<\/no(script|embed|frames)/i, V.innerHTML) ? (Ye(V), !0) : (O && V.nodeType === br.text && (pt = V.textContent, vo([Xt, zt, c], (Yt) => {
      pt = vr(pt, Yt, " ");
    }), V.textContent !== pt && (mr(e.removed, {
      element: V.cloneNode()
    }), V.textContent = pt)), xt("afterSanitizeElements", V, null), !1);
  }, Ht = function(V, pt, wt) {
    if (K && (pt === "id" || pt === "name") && (wt in n || wt in hi))
      return !1;
    if (!(A && !S[pt] && we(o, pt))) {
      if (!(E && we(l, pt))) {
        if (!d[pt] || S[pt]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Ai(V) && (y.tagNameCheck instanceof RegExp && we(y.tagNameCheck, V) || y.tagNameCheck instanceof Function && y.tagNameCheck(V)) && (y.attributeNameCheck instanceof RegExp && we(y.attributeNameCheck, pt) || y.attributeNameCheck instanceof Function && y.attributeNameCheck(pt)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            pt === "is" && y.allowCustomizedBuiltInElements && (y.tagNameCheck instanceof RegExp && we(y.tagNameCheck, wt) || y.tagNameCheck instanceof Function && y.tagNameCheck(wt)))
          ) return !1;
        } else if (!st[pt]) {
          if (!we(s, vr(wt, i, ""))) {
            if (!((pt === "src" || pt === "xlink:href" || pt === "href") && V !== "script" && Vp(wt, "data:") === 0 && ct[V])) {
              if (!(M && !we(f, vr(wt, i, "")))) {
                if (wt)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Ai = function(V) {
    return V !== "annotation-xml" && $c(V, r);
  }, Mn = function(V) {
    xt("beforeSanitizeAttributes", V, null);
    const {
      attributes: pt
    } = V;
    if (!pt)
      return;
    const wt = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: d
    };
    let Yt = pt.length;
    for (; Yt--; ) {
      const ge = pt[Yt], {
        name: he,
        namespaceURI: ke,
        value: mn
      } = ge, gr = Rt(he);
      let be = he === "value" ? mn : Zp(mn);
      if (wt.attrName = gr, wt.attrValue = be, wt.keepAttr = !0, wt.forceKeepAttr = void 0, xt("uponSanitizeAttribute", V, wt), be = wt.attrValue, N && we(/((--!?|])>)|<\/(style|title)/i, be)) {
        Xn(he, V);
        continue;
      }
      if (wt.forceKeepAttr || (Xn(he, V), !wt.keepAttr))
        continue;
      if (!C && we(/\/>/i, be)) {
        Xn(he, V);
        continue;
      }
      O && vo([Xt, zt, c], (Tc) => {
        be = vr(be, Tc, " ");
      });
      const Sc = Rt(V.nodeName);
      if (Ht(Sc, gr, be)) {
        if (U && (gr === "id" || gr === "name") && (Xn(he, V), be = R + be), $ && typeof J == "object" && typeof J.getAttributeType == "function" && !ke)
          switch (J.getAttributeType(Sc, gr)) {
            case "TrustedHTML": {
              be = $.createHTML(be);
              break;
            }
            case "TrustedScriptURL": {
              be = $.createScriptURL(be);
              break;
            }
          }
        try {
          ke ? V.setAttributeNS(ke, he, be) : V.setAttribute(he, be), _t(V) ? Ye(V) : Jc(e.removed);
        } catch {
        }
      }
    }
    xt("afterSanitizeAttributes", V, null);
  }, Ga = function Ct(V) {
    let pt = null;
    const wt = tt(V);
    for (xt("beforeSanitizeShadowDOM", V, null); pt = wt.nextNode(); )
      xt("uponSanitizeShadowNode", pt, null), !Pt(pt) && (pt.content instanceof g && Ct(pt.content), Mn(pt));
    xt("afterSanitizeShadowDOM", V, null);
  };
  return e.sanitize = function(Ct) {
    let V = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, pt = null, wt = null, Yt = null, ge = null;
    if (Ot = !Ct, Ot && (Ct = "<!-->"), typeof Ct != "string" && !kt(Ct))
      if (typeof Ct.toString == "function") {
        if (Ct = Ct.toString(), typeof Ct != "string")
          throw yr("dirty is not a string, aborting");
      } else
        throw yr("toString is not a function");
    if (!e.isSupported)
      return Ct;
    if (W || dr(V), e.removed = [], typeof Ct == "string" && (q = !1), q) {
      if (Ct.nodeName) {
        const mn = Rt(Ct.nodeName);
        if (!u[mn] || b[mn])
          throw yr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (Ct instanceof w)
      pt = Ie("<!---->"), wt = pt.ownerDocument.importNode(Ct, !0), wt.nodeType === br.element && wt.nodeName === "BODY" || wt.nodeName === "HTML" ? pt = wt : pt.appendChild(wt);
    else {
      if (!k && !O && !z && // eslint-disable-next-line unicorn/prefer-includes
      Ct.indexOf("<") === -1)
        return $ && Z ? $.createHTML(Ct) : Ct;
      if (pt = Ie(Ct), !pt)
        return k ? null : Z ? ht : "";
    }
    pt && F && Ye(pt.firstChild);
    const he = tt(q ? Ct : pt);
    for (; Yt = he.nextNode(); )
      Pt(Yt) || (Yt.content instanceof g && Ga(Yt.content), Mn(Yt));
    if (q)
      return Ct;
    if (k) {
      if (B)
        for (ge = v.call(pt.ownerDocument); pt.firstChild; )
          ge.appendChild(pt.firstChild);
      else
        ge = pt;
      return (d.shadowroot || d.shadowrootmode) && (ge = I.call(a, ge, !0)), ge;
    }
    let ke = z ? pt.outerHTML : pt.innerHTML;
    return z && u["!doctype"] && pt.ownerDocument && pt.ownerDocument.doctype && pt.ownerDocument.doctype.name && we(Gh, pt.ownerDocument.doctype.name) && (ke = "<!DOCTYPE " + pt.ownerDocument.doctype.name + `>
` + ke), O && vo([Xt, zt, c], (mn) => {
      ke = vr(ke, mn, " ");
    }), $ && Z ? $.createHTML(ke) : ke;
  }, e.setConfig = function() {
    let Ct = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    dr(Ct), W = !0;
  }, e.clearConfig = function() {
    te = null, W = !1;
  }, e.isValidAttribute = function(Ct, V, pt) {
    te || dr({});
    const wt = Rt(Ct), Yt = Rt(V);
    return Ht(wt, Yt, pt);
  }, e.addHook = function(Ct, V) {
    typeof V == "function" && (Et[Ct] = Et[Ct] || [], mr(Et[Ct], V));
  }, e.removeHook = function(Ct) {
    if (Et[Ct])
      return Jc(Et[Ct]);
  }, e.removeHooks = function(Ct) {
    Et[Ct] && (Et[Ct] = []);
  }, e.removeAllHooks = function() {
    Et = {};
  }, e;
}
Hh();
(function() {
  try {
    if (typeof document < "u") {
      var t = document.createElement("style");
      t.appendChild(document.createTextNode(":root{--svg-filter: #313131;--svg-filter-active: #0095ff;--font-color: #000;--background-color: #fff;--background-color-active: #f0f0f0}[data-theme=dark]{--svg-filter: white;--svg-filter-active: #a5ffff;--font-color: #fff;--background-color: #333;--background-color-active: #7a7a7a}.panel-paint-box{width:100%;height:100%}#prompt-input-box{display:flex;justify-content:center;width:80%;margin-inline:auto}#prompt-input-box #prompt-input{border-radius:1rem;border-style:solid;border-width:1px;width:80%;padding:.2rem 1rem;margin-inline:.3rem;color:var(--font-color);background-color:var(--background-color)}#prompt-input-box #wand-icon{transition:color 1s ease}.blinking{animation:blink .5s infinite alternate}@keyframes blink{0%{opacity:1}to{opacity:.1}}.shining{fill:#ffcd28!important;animation:shine .5s forwards}@keyframes shine{0%{transform:scale(1)}50%{transform:scale(1.5)}to{transform:scale(1)}}#tool-bar{display:flex;width:100%;overflow-x:scroll;scrollbar-width:none;-ms-overflow-style:none}#tool-bar::-webkit-scrollbar{display:none}#essential-tool-box{display:flex}.painter-tool-icon{width:1.5rem;height:1.5rem;margin-inline:.2rem;cursor:pointer;display:flex;align-self:center}.painter-tool-icon svg{width:100%;height:100%;align-self:center;-webkit-user-drag:none;-khtml-user-drag:none;-moz-user-drag:none;-o-user-drag:none}.painter-tool-icon svg:hover{opacity:.8}.painter-tool-icon svg{fill:var(--svg-filter)}.painter-tool-icon svg.active{fill:var(--svg-filter-active)}.painter-tool-icon.disabled{opacity:.3;cursor:not-allowed}#stroke-size-box{display:flex}#stroke-size-box #stroke-width-slider{width:6rem;align-self:center}#stroke-size-box #stroke-width-value{font-size:.8rem;margin-left:.2rem;align-self:center;color:var(--font-color)}#stroke-color{align-self:center;width:3rem;height:1.5rem;padding:0}#stroke-color-transparent{align-self:center;width:3.5rem;height:1.5rem;padding:.2rem;margin-left:.2rem;font-size:.8rem;color:var(--font-color);background-color:var(--background-color);border-radius:1rem;border-style:solid;border-width:1px;border-radius:.2rem;box-sizing:border-box}#painter-history-panel{display:flex}.side-bar{width:7rem;display:flex;flex-direction:column;justify-content:space-between}.side-bar button{width:24px}.top-bar{width:100%;min-height:5rem;display:flex;flex-direction:column;justify-content:space-evenly}.lower-area{width:100%;height:calc(100% - 7rem);display:flex}.separator{align-self:center;width:1px;height:25px;background-color:var(--border-color);display:inline-block;vertical-align:middle;margin:0 4px}#color-and-alpha-box{display:flex}#output-img-box{position:relative}#output-operation-box{position:absolute;bottom:.5rem;width:80%;left:10%;background:#e3e3e333;padding:.5rem 1rem;box-sizing:border-box;border-radius:.5rem;display:flex;justify-content:space-around}.side-bar .layer-box{display:flex;flex-direction:column;height:calc(100% - 1.5rem)}.layer-item-list{display:flex;flex-direction:column;gap:2px;align-items:center;overflow-y:auto;overflow-x:hidden;padding-block:.5rem;max-height:350px}.layer-operation-box{display:flex;justify-content:space-between;padding-inline:.3rem}.layer-item-container{flex-direction:row;display:flex;justify-content:space-between;align-items:center;width:85%;padding:.05rem .4rem;margin-block:.1rem;box-sizing:border-box;border-radius:.4rem;border:1px solid #737373}.layer-item-container .layer-item{width:80%;font-size:.7rem;color:var(--font-color);cursor:pointer}.layer-item-container:hover{opacity:.8}.layer-item-container.active{background:var(--background-color-active)}.layer-item-container .layer-item-remove{width:20%;border-radius:50%;box-sizing:border-box;padding:2%;cursor:pointer;fill:var(--svg-filter);-webkit-user-drag:none;-khtml-user-drag:none;-moz-user-drag:none;-o-user-drag:none}.layer-item-container .layer-item-remove:hover{opacity:.6}#output-area{width:calc(100% - 7rem);display:flex}#canvas-box{width:50%}#left-box{position:relative}#bg-reminder{position:absolute;width:100%;height:100%;z-index:10;display:flex;cursor:pointer}#bg-reminder-text{color:#fff;text-align:center;display:block;margin:auto;padding:.3rem 1rem;border-radius:1rem}#output-img{background-color:gray;width:100%;height:100%}#loading-status{text-align:center;margin-top:1rem;height:1.5rem}#loading-status svg{width:1.2rem;height:1.2rem;margin:auto;fill:var(--svg-filter)}@-webkit-keyframes rotating{0%{-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes rotating{0%{-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);-o-transform:rotate(0deg);transform:rotate(0)}to{-ms-transform:rotate(360deg);-moz-transform:rotate(360deg);-webkit-transform:rotate(360deg);-o-transform:rotate(360deg);transform:rotate(360deg)}}.rotating{-webkit-animation:rotating 2s linear infinite;-moz-animation:rotating 2s linear infinite;-ms-animation:rotating 2s linear infinite;-o-animation:rotating 2s linear infinite;animation:rotating 2s linear infinite}")), document.head.appendChild(t);
    }
  } catch (e) {
    console.error("vite-plugin-css-injected-by-js", e);
  }
})();
function Vh(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Zh = { exports: {} }, Oa = {}, qh = { exports: {} }, It = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ao = Symbol.for("react.element"), cg = Symbol.for("react.portal"), ug = Symbol.for("react.fragment"), hg = Symbol.for("react.strict_mode"), fg = Symbol.for("react.profiler"), dg = Symbol.for("react.provider"), pg = Symbol.for("react.context"), gg = Symbol.for("react.forward_ref"), mg = Symbol.for("react.suspense"), vg = Symbol.for("react.memo"), yg = Symbol.for("react.lazy"), ou = Symbol.iterator;
function _g(t) {
  return t === null || typeof t != "object" ? null : (t = ou && t[ou] || t["@@iterator"], typeof t == "function" ? t : null);
}
var Kh = { isMounted: function() {
  return !1;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, Qh = Object.assign, Jh = {};
function cr(t, e, n) {
  this.props = t, this.context = e, this.refs = Jh, this.updater = n || Kh;
}
cr.prototype.isReactComponent = {};
cr.prototype.setState = function(t, e) {
  if (typeof t != "object" && typeof t != "function" && t != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, t, e, "setState");
};
cr.prototype.forceUpdate = function(t) {
  this.updater.enqueueForceUpdate(this, t, "forceUpdate");
};
function $h() {
}
$h.prototype = cr.prototype;
function Ol(t, e, n) {
  this.props = t, this.context = e, this.refs = Jh, this.updater = n || Kh;
}
var Ml = Ol.prototype = new $h();
Ml.constructor = Ol;
Qh(Ml, cr.prototype);
Ml.isPureReactComponent = !0;
var au = Array.isArray, tf = Object.prototype.hasOwnProperty, Pl = { current: null }, ef = { key: !0, ref: !0, __self: !0, __source: !0 };
function nf(t, e, n) {
  var a, p = {}, g = null, _ = null;
  if (e != null) for (a in e.ref !== void 0 && (_ = e.ref), e.key !== void 0 && (g = "" + e.key), e) tf.call(e, a) && !ef.hasOwnProperty(a) && (p[a] = e[a]);
  var w = arguments.length - 2;
  if (w === 1) p.children = n;
  else if (1 < w) {
    for (var x = Array(w), T = 0; T < w; T++) x[T] = arguments[T + 2];
    p.children = x;
  }
  if (t && t.defaultProps) for (a in w = t.defaultProps, w) p[a] === void 0 && (p[a] = w[a]);
  return { $$typeof: ao, type: t, key: g, ref: _, props: p, _owner: Pl.current };
}
function bg(t, e) {
  return { $$typeof: ao, type: t.type, key: e, ref: t.ref, props: t.props, _owner: t._owner };
}
function Al(t) {
  return typeof t == "object" && t !== null && t.$$typeof === ao;
}
function wg(t) {
  var e = { "=": "=0", ":": "=2" };
  return "$" + t.replace(/[=:]/g, function(n) {
    return e[n];
  });
}
var su = /\/+/g;
function ts(t, e) {
  return typeof t == "object" && t !== null && t.key != null ? wg("" + t.key) : e.toString(36);
}
function Wo(t, e, n, a, p) {
  var g = typeof t;
  (g === "undefined" || g === "boolean") && (t = null);
  var _ = !1;
  if (t === null) _ = !0;
  else switch (g) {
    case "string":
    case "number":
      _ = !0;
      break;
    case "object":
      switch (t.$$typeof) {
        case ao:
        case cg:
          _ = !0;
      }
  }
  if (_) return _ = t, p = p(_), t = a === "" ? "." + ts(_, 0) : a, au(p) ? (n = "", t != null && (n = t.replace(su, "$&/") + "/"), Wo(p, e, n, "", function(T) {
    return T;
  })) : p != null && (Al(p) && (p = bg(p, n + (!p.key || _ && _.key === p.key ? "" : ("" + p.key).replace(su, "$&/") + "/") + t)), e.push(p)), 1;
  if (_ = 0, a = a === "" ? "." : a + ":", au(t)) for (var w = 0; w < t.length; w++) {
    g = t[w];
    var x = a + ts(g, w);
    _ += Wo(g, e, n, x, p);
  }
  else if (x = _g(t), typeof x == "function") for (t = x.call(t), w = 0; !(g = t.next()).done; ) g = g.value, x = a + ts(g, w++), _ += Wo(g, e, n, x, p);
  else if (g === "object") throw e = String(t), Error("Objects are not valid as a React child (found: " + (e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e) + "). If you meant to render a collection of children, use an array instead.");
  return _;
}
function _o(t, e, n) {
  if (t == null) return t;
  var a = [], p = 0;
  return Wo(t, a, "", "", function(g) {
    return e.call(n, g, p++);
  }), a;
}
function Cg(t) {
  if (t._status === -1) {
    var e = t._result;
    e = e(), e.then(function(n) {
      (t._status === 0 || t._status === -1) && (t._status = 1, t._result = n);
    }, function(n) {
      (t._status === 0 || t._status === -1) && (t._status = 2, t._result = n);
    }), t._status === -1 && (t._status = 0, t._result = e);
  }
  if (t._status === 1) return t._result.default;
  throw t._result;
}
var Te = { current: null }, Xo = { transition: null }, xg = { ReactCurrentDispatcher: Te, ReactCurrentBatchConfig: Xo, ReactCurrentOwner: Pl };
function rf() {
  throw Error("act(...) is not supported in production builds of React.");
}
It.Children = { map: _o, forEach: function(t, e, n) {
  _o(t, function() {
    e.apply(this, arguments);
  }, n);
}, count: function(t) {
  var e = 0;
  return _o(t, function() {
    e++;
  }), e;
}, toArray: function(t) {
  return _o(t, function(e) {
    return e;
  }) || [];
}, only: function(t) {
  if (!Al(t)) throw Error("React.Children.only expected to receive a single React element child.");
  return t;
} };
It.Component = cr;
It.Fragment = ug;
It.Profiler = fg;
It.PureComponent = Ol;
It.StrictMode = hg;
It.Suspense = mg;
It.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = xg;
It.act = rf;
It.cloneElement = function(t, e, n) {
  if (t == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + t + ".");
  var a = Qh({}, t.props), p = t.key, g = t.ref, _ = t._owner;
  if (e != null) {
    if (e.ref !== void 0 && (g = e.ref, _ = Pl.current), e.key !== void 0 && (p = "" + e.key), t.type && t.type.defaultProps) var w = t.type.defaultProps;
    for (x in e) tf.call(e, x) && !ef.hasOwnProperty(x) && (a[x] = e[x] === void 0 && w !== void 0 ? w[x] : e[x]);
  }
  var x = arguments.length - 2;
  if (x === 1) a.children = n;
  else if (1 < x) {
    w = Array(x);
    for (var T = 0; T < x; T++) w[T] = arguments[T + 2];
    a.children = w;
  }
  return { $$typeof: ao, type: t.type, key: p, ref: g, props: a, _owner: _ };
};
It.createContext = function(t) {
  return t = { $$typeof: pg, _currentValue: t, _currentValue2: t, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, t.Provider = { $$typeof: dg, _context: t }, t.Consumer = t;
};
It.createElement = nf;
It.createFactory = function(t) {
  var e = nf.bind(null, t);
  return e.type = t, e;
};
It.createRef = function() {
  return { current: null };
};
It.forwardRef = function(t) {
  return { $$typeof: gg, render: t };
};
It.isValidElement = Al;
It.lazy = function(t) {
  return { $$typeof: yg, _payload: { _status: -1, _result: t }, _init: Cg };
};
It.memo = function(t, e) {
  return { $$typeof: vg, type: t, compare: e === void 0 ? null : e };
};
It.startTransition = function(t) {
  var e = Xo.transition;
  Xo.transition = {};
  try {
    t();
  } finally {
    Xo.transition = e;
  }
};
It.unstable_act = rf;
It.useCallback = function(t, e) {
  return Te.current.useCallback(t, e);
};
It.useContext = function(t) {
  return Te.current.useContext(t);
};
It.useDebugValue = function() {
};
It.useDeferredValue = function(t) {
  return Te.current.useDeferredValue(t);
};
It.useEffect = function(t, e) {
  return Te.current.useEffect(t, e);
};
It.useId = function() {
  return Te.current.useId();
};
It.useImperativeHandle = function(t, e, n) {
  return Te.current.useImperativeHandle(t, e, n);
};
It.useInsertionEffect = function(t, e) {
  return Te.current.useInsertionEffect(t, e);
};
It.useLayoutEffect = function(t, e) {
  return Te.current.useLayoutEffect(t, e);
};
It.useMemo = function(t, e) {
  return Te.current.useMemo(t, e);
};
It.useReducer = function(t, e, n) {
  return Te.current.useReducer(t, e, n);
};
It.useRef = function(t) {
  return Te.current.useRef(t);
};
It.useState = function(t) {
  return Te.current.useState(t);
};
It.useSyncExternalStore = function(t, e, n) {
  return Te.current.useSyncExternalStore(t, e, n);
};
It.useTransition = function() {
  return Te.current.useTransition();
};
It.version = "18.3.1";
qh.exports = It;
var D = qh.exports;
const Sg = /* @__PURE__ */ Vh(D);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Tg = D, Eg = Symbol.for("react.element"), kg = Symbol.for("react.fragment"), Og = Object.prototype.hasOwnProperty, Mg = Tg.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, Pg = { key: !0, ref: !0, __self: !0, __source: !0 };
function of(t, e, n) {
  var a, p = {}, g = null, _ = null;
  n !== void 0 && (g = "" + n), e.key !== void 0 && (g = "" + e.key), e.ref !== void 0 && (_ = e.ref);
  for (a in e) Og.call(e, a) && !Pg.hasOwnProperty(a) && (p[a] = e[a]);
  if (t && t.defaultProps) for (a in e = t.defaultProps, e) p[a] === void 0 && (p[a] = e[a]);
  return { $$typeof: Eg, type: t, key: g, ref: _, props: p, _owner: Mg.current };
}
Oa.Fragment = kg;
Oa.jsx = of;
Oa.jsxs = of;
Zh.exports = Oa;
var St = Zh.exports, af = { exports: {} }, We = {}, sf = { exports: {} }, lf = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(t) {
  function e(i, r) {
    var s = i.length;
    i.push(r);
    t: for (; 0 < s; ) {
      var u = s - 1 >>> 1, h = i[u];
      if (0 < p(h, r)) i[u] = r, i[s] = h, s = u;
      else break t;
    }
  }
  function n(i) {
    return i.length === 0 ? null : i[0];
  }
  function a(i) {
    if (i.length === 0) return null;
    var r = i[0], s = i.pop();
    if (s !== r) {
      i[0] = s;
      t: for (var u = 0, h = i.length, d = h >>> 1; u < d; ) {
        var m = 2 * (u + 1) - 1, y = i[m], b = m + 1, S = i[b];
        if (0 > p(y, s)) b < h && 0 > p(S, y) ? (i[u] = S, i[b] = s, u = b) : (i[u] = y, i[m] = s, u = m);
        else if (b < h && 0 > p(S, s)) i[u] = S, i[b] = s, u = b;
        else break t;
      }
    }
    return r;
  }
  function p(i, r) {
    var s = i.sortIndex - r.sortIndex;
    return s !== 0 ? s : i.id - r.id;
  }
  if (typeof performance == "object" && typeof performance.now == "function") {
    var g = performance;
    t.unstable_now = function() {
      return g.now();
    };
  } else {
    var _ = Date, w = _.now();
    t.unstable_now = function() {
      return _.now() - w;
    };
  }
  var x = [], T = [], L = 1, X = null, G = 3, J = !1, et = !1, rt = !1, vt = typeof setTimeout == "function" ? setTimeout : null, Y = typeof clearTimeout == "function" ? clearTimeout : null, j = typeof setImmediate < "u" ? setImmediate : null;
  typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function P(i) {
    for (var r = n(T); r !== null; ) {
      if (r.callback === null) a(T);
      else if (r.startTime <= i) a(T), r.sortIndex = r.expirationTime, e(x, r);
      else break;
      r = n(T);
    }
  }
  function $(i) {
    if (rt = !1, P(i), !et) if (n(x) !== null) et = !0, l(ht);
    else {
      var r = n(T);
      r !== null && f($, r.startTime - i);
    }
  }
  function ht(i, r) {
    et = !1, rt && (rt = !1, Y(v), v = -1), J = !0;
    var s = G;
    try {
      for (P(r), X = n(x); X !== null && (!(X.expirationTime > r) || i && !Et()); ) {
        var u = X.callback;
        if (typeof u == "function") {
          X.callback = null, G = X.priorityLevel;
          var h = u(X.expirationTime <= r);
          r = t.unstable_now(), typeof h == "function" ? X.callback = h : X === n(x) && a(x), P(r);
        } else a(x);
        X = n(x);
      }
      if (X !== null) var d = !0;
      else {
        var m = n(T);
        m !== null && f($, m.startTime - r), d = !1;
      }
      return d;
    } finally {
      X = null, G = s, J = !1;
    }
  }
  var it = !1, dt = null, v = -1, Tt = 5, I = -1;
  function Et() {
    return !(t.unstable_now() - I < Tt);
  }
  function Xt() {
    if (dt !== null) {
      var i = t.unstable_now();
      I = i;
      var r = !0;
      try {
        r = dt(!0, i);
      } finally {
        r ? zt() : (it = !1, dt = null);
      }
    } else it = !1;
  }
  var zt;
  if (typeof j == "function") zt = function() {
    j(Xt);
  };
  else if (typeof MessageChannel < "u") {
    var c = new MessageChannel(), o = c.port2;
    c.port1.onmessage = Xt, zt = function() {
      o.postMessage(null);
    };
  } else zt = function() {
    vt(Xt, 0);
  };
  function l(i) {
    dt = i, it || (it = !0, zt());
  }
  function f(i, r) {
    v = vt(function() {
      i(t.unstable_now());
    }, r);
  }
  t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(i) {
    i.callback = null;
  }, t.unstable_continueExecution = function() {
    et || J || (et = !0, l(ht));
  }, t.unstable_forceFrameRate = function(i) {
    0 > i || 125 < i ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : Tt = 0 < i ? Math.floor(1e3 / i) : 5;
  }, t.unstable_getCurrentPriorityLevel = function() {
    return G;
  }, t.unstable_getFirstCallbackNode = function() {
    return n(x);
  }, t.unstable_next = function(i) {
    switch (G) {
      case 1:
      case 2:
      case 3:
        var r = 3;
        break;
      default:
        r = G;
    }
    var s = G;
    G = r;
    try {
      return i();
    } finally {
      G = s;
    }
  }, t.unstable_pauseExecution = function() {
  }, t.unstable_requestPaint = function() {
  }, t.unstable_runWithPriority = function(i, r) {
    switch (i) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        i = 3;
    }
    var s = G;
    G = i;
    try {
      return r();
    } finally {
      G = s;
    }
  }, t.unstable_scheduleCallback = function(i, r, s) {
    var u = t.unstable_now();
    switch (typeof s == "object" && s !== null ? (s = s.delay, s = typeof s == "number" && 0 < s ? u + s : u) : s = u, i) {
      case 1:
        var h = -1;
        break;
      case 2:
        h = 250;
        break;
      case 5:
        h = 1073741823;
        break;
      case 4:
        h = 1e4;
        break;
      default:
        h = 5e3;
    }
    return h = s + h, i = { id: L++, callback: r, priorityLevel: i, startTime: s, expirationTime: h, sortIndex: -1 }, s > u ? (i.sortIndex = s, e(T, i), n(x) === null && i === n(T) && (rt ? (Y(v), v = -1) : rt = !0, f($, s - u))) : (i.sortIndex = h, e(x, i), et || J || (et = !0, l(ht))), i;
  }, t.unstable_shouldYield = Et, t.unstable_wrapCallback = function(i) {
    var r = G;
    return function() {
      var s = G;
      G = r;
      try {
        return i.apply(this, arguments);
      } finally {
        G = s;
      }
    };
  };
})(lf);
sf.exports = lf;
var Ag = sf.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Dg = D, ze = Ag;
function ut(t) {
  for (var e = "https://reactjs.org/docs/error-decoder.html?invariant=" + t, n = 1; n < arguments.length; n++) e += "&args[]=" + encodeURIComponent(arguments[n]);
  return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var cf = /* @__PURE__ */ new Set(), Xr = {};
function Oi(t, e) {
  er(t, e), er(t + "Capture", e);
}
function er(t, e) {
  for (Xr[t] = e, t = 0; t < e.length; t++) cf.add(e[t]);
}
var Bn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Fs = Object.prototype.hasOwnProperty, Lg = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, lu = {}, cu = {};
function jg(t) {
  return Fs.call(cu, t) ? !0 : Fs.call(lu, t) ? !1 : Lg.test(t) ? cu[t] = !0 : (lu[t] = !0, !1);
}
function Ig(t, e, n, a) {
  if (n !== null && n.type === 0) return !1;
  switch (typeof e) {
    case "function":
    case "symbol":
      return !0;
    case "boolean":
      return a ? !1 : n !== null ? !n.acceptsBooleans : (t = t.toLowerCase().slice(0, 5), t !== "data-" && t !== "aria-");
    default:
      return !1;
  }
}
function Fg(t, e, n, a) {
  if (e === null || typeof e > "u" || Ig(t, e, n, a)) return !0;
  if (a) return !1;
  if (n !== null) switch (n.type) {
    case 3:
      return !e;
    case 4:
      return e === !1;
    case 5:
      return isNaN(e);
    case 6:
      return isNaN(e) || 1 > e;
  }
  return !1;
}
function Ee(t, e, n, a, p, g, _) {
  this.acceptsBooleans = e === 2 || e === 3 || e === 4, this.attributeName = a, this.attributeNamespace = p, this.mustUseProperty = n, this.propertyName = t, this.type = e, this.sanitizeURL = g, this.removeEmptyString = _;
}
var pe = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t) {
  pe[t] = new Ee(t, 0, !1, t, null, !1, !1);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(t) {
  var e = t[0];
  pe[e] = new Ee(e, 1, !1, t[1], null, !1, !1);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(t) {
  pe[t] = new Ee(t, 2, !1, t.toLowerCase(), null, !1, !1);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(t) {
  pe[t] = new Ee(t, 2, !1, t, null, !1, !1);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t) {
  pe[t] = new Ee(t, 3, !1, t.toLowerCase(), null, !1, !1);
});
["checked", "multiple", "muted", "selected"].forEach(function(t) {
  pe[t] = new Ee(t, 3, !0, t, null, !1, !1);
});
["capture", "download"].forEach(function(t) {
  pe[t] = new Ee(t, 4, !1, t, null, !1, !1);
});
["cols", "rows", "size", "span"].forEach(function(t) {
  pe[t] = new Ee(t, 6, !1, t, null, !1, !1);
});
["rowSpan", "start"].forEach(function(t) {
  pe[t] = new Ee(t, 5, !1, t.toLowerCase(), null, !1, !1);
});
var Dl = /[\-:]([a-z])/g;
function Ll(t) {
  return t[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t) {
  var e = t.replace(
    Dl,
    Ll
  );
  pe[e] = new Ee(e, 1, !1, t, null, !1, !1);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t) {
  var e = t.replace(Dl, Ll);
  pe[e] = new Ee(e, 1, !1, t, "http://www.w3.org/1999/xlink", !1, !1);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(t) {
  var e = t.replace(Dl, Ll);
  pe[e] = new Ee(e, 1, !1, t, "http://www.w3.org/XML/1998/namespace", !1, !1);
});
["tabIndex", "crossOrigin"].forEach(function(t) {
  pe[t] = new Ee(t, 1, !1, t.toLowerCase(), null, !1, !1);
});
pe.xlinkHref = new Ee("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(t) {
  pe[t] = new Ee(t, 1, !1, t.toLowerCase(), null, !0, !0);
});
function jl(t, e, n, a) {
  var p = pe.hasOwnProperty(e) ? pe[e] : null;
  (p !== null ? p.type !== 0 : a || !(2 < e.length) || e[0] !== "o" && e[0] !== "O" || e[1] !== "n" && e[1] !== "N") && (Fg(e, n, p, a) && (n = null), a || p === null ? jg(e) && (n === null ? t.removeAttribute(e) : t.setAttribute(e, "" + n)) : p.mustUseProperty ? t[p.propertyName] = n === null ? p.type === 3 ? !1 : "" : n : (e = p.attributeName, a = p.attributeNamespace, n === null ? t.removeAttribute(e) : (p = p.type, n = p === 3 || p === 4 && n === !0 ? "" : "" + n, a ? t.setAttributeNS(a, e, n) : t.setAttribute(e, n))));
}
var Wn = Dg.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, bo = Symbol.for("react.element"), Fi = Symbol.for("react.portal"), Ri = Symbol.for("react.fragment"), Il = Symbol.for("react.strict_mode"), Rs = Symbol.for("react.profiler"), uf = Symbol.for("react.provider"), hf = Symbol.for("react.context"), Fl = Symbol.for("react.forward_ref"), Bs = Symbol.for("react.suspense"), Ns = Symbol.for("react.suspense_list"), Rl = Symbol.for("react.memo"), Gn = Symbol.for("react.lazy"), ff = Symbol.for("react.offscreen"), uu = Symbol.iterator;
function wr(t) {
  return t === null || typeof t != "object" ? null : (t = uu && t[uu] || t["@@iterator"], typeof t == "function" ? t : null);
}
var $t = Object.assign, es;
function Mr(t) {
  if (es === void 0) try {
    throw Error();
  } catch (n) {
    var e = n.stack.trim().match(/\n( *(at )?)/);
    es = e && e[1] || "";
  }
  return `
` + es + t;
}
var ns = !1;
function is(t, e) {
  if (!t || ns) return "";
  ns = !0;
  var n = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (e) if (e = function() {
      throw Error();
    }, Object.defineProperty(e.prototype, "props", { set: function() {
      throw Error();
    } }), typeof Reflect == "object" && Reflect.construct) {
      try {
        Reflect.construct(e, []);
      } catch (T) {
        var a = T;
      }
      Reflect.construct(t, [], e);
    } else {
      try {
        e.call();
      } catch (T) {
        a = T;
      }
      t.call(e.prototype);
    }
    else {
      try {
        throw Error();
      } catch (T) {
        a = T;
      }
      t();
    }
  } catch (T) {
    if (T && a && typeof T.stack == "string") {
      for (var p = T.stack.split(`
`), g = a.stack.split(`
`), _ = p.length - 1, w = g.length - 1; 1 <= _ && 0 <= w && p[_] !== g[w]; ) w--;
      for (; 1 <= _ && 0 <= w; _--, w--) if (p[_] !== g[w]) {
        if (_ !== 1 || w !== 1)
          do
            if (_--, w--, 0 > w || p[_] !== g[w]) {
              var x = `
` + p[_].replace(" at new ", " at ");
              return t.displayName && x.includes("<anonymous>") && (x = x.replace("<anonymous>", t.displayName)), x;
            }
          while (1 <= _ && 0 <= w);
        break;
      }
    }
  } finally {
    ns = !1, Error.prepareStackTrace = n;
  }
  return (t = t ? t.displayName || t.name : "") ? Mr(t) : "";
}
function Rg(t) {
  switch (t.tag) {
    case 5:
      return Mr(t.type);
    case 16:
      return Mr("Lazy");
    case 13:
      return Mr("Suspense");
    case 19:
      return Mr("SuspenseList");
    case 0:
    case 2:
    case 15:
      return t = is(t.type, !1), t;
    case 11:
      return t = is(t.type.render, !1), t;
    case 1:
      return t = is(t.type, !0), t;
    default:
      return "";
  }
}
function Us(t) {
  if (t == null) return null;
  if (typeof t == "function") return t.displayName || t.name || null;
  if (typeof t == "string") return t;
  switch (t) {
    case Ri:
      return "Fragment";
    case Fi:
      return "Portal";
    case Rs:
      return "Profiler";
    case Il:
      return "StrictMode";
    case Bs:
      return "Suspense";
    case Ns:
      return "SuspenseList";
  }
  if (typeof t == "object") switch (t.$$typeof) {
    case hf:
      return (t.displayName || "Context") + ".Consumer";
    case uf:
      return (t._context.displayName || "Context") + ".Provider";
    case Fl:
      var e = t.render;
      return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
    case Rl:
      return e = t.displayName || null, e !== null ? e : Us(t.type) || "Memo";
    case Gn:
      e = t._payload, t = t._init;
      try {
        return Us(t(e));
      } catch {
      }
  }
  return null;
}
function Bg(t) {
  var e = t.type;
  switch (t.tag) {
    case 24:
      return "Cache";
    case 9:
      return (e.displayName || "Context") + ".Consumer";
    case 10:
      return (e._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return t = e.render, t = t.displayName || t.name || "", e.displayName || (t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return e;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Us(e);
    case 8:
      return e === Il ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof e == "function") return e.displayName || e.name || null;
      if (typeof e == "string") return e;
  }
  return null;
}
function ai(t) {
  switch (typeof t) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return t;
    case "object":
      return t;
    default:
      return "";
  }
}
function df(t) {
  var e = t.type;
  return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio");
}
function Ng(t) {
  var e = df(t) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(t.constructor.prototype, e), a = "" + t[e];
  if (!t.hasOwnProperty(e) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
    var p = n.get, g = n.set;
    return Object.defineProperty(t, e, { configurable: !0, get: function() {
      return p.call(this);
    }, set: function(_) {
      a = "" + _, g.call(this, _);
    } }), Object.defineProperty(t, e, { enumerable: n.enumerable }), { getValue: function() {
      return a;
    }, setValue: function(_) {
      a = "" + _;
    }, stopTracking: function() {
      t._valueTracker = null, delete t[e];
    } };
  }
}
function wo(t) {
  t._valueTracker || (t._valueTracker = Ng(t));
}
function pf(t) {
  if (!t) return !1;
  var e = t._valueTracker;
  if (!e) return !0;
  var n = e.getValue(), a = "";
  return t && (a = df(t) ? t.checked ? "true" : "false" : t.value), t = a, t !== n ? (e.setValue(t), !0) : !1;
}
function ea(t) {
  if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
  try {
    return t.activeElement || t.body;
  } catch {
    return t.body;
  }
}
function zs(t, e) {
  var n = e.checked;
  return $t({}, e, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: n ?? t._wrapperState.initialChecked });
}
function hu(t, e) {
  var n = e.defaultValue == null ? "" : e.defaultValue, a = e.checked != null ? e.checked : e.defaultChecked;
  n = ai(e.value != null ? e.value : n), t._wrapperState = { initialChecked: a, initialValue: n, controlled: e.type === "checkbox" || e.type === "radio" ? e.checked != null : e.value != null };
}
function gf(t, e) {
  e = e.checked, e != null && jl(t, "checked", e, !1);
}
function Ws(t, e) {
  gf(t, e);
  var n = ai(e.value), a = e.type;
  if (n != null) a === "number" ? (n === 0 && t.value === "" || t.value != n) && (t.value = "" + n) : t.value !== "" + n && (t.value = "" + n);
  else if (a === "submit" || a === "reset") {
    t.removeAttribute("value");
    return;
  }
  e.hasOwnProperty("value") ? Xs(t, e.type, n) : e.hasOwnProperty("defaultValue") && Xs(t, e.type, ai(e.defaultValue)), e.checked == null && e.defaultChecked != null && (t.defaultChecked = !!e.defaultChecked);
}
function fu(t, e, n) {
  if (e.hasOwnProperty("value") || e.hasOwnProperty("defaultValue")) {
    var a = e.type;
    if (!(a !== "submit" && a !== "reset" || e.value !== void 0 && e.value !== null)) return;
    e = "" + t._wrapperState.initialValue, n || e === t.value || (t.value = e), t.defaultValue = e;
  }
  n = t.name, n !== "" && (t.name = ""), t.defaultChecked = !!t._wrapperState.initialChecked, n !== "" && (t.name = n);
}
function Xs(t, e, n) {
  (e !== "number" || ea(t.ownerDocument) !== t) && (n == null ? t.defaultValue = "" + t._wrapperState.initialValue : t.defaultValue !== "" + n && (t.defaultValue = "" + n));
}
var Pr = Array.isArray;
function qi(t, e, n, a) {
  if (t = t.options, e) {
    e = {};
    for (var p = 0; p < n.length; p++) e["$" + n[p]] = !0;
    for (n = 0; n < t.length; n++) p = e.hasOwnProperty("$" + t[n].value), t[n].selected !== p && (t[n].selected = p), p && a && (t[n].defaultSelected = !0);
  } else {
    for (n = "" + ai(n), e = null, p = 0; p < t.length; p++) {
      if (t[p].value === n) {
        t[p].selected = !0, a && (t[p].defaultSelected = !0);
        return;
      }
      e !== null || t[p].disabled || (e = t[p]);
    }
    e !== null && (e.selected = !0);
  }
}
function Ys(t, e) {
  if (e.dangerouslySetInnerHTML != null) throw Error(ut(91));
  return $t({}, e, { value: void 0, defaultValue: void 0, children: "" + t._wrapperState.initialValue });
}
function du(t, e) {
  var n = e.value;
  if (n == null) {
    if (n = e.children, e = e.defaultValue, n != null) {
      if (e != null) throw Error(ut(92));
      if (Pr(n)) {
        if (1 < n.length) throw Error(ut(93));
        n = n[0];
      }
      e = n;
    }
    e == null && (e = ""), n = e;
  }
  t._wrapperState = { initialValue: ai(n) };
}
function mf(t, e) {
  var n = ai(e.value), a = ai(e.defaultValue);
  n != null && (n = "" + n, n !== t.value && (t.value = n), e.defaultValue == null && t.defaultValue !== n && (t.defaultValue = n)), a != null && (t.defaultValue = "" + a);
}
function pu(t) {
  var e = t.textContent;
  e === t._wrapperState.initialValue && e !== "" && e !== null && (t.value = e);
}
function vf(t) {
  switch (t) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function Gs(t, e) {
  return t == null || t === "http://www.w3.org/1999/xhtml" ? vf(e) : t === "http://www.w3.org/2000/svg" && e === "foreignObject" ? "http://www.w3.org/1999/xhtml" : t;
}
var Co, yf = function(t) {
  return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(e, n, a, p) {
    MSApp.execUnsafeLocalFunction(function() {
      return t(e, n, a, p);
    });
  } : t;
}(function(t, e) {
  if (t.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in t) t.innerHTML = e;
  else {
    for (Co = Co || document.createElement("div"), Co.innerHTML = "<svg>" + e.valueOf().toString() + "</svg>", e = Co.firstChild; t.firstChild; ) t.removeChild(t.firstChild);
    for (; e.firstChild; ) t.appendChild(e.firstChild);
  }
});
function Yr(t, e) {
  if (e) {
    var n = t.firstChild;
    if (n && n === t.lastChild && n.nodeType === 3) {
      n.nodeValue = e;
      return;
    }
  }
  t.textContent = e;
}
var Lr = {
  animationIterationCount: !0,
  aspectRatio: !0,
  borderImageOutset: !0,
  borderImageSlice: !0,
  borderImageWidth: !0,
  boxFlex: !0,
  boxFlexGroup: !0,
  boxOrdinalGroup: !0,
  columnCount: !0,
  columns: !0,
  flex: !0,
  flexGrow: !0,
  flexPositive: !0,
  flexShrink: !0,
  flexNegative: !0,
  flexOrder: !0,
  gridArea: !0,
  gridRow: !0,
  gridRowEnd: !0,
  gridRowSpan: !0,
  gridRowStart: !0,
  gridColumn: !0,
  gridColumnEnd: !0,
  gridColumnSpan: !0,
  gridColumnStart: !0,
  fontWeight: !0,
  lineClamp: !0,
  lineHeight: !0,
  opacity: !0,
  order: !0,
  orphans: !0,
  tabSize: !0,
  widows: !0,
  zIndex: !0,
  zoom: !0,
  fillOpacity: !0,
  floodOpacity: !0,
  stopOpacity: !0,
  strokeDasharray: !0,
  strokeDashoffset: !0,
  strokeMiterlimit: !0,
  strokeOpacity: !0,
  strokeWidth: !0
}, Ug = ["Webkit", "ms", "Moz", "O"];
Object.keys(Lr).forEach(function(t) {
  Ug.forEach(function(e) {
    e = e + t.charAt(0).toUpperCase() + t.substring(1), Lr[e] = Lr[t];
  });
});
function _f(t, e, n) {
  return e == null || typeof e == "boolean" || e === "" ? "" : n || typeof e != "number" || e === 0 || Lr.hasOwnProperty(t) && Lr[t] ? ("" + e).trim() : e + "px";
}
function bf(t, e) {
  t = t.style;
  for (var n in e) if (e.hasOwnProperty(n)) {
    var a = n.indexOf("--") === 0, p = _f(n, e[n], a);
    n === "float" && (n = "cssFloat"), a ? t.setProperty(n, p) : t[n] = p;
  }
}
var zg = $t({ menuitem: !0 }, { area: !0, base: !0, br: !0, col: !0, embed: !0, hr: !0, img: !0, input: !0, keygen: !0, link: !0, meta: !0, param: !0, source: !0, track: !0, wbr: !0 });
function Hs(t, e) {
  if (e) {
    if (zg[t] && (e.children != null || e.dangerouslySetInnerHTML != null)) throw Error(ut(137, t));
    if (e.dangerouslySetInnerHTML != null) {
      if (e.children != null) throw Error(ut(60));
      if (typeof e.dangerouslySetInnerHTML != "object" || !("__html" in e.dangerouslySetInnerHTML)) throw Error(ut(61));
    }
    if (e.style != null && typeof e.style != "object") throw Error(ut(62));
  }
}
function Vs(t, e) {
  if (t.indexOf("-") === -1) return typeof e.is == "string";
  switch (t) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return !1;
    default:
      return !0;
  }
}
var Zs = null;
function Bl(t) {
  return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
}
var qs = null, Ki = null, Qi = null;
function gu(t) {
  if (t = co(t)) {
    if (typeof qs != "function") throw Error(ut(280));
    var e = t.stateNode;
    e && (e = La(e), qs(t.stateNode, t.type, e));
  }
}
function wf(t) {
  Ki ? Qi ? Qi.push(t) : Qi = [t] : Ki = t;
}
function Cf() {
  if (Ki) {
    var t = Ki, e = Qi;
    if (Qi = Ki = null, gu(t), e) for (t = 0; t < e.length; t++) gu(e[t]);
  }
}
function xf(t, e) {
  return t(e);
}
function Sf() {
}
var rs = !1;
function Tf(t, e, n) {
  if (rs) return t(e, n);
  rs = !0;
  try {
    return xf(t, e, n);
  } finally {
    rs = !1, (Ki !== null || Qi !== null) && (Sf(), Cf());
  }
}
function Gr(t, e) {
  var n = t.stateNode;
  if (n === null) return null;
  var a = La(n);
  if (a === null) return null;
  n = a[e];
  t: switch (e) {
    case "onClick":
    case "onClickCapture":
    case "onDoubleClick":
    case "onDoubleClickCapture":
    case "onMouseDown":
    case "onMouseDownCapture":
    case "onMouseMove":
    case "onMouseMoveCapture":
    case "onMouseUp":
    case "onMouseUpCapture":
    case "onMouseEnter":
      (a = !a.disabled) || (t = t.type, a = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !a;
      break t;
    default:
      t = !1;
  }
  if (t) return null;
  if (n && typeof n != "function") throw Error(ut(231, e, typeof n));
  return n;
}
var Ks = !1;
if (Bn) try {
  var Cr = {};
  Object.defineProperty(Cr, "passive", { get: function() {
    Ks = !0;
  } }), window.addEventListener("test", Cr, Cr), window.removeEventListener("test", Cr, Cr);
} catch {
  Ks = !1;
}
function Wg(t, e, n, a, p, g, _, w, x) {
  var T = Array.prototype.slice.call(arguments, 3);
  try {
    e.apply(n, T);
  } catch (L) {
    this.onError(L);
  }
}
var jr = !1, na = null, ia = !1, Qs = null, Xg = { onError: function(t) {
  jr = !0, na = t;
} };
function Yg(t, e, n, a, p, g, _, w, x) {
  jr = !1, na = null, Wg.apply(Xg, arguments);
}
function Gg(t, e, n, a, p, g, _, w, x) {
  if (Yg.apply(this, arguments), jr) {
    if (jr) {
      var T = na;
      jr = !1, na = null;
    } else throw Error(ut(198));
    ia || (ia = !0, Qs = T);
  }
}
function Mi(t) {
  var e = t, n = t;
  if (t.alternate) for (; e.return; ) e = e.return;
  else {
    t = e;
    do
      e = t, e.flags & 4098 && (n = e.return), t = e.return;
    while (t);
  }
  return e.tag === 3 ? n : null;
}
function Ef(t) {
  if (t.tag === 13) {
    var e = t.memoizedState;
    if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
  }
  return null;
}
function mu(t) {
  if (Mi(t) !== t) throw Error(ut(188));
}
function Hg(t) {
  var e = t.alternate;
  if (!e) {
    if (e = Mi(t), e === null) throw Error(ut(188));
    return e !== t ? null : t;
  }
  for (var n = t, a = e; ; ) {
    var p = n.return;
    if (p === null) break;
    var g = p.alternate;
    if (g === null) {
      if (a = p.return, a !== null) {
        n = a;
        continue;
      }
      break;
    }
    if (p.child === g.child) {
      for (g = p.child; g; ) {
        if (g === n) return mu(p), t;
        if (g === a) return mu(p), e;
        g = g.sibling;
      }
      throw Error(ut(188));
    }
    if (n.return !== a.return) n = p, a = g;
    else {
      for (var _ = !1, w = p.child; w; ) {
        if (w === n) {
          _ = !0, n = p, a = g;
          break;
        }
        if (w === a) {
          _ = !0, a = p, n = g;
          break;
        }
        w = w.sibling;
      }
      if (!_) {
        for (w = g.child; w; ) {
          if (w === n) {
            _ = !0, n = g, a = p;
            break;
          }
          if (w === a) {
            _ = !0, a = g, n = p;
            break;
          }
          w = w.sibling;
        }
        if (!_) throw Error(ut(189));
      }
    }
    if (n.alternate !== a) throw Error(ut(190));
  }
  if (n.tag !== 3) throw Error(ut(188));
  return n.stateNode.current === n ? t : e;
}
function kf(t) {
  return t = Hg(t), t !== null ? Of(t) : null;
}
function Of(t) {
  if (t.tag === 5 || t.tag === 6) return t;
  for (t = t.child; t !== null; ) {
    var e = Of(t);
    if (e !== null) return e;
    t = t.sibling;
  }
  return null;
}
var Mf = ze.unstable_scheduleCallback, vu = ze.unstable_cancelCallback, Vg = ze.unstable_shouldYield, Zg = ze.unstable_requestPaint, ne = ze.unstable_now, qg = ze.unstable_getCurrentPriorityLevel, Nl = ze.unstable_ImmediatePriority, Pf = ze.unstable_UserBlockingPriority, ra = ze.unstable_NormalPriority, Kg = ze.unstable_LowPriority, Af = ze.unstable_IdlePriority, Ma = null, En = null;
function Qg(t) {
  if (En && typeof En.onCommitFiberRoot == "function") try {
    En.onCommitFiberRoot(Ma, t, void 0, (t.current.flags & 128) === 128);
  } catch {
  }
}
var dn = Math.clz32 ? Math.clz32 : t1, Jg = Math.log, $g = Math.LN2;
function t1(t) {
  return t >>>= 0, t === 0 ? 32 : 31 - (Jg(t) / $g | 0) | 0;
}
var xo = 64, So = 4194304;
function Ar(t) {
  switch (t & -t) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return t & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return t & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return t;
  }
}
function oa(t, e) {
  var n = t.pendingLanes;
  if (n === 0) return 0;
  var a = 0, p = t.suspendedLanes, g = t.pingedLanes, _ = n & 268435455;
  if (_ !== 0) {
    var w = _ & ~p;
    w !== 0 ? a = Ar(w) : (g &= _, g !== 0 && (a = Ar(g)));
  } else _ = n & ~p, _ !== 0 ? a = Ar(_) : g !== 0 && (a = Ar(g));
  if (a === 0) return 0;
  if (e !== 0 && e !== a && !(e & p) && (p = a & -a, g = e & -e, p >= g || p === 16 && (g & 4194240) !== 0)) return e;
  if (a & 4 && (a |= n & 16), e = t.entangledLanes, e !== 0) for (t = t.entanglements, e &= a; 0 < e; ) n = 31 - dn(e), p = 1 << n, a |= t[n], e &= ~p;
  return a;
}
function e1(t, e) {
  switch (t) {
    case 1:
    case 2:
    case 4:
      return e + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return e + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function n1(t, e) {
  for (var n = t.suspendedLanes, a = t.pingedLanes, p = t.expirationTimes, g = t.pendingLanes; 0 < g; ) {
    var _ = 31 - dn(g), w = 1 << _, x = p[_];
    x === -1 ? (!(w & n) || w & a) && (p[_] = e1(w, e)) : x <= e && (t.expiredLanes |= w), g &= ~w;
  }
}
function Js(t) {
  return t = t.pendingLanes & -1073741825, t !== 0 ? t : t & 1073741824 ? 1073741824 : 0;
}
function Df() {
  var t = xo;
  return xo <<= 1, !(xo & 4194240) && (xo = 64), t;
}
function os(t) {
  for (var e = [], n = 0; 31 > n; n++) e.push(t);
  return e;
}
function so(t, e, n) {
  t.pendingLanes |= e, e !== 536870912 && (t.suspendedLanes = 0, t.pingedLanes = 0), t = t.eventTimes, e = 31 - dn(e), t[e] = n;
}
function i1(t, e) {
  var n = t.pendingLanes & ~e;
  t.pendingLanes = e, t.suspendedLanes = 0, t.pingedLanes = 0, t.expiredLanes &= e, t.mutableReadLanes &= e, t.entangledLanes &= e, e = t.entanglements;
  var a = t.eventTimes;
  for (t = t.expirationTimes; 0 < n; ) {
    var p = 31 - dn(n), g = 1 << p;
    e[p] = 0, a[p] = -1, t[p] = -1, n &= ~g;
  }
}
function Ul(t, e) {
  var n = t.entangledLanes |= e;
  for (t = t.entanglements; n; ) {
    var a = 31 - dn(n), p = 1 << a;
    p & e | t[a] & e && (t[a] |= e), n &= ~p;
  }
}
var Wt = 0;
function Lf(t) {
  return t &= -t, 1 < t ? 4 < t ? t & 268435455 ? 16 : 536870912 : 4 : 1;
}
var jf, zl, If, Ff, Rf, $s = !1, To = [], Jn = null, $n = null, ti = null, Hr = /* @__PURE__ */ new Map(), Vr = /* @__PURE__ */ new Map(), Vn = [], r1 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function yu(t, e) {
  switch (t) {
    case "focusin":
    case "focusout":
      Jn = null;
      break;
    case "dragenter":
    case "dragleave":
      $n = null;
      break;
    case "mouseover":
    case "mouseout":
      ti = null;
      break;
    case "pointerover":
    case "pointerout":
      Hr.delete(e.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Vr.delete(e.pointerId);
  }
}
function xr(t, e, n, a, p, g) {
  return t === null || t.nativeEvent !== g ? (t = { blockedOn: e, domEventName: n, eventSystemFlags: a, nativeEvent: g, targetContainers: [p] }, e !== null && (e = co(e), e !== null && zl(e)), t) : (t.eventSystemFlags |= a, e = t.targetContainers, p !== null && e.indexOf(p) === -1 && e.push(p), t);
}
function o1(t, e, n, a, p) {
  switch (e) {
    case "focusin":
      return Jn = xr(Jn, t, e, n, a, p), !0;
    case "dragenter":
      return $n = xr($n, t, e, n, a, p), !0;
    case "mouseover":
      return ti = xr(ti, t, e, n, a, p), !0;
    case "pointerover":
      var g = p.pointerId;
      return Hr.set(g, xr(Hr.get(g) || null, t, e, n, a, p)), !0;
    case "gotpointercapture":
      return g = p.pointerId, Vr.set(g, xr(Vr.get(g) || null, t, e, n, a, p)), !0;
  }
  return !1;
}
function Bf(t) {
  var e = yi(t.target);
  if (e !== null) {
    var n = Mi(e);
    if (n !== null) {
      if (e = n.tag, e === 13) {
        if (e = Ef(n), e !== null) {
          t.blockedOn = e, Rf(t.priority, function() {
            If(n);
          });
          return;
        }
      } else if (e === 3 && n.stateNode.current.memoizedState.isDehydrated) {
        t.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
        return;
      }
    }
  }
  t.blockedOn = null;
}
function Yo(t) {
  if (t.blockedOn !== null) return !1;
  for (var e = t.targetContainers; 0 < e.length; ) {
    var n = tl(t.domEventName, t.eventSystemFlags, e[0], t.nativeEvent);
    if (n === null) {
      n = t.nativeEvent;
      var a = new n.constructor(n.type, n);
      Zs = a, n.target.dispatchEvent(a), Zs = null;
    } else return e = co(n), e !== null && zl(e), t.blockedOn = n, !1;
    e.shift();
  }
  return !0;
}
function _u(t, e, n) {
  Yo(t) && n.delete(e);
}
function a1() {
  $s = !1, Jn !== null && Yo(Jn) && (Jn = null), $n !== null && Yo($n) && ($n = null), ti !== null && Yo(ti) && (ti = null), Hr.forEach(_u), Vr.forEach(_u);
}
function Sr(t, e) {
  t.blockedOn === e && (t.blockedOn = null, $s || ($s = !0, ze.unstable_scheduleCallback(ze.unstable_NormalPriority, a1)));
}
function Zr(t) {
  function e(p) {
    return Sr(p, t);
  }
  if (0 < To.length) {
    Sr(To[0], t);
    for (var n = 1; n < To.length; n++) {
      var a = To[n];
      a.blockedOn === t && (a.blockedOn = null);
    }
  }
  for (Jn !== null && Sr(Jn, t), $n !== null && Sr($n, t), ti !== null && Sr(ti, t), Hr.forEach(e), Vr.forEach(e), n = 0; n < Vn.length; n++) a = Vn[n], a.blockedOn === t && (a.blockedOn = null);
  for (; 0 < Vn.length && (n = Vn[0], n.blockedOn === null); ) Bf(n), n.blockedOn === null && Vn.shift();
}
var Ji = Wn.ReactCurrentBatchConfig, aa = !0;
function s1(t, e, n, a) {
  var p = Wt, g = Ji.transition;
  Ji.transition = null;
  try {
    Wt = 1, Wl(t, e, n, a);
  } finally {
    Wt = p, Ji.transition = g;
  }
}
function l1(t, e, n, a) {
  var p = Wt, g = Ji.transition;
  Ji.transition = null;
  try {
    Wt = 4, Wl(t, e, n, a);
  } finally {
    Wt = p, Ji.transition = g;
  }
}
function Wl(t, e, n, a) {
  if (aa) {
    var p = tl(t, e, n, a);
    if (p === null) gs(t, e, a, sa, n), yu(t, a);
    else if (o1(p, t, e, n, a)) a.stopPropagation();
    else if (yu(t, a), e & 4 && -1 < r1.indexOf(t)) {
      for (; p !== null; ) {
        var g = co(p);
        if (g !== null && jf(g), g = tl(t, e, n, a), g === null && gs(t, e, a, sa, n), g === p) break;
        p = g;
      }
      p !== null && a.stopPropagation();
    } else gs(t, e, a, null, n);
  }
}
var sa = null;
function tl(t, e, n, a) {
  if (sa = null, t = Bl(a), t = yi(t), t !== null) if (e = Mi(t), e === null) t = null;
  else if (n = e.tag, n === 13) {
    if (t = Ef(e), t !== null) return t;
    t = null;
  } else if (n === 3) {
    if (e.stateNode.current.memoizedState.isDehydrated) return e.tag === 3 ? e.stateNode.containerInfo : null;
    t = null;
  } else e !== t && (t = null);
  return sa = t, null;
}
function Nf(t) {
  switch (t) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (qg()) {
        case Nl:
          return 1;
        case Pf:
          return 4;
        case ra:
        case Kg:
          return 16;
        case Af:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var Kn = null, Xl = null, Go = null;
function Uf() {
  if (Go) return Go;
  var t, e = Xl, n = e.length, a, p = "value" in Kn ? Kn.value : Kn.textContent, g = p.length;
  for (t = 0; t < n && e[t] === p[t]; t++) ;
  var _ = n - t;
  for (a = 1; a <= _ && e[n - a] === p[g - a]; a++) ;
  return Go = p.slice(t, 1 < a ? 1 - a : void 0);
}
function Ho(t) {
  var e = t.keyCode;
  return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
}
function Eo() {
  return !0;
}
function bu() {
  return !1;
}
function Xe(t) {
  function e(n, a, p, g, _) {
    this._reactName = n, this._targetInst = p, this.type = a, this.nativeEvent = g, this.target = _, this.currentTarget = null;
    for (var w in t) t.hasOwnProperty(w) && (n = t[w], this[w] = n ? n(g) : g[w]);
    return this.isDefaultPrevented = (g.defaultPrevented != null ? g.defaultPrevented : g.returnValue === !1) ? Eo : bu, this.isPropagationStopped = bu, this;
  }
  return $t(e.prototype, { preventDefault: function() {
    this.defaultPrevented = !0;
    var n = this.nativeEvent;
    n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Eo);
  }, stopPropagation: function() {
    var n = this.nativeEvent;
    n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Eo);
  }, persist: function() {
  }, isPersistent: Eo }), e;
}
var ur = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(t) {
  return t.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, Yl = Xe(ur), lo = $t({}, ur, { view: 0, detail: 0 }), c1 = Xe(lo), as, ss, Tr, Pa = $t({}, lo, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: Gl, button: 0, buttons: 0, relatedTarget: function(t) {
  return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
}, movementX: function(t) {
  return "movementX" in t ? t.movementX : (t !== Tr && (Tr && t.type === "mousemove" ? (as = t.screenX - Tr.screenX, ss = t.screenY - Tr.screenY) : ss = as = 0, Tr = t), as);
}, movementY: function(t) {
  return "movementY" in t ? t.movementY : ss;
} }), wu = Xe(Pa), u1 = $t({}, Pa, { dataTransfer: 0 }), h1 = Xe(u1), f1 = $t({}, lo, { relatedTarget: 0 }), ls = Xe(f1), d1 = $t({}, ur, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), p1 = Xe(d1), g1 = $t({}, ur, { clipboardData: function(t) {
  return "clipboardData" in t ? t.clipboardData : window.clipboardData;
} }), m1 = Xe(g1), v1 = $t({}, ur, { data: 0 }), Cu = Xe(v1), y1 = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, _1 = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, b1 = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function w1(t) {
  var e = this.nativeEvent;
  return e.getModifierState ? e.getModifierState(t) : (t = b1[t]) ? !!e[t] : !1;
}
function Gl() {
  return w1;
}
var C1 = $t({}, lo, { key: function(t) {
  if (t.key) {
    var e = y1[t.key] || t.key;
    if (e !== "Unidentified") return e;
  }
  return t.type === "keypress" ? (t = Ho(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? _1[t.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: Gl, charCode: function(t) {
  return t.type === "keypress" ? Ho(t) : 0;
}, keyCode: function(t) {
  return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
}, which: function(t) {
  return t.type === "keypress" ? Ho(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
} }), x1 = Xe(C1), S1 = $t({}, Pa, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), xu = Xe(S1), T1 = $t({}, lo, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: Gl }), E1 = Xe(T1), k1 = $t({}, ur, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), O1 = Xe(k1), M1 = $t({}, Pa, {
  deltaX: function(t) {
    return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
  },
  deltaY: function(t) {
    return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), P1 = Xe(M1), A1 = [9, 13, 27, 32], Hl = Bn && "CompositionEvent" in window, Ir = null;
Bn && "documentMode" in document && (Ir = document.documentMode);
var D1 = Bn && "TextEvent" in window && !Ir, zf = Bn && (!Hl || Ir && 8 < Ir && 11 >= Ir), Su = " ", Tu = !1;
function Wf(t, e) {
  switch (t) {
    case "keyup":
      return A1.indexOf(e.keyCode) !== -1;
    case "keydown":
      return e.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return !0;
    default:
      return !1;
  }
}
function Xf(t) {
  return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
}
var Bi = !1;
function L1(t, e) {
  switch (t) {
    case "compositionend":
      return Xf(e);
    case "keypress":
      return e.which !== 32 ? null : (Tu = !0, Su);
    case "textInput":
      return t = e.data, t === Su && Tu ? null : t;
    default:
      return null;
  }
}
function j1(t, e) {
  if (Bi) return t === "compositionend" || !Hl && Wf(t, e) ? (t = Uf(), Go = Xl = Kn = null, Bi = !1, t) : null;
  switch (t) {
    case "paste":
      return null;
    case "keypress":
      if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
        if (e.char && 1 < e.char.length) return e.char;
        if (e.which) return String.fromCharCode(e.which);
      }
      return null;
    case "compositionend":
      return zf && e.locale !== "ko" ? null : e.data;
    default:
      return null;
  }
}
var I1 = { color: !0, date: !0, datetime: !0, "datetime-local": !0, email: !0, month: !0, number: !0, password: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0 };
function Eu(t) {
  var e = t && t.nodeName && t.nodeName.toLowerCase();
  return e === "input" ? !!I1[t.type] : e === "textarea";
}
function Yf(t, e, n, a) {
  wf(a), e = la(e, "onChange"), 0 < e.length && (n = new Yl("onChange", "change", null, n, a), t.push({ event: n, listeners: e }));
}
var Fr = null, qr = null;
function F1(t) {
  ed(t, 0);
}
function Aa(t) {
  var e = zi(t);
  if (pf(e)) return t;
}
function R1(t, e) {
  if (t === "change") return e;
}
var Gf = !1;
if (Bn) {
  var cs;
  if (Bn) {
    var us = "oninput" in document;
    if (!us) {
      var ku = document.createElement("div");
      ku.setAttribute("oninput", "return;"), us = typeof ku.oninput == "function";
    }
    cs = us;
  } else cs = !1;
  Gf = cs && (!document.documentMode || 9 < document.documentMode);
}
function Ou() {
  Fr && (Fr.detachEvent("onpropertychange", Hf), qr = Fr = null);
}
function Hf(t) {
  if (t.propertyName === "value" && Aa(qr)) {
    var e = [];
    Yf(e, qr, t, Bl(t)), Tf(F1, e);
  }
}
function B1(t, e, n) {
  t === "focusin" ? (Ou(), Fr = e, qr = n, Fr.attachEvent("onpropertychange", Hf)) : t === "focusout" && Ou();
}
function N1(t) {
  if (t === "selectionchange" || t === "keyup" || t === "keydown") return Aa(qr);
}
function U1(t, e) {
  if (t === "click") return Aa(e);
}
function z1(t, e) {
  if (t === "input" || t === "change") return Aa(e);
}
function W1(t, e) {
  return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e;
}
var gn = typeof Object.is == "function" ? Object.is : W1;
function Kr(t, e) {
  if (gn(t, e)) return !0;
  if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
  var n = Object.keys(t), a = Object.keys(e);
  if (n.length !== a.length) return !1;
  for (a = 0; a < n.length; a++) {
    var p = n[a];
    if (!Fs.call(e, p) || !gn(t[p], e[p])) return !1;
  }
  return !0;
}
function Mu(t) {
  for (; t && t.firstChild; ) t = t.firstChild;
  return t;
}
function Pu(t, e) {
  var n = Mu(t);
  t = 0;
  for (var a; n; ) {
    if (n.nodeType === 3) {
      if (a = t + n.textContent.length, t <= e && a >= e) return { node: n, offset: e - t };
      t = a;
    }
    t: {
      for (; n; ) {
        if (n.nextSibling) {
          n = n.nextSibling;
          break t;
        }
        n = n.parentNode;
      }
      n = void 0;
    }
    n = Mu(n);
  }
}
function Vf(t, e) {
  return t && e ? t === e ? !0 : t && t.nodeType === 3 ? !1 : e && e.nodeType === 3 ? Vf(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : !1 : !1;
}
function Zf() {
  for (var t = window, e = ea(); e instanceof t.HTMLIFrameElement; ) {
    try {
      var n = typeof e.contentWindow.location.href == "string";
    } catch {
      n = !1;
    }
    if (n) t = e.contentWindow;
    else break;
    e = ea(t.document);
  }
  return e;
}
function Vl(t) {
  var e = t && t.nodeName && t.nodeName.toLowerCase();
  return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true");
}
function X1(t) {
  var e = Zf(), n = t.focusedElem, a = t.selectionRange;
  if (e !== n && n && n.ownerDocument && Vf(n.ownerDocument.documentElement, n)) {
    if (a !== null && Vl(n)) {
      if (e = a.start, t = a.end, t === void 0 && (t = e), "selectionStart" in n) n.selectionStart = e, n.selectionEnd = Math.min(t, n.value.length);
      else if (t = (e = n.ownerDocument || document) && e.defaultView || window, t.getSelection) {
        t = t.getSelection();
        var p = n.textContent.length, g = Math.min(a.start, p);
        a = a.end === void 0 ? g : Math.min(a.end, p), !t.extend && g > a && (p = a, a = g, g = p), p = Pu(n, g);
        var _ = Pu(
          n,
          a
        );
        p && _ && (t.rangeCount !== 1 || t.anchorNode !== p.node || t.anchorOffset !== p.offset || t.focusNode !== _.node || t.focusOffset !== _.offset) && (e = e.createRange(), e.setStart(p.node, p.offset), t.removeAllRanges(), g > a ? (t.addRange(e), t.extend(_.node, _.offset)) : (e.setEnd(_.node, _.offset), t.addRange(e)));
      }
    }
    for (e = [], t = n; t = t.parentNode; ) t.nodeType === 1 && e.push({ element: t, left: t.scrollLeft, top: t.scrollTop });
    for (typeof n.focus == "function" && n.focus(), n = 0; n < e.length; n++) t = e[n], t.element.scrollLeft = t.left, t.element.scrollTop = t.top;
  }
}
var Y1 = Bn && "documentMode" in document && 11 >= document.documentMode, Ni = null, el = null, Rr = null, nl = !1;
function Au(t, e, n) {
  var a = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
  nl || Ni == null || Ni !== ea(a) || (a = Ni, "selectionStart" in a && Vl(a) ? a = { start: a.selectionStart, end: a.selectionEnd } : (a = (a.ownerDocument && a.ownerDocument.defaultView || window).getSelection(), a = { anchorNode: a.anchorNode, anchorOffset: a.anchorOffset, focusNode: a.focusNode, focusOffset: a.focusOffset }), Rr && Kr(Rr, a) || (Rr = a, a = la(el, "onSelect"), 0 < a.length && (e = new Yl("onSelect", "select", null, e, n), t.push({ event: e, listeners: a }), e.target = Ni)));
}
function ko(t, e) {
  var n = {};
  return n[t.toLowerCase()] = e.toLowerCase(), n["Webkit" + t] = "webkit" + e, n["Moz" + t] = "moz" + e, n;
}
var Ui = { animationend: ko("Animation", "AnimationEnd"), animationiteration: ko("Animation", "AnimationIteration"), animationstart: ko("Animation", "AnimationStart"), transitionend: ko("Transition", "TransitionEnd") }, hs = {}, qf = {};
Bn && (qf = document.createElement("div").style, "AnimationEvent" in window || (delete Ui.animationend.animation, delete Ui.animationiteration.animation, delete Ui.animationstart.animation), "TransitionEvent" in window || delete Ui.transitionend.transition);
function Da(t) {
  if (hs[t]) return hs[t];
  if (!Ui[t]) return t;
  var e = Ui[t], n;
  for (n in e) if (e.hasOwnProperty(n) && n in qf) return hs[t] = e[n];
  return t;
}
var Kf = Da("animationend"), Qf = Da("animationiteration"), Jf = Da("animationstart"), $f = Da("transitionend"), td = /* @__PURE__ */ new Map(), Du = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function li(t, e) {
  td.set(t, e), Oi(e, [t]);
}
for (var fs = 0; fs < Du.length; fs++) {
  var ds = Du[fs], G1 = ds.toLowerCase(), H1 = ds[0].toUpperCase() + ds.slice(1);
  li(G1, "on" + H1);
}
li(Kf, "onAnimationEnd");
li(Qf, "onAnimationIteration");
li(Jf, "onAnimationStart");
li("dblclick", "onDoubleClick");
li("focusin", "onFocus");
li("focusout", "onBlur");
li($f, "onTransitionEnd");
er("onMouseEnter", ["mouseout", "mouseover"]);
er("onMouseLeave", ["mouseout", "mouseover"]);
er("onPointerEnter", ["pointerout", "pointerover"]);
er("onPointerLeave", ["pointerout", "pointerover"]);
Oi("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Oi("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Oi("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Oi("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Oi("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Oi("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Dr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), V1 = new Set("cancel close invalid load scroll toggle".split(" ").concat(Dr));
function Lu(t, e, n) {
  var a = t.type || "unknown-event";
  t.currentTarget = n, Gg(a, e, void 0, t), t.currentTarget = null;
}
function ed(t, e) {
  e = (e & 4) !== 0;
  for (var n = 0; n < t.length; n++) {
    var a = t[n], p = a.event;
    a = a.listeners;
    t: {
      var g = void 0;
      if (e) for (var _ = a.length - 1; 0 <= _; _--) {
        var w = a[_], x = w.instance, T = w.currentTarget;
        if (w = w.listener, x !== g && p.isPropagationStopped()) break t;
        Lu(p, w, T), g = x;
      }
      else for (_ = 0; _ < a.length; _++) {
        if (w = a[_], x = w.instance, T = w.currentTarget, w = w.listener, x !== g && p.isPropagationStopped()) break t;
        Lu(p, w, T), g = x;
      }
    }
  }
  if (ia) throw t = Qs, ia = !1, Qs = null, t;
}
function Vt(t, e) {
  var n = e[sl];
  n === void 0 && (n = e[sl] = /* @__PURE__ */ new Set());
  var a = t + "__bubble";
  n.has(a) || (nd(e, t, 2, !1), n.add(a));
}
function ps(t, e, n) {
  var a = 0;
  e && (a |= 4), nd(n, t, a, e);
}
var Oo = "_reactListening" + Math.random().toString(36).slice(2);
function Qr(t) {
  if (!t[Oo]) {
    t[Oo] = !0, cf.forEach(function(n) {
      n !== "selectionchange" && (V1.has(n) || ps(n, !1, t), ps(n, !0, t));
    });
    var e = t.nodeType === 9 ? t : t.ownerDocument;
    e === null || e[Oo] || (e[Oo] = !0, ps("selectionchange", !1, e));
  }
}
function nd(t, e, n, a) {
  switch (Nf(e)) {
    case 1:
      var p = s1;
      break;
    case 4:
      p = l1;
      break;
    default:
      p = Wl;
  }
  n = p.bind(null, e, n, t), p = void 0, !Ks || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (p = !0), a ? p !== void 0 ? t.addEventListener(e, n, { capture: !0, passive: p }) : t.addEventListener(e, n, !0) : p !== void 0 ? t.addEventListener(e, n, { passive: p }) : t.addEventListener(e, n, !1);
}
function gs(t, e, n, a, p) {
  var g = a;
  if (!(e & 1) && !(e & 2) && a !== null) t: for (; ; ) {
    if (a === null) return;
    var _ = a.tag;
    if (_ === 3 || _ === 4) {
      var w = a.stateNode.containerInfo;
      if (w === p || w.nodeType === 8 && w.parentNode === p) break;
      if (_ === 4) for (_ = a.return; _ !== null; ) {
        var x = _.tag;
        if ((x === 3 || x === 4) && (x = _.stateNode.containerInfo, x === p || x.nodeType === 8 && x.parentNode === p)) return;
        _ = _.return;
      }
      for (; w !== null; ) {
        if (_ = yi(w), _ === null) return;
        if (x = _.tag, x === 5 || x === 6) {
          a = g = _;
          continue t;
        }
        w = w.parentNode;
      }
    }
    a = a.return;
  }
  Tf(function() {
    var T = g, L = Bl(n), X = [];
    t: {
      var G = td.get(t);
      if (G !== void 0) {
        var J = Yl, et = t;
        switch (t) {
          case "keypress":
            if (Ho(n) === 0) break t;
          case "keydown":
          case "keyup":
            J = x1;
            break;
          case "focusin":
            et = "focus", J = ls;
            break;
          case "focusout":
            et = "blur", J = ls;
            break;
          case "beforeblur":
          case "afterblur":
            J = ls;
            break;
          case "click":
            if (n.button === 2) break t;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            J = wu;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            J = h1;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            J = E1;
            break;
          case Kf:
          case Qf:
          case Jf:
            J = p1;
            break;
          case $f:
            J = O1;
            break;
          case "scroll":
            J = c1;
            break;
          case "wheel":
            J = P1;
            break;
          case "copy":
          case "cut":
          case "paste":
            J = m1;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            J = xu;
        }
        var rt = (e & 4) !== 0, vt = !rt && t === "scroll", Y = rt ? G !== null ? G + "Capture" : null : G;
        rt = [];
        for (var j = T, P; j !== null; ) {
          P = j;
          var $ = P.stateNode;
          if (P.tag === 5 && $ !== null && (P = $, Y !== null && ($ = Gr(j, Y), $ != null && rt.push(Jr(j, $, P)))), vt) break;
          j = j.return;
        }
        0 < rt.length && (G = new J(G, et, null, n, L), X.push({ event: G, listeners: rt }));
      }
    }
    if (!(e & 7)) {
      t: {
        if (G = t === "mouseover" || t === "pointerover", J = t === "mouseout" || t === "pointerout", G && n !== Zs && (et = n.relatedTarget || n.fromElement) && (yi(et) || et[Nn])) break t;
        if ((J || G) && (G = L.window === L ? L : (G = L.ownerDocument) ? G.defaultView || G.parentWindow : window, J ? (et = n.relatedTarget || n.toElement, J = T, et = et ? yi(et) : null, et !== null && (vt = Mi(et), et !== vt || et.tag !== 5 && et.tag !== 6) && (et = null)) : (J = null, et = T), J !== et)) {
          if (rt = wu, $ = "onMouseLeave", Y = "onMouseEnter", j = "mouse", (t === "pointerout" || t === "pointerover") && (rt = xu, $ = "onPointerLeave", Y = "onPointerEnter", j = "pointer"), vt = J == null ? G : zi(J), P = et == null ? G : zi(et), G = new rt($, j + "leave", J, n, L), G.target = vt, G.relatedTarget = P, $ = null, yi(L) === T && (rt = new rt(Y, j + "enter", et, n, L), rt.target = P, rt.relatedTarget = vt, $ = rt), vt = $, J && et) e: {
            for (rt = J, Y = et, j = 0, P = rt; P; P = ji(P)) j++;
            for (P = 0, $ = Y; $; $ = ji($)) P++;
            for (; 0 < j - P; ) rt = ji(rt), j--;
            for (; 0 < P - j; ) Y = ji(Y), P--;
            for (; j--; ) {
              if (rt === Y || Y !== null && rt === Y.alternate) break e;
              rt = ji(rt), Y = ji(Y);
            }
            rt = null;
          }
          else rt = null;
          J !== null && ju(X, G, J, rt, !1), et !== null && vt !== null && ju(X, vt, et, rt, !0);
        }
      }
      t: {
        if (G = T ? zi(T) : window, J = G.nodeName && G.nodeName.toLowerCase(), J === "select" || J === "input" && G.type === "file") var ht = R1;
        else if (Eu(G)) if (Gf) ht = z1;
        else {
          ht = N1;
          var it = B1;
        }
        else (J = G.nodeName) && J.toLowerCase() === "input" && (G.type === "checkbox" || G.type === "radio") && (ht = U1);
        if (ht && (ht = ht(t, T))) {
          Yf(X, ht, n, L);
          break t;
        }
        it && it(t, G, T), t === "focusout" && (it = G._wrapperState) && it.controlled && G.type === "number" && Xs(G, "number", G.value);
      }
      switch (it = T ? zi(T) : window, t) {
        case "focusin":
          (Eu(it) || it.contentEditable === "true") && (Ni = it, el = T, Rr = null);
          break;
        case "focusout":
          Rr = el = Ni = null;
          break;
        case "mousedown":
          nl = !0;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          nl = !1, Au(X, n, L);
          break;
        case "selectionchange":
          if (Y1) break;
        case "keydown":
        case "keyup":
          Au(X, n, L);
      }
      var dt;
      if (Hl) t: {
        switch (t) {
          case "compositionstart":
            var v = "onCompositionStart";
            break t;
          case "compositionend":
            v = "onCompositionEnd";
            break t;
          case "compositionupdate":
            v = "onCompositionUpdate";
            break t;
        }
        v = void 0;
      }
      else Bi ? Wf(t, n) && (v = "onCompositionEnd") : t === "keydown" && n.keyCode === 229 && (v = "onCompositionStart");
      v && (zf && n.locale !== "ko" && (Bi || v !== "onCompositionStart" ? v === "onCompositionEnd" && Bi && (dt = Uf()) : (Kn = L, Xl = "value" in Kn ? Kn.value : Kn.textContent, Bi = !0)), it = la(T, v), 0 < it.length && (v = new Cu(v, t, null, n, L), X.push({ event: v, listeners: it }), dt ? v.data = dt : (dt = Xf(n), dt !== null && (v.data = dt)))), (dt = D1 ? L1(t, n) : j1(t, n)) && (T = la(T, "onBeforeInput"), 0 < T.length && (L = new Cu("onBeforeInput", "beforeinput", null, n, L), X.push({ event: L, listeners: T }), L.data = dt));
    }
    ed(X, e);
  });
}
function Jr(t, e, n) {
  return { instance: t, listener: e, currentTarget: n };
}
function la(t, e) {
  for (var n = e + "Capture", a = []; t !== null; ) {
    var p = t, g = p.stateNode;
    p.tag === 5 && g !== null && (p = g, g = Gr(t, n), g != null && a.unshift(Jr(t, g, p)), g = Gr(t, e), g != null && a.push(Jr(t, g, p))), t = t.return;
  }
  return a;
}
function ji(t) {
  if (t === null) return null;
  do
    t = t.return;
  while (t && t.tag !== 5);
  return t || null;
}
function ju(t, e, n, a, p) {
  for (var g = e._reactName, _ = []; n !== null && n !== a; ) {
    var w = n, x = w.alternate, T = w.stateNode;
    if (x !== null && x === a) break;
    w.tag === 5 && T !== null && (w = T, p ? (x = Gr(n, g), x != null && _.unshift(Jr(n, x, w))) : p || (x = Gr(n, g), x != null && _.push(Jr(n, x, w)))), n = n.return;
  }
  _.length !== 0 && t.push({ event: e, listeners: _ });
}
var Z1 = /\r\n?/g, q1 = /\u0000|\uFFFD/g;
function Iu(t) {
  return (typeof t == "string" ? t : "" + t).replace(Z1, `
`).replace(q1, "");
}
function Mo(t, e, n) {
  if (e = Iu(e), Iu(t) !== e && n) throw Error(ut(425));
}
function ca() {
}
var il = null, rl = null;
function ol(t, e) {
  return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null;
}
var al = typeof setTimeout == "function" ? setTimeout : void 0, K1 = typeof clearTimeout == "function" ? clearTimeout : void 0, Fu = typeof Promise == "function" ? Promise : void 0, Q1 = typeof queueMicrotask == "function" ? queueMicrotask : typeof Fu < "u" ? function(t) {
  return Fu.resolve(null).then(t).catch(J1);
} : al;
function J1(t) {
  setTimeout(function() {
    throw t;
  });
}
function ms(t, e) {
  var n = e, a = 0;
  do {
    var p = n.nextSibling;
    if (t.removeChild(n), p && p.nodeType === 8) if (n = p.data, n === "/$") {
      if (a === 0) {
        t.removeChild(p), Zr(e);
        return;
      }
      a--;
    } else n !== "$" && n !== "$?" && n !== "$!" || a++;
    n = p;
  } while (n);
  Zr(e);
}
function ei(t) {
  for (; t != null; t = t.nextSibling) {
    var e = t.nodeType;
    if (e === 1 || e === 3) break;
    if (e === 8) {
      if (e = t.data, e === "$" || e === "$!" || e === "$?") break;
      if (e === "/$") return null;
    }
  }
  return t;
}
function Ru(t) {
  t = t.previousSibling;
  for (var e = 0; t; ) {
    if (t.nodeType === 8) {
      var n = t.data;
      if (n === "$" || n === "$!" || n === "$?") {
        if (e === 0) return t;
        e--;
      } else n === "/$" && e++;
    }
    t = t.previousSibling;
  }
  return null;
}
var hr = Math.random().toString(36).slice(2), wn = "__reactFiber$" + hr, $r = "__reactProps$" + hr, Nn = "__reactContainer$" + hr, sl = "__reactEvents$" + hr, $1 = "__reactListeners$" + hr, tm = "__reactHandles$" + hr;
function yi(t) {
  var e = t[wn];
  if (e) return e;
  for (var n = t.parentNode; n; ) {
    if (e = n[Nn] || n[wn]) {
      if (n = e.alternate, e.child !== null || n !== null && n.child !== null) for (t = Ru(t); t !== null; ) {
        if (n = t[wn]) return n;
        t = Ru(t);
      }
      return e;
    }
    t = n, n = t.parentNode;
  }
  return null;
}
function co(t) {
  return t = t[wn] || t[Nn], !t || t.tag !== 5 && t.tag !== 6 && t.tag !== 13 && t.tag !== 3 ? null : t;
}
function zi(t) {
  if (t.tag === 5 || t.tag === 6) return t.stateNode;
  throw Error(ut(33));
}
function La(t) {
  return t[$r] || null;
}
var ll = [], Wi = -1;
function ci(t) {
  return { current: t };
}
function Zt(t) {
  0 > Wi || (t.current = ll[Wi], ll[Wi] = null, Wi--);
}
function Gt(t, e) {
  Wi++, ll[Wi] = t.current, t.current = e;
}
var si = {}, _e = ci(si), De = ci(!1), xi = si;
function nr(t, e) {
  var n = t.type.contextTypes;
  if (!n) return si;
  var a = t.stateNode;
  if (a && a.__reactInternalMemoizedUnmaskedChildContext === e) return a.__reactInternalMemoizedMaskedChildContext;
  var p = {}, g;
  for (g in n) p[g] = e[g];
  return a && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = e, t.__reactInternalMemoizedMaskedChildContext = p), p;
}
function Le(t) {
  return t = t.childContextTypes, t != null;
}
function ua() {
  Zt(De), Zt(_e);
}
function Bu(t, e, n) {
  if (_e.current !== si) throw Error(ut(168));
  Gt(_e, e), Gt(De, n);
}
function id(t, e, n) {
  var a = t.stateNode;
  if (e = e.childContextTypes, typeof a.getChildContext != "function") return n;
  a = a.getChildContext();
  for (var p in a) if (!(p in e)) throw Error(ut(108, Bg(t) || "Unknown", p));
  return $t({}, n, a);
}
function ha(t) {
  return t = (t = t.stateNode) && t.__reactInternalMemoizedMergedChildContext || si, xi = _e.current, Gt(_e, t), Gt(De, De.current), !0;
}
function Nu(t, e, n) {
  var a = t.stateNode;
  if (!a) throw Error(ut(169));
  n ? (t = id(t, e, xi), a.__reactInternalMemoizedMergedChildContext = t, Zt(De), Zt(_e), Gt(_e, t)) : Zt(De), Gt(De, n);
}
var Ln = null, ja = !1, vs = !1;
function rd(t) {
  Ln === null ? Ln = [t] : Ln.push(t);
}
function em(t) {
  ja = !0, rd(t);
}
function ui() {
  if (!vs && Ln !== null) {
    vs = !0;
    var t = 0, e = Wt;
    try {
      var n = Ln;
      for (Wt = 1; t < n.length; t++) {
        var a = n[t];
        do
          a = a(!0);
        while (a !== null);
      }
      Ln = null, ja = !1;
    } catch (p) {
      throw Ln !== null && (Ln = Ln.slice(t + 1)), Mf(Nl, ui), p;
    } finally {
      Wt = e, vs = !1;
    }
  }
  return null;
}
var Xi = [], Yi = 0, fa = null, da = 0, Ve = [], Ze = 0, Si = null, jn = 1, In = "";
function gi(t, e) {
  Xi[Yi++] = da, Xi[Yi++] = fa, fa = t, da = e;
}
function od(t, e, n) {
  Ve[Ze++] = jn, Ve[Ze++] = In, Ve[Ze++] = Si, Si = t;
  var a = jn;
  t = In;
  var p = 32 - dn(a) - 1;
  a &= ~(1 << p), n += 1;
  var g = 32 - dn(e) + p;
  if (30 < g) {
    var _ = p - p % 5;
    g = (a & (1 << _) - 1).toString(32), a >>= _, p -= _, jn = 1 << 32 - dn(e) + p | n << p | a, In = g + t;
  } else jn = 1 << g | n << p | a, In = t;
}
function Zl(t) {
  t.return !== null && (gi(t, 1), od(t, 1, 0));
}
function ql(t) {
  for (; t === fa; ) fa = Xi[--Yi], Xi[Yi] = null, da = Xi[--Yi], Xi[Yi] = null;
  for (; t === Si; ) Si = Ve[--Ze], Ve[Ze] = null, In = Ve[--Ze], Ve[Ze] = null, jn = Ve[--Ze], Ve[Ze] = null;
}
var Ne = null, Be = null, qt = !1, un = null;
function ad(t, e) {
  var n = Ke(5, null, null, 0);
  n.elementType = "DELETED", n.stateNode = e, n.return = t, e = t.deletions, e === null ? (t.deletions = [n], t.flags |= 16) : e.push(n);
}
function Uu(t, e) {
  switch (t.tag) {
    case 5:
      var n = t.type;
      return e = e.nodeType !== 1 || n.toLowerCase() !== e.nodeName.toLowerCase() ? null : e, e !== null ? (t.stateNode = e, Ne = t, Be = ei(e.firstChild), !0) : !1;
    case 6:
      return e = t.pendingProps === "" || e.nodeType !== 3 ? null : e, e !== null ? (t.stateNode = e, Ne = t, Be = null, !0) : !1;
    case 13:
      return e = e.nodeType !== 8 ? null : e, e !== null ? (n = Si !== null ? { id: jn, overflow: In } : null, t.memoizedState = { dehydrated: e, treeContext: n, retryLane: 1073741824 }, n = Ke(18, null, null, 0), n.stateNode = e, n.return = t, t.child = n, Ne = t, Be = null, !0) : !1;
    default:
      return !1;
  }
}
function cl(t) {
  return (t.mode & 1) !== 0 && (t.flags & 128) === 0;
}
function ul(t) {
  if (qt) {
    var e = Be;
    if (e) {
      var n = e;
      if (!Uu(t, e)) {
        if (cl(t)) throw Error(ut(418));
        e = ei(n.nextSibling);
        var a = Ne;
        e && Uu(t, e) ? ad(a, n) : (t.flags = t.flags & -4097 | 2, qt = !1, Ne = t);
      }
    } else {
      if (cl(t)) throw Error(ut(418));
      t.flags = t.flags & -4097 | 2, qt = !1, Ne = t;
    }
  }
}
function zu(t) {
  for (t = t.return; t !== null && t.tag !== 5 && t.tag !== 3 && t.tag !== 13; ) t = t.return;
  Ne = t;
}
function Po(t) {
  if (t !== Ne) return !1;
  if (!qt) return zu(t), qt = !0, !1;
  var e;
  if ((e = t.tag !== 3) && !(e = t.tag !== 5) && (e = t.type, e = e !== "head" && e !== "body" && !ol(t.type, t.memoizedProps)), e && (e = Be)) {
    if (cl(t)) throw sd(), Error(ut(418));
    for (; e; ) ad(t, e), e = ei(e.nextSibling);
  }
  if (zu(t), t.tag === 13) {
    if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(ut(317));
    t: {
      for (t = t.nextSibling, e = 0; t; ) {
        if (t.nodeType === 8) {
          var n = t.data;
          if (n === "/$") {
            if (e === 0) {
              Be = ei(t.nextSibling);
              break t;
            }
            e--;
          } else n !== "$" && n !== "$!" && n !== "$?" || e++;
        }
        t = t.nextSibling;
      }
      Be = null;
    }
  } else Be = Ne ? ei(t.stateNode.nextSibling) : null;
  return !0;
}
function sd() {
  for (var t = Be; t; ) t = ei(t.nextSibling);
}
function ir() {
  Be = Ne = null, qt = !1;
}
function Kl(t) {
  un === null ? un = [t] : un.push(t);
}
var nm = Wn.ReactCurrentBatchConfig;
function Er(t, e, n) {
  if (t = n.ref, t !== null && typeof t != "function" && typeof t != "object") {
    if (n._owner) {
      if (n = n._owner, n) {
        if (n.tag !== 1) throw Error(ut(309));
        var a = n.stateNode;
      }
      if (!a) throw Error(ut(147, t));
      var p = a, g = "" + t;
      return e !== null && e.ref !== null && typeof e.ref == "function" && e.ref._stringRef === g ? e.ref : (e = function(_) {
        var w = p.refs;
        _ === null ? delete w[g] : w[g] = _;
      }, e._stringRef = g, e);
    }
    if (typeof t != "string") throw Error(ut(284));
    if (!n._owner) throw Error(ut(290, t));
  }
  return t;
}
function Ao(t, e) {
  throw t = Object.prototype.toString.call(e), Error(ut(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t));
}
function Wu(t) {
  var e = t._init;
  return e(t._payload);
}
function ld(t) {
  function e(Y, j) {
    if (t) {
      var P = Y.deletions;
      P === null ? (Y.deletions = [j], Y.flags |= 16) : P.push(j);
    }
  }
  function n(Y, j) {
    if (!t) return null;
    for (; j !== null; ) e(Y, j), j = j.sibling;
    return null;
  }
  function a(Y, j) {
    for (Y = /* @__PURE__ */ new Map(); j !== null; ) j.key !== null ? Y.set(j.key, j) : Y.set(j.index, j), j = j.sibling;
    return Y;
  }
  function p(Y, j) {
    return Y = oi(Y, j), Y.index = 0, Y.sibling = null, Y;
  }
  function g(Y, j, P) {
    return Y.index = P, t ? (P = Y.alternate, P !== null ? (P = P.index, P < j ? (Y.flags |= 2, j) : P) : (Y.flags |= 2, j)) : (Y.flags |= 1048576, j);
  }
  function _(Y) {
    return t && Y.alternate === null && (Y.flags |= 2), Y;
  }
  function w(Y, j, P, $) {
    return j === null || j.tag !== 6 ? (j = Ss(P, Y.mode, $), j.return = Y, j) : (j = p(j, P), j.return = Y, j);
  }
  function x(Y, j, P, $) {
    var ht = P.type;
    return ht === Ri ? L(Y, j, P.props.children, $, P.key) : j !== null && (j.elementType === ht || typeof ht == "object" && ht !== null && ht.$$typeof === Gn && Wu(ht) === j.type) ? ($ = p(j, P.props), $.ref = Er(Y, j, P), $.return = Y, $) : ($ = $o(P.type, P.key, P.props, null, Y.mode, $), $.ref = Er(Y, j, P), $.return = Y, $);
  }
  function T(Y, j, P, $) {
    return j === null || j.tag !== 4 || j.stateNode.containerInfo !== P.containerInfo || j.stateNode.implementation !== P.implementation ? (j = Ts(P, Y.mode, $), j.return = Y, j) : (j = p(j, P.children || []), j.return = Y, j);
  }
  function L(Y, j, P, $, ht) {
    return j === null || j.tag !== 7 ? (j = Ci(P, Y.mode, $, ht), j.return = Y, j) : (j = p(j, P), j.return = Y, j);
  }
  function X(Y, j, P) {
    if (typeof j == "string" && j !== "" || typeof j == "number") return j = Ss("" + j, Y.mode, P), j.return = Y, j;
    if (typeof j == "object" && j !== null) {
      switch (j.$$typeof) {
        case bo:
          return P = $o(j.type, j.key, j.props, null, Y.mode, P), P.ref = Er(Y, null, j), P.return = Y, P;
        case Fi:
          return j = Ts(j, Y.mode, P), j.return = Y, j;
        case Gn:
          var $ = j._init;
          return X(Y, $(j._payload), P);
      }
      if (Pr(j) || wr(j)) return j = Ci(j, Y.mode, P, null), j.return = Y, j;
      Ao(Y, j);
    }
    return null;
  }
  function G(Y, j, P, $) {
    var ht = j !== null ? j.key : null;
    if (typeof P == "string" && P !== "" || typeof P == "number") return ht !== null ? null : w(Y, j, "" + P, $);
    if (typeof P == "object" && P !== null) {
      switch (P.$$typeof) {
        case bo:
          return P.key === ht ? x(Y, j, P, $) : null;
        case Fi:
          return P.key === ht ? T(Y, j, P, $) : null;
        case Gn:
          return ht = P._init, G(
            Y,
            j,
            ht(P._payload),
            $
          );
      }
      if (Pr(P) || wr(P)) return ht !== null ? null : L(Y, j, P, $, null);
      Ao(Y, P);
    }
    return null;
  }
  function J(Y, j, P, $, ht) {
    if (typeof $ == "string" && $ !== "" || typeof $ == "number") return Y = Y.get(P) || null, w(j, Y, "" + $, ht);
    if (typeof $ == "object" && $ !== null) {
      switch ($.$$typeof) {
        case bo:
          return Y = Y.get($.key === null ? P : $.key) || null, x(j, Y, $, ht);
        case Fi:
          return Y = Y.get($.key === null ? P : $.key) || null, T(j, Y, $, ht);
        case Gn:
          var it = $._init;
          return J(Y, j, P, it($._payload), ht);
      }
      if (Pr($) || wr($)) return Y = Y.get(P) || null, L(j, Y, $, ht, null);
      Ao(j, $);
    }
    return null;
  }
  function et(Y, j, P, $) {
    for (var ht = null, it = null, dt = j, v = j = 0, Tt = null; dt !== null && v < P.length; v++) {
      dt.index > v ? (Tt = dt, dt = null) : Tt = dt.sibling;
      var I = G(Y, dt, P[v], $);
      if (I === null) {
        dt === null && (dt = Tt);
        break;
      }
      t && dt && I.alternate === null && e(Y, dt), j = g(I, j, v), it === null ? ht = I : it.sibling = I, it = I, dt = Tt;
    }
    if (v === P.length) return n(Y, dt), qt && gi(Y, v), ht;
    if (dt === null) {
      for (; v < P.length; v++) dt = X(Y, P[v], $), dt !== null && (j = g(dt, j, v), it === null ? ht = dt : it.sibling = dt, it = dt);
      return qt && gi(Y, v), ht;
    }
    for (dt = a(Y, dt); v < P.length; v++) Tt = J(dt, Y, v, P[v], $), Tt !== null && (t && Tt.alternate !== null && dt.delete(Tt.key === null ? v : Tt.key), j = g(Tt, j, v), it === null ? ht = Tt : it.sibling = Tt, it = Tt);
    return t && dt.forEach(function(Et) {
      return e(Y, Et);
    }), qt && gi(Y, v), ht;
  }
  function rt(Y, j, P, $) {
    var ht = wr(P);
    if (typeof ht != "function") throw Error(ut(150));
    if (P = ht.call(P), P == null) throw Error(ut(151));
    for (var it = ht = null, dt = j, v = j = 0, Tt = null, I = P.next(); dt !== null && !I.done; v++, I = P.next()) {
      dt.index > v ? (Tt = dt, dt = null) : Tt = dt.sibling;
      var Et = G(Y, dt, I.value, $);
      if (Et === null) {
        dt === null && (dt = Tt);
        break;
      }
      t && dt && Et.alternate === null && e(Y, dt), j = g(Et, j, v), it === null ? ht = Et : it.sibling = Et, it = Et, dt = Tt;
    }
    if (I.done) return n(
      Y,
      dt
    ), qt && gi(Y, v), ht;
    if (dt === null) {
      for (; !I.done; v++, I = P.next()) I = X(Y, I.value, $), I !== null && (j = g(I, j, v), it === null ? ht = I : it.sibling = I, it = I);
      return qt && gi(Y, v), ht;
    }
    for (dt = a(Y, dt); !I.done; v++, I = P.next()) I = J(dt, Y, v, I.value, $), I !== null && (t && I.alternate !== null && dt.delete(I.key === null ? v : I.key), j = g(I, j, v), it === null ? ht = I : it.sibling = I, it = I);
    return t && dt.forEach(function(Xt) {
      return e(Y, Xt);
    }), qt && gi(Y, v), ht;
  }
  function vt(Y, j, P, $) {
    if (typeof P == "object" && P !== null && P.type === Ri && P.key === null && (P = P.props.children), typeof P == "object" && P !== null) {
      switch (P.$$typeof) {
        case bo:
          t: {
            for (var ht = P.key, it = j; it !== null; ) {
              if (it.key === ht) {
                if (ht = P.type, ht === Ri) {
                  if (it.tag === 7) {
                    n(Y, it.sibling), j = p(it, P.props.children), j.return = Y, Y = j;
                    break t;
                  }
                } else if (it.elementType === ht || typeof ht == "object" && ht !== null && ht.$$typeof === Gn && Wu(ht) === it.type) {
                  n(Y, it.sibling), j = p(it, P.props), j.ref = Er(Y, it, P), j.return = Y, Y = j;
                  break t;
                }
                n(Y, it);
                break;
              } else e(Y, it);
              it = it.sibling;
            }
            P.type === Ri ? (j = Ci(P.props.children, Y.mode, $, P.key), j.return = Y, Y = j) : ($ = $o(P.type, P.key, P.props, null, Y.mode, $), $.ref = Er(Y, j, P), $.return = Y, Y = $);
          }
          return _(Y);
        case Fi:
          t: {
            for (it = P.key; j !== null; ) {
              if (j.key === it) if (j.tag === 4 && j.stateNode.containerInfo === P.containerInfo && j.stateNode.implementation === P.implementation) {
                n(Y, j.sibling), j = p(j, P.children || []), j.return = Y, Y = j;
                break t;
              } else {
                n(Y, j);
                break;
              }
              else e(Y, j);
              j = j.sibling;
            }
            j = Ts(P, Y.mode, $), j.return = Y, Y = j;
          }
          return _(Y);
        case Gn:
          return it = P._init, vt(Y, j, it(P._payload), $);
      }
      if (Pr(P)) return et(Y, j, P, $);
      if (wr(P)) return rt(Y, j, P, $);
      Ao(Y, P);
    }
    return typeof P == "string" && P !== "" || typeof P == "number" ? (P = "" + P, j !== null && j.tag === 6 ? (n(Y, j.sibling), j = p(j, P), j.return = Y, Y = j) : (n(Y, j), j = Ss(P, Y.mode, $), j.return = Y, Y = j), _(Y)) : n(Y, j);
  }
  return vt;
}
var rr = ld(!0), cd = ld(!1), pa = ci(null), ga = null, Gi = null, Ql = null;
function Jl() {
  Ql = Gi = ga = null;
}
function $l(t) {
  var e = pa.current;
  Zt(pa), t._currentValue = e;
}
function hl(t, e, n) {
  for (; t !== null; ) {
    var a = t.alternate;
    if ((t.childLanes & e) !== e ? (t.childLanes |= e, a !== null && (a.childLanes |= e)) : a !== null && (a.childLanes & e) !== e && (a.childLanes |= e), t === n) break;
    t = t.return;
  }
}
function $i(t, e) {
  ga = t, Ql = Gi = null, t = t.dependencies, t !== null && t.firstContext !== null && (t.lanes & e && (Ae = !0), t.firstContext = null);
}
function tn(t) {
  var e = t._currentValue;
  if (Ql !== t) if (t = { context: t, memoizedValue: e, next: null }, Gi === null) {
    if (ga === null) throw Error(ut(308));
    Gi = t, ga.dependencies = { lanes: 0, firstContext: t };
  } else Gi = Gi.next = t;
  return e;
}
var _i = null;
function tc(t) {
  _i === null ? _i = [t] : _i.push(t);
}
function ud(t, e, n, a) {
  var p = e.interleaved;
  return p === null ? (n.next = n, tc(e)) : (n.next = p.next, p.next = n), e.interleaved = n, Un(t, a);
}
function Un(t, e) {
  t.lanes |= e;
  var n = t.alternate;
  for (n !== null && (n.lanes |= e), n = t, t = t.return; t !== null; ) t.childLanes |= e, n = t.alternate, n !== null && (n.childLanes |= e), n = t, t = t.return;
  return n.tag === 3 ? n.stateNode : null;
}
var Hn = !1;
function ec(t) {
  t.updateQueue = { baseState: t.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function hd(t, e) {
  t = t.updateQueue, e.updateQueue === t && (e.updateQueue = { baseState: t.baseState, firstBaseUpdate: t.firstBaseUpdate, lastBaseUpdate: t.lastBaseUpdate, shared: t.shared, effects: t.effects });
}
function Rn(t, e) {
  return { eventTime: t, lane: e, tag: 0, payload: null, callback: null, next: null };
}
function ni(t, e, n) {
  var a = t.updateQueue;
  if (a === null) return null;
  if (a = a.shared, Nt & 2) {
    var p = a.pending;
    return p === null ? e.next = e : (e.next = p.next, p.next = e), a.pending = e, Un(t, n);
  }
  return p = a.interleaved, p === null ? (e.next = e, tc(a)) : (e.next = p.next, p.next = e), a.interleaved = e, Un(t, n);
}
function Vo(t, e, n) {
  if (e = e.updateQueue, e !== null && (e = e.shared, (n & 4194240) !== 0)) {
    var a = e.lanes;
    a &= t.pendingLanes, n |= a, e.lanes = n, Ul(t, n);
  }
}
function Xu(t, e) {
  var n = t.updateQueue, a = t.alternate;
  if (a !== null && (a = a.updateQueue, n === a)) {
    var p = null, g = null;
    if (n = n.firstBaseUpdate, n !== null) {
      do {
        var _ = { eventTime: n.eventTime, lane: n.lane, tag: n.tag, payload: n.payload, callback: n.callback, next: null };
        g === null ? p = g = _ : g = g.next = _, n = n.next;
      } while (n !== null);
      g === null ? p = g = e : g = g.next = e;
    } else p = g = e;
    n = { baseState: a.baseState, firstBaseUpdate: p, lastBaseUpdate: g, shared: a.shared, effects: a.effects }, t.updateQueue = n;
    return;
  }
  t = n.lastBaseUpdate, t === null ? n.firstBaseUpdate = e : t.next = e, n.lastBaseUpdate = e;
}
function ma(t, e, n, a) {
  var p = t.updateQueue;
  Hn = !1;
  var g = p.firstBaseUpdate, _ = p.lastBaseUpdate, w = p.shared.pending;
  if (w !== null) {
    p.shared.pending = null;
    var x = w, T = x.next;
    x.next = null, _ === null ? g = T : _.next = T, _ = x;
    var L = t.alternate;
    L !== null && (L = L.updateQueue, w = L.lastBaseUpdate, w !== _ && (w === null ? L.firstBaseUpdate = T : w.next = T, L.lastBaseUpdate = x));
  }
  if (g !== null) {
    var X = p.baseState;
    _ = 0, L = T = x = null, w = g;
    do {
      var G = w.lane, J = w.eventTime;
      if ((a & G) === G) {
        L !== null && (L = L.next = {
          eventTime: J,
          lane: 0,
          tag: w.tag,
          payload: w.payload,
          callback: w.callback,
          next: null
        });
        t: {
          var et = t, rt = w;
          switch (G = e, J = n, rt.tag) {
            case 1:
              if (et = rt.payload, typeof et == "function") {
                X = et.call(J, X, G);
                break t;
              }
              X = et;
              break t;
            case 3:
              et.flags = et.flags & -65537 | 128;
            case 0:
              if (et = rt.payload, G = typeof et == "function" ? et.call(J, X, G) : et, G == null) break t;
              X = $t({}, X, G);
              break t;
            case 2:
              Hn = !0;
          }
        }
        w.callback !== null && w.lane !== 0 && (t.flags |= 64, G = p.effects, G === null ? p.effects = [w] : G.push(w));
      } else J = { eventTime: J, lane: G, tag: w.tag, payload: w.payload, callback: w.callback, next: null }, L === null ? (T = L = J, x = X) : L = L.next = J, _ |= G;
      if (w = w.next, w === null) {
        if (w = p.shared.pending, w === null) break;
        G = w, w = G.next, G.next = null, p.lastBaseUpdate = G, p.shared.pending = null;
      }
    } while (!0);
    if (L === null && (x = X), p.baseState = x, p.firstBaseUpdate = T, p.lastBaseUpdate = L, e = p.shared.interleaved, e !== null) {
      p = e;
      do
        _ |= p.lane, p = p.next;
      while (p !== e);
    } else g === null && (p.shared.lanes = 0);
    Ei |= _, t.lanes = _, t.memoizedState = X;
  }
}
function Yu(t, e, n) {
  if (t = e.effects, e.effects = null, t !== null) for (e = 0; e < t.length; e++) {
    var a = t[e], p = a.callback;
    if (p !== null) {
      if (a.callback = null, a = n, typeof p != "function") throw Error(ut(191, p));
      p.call(a);
    }
  }
}
var uo = {}, kn = ci(uo), to = ci(uo), eo = ci(uo);
function bi(t) {
  if (t === uo) throw Error(ut(174));
  return t;
}
function nc(t, e) {
  switch (Gt(eo, e), Gt(to, t), Gt(kn, uo), t = e.nodeType, t) {
    case 9:
    case 11:
      e = (e = e.documentElement) ? e.namespaceURI : Gs(null, "");
      break;
    default:
      t = t === 8 ? e.parentNode : e, e = t.namespaceURI || null, t = t.tagName, e = Gs(e, t);
  }
  Zt(kn), Gt(kn, e);
}
function or() {
  Zt(kn), Zt(to), Zt(eo);
}
function fd(t) {
  bi(eo.current);
  var e = bi(kn.current), n = Gs(e, t.type);
  e !== n && (Gt(to, t), Gt(kn, n));
}
function ic(t) {
  to.current === t && (Zt(kn), Zt(to));
}
var Kt = ci(0);
function va(t) {
  for (var e = t; e !== null; ) {
    if (e.tag === 13) {
      var n = e.memoizedState;
      if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return e;
    } else if (e.tag === 19 && e.memoizedProps.revealOrder !== void 0) {
      if (e.flags & 128) return e;
    } else if (e.child !== null) {
      e.child.return = e, e = e.child;
      continue;
    }
    if (e === t) break;
    for (; e.sibling === null; ) {
      if (e.return === null || e.return === t) return null;
      e = e.return;
    }
    e.sibling.return = e.return, e = e.sibling;
  }
  return null;
}
var ys = [];
function rc() {
  for (var t = 0; t < ys.length; t++) ys[t]._workInProgressVersionPrimary = null;
  ys.length = 0;
}
var Zo = Wn.ReactCurrentDispatcher, _s = Wn.ReactCurrentBatchConfig, Ti = 0, Jt = null, ae = null, ce = null, ya = !1, Br = !1, no = 0, im = 0;
function me() {
  throw Error(ut(321));
}
function oc(t, e) {
  if (e === null) return !1;
  for (var n = 0; n < e.length && n < t.length; n++) if (!gn(t[n], e[n])) return !1;
  return !0;
}
function ac(t, e, n, a, p, g) {
  if (Ti = g, Jt = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, Zo.current = t === null || t.memoizedState === null ? sm : lm, t = n(a, p), Br) {
    g = 0;
    do {
      if (Br = !1, no = 0, 25 <= g) throw Error(ut(301));
      g += 1, ce = ae = null, e.updateQueue = null, Zo.current = cm, t = n(a, p);
    } while (Br);
  }
  if (Zo.current = _a, e = ae !== null && ae.next !== null, Ti = 0, ce = ae = Jt = null, ya = !1, e) throw Error(ut(300));
  return t;
}
function sc() {
  var t = no !== 0;
  return no = 0, t;
}
function bn() {
  var t = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  return ce === null ? Jt.memoizedState = ce = t : ce = ce.next = t, ce;
}
function en() {
  if (ae === null) {
    var t = Jt.alternate;
    t = t !== null ? t.memoizedState : null;
  } else t = ae.next;
  var e = ce === null ? Jt.memoizedState : ce.next;
  if (e !== null) ce = e, ae = t;
  else {
    if (t === null) throw Error(ut(310));
    ae = t, t = { memoizedState: ae.memoizedState, baseState: ae.baseState, baseQueue: ae.baseQueue, queue: ae.queue, next: null }, ce === null ? Jt.memoizedState = ce = t : ce = ce.next = t;
  }
  return ce;
}
function io(t, e) {
  return typeof e == "function" ? e(t) : e;
}
function bs(t) {
  var e = en(), n = e.queue;
  if (n === null) throw Error(ut(311));
  n.lastRenderedReducer = t;
  var a = ae, p = a.baseQueue, g = n.pending;
  if (g !== null) {
    if (p !== null) {
      var _ = p.next;
      p.next = g.next, g.next = _;
    }
    a.baseQueue = p = g, n.pending = null;
  }
  if (p !== null) {
    g = p.next, a = a.baseState;
    var w = _ = null, x = null, T = g;
    do {
      var L = T.lane;
      if ((Ti & L) === L) x !== null && (x = x.next = { lane: 0, action: T.action, hasEagerState: T.hasEagerState, eagerState: T.eagerState, next: null }), a = T.hasEagerState ? T.eagerState : t(a, T.action);
      else {
        var X = {
          lane: L,
          action: T.action,
          hasEagerState: T.hasEagerState,
          eagerState: T.eagerState,
          next: null
        };
        x === null ? (w = x = X, _ = a) : x = x.next = X, Jt.lanes |= L, Ei |= L;
      }
      T = T.next;
    } while (T !== null && T !== g);
    x === null ? _ = a : x.next = w, gn(a, e.memoizedState) || (Ae = !0), e.memoizedState = a, e.baseState = _, e.baseQueue = x, n.lastRenderedState = a;
  }
  if (t = n.interleaved, t !== null) {
    p = t;
    do
      g = p.lane, Jt.lanes |= g, Ei |= g, p = p.next;
    while (p !== t);
  } else p === null && (n.lanes = 0);
  return [e.memoizedState, n.dispatch];
}
function ws(t) {
  var e = en(), n = e.queue;
  if (n === null) throw Error(ut(311));
  n.lastRenderedReducer = t;
  var a = n.dispatch, p = n.pending, g = e.memoizedState;
  if (p !== null) {
    n.pending = null;
    var _ = p = p.next;
    do
      g = t(g, _.action), _ = _.next;
    while (_ !== p);
    gn(g, e.memoizedState) || (Ae = !0), e.memoizedState = g, e.baseQueue === null && (e.baseState = g), n.lastRenderedState = g;
  }
  return [g, a];
}
function dd() {
}
function pd(t, e) {
  var n = Jt, a = en(), p = e(), g = !gn(a.memoizedState, p);
  if (g && (a.memoizedState = p, Ae = !0), a = a.queue, lc(vd.bind(null, n, a, t), [t]), a.getSnapshot !== e || g || ce !== null && ce.memoizedState.tag & 1) {
    if (n.flags |= 2048, ro(9, md.bind(null, n, a, p, e), void 0, null), ue === null) throw Error(ut(349));
    Ti & 30 || gd(n, e, p);
  }
  return p;
}
function gd(t, e, n) {
  t.flags |= 16384, t = { getSnapshot: e, value: n }, e = Jt.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, Jt.updateQueue = e, e.stores = [t]) : (n = e.stores, n === null ? e.stores = [t] : n.push(t));
}
function md(t, e, n, a) {
  e.value = n, e.getSnapshot = a, yd(e) && _d(t);
}
function vd(t, e, n) {
  return n(function() {
    yd(e) && _d(t);
  });
}
function yd(t) {
  var e = t.getSnapshot;
  t = t.value;
  try {
    var n = e();
    return !gn(t, n);
  } catch {
    return !0;
  }
}
function _d(t) {
  var e = Un(t, 1);
  e !== null && pn(e, t, 1, -1);
}
function Gu(t) {
  var e = bn();
  return typeof t == "function" && (t = t()), e.memoizedState = e.baseState = t, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: io, lastRenderedState: t }, e.queue = t, t = t.dispatch = am.bind(null, Jt, t), [e.memoizedState, t];
}
function ro(t, e, n, a) {
  return t = { tag: t, create: e, destroy: n, deps: a, next: null }, e = Jt.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, Jt.updateQueue = e, e.lastEffect = t.next = t) : (n = e.lastEffect, n === null ? e.lastEffect = t.next = t : (a = n.next, n.next = t, t.next = a, e.lastEffect = t)), t;
}
function bd() {
  return en().memoizedState;
}
function qo(t, e, n, a) {
  var p = bn();
  Jt.flags |= t, p.memoizedState = ro(1 | e, n, void 0, a === void 0 ? null : a);
}
function Ia(t, e, n, a) {
  var p = en();
  a = a === void 0 ? null : a;
  var g = void 0;
  if (ae !== null) {
    var _ = ae.memoizedState;
    if (g = _.destroy, a !== null && oc(a, _.deps)) {
      p.memoizedState = ro(e, n, g, a);
      return;
    }
  }
  Jt.flags |= t, p.memoizedState = ro(1 | e, n, g, a);
}
function Hu(t, e) {
  return qo(8390656, 8, t, e);
}
function lc(t, e) {
  return Ia(2048, 8, t, e);
}
function wd(t, e) {
  return Ia(4, 2, t, e);
}
function Cd(t, e) {
  return Ia(4, 4, t, e);
}
function xd(t, e) {
  if (typeof e == "function") return t = t(), e(t), function() {
    e(null);
  };
  if (e != null) return t = t(), e.current = t, function() {
    e.current = null;
  };
}
function Sd(t, e, n) {
  return n = n != null ? n.concat([t]) : null, Ia(4, 4, xd.bind(null, e, t), n);
}
function cc() {
}
function Td(t, e) {
  var n = en();
  e = e === void 0 ? null : e;
  var a = n.memoizedState;
  return a !== null && e !== null && oc(e, a[1]) ? a[0] : (n.memoizedState = [t, e], t);
}
function Ed(t, e) {
  var n = en();
  e = e === void 0 ? null : e;
  var a = n.memoizedState;
  return a !== null && e !== null && oc(e, a[1]) ? a[0] : (t = t(), n.memoizedState = [t, e], t);
}
function kd(t, e, n) {
  return Ti & 21 ? (gn(n, e) || (n = Df(), Jt.lanes |= n, Ei |= n, t.baseState = !0), e) : (t.baseState && (t.baseState = !1, Ae = !0), t.memoizedState = n);
}
function rm(t, e) {
  var n = Wt;
  Wt = n !== 0 && 4 > n ? n : 4, t(!0);
  var a = _s.transition;
  _s.transition = {};
  try {
    t(!1), e();
  } finally {
    Wt = n, _s.transition = a;
  }
}
function Od() {
  return en().memoizedState;
}
function om(t, e, n) {
  var a = ri(t);
  if (n = { lane: a, action: n, hasEagerState: !1, eagerState: null, next: null }, Md(t)) Pd(e, n);
  else if (n = ud(t, e, n, a), n !== null) {
    var p = xe();
    pn(n, t, a, p), Ad(n, e, a);
  }
}
function am(t, e, n) {
  var a = ri(t), p = { lane: a, action: n, hasEagerState: !1, eagerState: null, next: null };
  if (Md(t)) Pd(e, p);
  else {
    var g = t.alternate;
    if (t.lanes === 0 && (g === null || g.lanes === 0) && (g = e.lastRenderedReducer, g !== null)) try {
      var _ = e.lastRenderedState, w = g(_, n);
      if (p.hasEagerState = !0, p.eagerState = w, gn(w, _)) {
        var x = e.interleaved;
        x === null ? (p.next = p, tc(e)) : (p.next = x.next, x.next = p), e.interleaved = p;
        return;
      }
    } catch {
    } finally {
    }
    n = ud(t, e, p, a), n !== null && (p = xe(), pn(n, t, a, p), Ad(n, e, a));
  }
}
function Md(t) {
  var e = t.alternate;
  return t === Jt || e !== null && e === Jt;
}
function Pd(t, e) {
  Br = ya = !0;
  var n = t.pending;
  n === null ? e.next = e : (e.next = n.next, n.next = e), t.pending = e;
}
function Ad(t, e, n) {
  if (n & 4194240) {
    var a = e.lanes;
    a &= t.pendingLanes, n |= a, e.lanes = n, Ul(t, n);
  }
}
var _a = { readContext: tn, useCallback: me, useContext: me, useEffect: me, useImperativeHandle: me, useInsertionEffect: me, useLayoutEffect: me, useMemo: me, useReducer: me, useRef: me, useState: me, useDebugValue: me, useDeferredValue: me, useTransition: me, useMutableSource: me, useSyncExternalStore: me, useId: me, unstable_isNewReconciler: !1 }, sm = { readContext: tn, useCallback: function(t, e) {
  return bn().memoizedState = [t, e === void 0 ? null : e], t;
}, useContext: tn, useEffect: Hu, useImperativeHandle: function(t, e, n) {
  return n = n != null ? n.concat([t]) : null, qo(
    4194308,
    4,
    xd.bind(null, e, t),
    n
  );
}, useLayoutEffect: function(t, e) {
  return qo(4194308, 4, t, e);
}, useInsertionEffect: function(t, e) {
  return qo(4, 2, t, e);
}, useMemo: function(t, e) {
  var n = bn();
  return e = e === void 0 ? null : e, t = t(), n.memoizedState = [t, e], t;
}, useReducer: function(t, e, n) {
  var a = bn();
  return e = n !== void 0 ? n(e) : e, a.memoizedState = a.baseState = e, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: t, lastRenderedState: e }, a.queue = t, t = t.dispatch = om.bind(null, Jt, t), [a.memoizedState, t];
}, useRef: function(t) {
  var e = bn();
  return t = { current: t }, e.memoizedState = t;
}, useState: Gu, useDebugValue: cc, useDeferredValue: function(t) {
  return bn().memoizedState = t;
}, useTransition: function() {
  var t = Gu(!1), e = t[0];
  return t = rm.bind(null, t[1]), bn().memoizedState = t, [e, t];
}, useMutableSource: function() {
}, useSyncExternalStore: function(t, e, n) {
  var a = Jt, p = bn();
  if (qt) {
    if (n === void 0) throw Error(ut(407));
    n = n();
  } else {
    if (n = e(), ue === null) throw Error(ut(349));
    Ti & 30 || gd(a, e, n);
  }
  p.memoizedState = n;
  var g = { value: n, getSnapshot: e };
  return p.queue = g, Hu(vd.bind(
    null,
    a,
    g,
    t
  ), [t]), a.flags |= 2048, ro(9, md.bind(null, a, g, n, e), void 0, null), n;
}, useId: function() {
  var t = bn(), e = ue.identifierPrefix;
  if (qt) {
    var n = In, a = jn;
    n = (a & ~(1 << 32 - dn(a) - 1)).toString(32) + n, e = ":" + e + "R" + n, n = no++, 0 < n && (e += "H" + n.toString(32)), e += ":";
  } else n = im++, e = ":" + e + "r" + n.toString(32) + ":";
  return t.memoizedState = e;
}, unstable_isNewReconciler: !1 }, lm = {
  readContext: tn,
  useCallback: Td,
  useContext: tn,
  useEffect: lc,
  useImperativeHandle: Sd,
  useInsertionEffect: wd,
  useLayoutEffect: Cd,
  useMemo: Ed,
  useReducer: bs,
  useRef: bd,
  useState: function() {
    return bs(io);
  },
  useDebugValue: cc,
  useDeferredValue: function(t) {
    var e = en();
    return kd(e, ae.memoizedState, t);
  },
  useTransition: function() {
    var t = bs(io)[0], e = en().memoizedState;
    return [t, e];
  },
  useMutableSource: dd,
  useSyncExternalStore: pd,
  useId: Od,
  unstable_isNewReconciler: !1
}, cm = { readContext: tn, useCallback: Td, useContext: tn, useEffect: lc, useImperativeHandle: Sd, useInsertionEffect: wd, useLayoutEffect: Cd, useMemo: Ed, useReducer: ws, useRef: bd, useState: function() {
  return ws(io);
}, useDebugValue: cc, useDeferredValue: function(t) {
  var e = en();
  return ae === null ? e.memoizedState = t : kd(e, ae.memoizedState, t);
}, useTransition: function() {
  var t = ws(io)[0], e = en().memoizedState;
  return [t, e];
}, useMutableSource: dd, useSyncExternalStore: pd, useId: Od, unstable_isNewReconciler: !1 };
function ln(t, e) {
  if (t && t.defaultProps) {
    e = $t({}, e), t = t.defaultProps;
    for (var n in t) e[n] === void 0 && (e[n] = t[n]);
    return e;
  }
  return e;
}
function fl(t, e, n, a) {
  e = t.memoizedState, n = n(a, e), n = n == null ? e : $t({}, e, n), t.memoizedState = n, t.lanes === 0 && (t.updateQueue.baseState = n);
}
var Fa = { isMounted: function(t) {
  return (t = t._reactInternals) ? Mi(t) === t : !1;
}, enqueueSetState: function(t, e, n) {
  t = t._reactInternals;
  var a = xe(), p = ri(t), g = Rn(a, p);
  g.payload = e, n != null && (g.callback = n), e = ni(t, g, p), e !== null && (pn(e, t, p, a), Vo(e, t, p));
}, enqueueReplaceState: function(t, e, n) {
  t = t._reactInternals;
  var a = xe(), p = ri(t), g = Rn(a, p);
  g.tag = 1, g.payload = e, n != null && (g.callback = n), e = ni(t, g, p), e !== null && (pn(e, t, p, a), Vo(e, t, p));
}, enqueueForceUpdate: function(t, e) {
  t = t._reactInternals;
  var n = xe(), a = ri(t), p = Rn(n, a);
  p.tag = 2, e != null && (p.callback = e), e = ni(t, p, a), e !== null && (pn(e, t, a, n), Vo(e, t, a));
} };
function Vu(t, e, n, a, p, g, _) {
  return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(a, g, _) : e.prototype && e.prototype.isPureReactComponent ? !Kr(n, a) || !Kr(p, g) : !0;
}
function Dd(t, e, n) {
  var a = !1, p = si, g = e.contextType;
  return typeof g == "object" && g !== null ? g = tn(g) : (p = Le(e) ? xi : _e.current, a = e.contextTypes, g = (a = a != null) ? nr(t, p) : si), e = new e(n, g), t.memoizedState = e.state !== null && e.state !== void 0 ? e.state : null, e.updater = Fa, t.stateNode = e, e._reactInternals = t, a && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = p, t.__reactInternalMemoizedMaskedChildContext = g), e;
}
function Zu(t, e, n, a) {
  t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(n, a), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(n, a), e.state !== t && Fa.enqueueReplaceState(e, e.state, null);
}
function dl(t, e, n, a) {
  var p = t.stateNode;
  p.props = n, p.state = t.memoizedState, p.refs = {}, ec(t);
  var g = e.contextType;
  typeof g == "object" && g !== null ? p.context = tn(g) : (g = Le(e) ? xi : _e.current, p.context = nr(t, g)), p.state = t.memoizedState, g = e.getDerivedStateFromProps, typeof g == "function" && (fl(t, e, g, n), p.state = t.memoizedState), typeof e.getDerivedStateFromProps == "function" || typeof p.getSnapshotBeforeUpdate == "function" || typeof p.UNSAFE_componentWillMount != "function" && typeof p.componentWillMount != "function" || (e = p.state, typeof p.componentWillMount == "function" && p.componentWillMount(), typeof p.UNSAFE_componentWillMount == "function" && p.UNSAFE_componentWillMount(), e !== p.state && Fa.enqueueReplaceState(p, p.state, null), ma(t, n, p, a), p.state = t.memoizedState), typeof p.componentDidMount == "function" && (t.flags |= 4194308);
}
function ar(t, e) {
  try {
    var n = "", a = e;
    do
      n += Rg(a), a = a.return;
    while (a);
    var p = n;
  } catch (g) {
    p = `
Error generating stack: ` + g.message + `
` + g.stack;
  }
  return { value: t, source: e, stack: p, digest: null };
}
function Cs(t, e, n) {
  return { value: t, source: null, stack: n ?? null, digest: e ?? null };
}
function pl(t, e) {
  try {
    console.error(e.value);
  } catch (n) {
    setTimeout(function() {
      throw n;
    });
  }
}
var um = typeof WeakMap == "function" ? WeakMap : Map;
function Ld(t, e, n) {
  n = Rn(-1, n), n.tag = 3, n.payload = { element: null };
  var a = e.value;
  return n.callback = function() {
    wa || (wa = !0, xl = a), pl(t, e);
  }, n;
}
function jd(t, e, n) {
  n = Rn(-1, n), n.tag = 3;
  var a = t.type.getDerivedStateFromError;
  if (typeof a == "function") {
    var p = e.value;
    n.payload = function() {
      return a(p);
    }, n.callback = function() {
      pl(t, e);
    };
  }
  var g = t.stateNode;
  return g !== null && typeof g.componentDidCatch == "function" && (n.callback = function() {
    pl(t, e), typeof a != "function" && (ii === null ? ii = /* @__PURE__ */ new Set([this]) : ii.add(this));
    var _ = e.stack;
    this.componentDidCatch(e.value, { componentStack: _ !== null ? _ : "" });
  }), n;
}
function qu(t, e, n) {
  var a = t.pingCache;
  if (a === null) {
    a = t.pingCache = new um();
    var p = /* @__PURE__ */ new Set();
    a.set(e, p);
  } else p = a.get(e), p === void 0 && (p = /* @__PURE__ */ new Set(), a.set(e, p));
  p.has(n) || (p.add(n), t = Sm.bind(null, t, e, n), e.then(t, t));
}
function Ku(t) {
  do {
    var e;
    if ((e = t.tag === 13) && (e = t.memoizedState, e = e !== null ? e.dehydrated !== null : !0), e) return t;
    t = t.return;
  } while (t !== null);
  return null;
}
function Qu(t, e, n, a, p) {
  return t.mode & 1 ? (t.flags |= 65536, t.lanes = p, t) : (t === e ? t.flags |= 65536 : (t.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (e = Rn(-1, 1), e.tag = 2, ni(n, e, 1))), n.lanes |= 1), t);
}
var hm = Wn.ReactCurrentOwner, Ae = !1;
function Ce(t, e, n, a) {
  e.child = t === null ? cd(e, null, n, a) : rr(e, t.child, n, a);
}
function Ju(t, e, n, a, p) {
  n = n.render;
  var g = e.ref;
  return $i(e, p), a = ac(t, e, n, a, g, p), n = sc(), t !== null && !Ae ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~p, zn(t, e, p)) : (qt && n && Zl(e), e.flags |= 1, Ce(t, e, a, p), e.child);
}
function $u(t, e, n, a, p) {
  if (t === null) {
    var g = n.type;
    return typeof g == "function" && !vc(g) && g.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (e.tag = 15, e.type = g, Id(t, e, g, a, p)) : (t = $o(n.type, null, a, e, e.mode, p), t.ref = e.ref, t.return = e, e.child = t);
  }
  if (g = t.child, !(t.lanes & p)) {
    var _ = g.memoizedProps;
    if (n = n.compare, n = n !== null ? n : Kr, n(_, a) && t.ref === e.ref) return zn(t, e, p);
  }
  return e.flags |= 1, t = oi(g, a), t.ref = e.ref, t.return = e, e.child = t;
}
function Id(t, e, n, a, p) {
  if (t !== null) {
    var g = t.memoizedProps;
    if (Kr(g, a) && t.ref === e.ref) if (Ae = !1, e.pendingProps = a = g, (t.lanes & p) !== 0) t.flags & 131072 && (Ae = !0);
    else return e.lanes = t.lanes, zn(t, e, p);
  }
  return gl(t, e, n, a, p);
}
function Fd(t, e, n) {
  var a = e.pendingProps, p = a.children, g = t !== null ? t.memoizedState : null;
  if (a.mode === "hidden") if (!(e.mode & 1)) e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, Gt(Vi, Re), Re |= n;
  else {
    if (!(n & 1073741824)) return t = g !== null ? g.baseLanes | n : n, e.lanes = e.childLanes = 1073741824, e.memoizedState = { baseLanes: t, cachePool: null, transitions: null }, e.updateQueue = null, Gt(Vi, Re), Re |= t, null;
    e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, a = g !== null ? g.baseLanes : n, Gt(Vi, Re), Re |= a;
  }
  else g !== null ? (a = g.baseLanes | n, e.memoizedState = null) : a = n, Gt(Vi, Re), Re |= a;
  return Ce(t, e, p, n), e.child;
}
function Rd(t, e) {
  var n = e.ref;
  (t === null && n !== null || t !== null && t.ref !== n) && (e.flags |= 512, e.flags |= 2097152);
}
function gl(t, e, n, a, p) {
  var g = Le(n) ? xi : _e.current;
  return g = nr(e, g), $i(e, p), n = ac(t, e, n, a, g, p), a = sc(), t !== null && !Ae ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~p, zn(t, e, p)) : (qt && a && Zl(e), e.flags |= 1, Ce(t, e, n, p), e.child);
}
function th(t, e, n, a, p) {
  if (Le(n)) {
    var g = !0;
    ha(e);
  } else g = !1;
  if ($i(e, p), e.stateNode === null) Ko(t, e), Dd(e, n, a), dl(e, n, a, p), a = !0;
  else if (t === null) {
    var _ = e.stateNode, w = e.memoizedProps;
    _.props = w;
    var x = _.context, T = n.contextType;
    typeof T == "object" && T !== null ? T = tn(T) : (T = Le(n) ? xi : _e.current, T = nr(e, T));
    var L = n.getDerivedStateFromProps, X = typeof L == "function" || typeof _.getSnapshotBeforeUpdate == "function";
    X || typeof _.UNSAFE_componentWillReceiveProps != "function" && typeof _.componentWillReceiveProps != "function" || (w !== a || x !== T) && Zu(e, _, a, T), Hn = !1;
    var G = e.memoizedState;
    _.state = G, ma(e, a, _, p), x = e.memoizedState, w !== a || G !== x || De.current || Hn ? (typeof L == "function" && (fl(e, n, L, a), x = e.memoizedState), (w = Hn || Vu(e, n, w, a, G, x, T)) ? (X || typeof _.UNSAFE_componentWillMount != "function" && typeof _.componentWillMount != "function" || (typeof _.componentWillMount == "function" && _.componentWillMount(), typeof _.UNSAFE_componentWillMount == "function" && _.UNSAFE_componentWillMount()), typeof _.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof _.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = a, e.memoizedState = x), _.props = a, _.state = x, _.context = T, a = w) : (typeof _.componentDidMount == "function" && (e.flags |= 4194308), a = !1);
  } else {
    _ = e.stateNode, hd(t, e), w = e.memoizedProps, T = e.type === e.elementType ? w : ln(e.type, w), _.props = T, X = e.pendingProps, G = _.context, x = n.contextType, typeof x == "object" && x !== null ? x = tn(x) : (x = Le(n) ? xi : _e.current, x = nr(e, x));
    var J = n.getDerivedStateFromProps;
    (L = typeof J == "function" || typeof _.getSnapshotBeforeUpdate == "function") || typeof _.UNSAFE_componentWillReceiveProps != "function" && typeof _.componentWillReceiveProps != "function" || (w !== X || G !== x) && Zu(e, _, a, x), Hn = !1, G = e.memoizedState, _.state = G, ma(e, a, _, p);
    var et = e.memoizedState;
    w !== X || G !== et || De.current || Hn ? (typeof J == "function" && (fl(e, n, J, a), et = e.memoizedState), (T = Hn || Vu(e, n, T, a, G, et, x) || !1) ? (L || typeof _.UNSAFE_componentWillUpdate != "function" && typeof _.componentWillUpdate != "function" || (typeof _.componentWillUpdate == "function" && _.componentWillUpdate(a, et, x), typeof _.UNSAFE_componentWillUpdate == "function" && _.UNSAFE_componentWillUpdate(a, et, x)), typeof _.componentDidUpdate == "function" && (e.flags |= 4), typeof _.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof _.componentDidUpdate != "function" || w === t.memoizedProps && G === t.memoizedState || (e.flags |= 4), typeof _.getSnapshotBeforeUpdate != "function" || w === t.memoizedProps && G === t.memoizedState || (e.flags |= 1024), e.memoizedProps = a, e.memoizedState = et), _.props = a, _.state = et, _.context = x, a = T) : (typeof _.componentDidUpdate != "function" || w === t.memoizedProps && G === t.memoizedState || (e.flags |= 4), typeof _.getSnapshotBeforeUpdate != "function" || w === t.memoizedProps && G === t.memoizedState || (e.flags |= 1024), a = !1);
  }
  return ml(t, e, n, a, g, p);
}
function ml(t, e, n, a, p, g) {
  Rd(t, e);
  var _ = (e.flags & 128) !== 0;
  if (!a && !_) return p && Nu(e, n, !1), zn(t, e, g);
  a = e.stateNode, hm.current = e;
  var w = _ && typeof n.getDerivedStateFromError != "function" ? null : a.render();
  return e.flags |= 1, t !== null && _ ? (e.child = rr(e, t.child, null, g), e.child = rr(e, null, w, g)) : Ce(t, e, w, g), e.memoizedState = a.state, p && Nu(e, n, !0), e.child;
}
function Bd(t) {
  var e = t.stateNode;
  e.pendingContext ? Bu(t, e.pendingContext, e.pendingContext !== e.context) : e.context && Bu(t, e.context, !1), nc(t, e.containerInfo);
}
function eh(t, e, n, a, p) {
  return ir(), Kl(p), e.flags |= 256, Ce(t, e, n, a), e.child;
}
var vl = { dehydrated: null, treeContext: null, retryLane: 0 };
function yl(t) {
  return { baseLanes: t, cachePool: null, transitions: null };
}
function Nd(t, e, n) {
  var a = e.pendingProps, p = Kt.current, g = !1, _ = (e.flags & 128) !== 0, w;
  if ((w = _) || (w = t !== null && t.memoizedState === null ? !1 : (p & 2) !== 0), w ? (g = !0, e.flags &= -129) : (t === null || t.memoizedState !== null) && (p |= 1), Gt(Kt, p & 1), t === null)
    return ul(e), t = e.memoizedState, t !== null && (t = t.dehydrated, t !== null) ? (e.mode & 1 ? t.data === "$!" ? e.lanes = 8 : e.lanes = 1073741824 : e.lanes = 1, null) : (_ = a.children, t = a.fallback, g ? (a = e.mode, g = e.child, _ = { mode: "hidden", children: _ }, !(a & 1) && g !== null ? (g.childLanes = 0, g.pendingProps = _) : g = Na(_, a, 0, null), t = Ci(t, a, n, null), g.return = e, t.return = e, g.sibling = t, e.child = g, e.child.memoizedState = yl(n), e.memoizedState = vl, t) : uc(e, _));
  if (p = t.memoizedState, p !== null && (w = p.dehydrated, w !== null)) return fm(t, e, _, a, w, p, n);
  if (g) {
    g = a.fallback, _ = e.mode, p = t.child, w = p.sibling;
    var x = { mode: "hidden", children: a.children };
    return !(_ & 1) && e.child !== p ? (a = e.child, a.childLanes = 0, a.pendingProps = x, e.deletions = null) : (a = oi(p, x), a.subtreeFlags = p.subtreeFlags & 14680064), w !== null ? g = oi(w, g) : (g = Ci(g, _, n, null), g.flags |= 2), g.return = e, a.return = e, a.sibling = g, e.child = a, a = g, g = e.child, _ = t.child.memoizedState, _ = _ === null ? yl(n) : { baseLanes: _.baseLanes | n, cachePool: null, transitions: _.transitions }, g.memoizedState = _, g.childLanes = t.childLanes & ~n, e.memoizedState = vl, a;
  }
  return g = t.child, t = g.sibling, a = oi(g, { mode: "visible", children: a.children }), !(e.mode & 1) && (a.lanes = n), a.return = e, a.sibling = null, t !== null && (n = e.deletions, n === null ? (e.deletions = [t], e.flags |= 16) : n.push(t)), e.child = a, e.memoizedState = null, a;
}
function uc(t, e) {
  return e = Na({ mode: "visible", children: e }, t.mode, 0, null), e.return = t, t.child = e;
}
function Do(t, e, n, a) {
  return a !== null && Kl(a), rr(e, t.child, null, n), t = uc(e, e.pendingProps.children), t.flags |= 2, e.memoizedState = null, t;
}
function fm(t, e, n, a, p, g, _) {
  if (n)
    return e.flags & 256 ? (e.flags &= -257, a = Cs(Error(ut(422))), Do(t, e, _, a)) : e.memoizedState !== null ? (e.child = t.child, e.flags |= 128, null) : (g = a.fallback, p = e.mode, a = Na({ mode: "visible", children: a.children }, p, 0, null), g = Ci(g, p, _, null), g.flags |= 2, a.return = e, g.return = e, a.sibling = g, e.child = a, e.mode & 1 && rr(e, t.child, null, _), e.child.memoizedState = yl(_), e.memoizedState = vl, g);
  if (!(e.mode & 1)) return Do(t, e, _, null);
  if (p.data === "$!") {
    if (a = p.nextSibling && p.nextSibling.dataset, a) var w = a.dgst;
    return a = w, g = Error(ut(419)), a = Cs(g, a, void 0), Do(t, e, _, a);
  }
  if (w = (_ & t.childLanes) !== 0, Ae || w) {
    if (a = ue, a !== null) {
      switch (_ & -_) {
        case 4:
          p = 2;
          break;
        case 16:
          p = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          p = 32;
          break;
        case 536870912:
          p = 268435456;
          break;
        default:
          p = 0;
      }
      p = p & (a.suspendedLanes | _) ? 0 : p, p !== 0 && p !== g.retryLane && (g.retryLane = p, Un(t, p), pn(a, t, p, -1));
    }
    return mc(), a = Cs(Error(ut(421))), Do(t, e, _, a);
  }
  return p.data === "$?" ? (e.flags |= 128, e.child = t.child, e = Tm.bind(null, t), p._reactRetry = e, null) : (t = g.treeContext, Be = ei(p.nextSibling), Ne = e, qt = !0, un = null, t !== null && (Ve[Ze++] = jn, Ve[Ze++] = In, Ve[Ze++] = Si, jn = t.id, In = t.overflow, Si = e), e = uc(e, a.children), e.flags |= 4096, e);
}
function nh(t, e, n) {
  t.lanes |= e;
  var a = t.alternate;
  a !== null && (a.lanes |= e), hl(t.return, e, n);
}
function xs(t, e, n, a, p) {
  var g = t.memoizedState;
  g === null ? t.memoizedState = { isBackwards: e, rendering: null, renderingStartTime: 0, last: a, tail: n, tailMode: p } : (g.isBackwards = e, g.rendering = null, g.renderingStartTime = 0, g.last = a, g.tail = n, g.tailMode = p);
}
function Ud(t, e, n) {
  var a = e.pendingProps, p = a.revealOrder, g = a.tail;
  if (Ce(t, e, a.children, n), a = Kt.current, a & 2) a = a & 1 | 2, e.flags |= 128;
  else {
    if (t !== null && t.flags & 128) t: for (t = e.child; t !== null; ) {
      if (t.tag === 13) t.memoizedState !== null && nh(t, n, e);
      else if (t.tag === 19) nh(t, n, e);
      else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e) break t;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e) break t;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    a &= 1;
  }
  if (Gt(Kt, a), !(e.mode & 1)) e.memoizedState = null;
  else switch (p) {
    case "forwards":
      for (n = e.child, p = null; n !== null; ) t = n.alternate, t !== null && va(t) === null && (p = n), n = n.sibling;
      n = p, n === null ? (p = e.child, e.child = null) : (p = n.sibling, n.sibling = null), xs(e, !1, p, n, g);
      break;
    case "backwards":
      for (n = null, p = e.child, e.child = null; p !== null; ) {
        if (t = p.alternate, t !== null && va(t) === null) {
          e.child = p;
          break;
        }
        t = p.sibling, p.sibling = n, n = p, p = t;
      }
      xs(e, !0, n, null, g);
      break;
    case "together":
      xs(e, !1, null, null, void 0);
      break;
    default:
      e.memoizedState = null;
  }
  return e.child;
}
function Ko(t, e) {
  !(e.mode & 1) && t !== null && (t.alternate = null, e.alternate = null, e.flags |= 2);
}
function zn(t, e, n) {
  if (t !== null && (e.dependencies = t.dependencies), Ei |= e.lanes, !(n & e.childLanes)) return null;
  if (t !== null && e.child !== t.child) throw Error(ut(153));
  if (e.child !== null) {
    for (t = e.child, n = oi(t, t.pendingProps), e.child = n, n.return = e; t.sibling !== null; ) t = t.sibling, n = n.sibling = oi(t, t.pendingProps), n.return = e;
    n.sibling = null;
  }
  return e.child;
}
function dm(t, e, n) {
  switch (e.tag) {
    case 3:
      Bd(e), ir();
      break;
    case 5:
      fd(e);
      break;
    case 1:
      Le(e.type) && ha(e);
      break;
    case 4:
      nc(e, e.stateNode.containerInfo);
      break;
    case 10:
      var a = e.type._context, p = e.memoizedProps.value;
      Gt(pa, a._currentValue), a._currentValue = p;
      break;
    case 13:
      if (a = e.memoizedState, a !== null)
        return a.dehydrated !== null ? (Gt(Kt, Kt.current & 1), e.flags |= 128, null) : n & e.child.childLanes ? Nd(t, e, n) : (Gt(Kt, Kt.current & 1), t = zn(t, e, n), t !== null ? t.sibling : null);
      Gt(Kt, Kt.current & 1);
      break;
    case 19:
      if (a = (n & e.childLanes) !== 0, t.flags & 128) {
        if (a) return Ud(t, e, n);
        e.flags |= 128;
      }
      if (p = e.memoizedState, p !== null && (p.rendering = null, p.tail = null, p.lastEffect = null), Gt(Kt, Kt.current), a) break;
      return null;
    case 22:
    case 23:
      return e.lanes = 0, Fd(t, e, n);
  }
  return zn(t, e, n);
}
var zd, _l, Wd, Xd;
zd = function(t, e) {
  for (var n = e.child; n !== null; ) {
    if (n.tag === 5 || n.tag === 6) t.appendChild(n.stateNode);
    else if (n.tag !== 4 && n.child !== null) {
      n.child.return = n, n = n.child;
      continue;
    }
    if (n === e) break;
    for (; n.sibling === null; ) {
      if (n.return === null || n.return === e) return;
      n = n.return;
    }
    n.sibling.return = n.return, n = n.sibling;
  }
};
_l = function() {
};
Wd = function(t, e, n, a) {
  var p = t.memoizedProps;
  if (p !== a) {
    t = e.stateNode, bi(kn.current);
    var g = null;
    switch (n) {
      case "input":
        p = zs(t, p), a = zs(t, a), g = [];
        break;
      case "select":
        p = $t({}, p, { value: void 0 }), a = $t({}, a, { value: void 0 }), g = [];
        break;
      case "textarea":
        p = Ys(t, p), a = Ys(t, a), g = [];
        break;
      default:
        typeof p.onClick != "function" && typeof a.onClick == "function" && (t.onclick = ca);
    }
    Hs(n, a);
    var _;
    n = null;
    for (T in p) if (!a.hasOwnProperty(T) && p.hasOwnProperty(T) && p[T] != null) if (T === "style") {
      var w = p[T];
      for (_ in w) w.hasOwnProperty(_) && (n || (n = {}), n[_] = "");
    } else T !== "dangerouslySetInnerHTML" && T !== "children" && T !== "suppressContentEditableWarning" && T !== "suppressHydrationWarning" && T !== "autoFocus" && (Xr.hasOwnProperty(T) ? g || (g = []) : (g = g || []).push(T, null));
    for (T in a) {
      var x = a[T];
      if (w = p != null ? p[T] : void 0, a.hasOwnProperty(T) && x !== w && (x != null || w != null)) if (T === "style") if (w) {
        for (_ in w) !w.hasOwnProperty(_) || x && x.hasOwnProperty(_) || (n || (n = {}), n[_] = "");
        for (_ in x) x.hasOwnProperty(_) && w[_] !== x[_] && (n || (n = {}), n[_] = x[_]);
      } else n || (g || (g = []), g.push(
        T,
        n
      )), n = x;
      else T === "dangerouslySetInnerHTML" ? (x = x ? x.__html : void 0, w = w ? w.__html : void 0, x != null && w !== x && (g = g || []).push(T, x)) : T === "children" ? typeof x != "string" && typeof x != "number" || (g = g || []).push(T, "" + x) : T !== "suppressContentEditableWarning" && T !== "suppressHydrationWarning" && (Xr.hasOwnProperty(T) ? (x != null && T === "onScroll" && Vt("scroll", t), g || w === x || (g = [])) : (g = g || []).push(T, x));
    }
    n && (g = g || []).push("style", n);
    var T = g;
    (e.updateQueue = T) && (e.flags |= 4);
  }
};
Xd = function(t, e, n, a) {
  n !== a && (e.flags |= 4);
};
function kr(t, e) {
  if (!qt) switch (t.tailMode) {
    case "hidden":
      e = t.tail;
      for (var n = null; e !== null; ) e.alternate !== null && (n = e), e = e.sibling;
      n === null ? t.tail = null : n.sibling = null;
      break;
    case "collapsed":
      n = t.tail;
      for (var a = null; n !== null; ) n.alternate !== null && (a = n), n = n.sibling;
      a === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : a.sibling = null;
  }
}
function ve(t) {
  var e = t.alternate !== null && t.alternate.child === t.child, n = 0, a = 0;
  if (e) for (var p = t.child; p !== null; ) n |= p.lanes | p.childLanes, a |= p.subtreeFlags & 14680064, a |= p.flags & 14680064, p.return = t, p = p.sibling;
  else for (p = t.child; p !== null; ) n |= p.lanes | p.childLanes, a |= p.subtreeFlags, a |= p.flags, p.return = t, p = p.sibling;
  return t.subtreeFlags |= a, t.childLanes = n, e;
}
function pm(t, e, n) {
  var a = e.pendingProps;
  switch (ql(e), e.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return ve(e), null;
    case 1:
      return Le(e.type) && ua(), ve(e), null;
    case 3:
      return a = e.stateNode, or(), Zt(De), Zt(_e), rc(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (t === null || t.child === null) && (Po(e) ? e.flags |= 4 : t === null || t.memoizedState.isDehydrated && !(e.flags & 256) || (e.flags |= 1024, un !== null && (El(un), un = null))), _l(t, e), ve(e), null;
    case 5:
      ic(e);
      var p = bi(eo.current);
      if (n = e.type, t !== null && e.stateNode != null) Wd(t, e, n, a, p), t.ref !== e.ref && (e.flags |= 512, e.flags |= 2097152);
      else {
        if (!a) {
          if (e.stateNode === null) throw Error(ut(166));
          return ve(e), null;
        }
        if (t = bi(kn.current), Po(e)) {
          a = e.stateNode, n = e.type;
          var g = e.memoizedProps;
          switch (a[wn] = e, a[$r] = g, t = (e.mode & 1) !== 0, n) {
            case "dialog":
              Vt("cancel", a), Vt("close", a);
              break;
            case "iframe":
            case "object":
            case "embed":
              Vt("load", a);
              break;
            case "video":
            case "audio":
              for (p = 0; p < Dr.length; p++) Vt(Dr[p], a);
              break;
            case "source":
              Vt("error", a);
              break;
            case "img":
            case "image":
            case "link":
              Vt(
                "error",
                a
              ), Vt("load", a);
              break;
            case "details":
              Vt("toggle", a);
              break;
            case "input":
              hu(a, g), Vt("invalid", a);
              break;
            case "select":
              a._wrapperState = { wasMultiple: !!g.multiple }, Vt("invalid", a);
              break;
            case "textarea":
              du(a, g), Vt("invalid", a);
          }
          Hs(n, g), p = null;
          for (var _ in g) if (g.hasOwnProperty(_)) {
            var w = g[_];
            _ === "children" ? typeof w == "string" ? a.textContent !== w && (g.suppressHydrationWarning !== !0 && Mo(a.textContent, w, t), p = ["children", w]) : typeof w == "number" && a.textContent !== "" + w && (g.suppressHydrationWarning !== !0 && Mo(
              a.textContent,
              w,
              t
            ), p = ["children", "" + w]) : Xr.hasOwnProperty(_) && w != null && _ === "onScroll" && Vt("scroll", a);
          }
          switch (n) {
            case "input":
              wo(a), fu(a, g, !0);
              break;
            case "textarea":
              wo(a), pu(a);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof g.onClick == "function" && (a.onclick = ca);
          }
          a = p, e.updateQueue = a, a !== null && (e.flags |= 4);
        } else {
          _ = p.nodeType === 9 ? p : p.ownerDocument, t === "http://www.w3.org/1999/xhtml" && (t = vf(n)), t === "http://www.w3.org/1999/xhtml" ? n === "script" ? (t = _.createElement("div"), t.innerHTML = "<script><\/script>", t = t.removeChild(t.firstChild)) : typeof a.is == "string" ? t = _.createElement(n, { is: a.is }) : (t = _.createElement(n), n === "select" && (_ = t, a.multiple ? _.multiple = !0 : a.size && (_.size = a.size))) : t = _.createElementNS(t, n), t[wn] = e, t[$r] = a, zd(t, e, !1, !1), e.stateNode = t;
          t: {
            switch (_ = Vs(n, a), n) {
              case "dialog":
                Vt("cancel", t), Vt("close", t), p = a;
                break;
              case "iframe":
              case "object":
              case "embed":
                Vt("load", t), p = a;
                break;
              case "video":
              case "audio":
                for (p = 0; p < Dr.length; p++) Vt(Dr[p], t);
                p = a;
                break;
              case "source":
                Vt("error", t), p = a;
                break;
              case "img":
              case "image":
              case "link":
                Vt(
                  "error",
                  t
                ), Vt("load", t), p = a;
                break;
              case "details":
                Vt("toggle", t), p = a;
                break;
              case "input":
                hu(t, a), p = zs(t, a), Vt("invalid", t);
                break;
              case "option":
                p = a;
                break;
              case "select":
                t._wrapperState = { wasMultiple: !!a.multiple }, p = $t({}, a, { value: void 0 }), Vt("invalid", t);
                break;
              case "textarea":
                du(t, a), p = Ys(t, a), Vt("invalid", t);
                break;
              default:
                p = a;
            }
            Hs(n, p), w = p;
            for (g in w) if (w.hasOwnProperty(g)) {
              var x = w[g];
              g === "style" ? bf(t, x) : g === "dangerouslySetInnerHTML" ? (x = x ? x.__html : void 0, x != null && yf(t, x)) : g === "children" ? typeof x == "string" ? (n !== "textarea" || x !== "") && Yr(t, x) : typeof x == "number" && Yr(t, "" + x) : g !== "suppressContentEditableWarning" && g !== "suppressHydrationWarning" && g !== "autoFocus" && (Xr.hasOwnProperty(g) ? x != null && g === "onScroll" && Vt("scroll", t) : x != null && jl(t, g, x, _));
            }
            switch (n) {
              case "input":
                wo(t), fu(t, a, !1);
                break;
              case "textarea":
                wo(t), pu(t);
                break;
              case "option":
                a.value != null && t.setAttribute("value", "" + ai(a.value));
                break;
              case "select":
                t.multiple = !!a.multiple, g = a.value, g != null ? qi(t, !!a.multiple, g, !1) : a.defaultValue != null && qi(
                  t,
                  !!a.multiple,
                  a.defaultValue,
                  !0
                );
                break;
              default:
                typeof p.onClick == "function" && (t.onclick = ca);
            }
            switch (n) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                a = !!a.autoFocus;
                break t;
              case "img":
                a = !0;
                break t;
              default:
                a = !1;
            }
          }
          a && (e.flags |= 4);
        }
        e.ref !== null && (e.flags |= 512, e.flags |= 2097152);
      }
      return ve(e), null;
    case 6:
      if (t && e.stateNode != null) Xd(t, e, t.memoizedProps, a);
      else {
        if (typeof a != "string" && e.stateNode === null) throw Error(ut(166));
        if (n = bi(eo.current), bi(kn.current), Po(e)) {
          if (a = e.stateNode, n = e.memoizedProps, a[wn] = e, (g = a.nodeValue !== n) && (t = Ne, t !== null)) switch (t.tag) {
            case 3:
              Mo(a.nodeValue, n, (t.mode & 1) !== 0);
              break;
            case 5:
              t.memoizedProps.suppressHydrationWarning !== !0 && Mo(a.nodeValue, n, (t.mode & 1) !== 0);
          }
          g && (e.flags |= 4);
        } else a = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(a), a[wn] = e, e.stateNode = a;
      }
      return ve(e), null;
    case 13:
      if (Zt(Kt), a = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
        if (qt && Be !== null && e.mode & 1 && !(e.flags & 128)) sd(), ir(), e.flags |= 98560, g = !1;
        else if (g = Po(e), a !== null && a.dehydrated !== null) {
          if (t === null) {
            if (!g) throw Error(ut(318));
            if (g = e.memoizedState, g = g !== null ? g.dehydrated : null, !g) throw Error(ut(317));
            g[wn] = e;
          } else ir(), !(e.flags & 128) && (e.memoizedState = null), e.flags |= 4;
          ve(e), g = !1;
        } else un !== null && (El(un), un = null), g = !0;
        if (!g) return e.flags & 65536 ? e : null;
      }
      return e.flags & 128 ? (e.lanes = n, e) : (a = a !== null, a !== (t !== null && t.memoizedState !== null) && a && (e.child.flags |= 8192, e.mode & 1 && (t === null || Kt.current & 1 ? se === 0 && (se = 3) : mc())), e.updateQueue !== null && (e.flags |= 4), ve(e), null);
    case 4:
      return or(), _l(t, e), t === null && Qr(e.stateNode.containerInfo), ve(e), null;
    case 10:
      return $l(e.type._context), ve(e), null;
    case 17:
      return Le(e.type) && ua(), ve(e), null;
    case 19:
      if (Zt(Kt), g = e.memoizedState, g === null) return ve(e), null;
      if (a = (e.flags & 128) !== 0, _ = g.rendering, _ === null) if (a) kr(g, !1);
      else {
        if (se !== 0 || t !== null && t.flags & 128) for (t = e.child; t !== null; ) {
          if (_ = va(t), _ !== null) {
            for (e.flags |= 128, kr(g, !1), a = _.updateQueue, a !== null && (e.updateQueue = a, e.flags |= 4), e.subtreeFlags = 0, a = n, n = e.child; n !== null; ) g = n, t = a, g.flags &= 14680066, _ = g.alternate, _ === null ? (g.childLanes = 0, g.lanes = t, g.child = null, g.subtreeFlags = 0, g.memoizedProps = null, g.memoizedState = null, g.updateQueue = null, g.dependencies = null, g.stateNode = null) : (g.childLanes = _.childLanes, g.lanes = _.lanes, g.child = _.child, g.subtreeFlags = 0, g.deletions = null, g.memoizedProps = _.memoizedProps, g.memoizedState = _.memoizedState, g.updateQueue = _.updateQueue, g.type = _.type, t = _.dependencies, g.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }), n = n.sibling;
            return Gt(Kt, Kt.current & 1 | 2), e.child;
          }
          t = t.sibling;
        }
        g.tail !== null && ne() > sr && (e.flags |= 128, a = !0, kr(g, !1), e.lanes = 4194304);
      }
      else {
        if (!a) if (t = va(_), t !== null) {
          if (e.flags |= 128, a = !0, n = t.updateQueue, n !== null && (e.updateQueue = n, e.flags |= 4), kr(g, !0), g.tail === null && g.tailMode === "hidden" && !_.alternate && !qt) return ve(e), null;
        } else 2 * ne() - g.renderingStartTime > sr && n !== 1073741824 && (e.flags |= 128, a = !0, kr(g, !1), e.lanes = 4194304);
        g.isBackwards ? (_.sibling = e.child, e.child = _) : (n = g.last, n !== null ? n.sibling = _ : e.child = _, g.last = _);
      }
      return g.tail !== null ? (e = g.tail, g.rendering = e, g.tail = e.sibling, g.renderingStartTime = ne(), e.sibling = null, n = Kt.current, Gt(Kt, a ? n & 1 | 2 : n & 1), e) : (ve(e), null);
    case 22:
    case 23:
      return gc(), a = e.memoizedState !== null, t !== null && t.memoizedState !== null !== a && (e.flags |= 8192), a && e.mode & 1 ? Re & 1073741824 && (ve(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : ve(e), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(ut(156, e.tag));
}
function gm(t, e) {
  switch (ql(e), e.tag) {
    case 1:
      return Le(e.type) && ua(), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
    case 3:
      return or(), Zt(De), Zt(_e), rc(), t = e.flags, t & 65536 && !(t & 128) ? (e.flags = t & -65537 | 128, e) : null;
    case 5:
      return ic(e), null;
    case 13:
      if (Zt(Kt), t = e.memoizedState, t !== null && t.dehydrated !== null) {
        if (e.alternate === null) throw Error(ut(340));
        ir();
      }
      return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
    case 19:
      return Zt(Kt), null;
    case 4:
      return or(), null;
    case 10:
      return $l(e.type._context), null;
    case 22:
    case 23:
      return gc(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var Lo = !1, ye = !1, mm = typeof WeakSet == "function" ? WeakSet : Set, bt = null;
function Hi(t, e) {
  var n = t.ref;
  if (n !== null) if (typeof n == "function") try {
    n(null);
  } catch (a) {
    ee(t, e, a);
  }
  else n.current = null;
}
function Yd(t, e, n) {
  try {
    n();
  } catch (a) {
    ee(t, e, a);
  }
}
var ih = !1;
function vm(t, e) {
  if (il = aa, t = Zf(), Vl(t)) {
    if ("selectionStart" in t) var n = { start: t.selectionStart, end: t.selectionEnd };
    else t: {
      n = (n = t.ownerDocument) && n.defaultView || window;
      var a = n.getSelection && n.getSelection();
      if (a && a.rangeCount !== 0) {
        n = a.anchorNode;
        var p = a.anchorOffset, g = a.focusNode;
        a = a.focusOffset;
        try {
          n.nodeType, g.nodeType;
        } catch {
          n = null;
          break t;
        }
        var _ = 0, w = -1, x = -1, T = 0, L = 0, X = t, G = null;
        e: for (; ; ) {
          for (var J; X !== n || p !== 0 && X.nodeType !== 3 || (w = _ + p), X !== g || a !== 0 && X.nodeType !== 3 || (x = _ + a), X.nodeType === 3 && (_ += X.nodeValue.length), (J = X.firstChild) !== null; )
            G = X, X = J;
          for (; ; ) {
            if (X === t) break e;
            if (G === n && ++T === p && (w = _), G === g && ++L === a && (x = _), (J = X.nextSibling) !== null) break;
            X = G, G = X.parentNode;
          }
          X = J;
        }
        n = w === -1 || x === -1 ? null : { start: w, end: x };
      } else n = null;
    }
    n = n || { start: 0, end: 0 };
  } else n = null;
  for (rl = { focusedElem: t, selectionRange: n }, aa = !1, bt = e; bt !== null; ) if (e = bt, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, bt = t;
  else for (; bt !== null; ) {
    e = bt;
    try {
      var et = e.alternate;
      if (e.flags & 1024) switch (e.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (et !== null) {
            var rt = et.memoizedProps, vt = et.memoizedState, Y = e.stateNode, j = Y.getSnapshotBeforeUpdate(e.elementType === e.type ? rt : ln(e.type, rt), vt);
            Y.__reactInternalSnapshotBeforeUpdate = j;
          }
          break;
        case 3:
          var P = e.stateNode.containerInfo;
          P.nodeType === 1 ? P.textContent = "" : P.nodeType === 9 && P.documentElement && P.removeChild(P.documentElement);
          break;
        case 5:
        case 6:
        case 4:
        case 17:
          break;
        default:
          throw Error(ut(163));
      }
    } catch ($) {
      ee(e, e.return, $);
    }
    if (t = e.sibling, t !== null) {
      t.return = e.return, bt = t;
      break;
    }
    bt = e.return;
  }
  return et = ih, ih = !1, et;
}
function Nr(t, e, n) {
  var a = e.updateQueue;
  if (a = a !== null ? a.lastEffect : null, a !== null) {
    var p = a = a.next;
    do {
      if ((p.tag & t) === t) {
        var g = p.destroy;
        p.destroy = void 0, g !== void 0 && Yd(e, n, g);
      }
      p = p.next;
    } while (p !== a);
  }
}
function Ra(t, e) {
  if (e = e.updateQueue, e = e !== null ? e.lastEffect : null, e !== null) {
    var n = e = e.next;
    do {
      if ((n.tag & t) === t) {
        var a = n.create;
        n.destroy = a();
      }
      n = n.next;
    } while (n !== e);
  }
}
function bl(t) {
  var e = t.ref;
  if (e !== null) {
    var n = t.stateNode;
    switch (t.tag) {
      case 5:
        t = n;
        break;
      default:
        t = n;
    }
    typeof e == "function" ? e(t) : e.current = t;
  }
}
function Gd(t) {
  var e = t.alternate;
  e !== null && (t.alternate = null, Gd(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && (delete e[wn], delete e[$r], delete e[sl], delete e[$1], delete e[tm])), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
}
function Hd(t) {
  return t.tag === 5 || t.tag === 3 || t.tag === 4;
}
function rh(t) {
  t: for (; ; ) {
    for (; t.sibling === null; ) {
      if (t.return === null || Hd(t.return)) return null;
      t = t.return;
    }
    for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
      if (t.flags & 2 || t.child === null || t.tag === 4) continue t;
      t.child.return = t, t = t.child;
    }
    if (!(t.flags & 2)) return t.stateNode;
  }
}
function wl(t, e, n) {
  var a = t.tag;
  if (a === 5 || a === 6) t = t.stateNode, e ? n.nodeType === 8 ? n.parentNode.insertBefore(t, e) : n.insertBefore(t, e) : (n.nodeType === 8 ? (e = n.parentNode, e.insertBefore(t, n)) : (e = n, e.appendChild(t)), n = n._reactRootContainer, n != null || e.onclick !== null || (e.onclick = ca));
  else if (a !== 4 && (t = t.child, t !== null)) for (wl(t, e, n), t = t.sibling; t !== null; ) wl(t, e, n), t = t.sibling;
}
function Cl(t, e, n) {
  var a = t.tag;
  if (a === 5 || a === 6) t = t.stateNode, e ? n.insertBefore(t, e) : n.appendChild(t);
  else if (a !== 4 && (t = t.child, t !== null)) for (Cl(t, e, n), t = t.sibling; t !== null; ) Cl(t, e, n), t = t.sibling;
}
var fe = null, cn = !1;
function Yn(t, e, n) {
  for (n = n.child; n !== null; ) Vd(t, e, n), n = n.sibling;
}
function Vd(t, e, n) {
  if (En && typeof En.onCommitFiberUnmount == "function") try {
    En.onCommitFiberUnmount(Ma, n);
  } catch {
  }
  switch (n.tag) {
    case 5:
      ye || Hi(n, e);
    case 6:
      var a = fe, p = cn;
      fe = null, Yn(t, e, n), fe = a, cn = p, fe !== null && (cn ? (t = fe, n = n.stateNode, t.nodeType === 8 ? t.parentNode.removeChild(n) : t.removeChild(n)) : fe.removeChild(n.stateNode));
      break;
    case 18:
      fe !== null && (cn ? (t = fe, n = n.stateNode, t.nodeType === 8 ? ms(t.parentNode, n) : t.nodeType === 1 && ms(t, n), Zr(t)) : ms(fe, n.stateNode));
      break;
    case 4:
      a = fe, p = cn, fe = n.stateNode.containerInfo, cn = !0, Yn(t, e, n), fe = a, cn = p;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!ye && (a = n.updateQueue, a !== null && (a = a.lastEffect, a !== null))) {
        p = a = a.next;
        do {
          var g = p, _ = g.destroy;
          g = g.tag, _ !== void 0 && (g & 2 || g & 4) && Yd(n, e, _), p = p.next;
        } while (p !== a);
      }
      Yn(t, e, n);
      break;
    case 1:
      if (!ye && (Hi(n, e), a = n.stateNode, typeof a.componentWillUnmount == "function")) try {
        a.props = n.memoizedProps, a.state = n.memoizedState, a.componentWillUnmount();
      } catch (w) {
        ee(n, e, w);
      }
      Yn(t, e, n);
      break;
    case 21:
      Yn(t, e, n);
      break;
    case 22:
      n.mode & 1 ? (ye = (a = ye) || n.memoizedState !== null, Yn(t, e, n), ye = a) : Yn(t, e, n);
      break;
    default:
      Yn(t, e, n);
  }
}
function oh(t) {
  var e = t.updateQueue;
  if (e !== null) {
    t.updateQueue = null;
    var n = t.stateNode;
    n === null && (n = t.stateNode = new mm()), e.forEach(function(a) {
      var p = Em.bind(null, t, a);
      n.has(a) || (n.add(a), a.then(p, p));
    });
  }
}
function an(t, e) {
  var n = e.deletions;
  if (n !== null) for (var a = 0; a < n.length; a++) {
    var p = n[a];
    try {
      var g = t, _ = e, w = _;
      t: for (; w !== null; ) {
        switch (w.tag) {
          case 5:
            fe = w.stateNode, cn = !1;
            break t;
          case 3:
            fe = w.stateNode.containerInfo, cn = !0;
            break t;
          case 4:
            fe = w.stateNode.containerInfo, cn = !0;
            break t;
        }
        w = w.return;
      }
      if (fe === null) throw Error(ut(160));
      Vd(g, _, p), fe = null, cn = !1;
      var x = p.alternate;
      x !== null && (x.return = null), p.return = null;
    } catch (T) {
      ee(p, e, T);
    }
  }
  if (e.subtreeFlags & 12854) for (e = e.child; e !== null; ) Zd(e, t), e = e.sibling;
}
function Zd(t, e) {
  var n = t.alternate, a = t.flags;
  switch (t.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      if (an(e, t), _n(t), a & 4) {
        try {
          Nr(3, t, t.return), Ra(3, t);
        } catch (rt) {
          ee(t, t.return, rt);
        }
        try {
          Nr(5, t, t.return);
        } catch (rt) {
          ee(t, t.return, rt);
        }
      }
      break;
    case 1:
      an(e, t), _n(t), a & 512 && n !== null && Hi(n, n.return);
      break;
    case 5:
      if (an(e, t), _n(t), a & 512 && n !== null && Hi(n, n.return), t.flags & 32) {
        var p = t.stateNode;
        try {
          Yr(p, "");
        } catch (rt) {
          ee(t, t.return, rt);
        }
      }
      if (a & 4 && (p = t.stateNode, p != null)) {
        var g = t.memoizedProps, _ = n !== null ? n.memoizedProps : g, w = t.type, x = t.updateQueue;
        if (t.updateQueue = null, x !== null) try {
          w === "input" && g.type === "radio" && g.name != null && gf(p, g), Vs(w, _);
          var T = Vs(w, g);
          for (_ = 0; _ < x.length; _ += 2) {
            var L = x[_], X = x[_ + 1];
            L === "style" ? bf(p, X) : L === "dangerouslySetInnerHTML" ? yf(p, X) : L === "children" ? Yr(p, X) : jl(p, L, X, T);
          }
          switch (w) {
            case "input":
              Ws(p, g);
              break;
            case "textarea":
              mf(p, g);
              break;
            case "select":
              var G = p._wrapperState.wasMultiple;
              p._wrapperState.wasMultiple = !!g.multiple;
              var J = g.value;
              J != null ? qi(p, !!g.multiple, J, !1) : G !== !!g.multiple && (g.defaultValue != null ? qi(
                p,
                !!g.multiple,
                g.defaultValue,
                !0
              ) : qi(p, !!g.multiple, g.multiple ? [] : "", !1));
          }
          p[$r] = g;
        } catch (rt) {
          ee(t, t.return, rt);
        }
      }
      break;
    case 6:
      if (an(e, t), _n(t), a & 4) {
        if (t.stateNode === null) throw Error(ut(162));
        p = t.stateNode, g = t.memoizedProps;
        try {
          p.nodeValue = g;
        } catch (rt) {
          ee(t, t.return, rt);
        }
      }
      break;
    case 3:
      if (an(e, t), _n(t), a & 4 && n !== null && n.memoizedState.isDehydrated) try {
        Zr(e.containerInfo);
      } catch (rt) {
        ee(t, t.return, rt);
      }
      break;
    case 4:
      an(e, t), _n(t);
      break;
    case 13:
      an(e, t), _n(t), p = t.child, p.flags & 8192 && (g = p.memoizedState !== null, p.stateNode.isHidden = g, !g || p.alternate !== null && p.alternate.memoizedState !== null || (dc = ne())), a & 4 && oh(t);
      break;
    case 22:
      if (L = n !== null && n.memoizedState !== null, t.mode & 1 ? (ye = (T = ye) || L, an(e, t), ye = T) : an(e, t), _n(t), a & 8192) {
        if (T = t.memoizedState !== null, (t.stateNode.isHidden = T) && !L && t.mode & 1) for (bt = t, L = t.child; L !== null; ) {
          for (X = bt = L; bt !== null; ) {
            switch (G = bt, J = G.child, G.tag) {
              case 0:
              case 11:
              case 14:
              case 15:
                Nr(4, G, G.return);
                break;
              case 1:
                Hi(G, G.return);
                var et = G.stateNode;
                if (typeof et.componentWillUnmount == "function") {
                  a = G, n = G.return;
                  try {
                    e = a, et.props = e.memoizedProps, et.state = e.memoizedState, et.componentWillUnmount();
                  } catch (rt) {
                    ee(a, n, rt);
                  }
                }
                break;
              case 5:
                Hi(G, G.return);
                break;
              case 22:
                if (G.memoizedState !== null) {
                  sh(X);
                  continue;
                }
            }
            J !== null ? (J.return = G, bt = J) : sh(X);
          }
          L = L.sibling;
        }
        t: for (L = null, X = t; ; ) {
          if (X.tag === 5) {
            if (L === null) {
              L = X;
              try {
                p = X.stateNode, T ? (g = p.style, typeof g.setProperty == "function" ? g.setProperty("display", "none", "important") : g.display = "none") : (w = X.stateNode, x = X.memoizedProps.style, _ = x != null && x.hasOwnProperty("display") ? x.display : null, w.style.display = _f("display", _));
              } catch (rt) {
                ee(t, t.return, rt);
              }
            }
          } else if (X.tag === 6) {
            if (L === null) try {
              X.stateNode.nodeValue = T ? "" : X.memoizedProps;
            } catch (rt) {
              ee(t, t.return, rt);
            }
          } else if ((X.tag !== 22 && X.tag !== 23 || X.memoizedState === null || X === t) && X.child !== null) {
            X.child.return = X, X = X.child;
            continue;
          }
          if (X === t) break t;
          for (; X.sibling === null; ) {
            if (X.return === null || X.return === t) break t;
            L === X && (L = null), X = X.return;
          }
          L === X && (L = null), X.sibling.return = X.return, X = X.sibling;
        }
      }
      break;
    case 19:
      an(e, t), _n(t), a & 4 && oh(t);
      break;
    case 21:
      break;
    default:
      an(
        e,
        t
      ), _n(t);
  }
}
function _n(t) {
  var e = t.flags;
  if (e & 2) {
    try {
      t: {
        for (var n = t.return; n !== null; ) {
          if (Hd(n)) {
            var a = n;
            break t;
          }
          n = n.return;
        }
        throw Error(ut(160));
      }
      switch (a.tag) {
        case 5:
          var p = a.stateNode;
          a.flags & 32 && (Yr(p, ""), a.flags &= -33);
          var g = rh(t);
          Cl(t, g, p);
          break;
        case 3:
        case 4:
          var _ = a.stateNode.containerInfo, w = rh(t);
          wl(t, w, _);
          break;
        default:
          throw Error(ut(161));
      }
    } catch (x) {
      ee(t, t.return, x);
    }
    t.flags &= -3;
  }
  e & 4096 && (t.flags &= -4097);
}
function ym(t, e, n) {
  bt = t, qd(t);
}
function qd(t, e, n) {
  for (var a = (t.mode & 1) !== 0; bt !== null; ) {
    var p = bt, g = p.child;
    if (p.tag === 22 && a) {
      var _ = p.memoizedState !== null || Lo;
      if (!_) {
        var w = p.alternate, x = w !== null && w.memoizedState !== null || ye;
        w = Lo;
        var T = ye;
        if (Lo = _, (ye = x) && !T) for (bt = p; bt !== null; ) _ = bt, x = _.child, _.tag === 22 && _.memoizedState !== null ? lh(p) : x !== null ? (x.return = _, bt = x) : lh(p);
        for (; g !== null; ) bt = g, qd(g), g = g.sibling;
        bt = p, Lo = w, ye = T;
      }
      ah(t);
    } else p.subtreeFlags & 8772 && g !== null ? (g.return = p, bt = g) : ah(t);
  }
}
function ah(t) {
  for (; bt !== null; ) {
    var e = bt;
    if (e.flags & 8772) {
      var n = e.alternate;
      try {
        if (e.flags & 8772) switch (e.tag) {
          case 0:
          case 11:
          case 15:
            ye || Ra(5, e);
            break;
          case 1:
            var a = e.stateNode;
            if (e.flags & 4 && !ye) if (n === null) a.componentDidMount();
            else {
              var p = e.elementType === e.type ? n.memoizedProps : ln(e.type, n.memoizedProps);
              a.componentDidUpdate(p, n.memoizedState, a.__reactInternalSnapshotBeforeUpdate);
            }
            var g = e.updateQueue;
            g !== null && Yu(e, g, a);
            break;
          case 3:
            var _ = e.updateQueue;
            if (_ !== null) {
              if (n = null, e.child !== null) switch (e.child.tag) {
                case 5:
                  n = e.child.stateNode;
                  break;
                case 1:
                  n = e.child.stateNode;
              }
              Yu(e, _, n);
            }
            break;
          case 5:
            var w = e.stateNode;
            if (n === null && e.flags & 4) {
              n = w;
              var x = e.memoizedProps;
              switch (e.type) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  x.autoFocus && n.focus();
                  break;
                case "img":
                  x.src && (n.src = x.src);
              }
            }
            break;
          case 6:
            break;
          case 4:
            break;
          case 12:
            break;
          case 13:
            if (e.memoizedState === null) {
              var T = e.alternate;
              if (T !== null) {
                var L = T.memoizedState;
                if (L !== null) {
                  var X = L.dehydrated;
                  X !== null && Zr(X);
                }
              }
            }
            break;
          case 19:
          case 17:
          case 21:
          case 22:
          case 23:
          case 25:
            break;
          default:
            throw Error(ut(163));
        }
        ye || e.flags & 512 && bl(e);
      } catch (G) {
        ee(e, e.return, G);
      }
    }
    if (e === t) {
      bt = null;
      break;
    }
    if (n = e.sibling, n !== null) {
      n.return = e.return, bt = n;
      break;
    }
    bt = e.return;
  }
}
function sh(t) {
  for (; bt !== null; ) {
    var e = bt;
    if (e === t) {
      bt = null;
      break;
    }
    var n = e.sibling;
    if (n !== null) {
      n.return = e.return, bt = n;
      break;
    }
    bt = e.return;
  }
}
function lh(t) {
  for (; bt !== null; ) {
    var e = bt;
    try {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          var n = e.return;
          try {
            Ra(4, e);
          } catch (x) {
            ee(e, n, x);
          }
          break;
        case 1:
          var a = e.stateNode;
          if (typeof a.componentDidMount == "function") {
            var p = e.return;
            try {
              a.componentDidMount();
            } catch (x) {
              ee(e, p, x);
            }
          }
          var g = e.return;
          try {
            bl(e);
          } catch (x) {
            ee(e, g, x);
          }
          break;
        case 5:
          var _ = e.return;
          try {
            bl(e);
          } catch (x) {
            ee(e, _, x);
          }
      }
    } catch (x) {
      ee(e, e.return, x);
    }
    if (e === t) {
      bt = null;
      break;
    }
    var w = e.sibling;
    if (w !== null) {
      w.return = e.return, bt = w;
      break;
    }
    bt = e.return;
  }
}
var _m = Math.ceil, ba = Wn.ReactCurrentDispatcher, hc = Wn.ReactCurrentOwner, Qe = Wn.ReactCurrentBatchConfig, Nt = 0, ue = null, ie = null, de = 0, Re = 0, Vi = ci(0), se = 0, oo = null, Ei = 0, Ba = 0, fc = 0, Ur = null, Pe = null, dc = 0, sr = 1 / 0, Dn = null, wa = !1, xl = null, ii = null, jo = !1, Qn = null, Ca = 0, zr = 0, Sl = null, Qo = -1, Jo = 0;
function xe() {
  return Nt & 6 ? ne() : Qo !== -1 ? Qo : Qo = ne();
}
function ri(t) {
  return t.mode & 1 ? Nt & 2 && de !== 0 ? de & -de : nm.transition !== null ? (Jo === 0 && (Jo = Df()), Jo) : (t = Wt, t !== 0 || (t = window.event, t = t === void 0 ? 16 : Nf(t.type)), t) : 1;
}
function pn(t, e, n, a) {
  if (50 < zr) throw zr = 0, Sl = null, Error(ut(185));
  so(t, n, a), (!(Nt & 2) || t !== ue) && (t === ue && (!(Nt & 2) && (Ba |= n), se === 4 && Zn(t, de)), je(t, a), n === 1 && Nt === 0 && !(e.mode & 1) && (sr = ne() + 500, ja && ui()));
}
function je(t, e) {
  var n = t.callbackNode;
  n1(t, e);
  var a = oa(t, t === ue ? de : 0);
  if (a === 0) n !== null && vu(n), t.callbackNode = null, t.callbackPriority = 0;
  else if (e = a & -a, t.callbackPriority !== e) {
    if (n != null && vu(n), e === 1) t.tag === 0 ? em(ch.bind(null, t)) : rd(ch.bind(null, t)), Q1(function() {
      !(Nt & 6) && ui();
    }), n = null;
    else {
      switch (Lf(a)) {
        case 1:
          n = Nl;
          break;
        case 4:
          n = Pf;
          break;
        case 16:
          n = ra;
          break;
        case 536870912:
          n = Af;
          break;
        default:
          n = ra;
      }
      n = i0(n, Kd.bind(null, t));
    }
    t.callbackPriority = e, t.callbackNode = n;
  }
}
function Kd(t, e) {
  if (Qo = -1, Jo = 0, Nt & 6) throw Error(ut(327));
  var n = t.callbackNode;
  if (tr() && t.callbackNode !== n) return null;
  var a = oa(t, t === ue ? de : 0);
  if (a === 0) return null;
  if (a & 30 || a & t.expiredLanes || e) e = xa(t, a);
  else {
    e = a;
    var p = Nt;
    Nt |= 2;
    var g = Jd();
    (ue !== t || de !== e) && (Dn = null, sr = ne() + 500, wi(t, e));
    do
      try {
        Cm();
        break;
      } catch (w) {
        Qd(t, w);
      }
    while (!0);
    Jl(), ba.current = g, Nt = p, ie !== null ? e = 0 : (ue = null, de = 0, e = se);
  }
  if (e !== 0) {
    if (e === 2 && (p = Js(t), p !== 0 && (a = p, e = Tl(t, p))), e === 1) throw n = oo, wi(t, 0), Zn(t, a), je(t, ne()), n;
    if (e === 6) Zn(t, a);
    else {
      if (p = t.current.alternate, !(a & 30) && !bm(p) && (e = xa(t, a), e === 2 && (g = Js(t), g !== 0 && (a = g, e = Tl(t, g))), e === 1)) throw n = oo, wi(t, 0), Zn(t, a), je(t, ne()), n;
      switch (t.finishedWork = p, t.finishedLanes = a, e) {
        case 0:
        case 1:
          throw Error(ut(345));
        case 2:
          mi(t, Pe, Dn);
          break;
        case 3:
          if (Zn(t, a), (a & 130023424) === a && (e = dc + 500 - ne(), 10 < e)) {
            if (oa(t, 0) !== 0) break;
            if (p = t.suspendedLanes, (p & a) !== a) {
              xe(), t.pingedLanes |= t.suspendedLanes & p;
              break;
            }
            t.timeoutHandle = al(mi.bind(null, t, Pe, Dn), e);
            break;
          }
          mi(t, Pe, Dn);
          break;
        case 4:
          if (Zn(t, a), (a & 4194240) === a) break;
          for (e = t.eventTimes, p = -1; 0 < a; ) {
            var _ = 31 - dn(a);
            g = 1 << _, _ = e[_], _ > p && (p = _), a &= ~g;
          }
          if (a = p, a = ne() - a, a = (120 > a ? 120 : 480 > a ? 480 : 1080 > a ? 1080 : 1920 > a ? 1920 : 3e3 > a ? 3e3 : 4320 > a ? 4320 : 1960 * _m(a / 1960)) - a, 10 < a) {
            t.timeoutHandle = al(mi.bind(null, t, Pe, Dn), a);
            break;
          }
          mi(t, Pe, Dn);
          break;
        case 5:
          mi(t, Pe, Dn);
          break;
        default:
          throw Error(ut(329));
      }
    }
  }
  return je(t, ne()), t.callbackNode === n ? Kd.bind(null, t) : null;
}
function Tl(t, e) {
  var n = Ur;
  return t.current.memoizedState.isDehydrated && (wi(t, e).flags |= 256), t = xa(t, e), t !== 2 && (e = Pe, Pe = n, e !== null && El(e)), t;
}
function El(t) {
  Pe === null ? Pe = t : Pe.push.apply(Pe, t);
}
function bm(t) {
  for (var e = t; ; ) {
    if (e.flags & 16384) {
      var n = e.updateQueue;
      if (n !== null && (n = n.stores, n !== null)) for (var a = 0; a < n.length; a++) {
        var p = n[a], g = p.getSnapshot;
        p = p.value;
        try {
          if (!gn(g(), p)) return !1;
        } catch {
          return !1;
        }
      }
    }
    if (n = e.child, e.subtreeFlags & 16384 && n !== null) n.return = e, e = n;
    else {
      if (e === t) break;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) return !0;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
  }
  return !0;
}
function Zn(t, e) {
  for (e &= ~fc, e &= ~Ba, t.suspendedLanes |= e, t.pingedLanes &= ~e, t = t.expirationTimes; 0 < e; ) {
    var n = 31 - dn(e), a = 1 << n;
    t[n] = -1, e &= ~a;
  }
}
function ch(t) {
  if (Nt & 6) throw Error(ut(327));
  tr();
  var e = oa(t, 0);
  if (!(e & 1)) return je(t, ne()), null;
  var n = xa(t, e);
  if (t.tag !== 0 && n === 2) {
    var a = Js(t);
    a !== 0 && (e = a, n = Tl(t, a));
  }
  if (n === 1) throw n = oo, wi(t, 0), Zn(t, e), je(t, ne()), n;
  if (n === 6) throw Error(ut(345));
  return t.finishedWork = t.current.alternate, t.finishedLanes = e, mi(t, Pe, Dn), je(t, ne()), null;
}
function pc(t, e) {
  var n = Nt;
  Nt |= 1;
  try {
    return t(e);
  } finally {
    Nt = n, Nt === 0 && (sr = ne() + 500, ja && ui());
  }
}
function ki(t) {
  Qn !== null && Qn.tag === 0 && !(Nt & 6) && tr();
  var e = Nt;
  Nt |= 1;
  var n = Qe.transition, a = Wt;
  try {
    if (Qe.transition = null, Wt = 1, t) return t();
  } finally {
    Wt = a, Qe.transition = n, Nt = e, !(Nt & 6) && ui();
  }
}
function gc() {
  Re = Vi.current, Zt(Vi);
}
function wi(t, e) {
  t.finishedWork = null, t.finishedLanes = 0;
  var n = t.timeoutHandle;
  if (n !== -1 && (t.timeoutHandle = -1, K1(n)), ie !== null) for (n = ie.return; n !== null; ) {
    var a = n;
    switch (ql(a), a.tag) {
      case 1:
        a = a.type.childContextTypes, a != null && ua();
        break;
      case 3:
        or(), Zt(De), Zt(_e), rc();
        break;
      case 5:
        ic(a);
        break;
      case 4:
        or();
        break;
      case 13:
        Zt(Kt);
        break;
      case 19:
        Zt(Kt);
        break;
      case 10:
        $l(a.type._context);
        break;
      case 22:
      case 23:
        gc();
    }
    n = n.return;
  }
  if (ue = t, ie = t = oi(t.current, null), de = Re = e, se = 0, oo = null, fc = Ba = Ei = 0, Pe = Ur = null, _i !== null) {
    for (e = 0; e < _i.length; e++) if (n = _i[e], a = n.interleaved, a !== null) {
      n.interleaved = null;
      var p = a.next, g = n.pending;
      if (g !== null) {
        var _ = g.next;
        g.next = p, a.next = _;
      }
      n.pending = a;
    }
    _i = null;
  }
  return t;
}
function Qd(t, e) {
  do {
    var n = ie;
    try {
      if (Jl(), Zo.current = _a, ya) {
        for (var a = Jt.memoizedState; a !== null; ) {
          var p = a.queue;
          p !== null && (p.pending = null), a = a.next;
        }
        ya = !1;
      }
      if (Ti = 0, ce = ae = Jt = null, Br = !1, no = 0, hc.current = null, n === null || n.return === null) {
        se = 1, oo = e, ie = null;
        break;
      }
      t: {
        var g = t, _ = n.return, w = n, x = e;
        if (e = de, w.flags |= 32768, x !== null && typeof x == "object" && typeof x.then == "function") {
          var T = x, L = w, X = L.tag;
          if (!(L.mode & 1) && (X === 0 || X === 11 || X === 15)) {
            var G = L.alternate;
            G ? (L.updateQueue = G.updateQueue, L.memoizedState = G.memoizedState, L.lanes = G.lanes) : (L.updateQueue = null, L.memoizedState = null);
          }
          var J = Ku(_);
          if (J !== null) {
            J.flags &= -257, Qu(J, _, w, g, e), J.mode & 1 && qu(g, T, e), e = J, x = T;
            var et = e.updateQueue;
            if (et === null) {
              var rt = /* @__PURE__ */ new Set();
              rt.add(x), e.updateQueue = rt;
            } else et.add(x);
            break t;
          } else {
            if (!(e & 1)) {
              qu(g, T, e), mc();
              break t;
            }
            x = Error(ut(426));
          }
        } else if (qt && w.mode & 1) {
          var vt = Ku(_);
          if (vt !== null) {
            !(vt.flags & 65536) && (vt.flags |= 256), Qu(vt, _, w, g, e), Kl(ar(x, w));
            break t;
          }
        }
        g = x = ar(x, w), se !== 4 && (se = 2), Ur === null ? Ur = [g] : Ur.push(g), g = _;
        do {
          switch (g.tag) {
            case 3:
              g.flags |= 65536, e &= -e, g.lanes |= e;
              var Y = Ld(g, x, e);
              Xu(g, Y);
              break t;
            case 1:
              w = x;
              var j = g.type, P = g.stateNode;
              if (!(g.flags & 128) && (typeof j.getDerivedStateFromError == "function" || P !== null && typeof P.componentDidCatch == "function" && (ii === null || !ii.has(P)))) {
                g.flags |= 65536, e &= -e, g.lanes |= e;
                var $ = jd(g, w, e);
                Xu(g, $);
                break t;
              }
          }
          g = g.return;
        } while (g !== null);
      }
      t0(n);
    } catch (ht) {
      e = ht, ie === n && n !== null && (ie = n = n.return);
      continue;
    }
    break;
  } while (!0);
}
function Jd() {
  var t = ba.current;
  return ba.current = _a, t === null ? _a : t;
}
function mc() {
  (se === 0 || se === 3 || se === 2) && (se = 4), ue === null || !(Ei & 268435455) && !(Ba & 268435455) || Zn(ue, de);
}
function xa(t, e) {
  var n = Nt;
  Nt |= 2;
  var a = Jd();
  (ue !== t || de !== e) && (Dn = null, wi(t, e));
  do
    try {
      wm();
      break;
    } catch (p) {
      Qd(t, p);
    }
  while (!0);
  if (Jl(), Nt = n, ba.current = a, ie !== null) throw Error(ut(261));
  return ue = null, de = 0, se;
}
function wm() {
  for (; ie !== null; ) $d(ie);
}
function Cm() {
  for (; ie !== null && !Vg(); ) $d(ie);
}
function $d(t) {
  var e = n0(t.alternate, t, Re);
  t.memoizedProps = t.pendingProps, e === null ? t0(t) : ie = e, hc.current = null;
}
function t0(t) {
  var e = t;
  do {
    var n = e.alternate;
    if (t = e.return, e.flags & 32768) {
      if (n = gm(n, e), n !== null) {
        n.flags &= 32767, ie = n;
        return;
      }
      if (t !== null) t.flags |= 32768, t.subtreeFlags = 0, t.deletions = null;
      else {
        se = 6, ie = null;
        return;
      }
    } else if (n = pm(n, e, Re), n !== null) {
      ie = n;
      return;
    }
    if (e = e.sibling, e !== null) {
      ie = e;
      return;
    }
    ie = e = t;
  } while (e !== null);
  se === 0 && (se = 5);
}
function mi(t, e, n) {
  var a = Wt, p = Qe.transition;
  try {
    Qe.transition = null, Wt = 1, xm(t, e, n, a);
  } finally {
    Qe.transition = p, Wt = a;
  }
  return null;
}
function xm(t, e, n, a) {
  do
    tr();
  while (Qn !== null);
  if (Nt & 6) throw Error(ut(327));
  n = t.finishedWork;
  var p = t.finishedLanes;
  if (n === null) return null;
  if (t.finishedWork = null, t.finishedLanes = 0, n === t.current) throw Error(ut(177));
  t.callbackNode = null, t.callbackPriority = 0;
  var g = n.lanes | n.childLanes;
  if (i1(t, g), t === ue && (ie = ue = null, de = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || jo || (jo = !0, i0(ra, function() {
    return tr(), null;
  })), g = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || g) {
    g = Qe.transition, Qe.transition = null;
    var _ = Wt;
    Wt = 1;
    var w = Nt;
    Nt |= 4, hc.current = null, vm(t, n), Zd(n, t), X1(rl), aa = !!il, rl = il = null, t.current = n, ym(n), Zg(), Nt = w, Wt = _, Qe.transition = g;
  } else t.current = n;
  if (jo && (jo = !1, Qn = t, Ca = p), g = t.pendingLanes, g === 0 && (ii = null), Qg(n.stateNode), je(t, ne()), e !== null) for (a = t.onRecoverableError, n = 0; n < e.length; n++) p = e[n], a(p.value, { componentStack: p.stack, digest: p.digest });
  if (wa) throw wa = !1, t = xl, xl = null, t;
  return Ca & 1 && t.tag !== 0 && tr(), g = t.pendingLanes, g & 1 ? t === Sl ? zr++ : (zr = 0, Sl = t) : zr = 0, ui(), null;
}
function tr() {
  if (Qn !== null) {
    var t = Lf(Ca), e = Qe.transition, n = Wt;
    try {
      if (Qe.transition = null, Wt = 16 > t ? 16 : t, Qn === null) var a = !1;
      else {
        if (t = Qn, Qn = null, Ca = 0, Nt & 6) throw Error(ut(331));
        var p = Nt;
        for (Nt |= 4, bt = t.current; bt !== null; ) {
          var g = bt, _ = g.child;
          if (bt.flags & 16) {
            var w = g.deletions;
            if (w !== null) {
              for (var x = 0; x < w.length; x++) {
                var T = w[x];
                for (bt = T; bt !== null; ) {
                  var L = bt;
                  switch (L.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Nr(8, L, g);
                  }
                  var X = L.child;
                  if (X !== null) X.return = L, bt = X;
                  else for (; bt !== null; ) {
                    L = bt;
                    var G = L.sibling, J = L.return;
                    if (Gd(L), L === T) {
                      bt = null;
                      break;
                    }
                    if (G !== null) {
                      G.return = J, bt = G;
                      break;
                    }
                    bt = J;
                  }
                }
              }
              var et = g.alternate;
              if (et !== null) {
                var rt = et.child;
                if (rt !== null) {
                  et.child = null;
                  do {
                    var vt = rt.sibling;
                    rt.sibling = null, rt = vt;
                  } while (rt !== null);
                }
              }
              bt = g;
            }
          }
          if (g.subtreeFlags & 2064 && _ !== null) _.return = g, bt = _;
          else t: for (; bt !== null; ) {
            if (g = bt, g.flags & 2048) switch (g.tag) {
              case 0:
              case 11:
              case 15:
                Nr(9, g, g.return);
            }
            var Y = g.sibling;
            if (Y !== null) {
              Y.return = g.return, bt = Y;
              break t;
            }
            bt = g.return;
          }
        }
        var j = t.current;
        for (bt = j; bt !== null; ) {
          _ = bt;
          var P = _.child;
          if (_.subtreeFlags & 2064 && P !== null) P.return = _, bt = P;
          else t: for (_ = j; bt !== null; ) {
            if (w = bt, w.flags & 2048) try {
              switch (w.tag) {
                case 0:
                case 11:
                case 15:
                  Ra(9, w);
              }
            } catch (ht) {
              ee(w, w.return, ht);
            }
            if (w === _) {
              bt = null;
              break t;
            }
            var $ = w.sibling;
            if ($ !== null) {
              $.return = w.return, bt = $;
              break t;
            }
            bt = w.return;
          }
        }
        if (Nt = p, ui(), En && typeof En.onPostCommitFiberRoot == "function") try {
          En.onPostCommitFiberRoot(Ma, t);
        } catch {
        }
        a = !0;
      }
      return a;
    } finally {
      Wt = n, Qe.transition = e;
    }
  }
  return !1;
}
function uh(t, e, n) {
  e = ar(n, e), e = Ld(t, e, 1), t = ni(t, e, 1), e = xe(), t !== null && (so(t, 1, e), je(t, e));
}
function ee(t, e, n) {
  if (t.tag === 3) uh(t, t, n);
  else for (; e !== null; ) {
    if (e.tag === 3) {
      uh(e, t, n);
      break;
    } else if (e.tag === 1) {
      var a = e.stateNode;
      if (typeof e.type.getDerivedStateFromError == "function" || typeof a.componentDidCatch == "function" && (ii === null || !ii.has(a))) {
        t = ar(n, t), t = jd(e, t, 1), e = ni(e, t, 1), t = xe(), e !== null && (so(e, 1, t), je(e, t));
        break;
      }
    }
    e = e.return;
  }
}
function Sm(t, e, n) {
  var a = t.pingCache;
  a !== null && a.delete(e), e = xe(), t.pingedLanes |= t.suspendedLanes & n, ue === t && (de & n) === n && (se === 4 || se === 3 && (de & 130023424) === de && 500 > ne() - dc ? wi(t, 0) : fc |= n), je(t, e);
}
function e0(t, e) {
  e === 0 && (t.mode & 1 ? (e = So, So <<= 1, !(So & 130023424) && (So = 4194304)) : e = 1);
  var n = xe();
  t = Un(t, e), t !== null && (so(t, e, n), je(t, n));
}
function Tm(t) {
  var e = t.memoizedState, n = 0;
  e !== null && (n = e.retryLane), e0(t, n);
}
function Em(t, e) {
  var n = 0;
  switch (t.tag) {
    case 13:
      var a = t.stateNode, p = t.memoizedState;
      p !== null && (n = p.retryLane);
      break;
    case 19:
      a = t.stateNode;
      break;
    default:
      throw Error(ut(314));
  }
  a !== null && a.delete(e), e0(t, n);
}
var n0;
n0 = function(t, e, n) {
  if (t !== null) if (t.memoizedProps !== e.pendingProps || De.current) Ae = !0;
  else {
    if (!(t.lanes & n) && !(e.flags & 128)) return Ae = !1, dm(t, e, n);
    Ae = !!(t.flags & 131072);
  }
  else Ae = !1, qt && e.flags & 1048576 && od(e, da, e.index);
  switch (e.lanes = 0, e.tag) {
    case 2:
      var a = e.type;
      Ko(t, e), t = e.pendingProps;
      var p = nr(e, _e.current);
      $i(e, n), p = ac(null, e, a, t, p, n);
      var g = sc();
      return e.flags |= 1, typeof p == "object" && p !== null && typeof p.render == "function" && p.$$typeof === void 0 ? (e.tag = 1, e.memoizedState = null, e.updateQueue = null, Le(a) ? (g = !0, ha(e)) : g = !1, e.memoizedState = p.state !== null && p.state !== void 0 ? p.state : null, ec(e), p.updater = Fa, e.stateNode = p, p._reactInternals = e, dl(e, a, t, n), e = ml(null, e, a, !0, g, n)) : (e.tag = 0, qt && g && Zl(e), Ce(null, e, p, n), e = e.child), e;
    case 16:
      a = e.elementType;
      t: {
        switch (Ko(t, e), t = e.pendingProps, p = a._init, a = p(a._payload), e.type = a, p = e.tag = Om(a), t = ln(a, t), p) {
          case 0:
            e = gl(null, e, a, t, n);
            break t;
          case 1:
            e = th(null, e, a, t, n);
            break t;
          case 11:
            e = Ju(null, e, a, t, n);
            break t;
          case 14:
            e = $u(null, e, a, ln(a.type, t), n);
            break t;
        }
        throw Error(ut(
          306,
          a,
          ""
        ));
      }
      return e;
    case 0:
      return a = e.type, p = e.pendingProps, p = e.elementType === a ? p : ln(a, p), gl(t, e, a, p, n);
    case 1:
      return a = e.type, p = e.pendingProps, p = e.elementType === a ? p : ln(a, p), th(t, e, a, p, n);
    case 3:
      t: {
        if (Bd(e), t === null) throw Error(ut(387));
        a = e.pendingProps, g = e.memoizedState, p = g.element, hd(t, e), ma(e, a, null, n);
        var _ = e.memoizedState;
        if (a = _.element, g.isDehydrated) if (g = { element: a, isDehydrated: !1, cache: _.cache, pendingSuspenseBoundaries: _.pendingSuspenseBoundaries, transitions: _.transitions }, e.updateQueue.baseState = g, e.memoizedState = g, e.flags & 256) {
          p = ar(Error(ut(423)), e), e = eh(t, e, a, n, p);
          break t;
        } else if (a !== p) {
          p = ar(Error(ut(424)), e), e = eh(t, e, a, n, p);
          break t;
        } else for (Be = ei(e.stateNode.containerInfo.firstChild), Ne = e, qt = !0, un = null, n = cd(e, null, a, n), e.child = n; n; ) n.flags = n.flags & -3 | 4096, n = n.sibling;
        else {
          if (ir(), a === p) {
            e = zn(t, e, n);
            break t;
          }
          Ce(t, e, a, n);
        }
        e = e.child;
      }
      return e;
    case 5:
      return fd(e), t === null && ul(e), a = e.type, p = e.pendingProps, g = t !== null ? t.memoizedProps : null, _ = p.children, ol(a, p) ? _ = null : g !== null && ol(a, g) && (e.flags |= 32), Rd(t, e), Ce(t, e, _, n), e.child;
    case 6:
      return t === null && ul(e), null;
    case 13:
      return Nd(t, e, n);
    case 4:
      return nc(e, e.stateNode.containerInfo), a = e.pendingProps, t === null ? e.child = rr(e, null, a, n) : Ce(t, e, a, n), e.child;
    case 11:
      return a = e.type, p = e.pendingProps, p = e.elementType === a ? p : ln(a, p), Ju(t, e, a, p, n);
    case 7:
      return Ce(t, e, e.pendingProps, n), e.child;
    case 8:
      return Ce(t, e, e.pendingProps.children, n), e.child;
    case 12:
      return Ce(t, e, e.pendingProps.children, n), e.child;
    case 10:
      t: {
        if (a = e.type._context, p = e.pendingProps, g = e.memoizedProps, _ = p.value, Gt(pa, a._currentValue), a._currentValue = _, g !== null) if (gn(g.value, _)) {
          if (g.children === p.children && !De.current) {
            e = zn(t, e, n);
            break t;
          }
        } else for (g = e.child, g !== null && (g.return = e); g !== null; ) {
          var w = g.dependencies;
          if (w !== null) {
            _ = g.child;
            for (var x = w.firstContext; x !== null; ) {
              if (x.context === a) {
                if (g.tag === 1) {
                  x = Rn(-1, n & -n), x.tag = 2;
                  var T = g.updateQueue;
                  if (T !== null) {
                    T = T.shared;
                    var L = T.pending;
                    L === null ? x.next = x : (x.next = L.next, L.next = x), T.pending = x;
                  }
                }
                g.lanes |= n, x = g.alternate, x !== null && (x.lanes |= n), hl(
                  g.return,
                  n,
                  e
                ), w.lanes |= n;
                break;
              }
              x = x.next;
            }
          } else if (g.tag === 10) _ = g.type === e.type ? null : g.child;
          else if (g.tag === 18) {
            if (_ = g.return, _ === null) throw Error(ut(341));
            _.lanes |= n, w = _.alternate, w !== null && (w.lanes |= n), hl(_, n, e), _ = g.sibling;
          } else _ = g.child;
          if (_ !== null) _.return = g;
          else for (_ = g; _ !== null; ) {
            if (_ === e) {
              _ = null;
              break;
            }
            if (g = _.sibling, g !== null) {
              g.return = _.return, _ = g;
              break;
            }
            _ = _.return;
          }
          g = _;
        }
        Ce(t, e, p.children, n), e = e.child;
      }
      return e;
    case 9:
      return p = e.type, a = e.pendingProps.children, $i(e, n), p = tn(p), a = a(p), e.flags |= 1, Ce(t, e, a, n), e.child;
    case 14:
      return a = e.type, p = ln(a, e.pendingProps), p = ln(a.type, p), $u(t, e, a, p, n);
    case 15:
      return Id(t, e, e.type, e.pendingProps, n);
    case 17:
      return a = e.type, p = e.pendingProps, p = e.elementType === a ? p : ln(a, p), Ko(t, e), e.tag = 1, Le(a) ? (t = !0, ha(e)) : t = !1, $i(e, n), Dd(e, a, p), dl(e, a, p, n), ml(null, e, a, !0, t, n);
    case 19:
      return Ud(t, e, n);
    case 22:
      return Fd(t, e, n);
  }
  throw Error(ut(156, e.tag));
};
function i0(t, e) {
  return Mf(t, e);
}
function km(t, e, n, a) {
  this.tag = t, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = a, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
}
function Ke(t, e, n, a) {
  return new km(t, e, n, a);
}
function vc(t) {
  return t = t.prototype, !(!t || !t.isReactComponent);
}
function Om(t) {
  if (typeof t == "function") return vc(t) ? 1 : 0;
  if (t != null) {
    if (t = t.$$typeof, t === Fl) return 11;
    if (t === Rl) return 14;
  }
  return 2;
}
function oi(t, e) {
  var n = t.alternate;
  return n === null ? (n = Ke(t.tag, e, t.key, t.mode), n.elementType = t.elementType, n.type = t.type, n.stateNode = t.stateNode, n.alternate = t, t.alternate = n) : (n.pendingProps = e, n.type = t.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = t.flags & 14680064, n.childLanes = t.childLanes, n.lanes = t.lanes, n.child = t.child, n.memoizedProps = t.memoizedProps, n.memoizedState = t.memoizedState, n.updateQueue = t.updateQueue, e = t.dependencies, n.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }, n.sibling = t.sibling, n.index = t.index, n.ref = t.ref, n;
}
function $o(t, e, n, a, p, g) {
  var _ = 2;
  if (a = t, typeof t == "function") vc(t) && (_ = 1);
  else if (typeof t == "string") _ = 5;
  else t: switch (t) {
    case Ri:
      return Ci(n.children, p, g, e);
    case Il:
      _ = 8, p |= 8;
      break;
    case Rs:
      return t = Ke(12, n, e, p | 2), t.elementType = Rs, t.lanes = g, t;
    case Bs:
      return t = Ke(13, n, e, p), t.elementType = Bs, t.lanes = g, t;
    case Ns:
      return t = Ke(19, n, e, p), t.elementType = Ns, t.lanes = g, t;
    case ff:
      return Na(n, p, g, e);
    default:
      if (typeof t == "object" && t !== null) switch (t.$$typeof) {
        case uf:
          _ = 10;
          break t;
        case hf:
          _ = 9;
          break t;
        case Fl:
          _ = 11;
          break t;
        case Rl:
          _ = 14;
          break t;
        case Gn:
          _ = 16, a = null;
          break t;
      }
      throw Error(ut(130, t == null ? t : typeof t, ""));
  }
  return e = Ke(_, n, e, p), e.elementType = t, e.type = a, e.lanes = g, e;
}
function Ci(t, e, n, a) {
  return t = Ke(7, t, a, e), t.lanes = n, t;
}
function Na(t, e, n, a) {
  return t = Ke(22, t, a, e), t.elementType = ff, t.lanes = n, t.stateNode = { isHidden: !1 }, t;
}
function Ss(t, e, n) {
  return t = Ke(6, t, null, e), t.lanes = n, t;
}
function Ts(t, e, n) {
  return e = Ke(4, t.children !== null ? t.children : [], t.key, e), e.lanes = n, e.stateNode = { containerInfo: t.containerInfo, pendingChildren: null, implementation: t.implementation }, e;
}
function Mm(t, e, n, a, p) {
  this.tag = e, this.containerInfo = t, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = os(0), this.expirationTimes = os(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = os(0), this.identifierPrefix = a, this.onRecoverableError = p, this.mutableSourceEagerHydrationData = null;
}
function yc(t, e, n, a, p, g, _, w, x) {
  return t = new Mm(t, e, n, w, x), e === 1 ? (e = 1, g === !0 && (e |= 8)) : e = 0, g = Ke(3, null, null, e), t.current = g, g.stateNode = t, g.memoizedState = { element: a, isDehydrated: n, cache: null, transitions: null, pendingSuspenseBoundaries: null }, ec(g), t;
}
function Pm(t, e, n) {
  var a = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
  return { $$typeof: Fi, key: a == null ? null : "" + a, children: t, containerInfo: e, implementation: n };
}
function r0(t) {
  if (!t) return si;
  t = t._reactInternals;
  t: {
    if (Mi(t) !== t || t.tag !== 1) throw Error(ut(170));
    var e = t;
    do {
      switch (e.tag) {
        case 3:
          e = e.stateNode.context;
          break t;
        case 1:
          if (Le(e.type)) {
            e = e.stateNode.__reactInternalMemoizedMergedChildContext;
            break t;
          }
      }
      e = e.return;
    } while (e !== null);
    throw Error(ut(171));
  }
  if (t.tag === 1) {
    var n = t.type;
    if (Le(n)) return id(t, n, e);
  }
  return e;
}
function o0(t, e, n, a, p, g, _, w, x) {
  return t = yc(n, a, !0, t, p, g, _, w, x), t.context = r0(null), n = t.current, a = xe(), p = ri(n), g = Rn(a, p), g.callback = e ?? null, ni(n, g, p), t.current.lanes = p, so(t, p, a), je(t, a), t;
}
function Ua(t, e, n, a) {
  var p = e.current, g = xe(), _ = ri(p);
  return n = r0(n), e.context === null ? e.context = n : e.pendingContext = n, e = Rn(g, _), e.payload = { element: t }, a = a === void 0 ? null : a, a !== null && (e.callback = a), t = ni(p, e, _), t !== null && (pn(t, p, _, g), Vo(t, p, _)), _;
}
function Sa(t) {
  if (t = t.current, !t.child) return null;
  switch (t.child.tag) {
    case 5:
      return t.child.stateNode;
    default:
      return t.child.stateNode;
  }
}
function hh(t, e) {
  if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
    var n = t.retryLane;
    t.retryLane = n !== 0 && n < e ? n : e;
  }
}
function _c(t, e) {
  hh(t, e), (t = t.alternate) && hh(t, e);
}
function Am() {
  return null;
}
var a0 = typeof reportError == "function" ? reportError : function(t) {
  console.error(t);
};
function bc(t) {
  this._internalRoot = t;
}
za.prototype.render = bc.prototype.render = function(t) {
  var e = this._internalRoot;
  if (e === null) throw Error(ut(409));
  Ua(t, e, null, null);
};
za.prototype.unmount = bc.prototype.unmount = function() {
  var t = this._internalRoot;
  if (t !== null) {
    this._internalRoot = null;
    var e = t.containerInfo;
    ki(function() {
      Ua(null, t, null, null);
    }), e[Nn] = null;
  }
};
function za(t) {
  this._internalRoot = t;
}
za.prototype.unstable_scheduleHydration = function(t) {
  if (t) {
    var e = Ff();
    t = { blockedOn: null, target: t, priority: e };
    for (var n = 0; n < Vn.length && e !== 0 && e < Vn[n].priority; n++) ;
    Vn.splice(n, 0, t), n === 0 && Bf(t);
  }
};
function wc(t) {
  return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
}
function Wa(t) {
  return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11 && (t.nodeType !== 8 || t.nodeValue !== " react-mount-point-unstable "));
}
function fh() {
}
function Dm(t, e, n, a, p) {
  if (p) {
    if (typeof a == "function") {
      var g = a;
      a = function() {
        var T = Sa(_);
        g.call(T);
      };
    }
    var _ = o0(e, a, t, 0, null, !1, !1, "", fh);
    return t._reactRootContainer = _, t[Nn] = _.current, Qr(t.nodeType === 8 ? t.parentNode : t), ki(), _;
  }
  for (; p = t.lastChild; ) t.removeChild(p);
  if (typeof a == "function") {
    var w = a;
    a = function() {
      var T = Sa(x);
      w.call(T);
    };
  }
  var x = yc(t, 0, !1, null, null, !1, !1, "", fh);
  return t._reactRootContainer = x, t[Nn] = x.current, Qr(t.nodeType === 8 ? t.parentNode : t), ki(function() {
    Ua(e, x, n, a);
  }), x;
}
function Xa(t, e, n, a, p) {
  var g = n._reactRootContainer;
  if (g) {
    var _ = g;
    if (typeof p == "function") {
      var w = p;
      p = function() {
        var x = Sa(_);
        w.call(x);
      };
    }
    Ua(e, _, t, p);
  } else _ = Dm(n, e, t, p, a);
  return Sa(_);
}
jf = function(t) {
  switch (t.tag) {
    case 3:
      var e = t.stateNode;
      if (e.current.memoizedState.isDehydrated) {
        var n = Ar(e.pendingLanes);
        n !== 0 && (Ul(e, n | 1), je(e, ne()), !(Nt & 6) && (sr = ne() + 500, ui()));
      }
      break;
    case 13:
      ki(function() {
        var a = Un(t, 1);
        if (a !== null) {
          var p = xe();
          pn(a, t, 1, p);
        }
      }), _c(t, 1);
  }
};
zl = function(t) {
  if (t.tag === 13) {
    var e = Un(t, 134217728);
    if (e !== null) {
      var n = xe();
      pn(e, t, 134217728, n);
    }
    _c(t, 134217728);
  }
};
If = function(t) {
  if (t.tag === 13) {
    var e = ri(t), n = Un(t, e);
    if (n !== null) {
      var a = xe();
      pn(n, t, e, a);
    }
    _c(t, e);
  }
};
Ff = function() {
  return Wt;
};
Rf = function(t, e) {
  var n = Wt;
  try {
    return Wt = t, e();
  } finally {
    Wt = n;
  }
};
qs = function(t, e, n) {
  switch (e) {
    case "input":
      if (Ws(t, n), e = n.name, n.type === "radio" && e != null) {
        for (n = t; n.parentNode; ) n = n.parentNode;
        for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + e) + '][type="radio"]'), e = 0; e < n.length; e++) {
          var a = n[e];
          if (a !== t && a.form === t.form) {
            var p = La(a);
            if (!p) throw Error(ut(90));
            pf(a), Ws(a, p);
          }
        }
      }
      break;
    case "textarea":
      mf(t, n);
      break;
    case "select":
      e = n.value, e != null && qi(t, !!n.multiple, e, !1);
  }
};
xf = pc;
Sf = ki;
var Lm = { usingClientEntryPoint: !1, Events: [co, zi, La, wf, Cf, pc] }, Or = { findFiberByHostInstance: yi, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, jm = { bundleType: Or.bundleType, version: Or.version, rendererPackageName: Or.rendererPackageName, rendererConfig: Or.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: Wn.ReactCurrentDispatcher, findHostInstanceByFiber: function(t) {
  return t = kf(t), t === null ? null : t.stateNode;
}, findFiberByHostInstance: Or.findFiberByHostInstance || Am, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
  var Io = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!Io.isDisabled && Io.supportsFiber) try {
    Ma = Io.inject(jm), En = Io;
  } catch {
  }
}
We.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Lm;
We.createPortal = function(t, e) {
  var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
  if (!wc(e)) throw Error(ut(200));
  return Pm(t, e, null, n);
};
We.createRoot = function(t, e) {
  if (!wc(t)) throw Error(ut(299));
  var n = !1, a = "", p = a0;
  return e != null && (e.unstable_strictMode === !0 && (n = !0), e.identifierPrefix !== void 0 && (a = e.identifierPrefix), e.onRecoverableError !== void 0 && (p = e.onRecoverableError)), e = yc(t, 1, !1, null, null, n, !1, a, p), t[Nn] = e.current, Qr(t.nodeType === 8 ? t.parentNode : t), new bc(e);
};
We.findDOMNode = function(t) {
  if (t == null) return null;
  if (t.nodeType === 1) return t;
  var e = t._reactInternals;
  if (e === void 0)
    throw typeof t.render == "function" ? Error(ut(188)) : (t = Object.keys(t).join(","), Error(ut(268, t)));
  return t = kf(e), t = t === null ? null : t.stateNode, t;
};
We.flushSync = function(t) {
  return ki(t);
};
We.hydrate = function(t, e, n) {
  if (!Wa(e)) throw Error(ut(200));
  return Xa(null, t, e, !0, n);
};
We.hydrateRoot = function(t, e, n) {
  if (!wc(t)) throw Error(ut(405));
  var a = n != null && n.hydratedSources || null, p = !1, g = "", _ = a0;
  if (n != null && (n.unstable_strictMode === !0 && (p = !0), n.identifierPrefix !== void 0 && (g = n.identifierPrefix), n.onRecoverableError !== void 0 && (_ = n.onRecoverableError)), e = o0(e, null, t, 1, n ?? null, p, !1, g, _), t[Nn] = e.current, Qr(t), a) for (t = 0; t < a.length; t++) n = a[t], p = n._getVersion, p = p(n._source), e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [n, p] : e.mutableSourceEagerHydrationData.push(
    n,
    p
  );
  return new za(e);
};
We.render = function(t, e, n) {
  if (!Wa(e)) throw Error(ut(200));
  return Xa(null, t, e, !1, n);
};
We.unmountComponentAtNode = function(t) {
  if (!Wa(t)) throw Error(ut(40));
  return t._reactRootContainer ? (ki(function() {
    Xa(null, null, t, !1, function() {
      t._reactRootContainer = null, t[Nn] = null;
    });
  }), !0) : !1;
};
We.unstable_batchedUpdates = pc;
We.unstable_renderSubtreeIntoContainer = function(t, e, n, a) {
  if (!Wa(n)) throw Error(ut(200));
  if (t == null || t._reactInternals === void 0) throw Error(ut(38));
  return Xa(t, e, n, !1, a);
};
We.version = "18.3.1-next-f1338f8080-20240426";
function s0() {
  if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s0);
    } catch (t) {
      console.error(t);
    }
}
s0(), af.exports = We;
var Im = af.exports;
const Fm = /* @__PURE__ */ Vh(Im);
function Rm(t, e) {
  return e.forEach(function(n) {
    n && typeof n != "string" && !Array.isArray(n) && Object.keys(n).forEach(function(a) {
      if (a !== "default" && !(a in t)) {
        var p = Object.getOwnPropertyDescriptor(n, a);
        Object.defineProperty(t, a, p.get ? p : { enumerable: !0, get: function() {
          return n[a];
        } });
      }
    });
  }), Object.freeze(t);
}
var dh = typeof global < "u" ? global : typeof self < "u" ? self : typeof window < "u" ? window : {}, Cn = [], Ge = [], Bm = typeof Uint8Array < "u" ? Uint8Array : Array, Cc = !1;
function l0() {
  Cc = !0;
  for (var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", e = 0; e < 64; ++e) Cn[e] = t[e], Ge[t.charCodeAt(e)] = e;
  Ge[45] = 62, Ge[95] = 63;
}
function Nm(t, e, n) {
  for (var a, p, g = [], _ = e; _ < n; _ += 3) a = (t[_] << 16) + (t[_ + 1] << 8) + t[_ + 2], g.push(Cn[(p = a) >> 18 & 63] + Cn[p >> 12 & 63] + Cn[p >> 6 & 63] + Cn[63 & p]);
  return g.join("");
}
function ph(t) {
  var e;
  Cc || l0();
  for (var n = t.length, a = n % 3, p = "", g = [], _ = 16383, w = 0, x = n - a; w < x; w += _) g.push(Nm(t, w, w + _ > x ? x : w + _));
  return a === 1 ? (e = t[n - 1], p += Cn[e >> 2], p += Cn[e << 4 & 63], p += "==") : a === 2 && (e = (t[n - 2] << 8) + t[n - 1], p += Cn[e >> 10], p += Cn[e >> 4 & 63], p += Cn[e << 2 & 63], p += "="), g.push(p), g.join("");
}
function Fo(t, e, n, a, p) {
  var g, _, w = 8 * p - a - 1, x = (1 << w) - 1, T = x >> 1, L = -7, X = n ? p - 1 : 0, G = n ? -1 : 1, J = t[e + X];
  for (X += G, g = J & (1 << -L) - 1, J >>= -L, L += w; L > 0; g = 256 * g + t[e + X], X += G, L -= 8) ;
  for (_ = g & (1 << -L) - 1, g >>= -L, L += a; L > 0; _ = 256 * _ + t[e + X], X += G, L -= 8) ;
  if (g === 0) g = 1 - T;
  else {
    if (g === x) return _ ? NaN : 1 / 0 * (J ? -1 : 1);
    _ += Math.pow(2, a), g -= T;
  }
  return (J ? -1 : 1) * _ * Math.pow(2, g - a);
}
function c0(t, e, n, a, p, g) {
  var _, w, x, T = 8 * g - p - 1, L = (1 << T) - 1, X = L >> 1, G = p === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, J = a ? 0 : g - 1, et = a ? 1 : -1, rt = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
  for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (w = isNaN(e) ? 1 : 0, _ = L) : (_ = Math.floor(Math.log(e) / Math.LN2), e * (x = Math.pow(2, -_)) < 1 && (_--, x *= 2), (e += _ + X >= 1 ? G / x : G * Math.pow(2, 1 - X)) * x >= 2 && (_++, x /= 2), _ + X >= L ? (w = 0, _ = L) : _ + X >= 1 ? (w = (e * x - 1) * Math.pow(2, p), _ += X) : (w = e * Math.pow(2, X - 1) * Math.pow(2, p), _ = 0)); p >= 8; t[n + J] = 255 & w, J += et, w /= 256, p -= 8) ;
  for (_ = _ << p | w, T += p; T > 0; t[n + J] = 255 & _, J += et, _ /= 256, T -= 8) ;
  t[n + J - et] |= 128 * rt;
}
var Um = {}.toString, u0 = Array.isArray || function(t) {
  return Um.call(t) == "[object Array]";
};
function Ta() {
  return ot.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;
}
function Fn(t, e) {
  if (Ta() < e) throw new RangeError("Invalid typed array length");
  return ot.TYPED_ARRAY_SUPPORT ? (t = new Uint8Array(e)).__proto__ = ot.prototype : (t === null && (t = new ot(e)), t.length = e), t;
}
function ot(t, e, n) {
  if (!(ot.TYPED_ARRAY_SUPPORT || this instanceof ot)) return new ot(t, e, n);
  if (typeof t == "number") {
    if (typeof e == "string") throw new Error("If encoding is specified then the first argument must be a string");
    return kl(this, t);
  }
  return h0(this, t, e, n);
}
function h0(t, e, n, a) {
  if (typeof e == "number") throw new TypeError('"value" argument must not be a number');
  return typeof ArrayBuffer < "u" && e instanceof ArrayBuffer ? function(p, g, _, w) {
    if (g.byteLength, _ < 0 || g.byteLength < _) throw new RangeError("'offset' is out of bounds");
    if (g.byteLength < _ + (w || 0)) throw new RangeError("'length' is out of bounds");
    return g = _ === void 0 && w === void 0 ? new Uint8Array(g) : w === void 0 ? new Uint8Array(g, _) : new Uint8Array(g, _, w), ot.TYPED_ARRAY_SUPPORT ? (p = g).__proto__ = ot.prototype : p = Es(p, g), p;
  }(t, e, n, a) : typeof e == "string" ? function(p, g, _) {
    if (typeof _ == "string" && _ !== "" || (_ = "utf8"), !ot.isEncoding(_)) throw new TypeError('"encoding" must be a valid string encoding');
    var w = 0 | d0(g, _);
    p = Fn(p, w);
    var x = p.write(g, _);
    return x !== w && (p = p.slice(0, x)), p;
  }(t, e, n) : function(p, g) {
    if (xn(g)) {
      var _ = 0 | xc(g.length);
      return (p = Fn(p, _)).length === 0 || g.copy(p, 0, 0, _), p;
    }
    if (g) {
      if (typeof ArrayBuffer < "u" && g.buffer instanceof ArrayBuffer || "length" in g) return typeof g.length != "number" || (w = g.length) != w ? Fn(p, 0) : Es(p, g);
      if (g.type === "Buffer" && u0(g.data)) return Es(p, g.data);
    }
    var w;
    throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
  }(t, e);
}
function f0(t) {
  if (typeof t != "number") throw new TypeError('"size" argument must be a number');
  if (t < 0) throw new RangeError('"size" argument must not be negative');
}
function kl(t, e) {
  if (f0(e), t = Fn(t, e < 0 ? 0 : 0 | xc(e)), !ot.TYPED_ARRAY_SUPPORT) for (var n = 0; n < e; ++n) t[n] = 0;
  return t;
}
function Es(t, e) {
  var n = e.length < 0 ? 0 : 0 | xc(e.length);
  t = Fn(t, n);
  for (var a = 0; a < n; a += 1) t[a] = 255 & e[a];
  return t;
}
function xc(t) {
  if (t >= Ta()) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + Ta().toString(16) + " bytes");
  return 0 | t;
}
function xn(t) {
  return !(t == null || !t._isBuffer);
}
function d0(t, e) {
  if (xn(t)) return t.length;
  if (typeof ArrayBuffer < "u" && typeof ArrayBuffer.isView == "function" && (ArrayBuffer.isView(t) || t instanceof ArrayBuffer)) return t.byteLength;
  typeof t != "string" && (t = "" + t);
  var n = t.length;
  if (n === 0) return 0;
  for (var a = !1; ; ) switch (e) {
    case "ascii":
    case "latin1":
    case "binary":
      return n;
    case "utf8":
    case "utf-8":
    case void 0:
      return Ea(t).length;
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return 2 * n;
    case "hex":
      return n >>> 1;
    case "base64":
      return v0(t).length;
    default:
      if (a) return Ea(t).length;
      e = ("" + e).toLowerCase(), a = !0;
  }
}
function zm(t, e, n) {
  var a = !1;
  if ((e === void 0 || e < 0) && (e = 0), e > this.length || ((n === void 0 || n > this.length) && (n = this.length), n <= 0) || (n >>>= 0) <= (e >>>= 0)) return "";
  for (t || (t = "utf8"); ; ) switch (t) {
    case "hex":
      return Km(this, e, n);
    case "utf8":
    case "utf-8":
      return g0(this, e, n);
    case "ascii":
      return Zm(this, e, n);
    case "latin1":
    case "binary":
      return qm(this, e, n);
    case "base64":
      return Vm(this, e, n);
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return Qm(this, e, n);
    default:
      if (a) throw new TypeError("Unknown encoding: " + t);
      t = (t + "").toLowerCase(), a = !0;
  }
}
function di(t, e, n) {
  var a = t[e];
  t[e] = t[n], t[n] = a;
}
function gh(t, e, n, a, p) {
  if (t.length === 0) return -1;
  if (typeof n == "string" ? (a = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), n = +n, isNaN(n) && (n = p ? 0 : t.length - 1), n < 0 && (n = t.length + n), n >= t.length) {
    if (p) return -1;
    n = t.length - 1;
  } else if (n < 0) {
    if (!p) return -1;
    n = 0;
  }
  if (typeof e == "string" && (e = ot.from(e, a)), xn(e)) return e.length === 0 ? -1 : mh(t, e, n, a, p);
  if (typeof e == "number") return e &= 255, ot.TYPED_ARRAY_SUPPORT && typeof Uint8Array.prototype.indexOf == "function" ? p ? Uint8Array.prototype.indexOf.call(t, e, n) : Uint8Array.prototype.lastIndexOf.call(t, e, n) : mh(t, [e], n, a, p);
  throw new TypeError("val must be string, number or Buffer");
}
function mh(t, e, n, a, p) {
  var g, _ = 1, w = t.length, x = e.length;
  if (a !== void 0 && ((a = String(a).toLowerCase()) === "ucs2" || a === "ucs-2" || a === "utf16le" || a === "utf-16le")) {
    if (t.length < 2 || e.length < 2) return -1;
    _ = 2, w /= 2, x /= 2, n /= 2;
  }
  function T(J, et) {
    return _ === 1 ? J[et] : J.readUInt16BE(et * _);
  }
  if (p) {
    var L = -1;
    for (g = n; g < w; g++) if (T(t, g) === T(e, L === -1 ? 0 : g - L)) {
      if (L === -1 && (L = g), g - L + 1 === x) return L * _;
    } else L !== -1 && (g -= g - L), L = -1;
  } else for (n + x > w && (n = w - x), g = n; g >= 0; g--) {
    for (var X = !0, G = 0; G < x; G++) if (T(t, g + G) !== T(e, G)) {
      X = !1;
      break;
    }
    if (X) return g;
  }
  return -1;
}
function Wm(t, e, n, a) {
  n = Number(n) || 0;
  var p = t.length - n;
  a ? (a = Number(a)) > p && (a = p) : a = p;
  var g = e.length;
  if (g % 2 != 0) throw new TypeError("Invalid hex string");
  a > g / 2 && (a = g / 2);
  for (var _ = 0; _ < a; ++_) {
    var w = parseInt(e.substr(2 * _, 2), 16);
    if (isNaN(w)) return _;
    t[n + _] = w;
  }
  return _;
}
function Xm(t, e, n, a) {
  return Ya(Ea(e, t.length - n), t, n, a);
}
function p0(t, e, n, a) {
  return Ya(function(p) {
    for (var g = [], _ = 0; _ < p.length; ++_) g.push(255 & p.charCodeAt(_));
    return g;
  }(e), t, n, a);
}
function Ym(t, e, n, a) {
  return p0(t, e, n, a);
}
function Gm(t, e, n, a) {
  return Ya(v0(e), t, n, a);
}
function Hm(t, e, n, a) {
  return Ya(function(p, g) {
    for (var _, w, x, T = [], L = 0; L < p.length && !((g -= 2) < 0); ++L) w = (_ = p.charCodeAt(L)) >> 8, x = _ % 256, T.push(x), T.push(w);
    return T;
  }(e, t.length - n), t, n, a);
}
function Vm(t, e, n) {
  return e === 0 && n === t.length ? ph(t) : ph(t.slice(e, n));
}
function g0(t, e, n) {
  n = Math.min(t.length, n);
  for (var a = [], p = e; p < n; ) {
    var g, _, w, x, T = t[p], L = null, X = T > 239 ? 4 : T > 223 ? 3 : T > 191 ? 2 : 1;
    if (p + X <= n) switch (X) {
      case 1:
        T < 128 && (L = T);
        break;
      case 2:
        (192 & (g = t[p + 1])) == 128 && (x = (31 & T) << 6 | 63 & g) > 127 && (L = x);
        break;
      case 3:
        g = t[p + 1], _ = t[p + 2], (192 & g) == 128 && (192 & _) == 128 && (x = (15 & T) << 12 | (63 & g) << 6 | 63 & _) > 2047 && (x < 55296 || x > 57343) && (L = x);
        break;
      case 4:
        g = t[p + 1], _ = t[p + 2], w = t[p + 3], (192 & g) == 128 && (192 & _) == 128 && (192 & w) == 128 && (x = (15 & T) << 18 | (63 & g) << 12 | (63 & _) << 6 | 63 & w) > 65535 && x < 1114112 && (L = x);
    }
    L === null ? (L = 65533, X = 1) : L > 65535 && (L -= 65536, a.push(L >>> 10 & 1023 | 55296), L = 56320 | 1023 & L), a.push(L), p += X;
  }
  return function(G) {
    var J = G.length;
    if (J <= vh) return String.fromCharCode.apply(String, G);
    for (var et = "", rt = 0; rt < J; ) et += String.fromCharCode.apply(String, G.slice(rt, rt += vh));
    return et;
  }(a);
}
ot.TYPED_ARRAY_SUPPORT = dh.TYPED_ARRAY_SUPPORT === void 0 || dh.TYPED_ARRAY_SUPPORT, Ta(), ot.poolSize = 8192, ot._augment = function(t) {
  return t.__proto__ = ot.prototype, t;
}, ot.from = function(t, e, n) {
  return h0(null, t, e, n);
}, ot.TYPED_ARRAY_SUPPORT && (ot.prototype.__proto__ = Uint8Array.prototype, ot.__proto__ = Uint8Array, typeof Symbol < "u" && Symbol.species && ot[Symbol.species]), ot.alloc = function(t, e, n) {
  return function(a, p, g, _) {
    return f0(p), p <= 0 ? Fn(a, p) : g !== void 0 ? typeof _ == "string" ? Fn(a, p).fill(g, _) : Fn(a, p).fill(g) : Fn(a, p);
  }(null, t, e, n);
}, ot.allocUnsafe = function(t) {
  return kl(null, t);
}, ot.allocUnsafeSlow = function(t) {
  return kl(null, t);
}, ot.isBuffer = function(t) {
  return t != null && (!!t._isBuffer || bh(t) || function(e) {
    return typeof e.readFloatLE == "function" && typeof e.slice == "function" && bh(e.slice(0, 0));
  }(t));
}, ot.compare = function(t, e) {
  if (!xn(t) || !xn(e)) throw new TypeError("Arguments must be Buffers");
  if (t === e) return 0;
  for (var n = t.length, a = e.length, p = 0, g = Math.min(n, a); p < g; ++p) if (t[p] !== e[p]) {
    n = t[p], a = e[p];
    break;
  }
  return n < a ? -1 : a < n ? 1 : 0;
}, ot.isEncoding = function(t) {
  switch (String(t).toLowerCase()) {
    case "hex":
    case "utf8":
    case "utf-8":
    case "ascii":
    case "latin1":
    case "binary":
    case "base64":
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return !0;
    default:
      return !1;
  }
}, ot.concat = function(t, e) {
  if (!u0(t)) throw new TypeError('"list" argument must be an Array of Buffers');
  if (t.length === 0) return ot.alloc(0);
  var n;
  if (e === void 0) for (e = 0, n = 0; n < t.length; ++n) e += t[n].length;
  var a = ot.allocUnsafe(e), p = 0;
  for (n = 0; n < t.length; ++n) {
    var g = t[n];
    if (!xn(g)) throw new TypeError('"list" argument must be an Array of Buffers');
    g.copy(a, p), p += g.length;
  }
  return a;
}, ot.byteLength = d0, ot.prototype._isBuffer = !0, ot.prototype.swap16 = function() {
  var t = this.length;
  if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
  for (var e = 0; e < t; e += 2) di(this, e, e + 1);
  return this;
}, ot.prototype.swap32 = function() {
  var t = this.length;
  if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
  for (var e = 0; e < t; e += 4) di(this, e, e + 3), di(this, e + 1, e + 2);
  return this;
}, ot.prototype.swap64 = function() {
  var t = this.length;
  if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
  for (var e = 0; e < t; e += 8) di(this, e, e + 7), di(this, e + 1, e + 6), di(this, e + 2, e + 5), di(this, e + 3, e + 4);
  return this;
}, ot.prototype.toString = function() {
  var t = 0 | this.length;
  return t === 0 ? "" : arguments.length === 0 ? g0(this, 0, t) : zm.apply(this, arguments);
}, ot.prototype.equals = function(t) {
  if (!xn(t)) throw new TypeError("Argument must be a Buffer");
  return this === t || ot.compare(this, t) === 0;
}, ot.prototype.inspect = function() {
  var t = "";
  return this.length > 0 && (t = this.toString("hex", 0, 50).match(/.{2}/g).join(" "), this.length > 50 && (t += " ... ")), "<Buffer " + t + ">";
}, ot.prototype.compare = function(t, e, n, a, p) {
  if (!xn(t)) throw new TypeError("Argument must be a Buffer");
  if (e === void 0 && (e = 0), n === void 0 && (n = t ? t.length : 0), a === void 0 && (a = 0), p === void 0 && (p = this.length), e < 0 || n > t.length || a < 0 || p > this.length) throw new RangeError("out of range index");
  if (a >= p && e >= n) return 0;
  if (a >= p) return -1;
  if (e >= n) return 1;
  if (this === t) return 0;
  for (var g = (p >>>= 0) - (a >>>= 0), _ = (n >>>= 0) - (e >>>= 0), w = Math.min(g, _), x = this.slice(a, p), T = t.slice(e, n), L = 0; L < w; ++L) if (x[L] !== T[L]) {
    g = x[L], _ = T[L];
    break;
  }
  return g < _ ? -1 : _ < g ? 1 : 0;
}, ot.prototype.includes = function(t, e, n) {
  return this.indexOf(t, e, n) !== -1;
}, ot.prototype.indexOf = function(t, e, n) {
  return gh(this, t, e, n, !0);
}, ot.prototype.lastIndexOf = function(t, e, n) {
  return gh(this, t, e, n, !1);
}, ot.prototype.write = function(t, e, n, a) {
  if (e === void 0) a = "utf8", n = this.length, e = 0;
  else if (n === void 0 && typeof e == "string") a = e, n = this.length, e = 0;
  else {
    if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
    e |= 0, isFinite(n) ? (n |= 0, a === void 0 && (a = "utf8")) : (a = n, n = void 0);
  }
  var p = this.length - e;
  if ((n === void 0 || n > p) && (n = p), t.length > 0 && (n < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
  a || (a = "utf8");
  for (var g = !1; ; ) switch (a) {
    case "hex":
      return Wm(this, t, e, n);
    case "utf8":
    case "utf-8":
      return Xm(this, t, e, n);
    case "ascii":
      return p0(this, t, e, n);
    case "latin1":
    case "binary":
      return Ym(this, t, e, n);
    case "base64":
      return Gm(this, t, e, n);
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
      return Hm(this, t, e, n);
    default:
      if (g) throw new TypeError("Unknown encoding: " + a);
      a = ("" + a).toLowerCase(), g = !0;
  }
}, ot.prototype.toJSON = function() {
  return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
};
var vh = 4096;
function Zm(t, e, n) {
  var a = "";
  n = Math.min(t.length, n);
  for (var p = e; p < n; ++p) a += String.fromCharCode(127 & t[p]);
  return a;
}
function qm(t, e, n) {
  var a = "";
  n = Math.min(t.length, n);
  for (var p = e; p < n; ++p) a += String.fromCharCode(t[p]);
  return a;
}
function Km(t, e, n) {
  var a = t.length;
  (!e || e < 0) && (e = 0), (!n || n < 0 || n > a) && (n = a);
  for (var p = "", g = e; g < n; ++g) p += $m(t[g]);
  return p;
}
function Qm(t, e, n) {
  for (var a = t.slice(e, n), p = "", g = 0; g < a.length; g += 2) p += String.fromCharCode(a[g] + 256 * a[g + 1]);
  return p;
}
function le(t, e, n) {
  if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
  if (t + e > n) throw new RangeError("Trying to access beyond buffer length");
}
function Me(t, e, n, a, p, g) {
  if (!xn(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
  if (e > p || e < g) throw new RangeError('"value" argument is out of bounds');
  if (n + a > t.length) throw new RangeError("Index out of range");
}
function Ro(t, e, n, a) {
  e < 0 && (e = 65535 + e + 1);
  for (var p = 0, g = Math.min(t.length - n, 2); p < g; ++p) t[n + p] = (e & 255 << 8 * (a ? p : 1 - p)) >>> 8 * (a ? p : 1 - p);
}
function Bo(t, e, n, a) {
  e < 0 && (e = 4294967295 + e + 1);
  for (var p = 0, g = Math.min(t.length - n, 4); p < g; ++p) t[n + p] = e >>> 8 * (a ? p : 3 - p) & 255;
}
function m0(t, e, n, a, p, g) {
  if (n + a > t.length) throw new RangeError("Index out of range");
  if (n < 0) throw new RangeError("Index out of range");
}
function yh(t, e, n, a, p) {
  return p || m0(t, 0, n, 4), c0(t, e, n, a, 23, 4), n + 4;
}
function _h(t, e, n, a, p) {
  return p || m0(t, 0, n, 8), c0(t, e, n, a, 52, 8), n + 8;
}
ot.prototype.slice = function(t, e) {
  var n, a = this.length;
  if ((t = ~~t) < 0 ? (t += a) < 0 && (t = 0) : t > a && (t = a), (e = e === void 0 ? a : ~~e) < 0 ? (e += a) < 0 && (e = 0) : e > a && (e = a), e < t && (e = t), ot.TYPED_ARRAY_SUPPORT) (n = this.subarray(t, e)).__proto__ = ot.prototype;
  else {
    var p = e - t;
    n = new ot(p, void 0);
    for (var g = 0; g < p; ++g) n[g] = this[g + t];
  }
  return n;
}, ot.prototype.readUIntLE = function(t, e, n) {
  t |= 0, e |= 0, n || le(t, e, this.length);
  for (var a = this[t], p = 1, g = 0; ++g < e && (p *= 256); ) a += this[t + g] * p;
  return a;
}, ot.prototype.readUIntBE = function(t, e, n) {
  t |= 0, e |= 0, n || le(t, e, this.length);
  for (var a = this[t + --e], p = 1; e > 0 && (p *= 256); ) a += this[t + --e] * p;
  return a;
}, ot.prototype.readUInt8 = function(t, e) {
  return e || le(t, 1, this.length), this[t];
}, ot.prototype.readUInt16LE = function(t, e) {
  return e || le(t, 2, this.length), this[t] | this[t + 1] << 8;
}, ot.prototype.readUInt16BE = function(t, e) {
  return e || le(t, 2, this.length), this[t] << 8 | this[t + 1];
}, ot.prototype.readUInt32LE = function(t, e) {
  return e || le(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
}, ot.prototype.readUInt32BE = function(t, e) {
  return e || le(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
}, ot.prototype.readIntLE = function(t, e, n) {
  t |= 0, e |= 0, n || le(t, e, this.length);
  for (var a = this[t], p = 1, g = 0; ++g < e && (p *= 256); ) a += this[t + g] * p;
  return a >= (p *= 128) && (a -= Math.pow(2, 8 * e)), a;
}, ot.prototype.readIntBE = function(t, e, n) {
  t |= 0, e |= 0, n || le(t, e, this.length);
  for (var a = e, p = 1, g = this[t + --a]; a > 0 && (p *= 256); ) g += this[t + --a] * p;
  return g >= (p *= 128) && (g -= Math.pow(2, 8 * e)), g;
}, ot.prototype.readInt8 = function(t, e) {
  return e || le(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
}, ot.prototype.readInt16LE = function(t, e) {
  e || le(t, 2, this.length);
  var n = this[t] | this[t + 1] << 8;
  return 32768 & n ? 4294901760 | n : n;
}, ot.prototype.readInt16BE = function(t, e) {
  e || le(t, 2, this.length);
  var n = this[t + 1] | this[t] << 8;
  return 32768 & n ? 4294901760 | n : n;
}, ot.prototype.readInt32LE = function(t, e) {
  return e || le(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
}, ot.prototype.readInt32BE = function(t, e) {
  return e || le(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
}, ot.prototype.readFloatLE = function(t, e) {
  return e || le(t, 4, this.length), Fo(this, t, !0, 23, 4);
}, ot.prototype.readFloatBE = function(t, e) {
  return e || le(t, 4, this.length), Fo(this, t, !1, 23, 4);
}, ot.prototype.readDoubleLE = function(t, e) {
  return e || le(t, 8, this.length), Fo(this, t, !0, 52, 8);
}, ot.prototype.readDoubleBE = function(t, e) {
  return e || le(t, 8, this.length), Fo(this, t, !1, 52, 8);
}, ot.prototype.writeUIntLE = function(t, e, n, a) {
  t = +t, e |= 0, n |= 0, a || Me(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
  var p = 1, g = 0;
  for (this[e] = 255 & t; ++g < n && (p *= 256); ) this[e + g] = t / p & 255;
  return e + n;
}, ot.prototype.writeUIntBE = function(t, e, n, a) {
  t = +t, e |= 0, n |= 0, a || Me(this, t, e, n, Math.pow(2, 8 * n) - 1, 0);
  var p = n - 1, g = 1;
  for (this[e + p] = 255 & t; --p >= 0 && (g *= 256); ) this[e + p] = t / g & 255;
  return e + n;
}, ot.prototype.writeUInt8 = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 1, 255, 0), ot.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), this[e] = 255 & t, e + 1;
}, ot.prototype.writeUInt16LE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 2, 65535, 0), ot.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8) : Ro(this, t, e, !0), e + 2;
}, ot.prototype.writeUInt16BE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 2, 65535, 0), ot.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, this[e + 1] = 255 & t) : Ro(this, t, e, !1), e + 2;
}, ot.prototype.writeUInt32LE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 4, 4294967295, 0), ot.TYPED_ARRAY_SUPPORT ? (this[e + 3] = t >>> 24, this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t) : Bo(this, t, e, !0), e + 4;
}, ot.prototype.writeUInt32BE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 4, 4294967295, 0), ot.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t) : Bo(this, t, e, !1), e + 4;
}, ot.prototype.writeIntLE = function(t, e, n, a) {
  if (t = +t, e |= 0, !a) {
    var p = Math.pow(2, 8 * n - 1);
    Me(this, t, e, n, p - 1, -p);
  }
  var g = 0, _ = 1, w = 0;
  for (this[e] = 255 & t; ++g < n && (_ *= 256); ) t < 0 && w === 0 && this[e + g - 1] !== 0 && (w = 1), this[e + g] = (t / _ >> 0) - w & 255;
  return e + n;
}, ot.prototype.writeIntBE = function(t, e, n, a) {
  if (t = +t, e |= 0, !a) {
    var p = Math.pow(2, 8 * n - 1);
    Me(this, t, e, n, p - 1, -p);
  }
  var g = n - 1, _ = 1, w = 0;
  for (this[e + g] = 255 & t; --g >= 0 && (_ *= 256); ) t < 0 && w === 0 && this[e + g + 1] !== 0 && (w = 1), this[e + g] = (t / _ >> 0) - w & 255;
  return e + n;
}, ot.prototype.writeInt8 = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 1, 127, -128), ot.TYPED_ARRAY_SUPPORT || (t = Math.floor(t)), t < 0 && (t = 255 + t + 1), this[e] = 255 & t, e + 1;
}, ot.prototype.writeInt16LE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 2, 32767, -32768), ot.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8) : Ro(this, t, e, !0), e + 2;
}, ot.prototype.writeInt16BE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 2, 32767, -32768), ot.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 8, this[e + 1] = 255 & t) : Ro(this, t, e, !1), e + 2;
}, ot.prototype.writeInt32LE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 4, 2147483647, -2147483648), ot.TYPED_ARRAY_SUPPORT ? (this[e] = 255 & t, this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24) : Bo(this, t, e, !0), e + 4;
}, ot.prototype.writeInt32BE = function(t, e, n) {
  return t = +t, e |= 0, n || Me(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), ot.TYPED_ARRAY_SUPPORT ? (this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t) : Bo(this, t, e, !1), e + 4;
}, ot.prototype.writeFloatLE = function(t, e, n) {
  return yh(this, t, e, !0, n);
}, ot.prototype.writeFloatBE = function(t, e, n) {
  return yh(this, t, e, !1, n);
}, ot.prototype.writeDoubleLE = function(t, e, n) {
  return _h(this, t, e, !0, n);
}, ot.prototype.writeDoubleBE = function(t, e, n) {
  return _h(this, t, e, !1, n);
}, ot.prototype.copy = function(t, e, n, a) {
  if (n || (n = 0), a || a === 0 || (a = this.length), e >= t.length && (e = t.length), e || (e = 0), a > 0 && a < n && (a = n), a === n || t.length === 0 || this.length === 0) return 0;
  if (e < 0) throw new RangeError("targetStart out of bounds");
  if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
  if (a < 0) throw new RangeError("sourceEnd out of bounds");
  a > this.length && (a = this.length), t.length - e < a - n && (a = t.length - e + n);
  var p, g = a - n;
  if (this === t && n < e && e < a) for (p = g - 1; p >= 0; --p) t[p + e] = this[p + n];
  else if (g < 1e3 || !ot.TYPED_ARRAY_SUPPORT) for (p = 0; p < g; ++p) t[p + e] = this[p + n];
  else Uint8Array.prototype.set.call(t, this.subarray(n, n + g), e);
  return g;
}, ot.prototype.fill = function(t, e, n, a) {
  if (typeof t == "string") {
    if (typeof e == "string" ? (a = e, e = 0, n = this.length) : typeof n == "string" && (a = n, n = this.length), t.length === 1) {
      var p = t.charCodeAt(0);
      p < 256 && (t = p);
    }
    if (a !== void 0 && typeof a != "string") throw new TypeError("encoding must be a string");
    if (typeof a == "string" && !ot.isEncoding(a)) throw new TypeError("Unknown encoding: " + a);
  } else typeof t == "number" && (t &= 255);
  if (e < 0 || this.length < e || this.length < n) throw new RangeError("Out of range index");
  if (n <= e) return this;
  var g;
  if (e >>>= 0, n = n === void 0 ? this.length : n >>> 0, t || (t = 0), typeof t == "number") for (g = e; g < n; ++g) this[g] = t;
  else {
    var _ = xn(t) ? t : Ea(new ot(t, a).toString()), w = _.length;
    for (g = 0; g < n - e; ++g) this[g + e] = _[g % w];
  }
  return this;
};
var Jm = /[^+\/0-9A-Za-z-_]/g;
function $m(t) {
  return t < 16 ? "0" + t.toString(16) : t.toString(16);
}
function Ea(t, e) {
  var n;
  e = e || 1 / 0;
  for (var a = t.length, p = null, g = [], _ = 0; _ < a; ++_) {
    if ((n = t.charCodeAt(_)) > 55295 && n < 57344) {
      if (!p) {
        if (n > 56319) {
          (e -= 3) > -1 && g.push(239, 191, 189);
          continue;
        }
        if (_ + 1 === a) {
          (e -= 3) > -1 && g.push(239, 191, 189);
          continue;
        }
        p = n;
        continue;
      }
      if (n < 56320) {
        (e -= 3) > -1 && g.push(239, 191, 189), p = n;
        continue;
      }
      n = 65536 + (p - 55296 << 10 | n - 56320);
    } else p && (e -= 3) > -1 && g.push(239, 191, 189);
    if (p = null, n < 128) {
      if ((e -= 1) < 0) break;
      g.push(n);
    } else if (n < 2048) {
      if ((e -= 2) < 0) break;
      g.push(n >> 6 | 192, 63 & n | 128);
    } else if (n < 65536) {
      if ((e -= 3) < 0) break;
      g.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128);
    } else {
      if (!(n < 1114112)) throw new Error("Invalid code point");
      if ((e -= 4) < 0) break;
      g.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128);
    }
  }
  return g;
}
function v0(t) {
  return function(e) {
    var n, a, p, g, _, w;
    Cc || l0();
    var x = e.length;
    if (x % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    _ = e[x - 2] === "=" ? 2 : e[x - 1] === "=" ? 1 : 0, w = new Bm(3 * x / 4 - _), p = _ > 0 ? x - 4 : x;
    var T = 0;
    for (n = 0, a = 0; n < p; n += 4, a += 3) g = Ge[e.charCodeAt(n)] << 18 | Ge[e.charCodeAt(n + 1)] << 12 | Ge[e.charCodeAt(n + 2)] << 6 | Ge[e.charCodeAt(n + 3)], w[T++] = g >> 16 & 255, w[T++] = g >> 8 & 255, w[T++] = 255 & g;
    return _ === 2 ? (g = Ge[e.charCodeAt(n)] << 2 | Ge[e.charCodeAt(n + 1)] >> 4, w[T++] = 255 & g) : _ === 1 && (g = Ge[e.charCodeAt(n)] << 10 | Ge[e.charCodeAt(n + 1)] << 4 | Ge[e.charCodeAt(n + 2)] >> 2, w[T++] = g >> 8 & 255, w[T++] = 255 & g), w;
  }(function(e) {
    if ((e = function(n) {
      return n.trim ? n.trim() : n.replace(/^\s+|\s+$/g, "");
    }(e).replace(Jm, "")).length < 2) return "";
    for (; e.length % 4 != 0; ) e += "=";
    return e;
  }(t));
}
function Ya(t, e, n, a) {
  for (var p = 0; p < a && !(p + n >= e.length || p >= t.length); ++p) e[p + n] = t[p];
  return p;
}
function bh(t) {
  return !!t.constructor && typeof t.constructor.isBuffer == "function" && t.constructor.isBuffer(t);
}
function tv(t) {
  if (t.__esModule) return t;
  var e = Object.defineProperty({}, "__esModule", { value: !0 });
  return Object.keys(t).forEach(function(n) {
    var a = Object.getOwnPropertyDescriptor(t, n);
    Object.defineProperty(e, n, a.get ? a : { enumerable: !0, get: function() {
      return t[n];
    } });
  }), e;
}
var y0 = {}, wh = {}, ks = tv(Rm({ __proto__: null, default: wh }, [wh]));
(function(t) {
  /*! Fabric.js Copyright 2008-2015, Printio (Juriy Zaytsev, Maxim Chernyak) */
  var e, n, a, p, g, _, w, x, T, L, X, G, J, et, rt, vt, Y, j, P, $, ht, it, dt, v = v || { version: "4.6.0" };
  if (t.fabric = v, typeof document < "u" && typeof window < "u") document instanceof (typeof HTMLDocument < "u" ? HTMLDocument : Document) ? v.document = document : v.document = document.implementation.createHTMLDocument(""), v.window = window;
  else {
    var Tt = new ks.JSDOM(decodeURIComponent("%3C!DOCTYPE%20html%3E%3Chtml%3E%3Chead%3E%3C%2Fhead%3E%3Cbody%3E%3C%2Fbody%3E%3C%2Fhtml%3E"), { features: { FetchExternalResources: ["img"] }, resources: "usable" }).window;
    v.document = Tt.document, v.jsdomImplForWrapper = ks.implForWrapper, v.nodeCanvas = ks.Canvas, v.window = Tt, DOMParser = v.window.DOMParser;
  }
  if (v.isTouchSupported = "ontouchstart" in v.window || "ontouchstart" in v.document || v.window && v.window.navigator && v.window.navigator.maxTouchPoints > 0, v.isLikelyNode = ot !== void 0 && typeof window > "u", v.SHARED_ATTRIBUTES = ["display", "transform", "fill", "fill-opacity", "fill-rule", "opacity", "stroke", "stroke-dasharray", "stroke-linecap", "stroke-dashoffset", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke-width", "id", "paint-order", "vector-effect", "instantiated_by_use", "clip-path"], v.DPI = 96, v.reNum = "(?:[-+]?(?:\\d+|\\d*\\.\\d+)(?:[eE][-+]?\\d+)?)", v.commaWsp = "(?:\\s+,?\\s*|,\\s*)", v.rePathCommand = /([-+]?((\d+\.\d+)|((\d+)|(\.\d+)))(?:[eE][-+]?\d+)?)/gi, v.reNonWord = /[ \n\.,;!\?\-]/, v.fontPaths = {}, v.iMatrix = [1, 0, 0, 1, 0, 0], v.svgNS = "http://www.w3.org/2000/svg", v.perfLimitSizeTotal = 2097152, v.maxCacheSideLimit = 4096, v.minCacheSideLimit = 256, v.charWidthsCache = {}, v.textureSize = 2048, v.disableStyleCopyPaste = !1, v.enableGLFiltering = !0, v.devicePixelRatio = v.window.devicePixelRatio || v.window.webkitDevicePixelRatio || v.window.mozDevicePixelRatio || 1, v.browserShadowBlurConstant = 1, v.arcToSegmentsCache = {}, v.boundsOfCurveCache = {}, v.cachesBoundsOfCurve = !0, v.forceGLPutImageData = !1, v.initFilterBackend = function() {
    return v.enableGLFiltering && v.isWebglSupported && v.isWebglSupported(v.textureSize) ? (console.log("max texture size: " + v.maxTextureSize), new v.WebglFilterBackend({ tileSize: v.textureSize })) : v.Canvas2dFilterBackend ? new v.Canvas2dFilterBackend() : void 0;
  }, typeof document < "u" && typeof window < "u" && (window.fabric = v), I === void 0) var I = {};
  if (function(c) {
    c.modifyEventListener = !1, c.modifySelectors = !1, c.configure = function(C) {
      isFinite(C.modifyEventListener) && (c.modifyEventListener = C.modifyEventListener), isFinite(C.modifySelectors) && (c.modifySelectors = C.modifySelectors), S === !1 && c.modifyEventListener && E(), A === !1 && c.modifySelectors && M();
    }, c.add = function(C, O, N, z) {
      return l(C, O, N, z, "add");
    }, c.remove = function(C, O, N, z) {
      return l(C, O, N, z, "remove");
    }, c.returnFalse = function(C) {
      return !1;
    }, c.stop = function(C) {
      C && (C.stopPropagation && C.stopPropagation(), C.cancelBubble = !0, C.cancelBubbleCount = 0);
    }, c.prevent = function(C) {
      C && (C.preventDefault ? C.preventDefault() : C.preventManipulation ? C.preventManipulation() : C.returnValue = !1);
    }, c.cancel = function(C) {
      c.stop(C), c.prevent(C);
    }, c.blur = function() {
      var C = document.activeElement;
      if (C) {
        var O = document.activeElement.nodeName;
        O !== "INPUT" && O !== "TEXTAREA" && C.contentEditable !== "true" || C.blur && C.blur();
      }
    }, c.getEventSupport = function(C, O) {
      if (typeof C == "string" && (O = C, C = window), (O = "on" + O) in C) return !0;
      if (C.setAttribute || (C = document.createElement("div")), C.setAttribute && C.removeAttribute) {
        C.setAttribute(O, "");
        var N = typeof C[O] == "function";
        return C[O] !== void 0 && (C[O] = null), C.removeAttribute(O), N;
      }
    };
    var o = function(C) {
      if (!C || typeof C != "object") return C;
      var O = new C.constructor();
      for (var N in C) C[N] && typeof C[N] == "object" ? O[N] = o(C[N]) : O[N] = C[N];
      return O;
    }, l = function(C, O, N, z, W, F) {
      if (z = z || {}, String(C) === "[object Object]") {
        var k = C;
        if (C = k.target, delete k.target, !k.type || !k.listener) {
          for (var B in k) {
            var Z = k[B];
            typeof Z != "function" && (z[B] = Z);
          }
          var K = {};
          for (var U in k) {
            B = U.split(",");
            var R = k[U], H = {};
            for (var q in z) H[q] = z[q];
            if (typeof R == "function") N = R;
            else {
              if (typeof R.listener != "function") continue;
              N = R.listener;
              for (var q in R) typeof R[q] != "function" && (H[q] = R[q]);
            }
            for (var Q = 0; Q < B.length; Q++) K[U] = I.add(C, B[Q], N, H, W);
          }
          return K;
        }
        for (var U in O = k.type, delete k.type, N = k.listener, delete k.listener, k) z[U] = k[U];
      }
      if (C && O && N) {
        if (typeof C == "string" && O === "ready") {
          if (!window.eventjs_stallOnReady) {
            var nt = (/* @__PURE__ */ new Date()).getTime(), gt = z.timeout, ct = z.interval || 1e3 / 60, ft = window.setInterval(function() {
              (/* @__PURE__ */ new Date()).getTime() - nt > gt && window.clearInterval(ft), document.querySelector(C) && (window.clearInterval(ft), setTimeout(N, 1));
            }, ct);
            return;
          }
          O = "load", C = window;
        }
        if (typeof C == "string") {
          if ((C = document.querySelectorAll(C)).length === 0) return i("Missing target on listener!", arguments);
          C.length === 1 && (C = C[0]);
        }
        var st, lt = {};
        if (C.length > 0 && C !== window) {
          for (var at = 0, yt = C.length; at < yt; at++) (st = l(C[at], O, N, o(z), W)) && (lt[at] = st);
          return f(lt);
        }
        if (typeof O == "string" && ((O = O.toLowerCase()).indexOf(" ") !== -1 ? O = O.split(" ") : O.indexOf(",") !== -1 && (O = O.split(","))), typeof O != "string") {
          if (typeof O.length == "number") for (var mt = 0, Mt = O.length; mt < Mt; mt++) (st = l(C, O[mt], N, o(z), W)) && (lt[O[mt]] = st);
          else for (var U in O) (st = typeof O[U] == "function" ? l(C, U, O[U], o(z), W) : l(C, U, O[U].listener, o(O[U]), W)) && (lt[U] = st);
          return f(lt);
        }
        if (O.indexOf("on") === 0 && (O = O.substr(2)), typeof C != "object") return i("Target is not defined!", arguments);
        if (typeof N != "function") return i("Listener is not a function!", arguments);
        var Ot = z.useCapture || !1, Lt = m(C) + "." + m(N) + "." + (Ot ? 1 : 0);
        if (c.Gesture && c.Gesture._gestureHandlers[O]) {
          if (Lt = O + Lt, W === "remove") {
            if (!h[Lt]) return;
            h[Lt].remove(), delete h[Lt];
          } else if (W === "add") {
            if (h[Lt]) return h[Lt].add(), h[Lt];
            if (z.useCall && !c.modifyEventListener) {
              var re = N;
              N = function(oe, Rt) {
                for (var te in Rt) oe[te] = Rt[te];
                return re.call(C, oe);
              };
            }
            z.gesture = O, z.target = C, z.listener = N, z.fromOverwrite = F, h[Lt] = c.proxy[O](z);
          }
          return h[Lt];
        }
        var Ut, Ft = u(O);
        for (Q = 0; Q < Ft.length; Q++) if (Ut = (O = Ft[Q]) + "." + Lt, W === "remove") {
          if (!h[Ut]) continue;
          C[b](O, N, Ot), delete h[Ut];
        } else if (W === "add") {
          if (h[Ut]) return h[Ut];
          C[y](O, N, Ot), h[Ut] = { id: Ut, type: O, target: C, listener: N, remove: function() {
            for (var oe = 0; oe < Ft.length; oe++) c.remove(C, Ft[oe], N, z);
          } };
        }
        return h[Ut];
      }
    }, f = function(C) {
      return { remove: function() {
        for (var O in C) C[O].remove();
      }, add: function() {
        for (var O in C) C[O].add();
      } };
    }, i = function(C, O) {
      typeof console < "u" && console.error !== void 0 && console.error(C, O);
    }, r = { msPointer: ["MSPointerDown", "MSPointerMove", "MSPointerUp"], touch: ["touchstart", "touchmove", "touchend"], mouse: ["mousedown", "mousemove", "mouseup"] }, s = { MSPointerDown: 0, MSPointerMove: 1, MSPointerUp: 2, touchstart: 0, touchmove: 1, touchend: 2, mousedown: 0, mousemove: 1, mouseup: 2 };
    c.supports = {}, window.navigator.msPointerEnabled && (c.supports.msPointer = !0), c.getEventSupport("touchstart") && (c.supports.touch = !0), c.getEventSupport("mousedown") && (c.supports.mouse = !0);
    var u = function(C) {
      var O = document.addEventListener ? "" : "on", N = s[C];
      if (isFinite(N)) {
        var z = [];
        for (var W in c.supports) z.push(O + r[W][N]);
        return z;
      }
      return [O + C];
    }, h = {}, d = 0, m = function(C) {
      return C === window ? "#window" : C === document ? "#document" : (C.uniqueID || (C.uniqueID = "e" + d++), C.uniqueID);
    }, y = document.addEventListener ? "addEventListener" : "attachEvent", b = document.removeEventListener ? "removeEventListener" : "detachEvent";
    c.createPointerEvent = function(C, O, N) {
      var z = O.gesture, W = O.target, F = C.changedTouches || c.proxy.getCoords(C);
      if (F.length) {
        var k = F[0];
        O.pointers = N ? [] : F, O.pageX = k.pageX, O.pageY = k.pageY, O.x = O.pageX, O.y = O.pageY;
      }
      var B = document.createEvent("Event");
      for (var Z in B.initEvent(z, !0, !0), B.originalEvent = C, O) Z !== "target" && (B[Z] = O[Z]);
      var K = B.type;
      c.Gesture && c.Gesture._gestureHandlers[K] && O.oldListener.call(W, B, O, !1);
    };
    var S = !1, E = function() {
      if (window.HTMLElement) {
        var C = function(O) {
          var N = function(z) {
            var W = z + "EventListener", F = O[W];
            O[W] = function(k, B, Z) {
              if (c.Gesture && c.Gesture._gestureHandlers[k]) {
                var K = Z;
                typeof Z == "object" ? K.useCall = !0 : K = { useCall: !0, useCapture: Z }, l(this, k, B, K, z, !0);
              } else for (var U = u(k), R = 0; R < U.length; R++) F.call(this, U[R], B, Z);
            };
          };
          N("add"), N("remove");
        };
        navigator.userAgent.match(/Firefox/) ? (C(HTMLDivElement.prototype), C(HTMLCanvasElement.prototype)) : C(HTMLElement.prototype), C(document), C(window);
      }
    }, A = !1, M = function() {
      var C = NodeList.prototype;
      C.removeEventListener = function(O, N, z) {
        for (var W = 0, F = this.length; W < F; W++) this[W].removeEventListener(O, N, z);
      }, C.addEventListener = function(O, N, z) {
        for (var W = 0, F = this.length; W < F; W++) this[W].addEventListener(O, N, z);
      };
    };
  }(I), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    c.pointerSetup = function(s, u) {
      s.target = s.target || window, s.doc = s.target.ownerDocument || s.target, s.minFingers = s.minFingers || s.fingers || 1, s.maxFingers = s.maxFingers || s.fingers || 1 / 0, s.position = s.position || "relative", delete s.fingers, (u = u || {}).enabled = !0, u.gesture = s.gesture, u.target = s.target, u.env = s.env, I.modifyEventListener && s.fromOverwrite && (s.oldListener = s.listener, s.listener = I.createPointerEvent);
      var h = 0, d = u.gesture.indexOf("pointer") === 0 && I.modifyEventListener ? "pointer" : "mouse";
      return s.oldListener && (u.oldListener = s.oldListener), u.listener = s.listener, u.proxy = function(m) {
        u.defaultListener = s.listener, s.listener = m, m(s.event, u);
      }, u.add = function() {
        u.enabled !== !0 && (s.onPointerDown && I.add(s.target, d + "down", s.onPointerDown), s.onPointerMove && I.add(s.doc, d + "move", s.onPointerMove), s.onPointerUp && I.add(s.doc, d + "up", s.onPointerUp), u.enabled = !0);
      }, u.remove = function() {
        u.enabled !== !1 && (s.onPointerDown && I.remove(s.target, d + "down", s.onPointerDown), s.onPointerMove && I.remove(s.doc, d + "move", s.onPointerMove), s.onPointerUp && I.remove(s.doc, d + "up", s.onPointerUp), u.reset(), u.enabled = !1);
      }, u.pause = function(m) {
        !s.onPointerMove || m && !m.move || I.remove(s.doc, d + "move", s.onPointerMove), !s.onPointerUp || m && !m.up || I.remove(s.doc, d + "up", s.onPointerUp), h = s.fingers, s.fingers = 0;
      }, u.resume = function(m) {
        !s.onPointerMove || m && !m.move || I.add(s.doc, d + "move", s.onPointerMove), !s.onPointerUp || m && !m.up || I.add(s.doc, d + "up", s.onPointerUp), s.fingers = h;
      }, u.reset = function() {
        s.tracker = {}, s.fingers = 0;
      }, u;
    };
    var o = I.supports;
    I.isMouse = !!o.mouse, I.isMSPointer = !!o.touch, I.isTouch = !!o.msPointer, c.pointerStart = function(s, u, h) {
      var d = (s.type || "mousedown").toUpperCase();
      d.indexOf("MOUSE") === 0 ? (I.isMouse = !0, I.isTouch = !1, I.isMSPointer = !1) : d.indexOf("TOUCH") === 0 ? (I.isMouse = !1, I.isTouch = !0, I.isMSPointer = !1) : d.indexOf("MSPOINTER") === 0 && (I.isMouse = !1, I.isTouch = !1, I.isMSPointer = !0);
      var m = function(z, W) {
        var F = h.bbox, k = b[W] = {};
        switch (h.position) {
          case "absolute":
            k.offsetX = 0, k.offsetY = 0;
            break;
          case "differenceFromLast":
          case "difference":
            k.offsetX = z.pageX, k.offsetY = z.pageY;
            break;
          case "move":
            k.offsetX = z.pageX - F.x1, k.offsetY = z.pageY - F.y1;
            break;
          default:
            k.offsetX = F.x1 - F.scrollLeft, k.offsetY = F.y1 - F.scrollTop;
        }
        var B = z.pageX - k.offsetX, Z = z.pageY - k.offsetY;
        k.rotation = 0, k.scale = 1, k.startTime = k.moveTime = (/* @__PURE__ */ new Date()).getTime(), k.move = { x: B, y: Z }, k.start = { x: B, y: Z }, h.fingers++;
      };
      h.event = s, u.defaultListener && (h.listener = u.defaultListener, delete u.defaultListener);
      for (var y = !h.fingers, b = h.tracker, S = s.changedTouches || c.getCoords(s), E = S.length, A = 0; A < E; A++) {
        var M = S[A], C = M.identifier || 1 / 0;
        if (h.fingers) {
          if (h.fingers >= h.maxFingers) {
            var O = [];
            for (var C in h.tracker) O.push(C);
            return u.identifier = O.join(","), y;
          }
          for (var N in b) if (b[N].up) {
            delete b[N], m(M, C), h.cancel = !0;
            break;
          }
          if (b[C]) continue;
          m(M, C);
        } else b = h.tracker = {}, u.bbox = h.bbox = c.getBoundingBox(h.target), h.fingers = 0, h.cancel = !1, m(M, C);
      }
      O = [];
      for (var C in h.tracker) O.push(C);
      return u.identifier = O.join(","), y;
    }, c.pointerEnd = function(s, u, h, d) {
      for (var m = s.touches || [], y = m.length, b = {}, S = 0; S < y; S++)
        b[(E = m[S].identifier) || 1 / 0] = !0;
      for (var E in h.tracker) {
        var A = h.tracker[E];
        b[E] || A.up || (d && d({ pageX: A.pageX, pageY: A.pageY, changedTouches: [{ pageX: A.pageX, pageY: A.pageY, identifier: E === "Infinity" ? 1 / 0 : E }] }, "up"), A.up = !0, h.fingers--);
      }
      if (h.fingers !== 0) return !1;
      var M = [];
      for (var E in h.gestureFingers = 0, h.tracker) h.gestureFingers++, M.push(E);
      return u.identifier = M.join(","), !0;
    }, c.getCoords = function(s) {
      return s.pageX !== void 0 ? c.getCoords = function(u) {
        return Array({ type: "mouse", x: u.pageX, y: u.pageY, pageX: u.pageX, pageY: u.pageY, identifier: u.pointerId || 1 / 0 });
      } : c.getCoords = function(u) {
        var h = document.documentElement;
        return u = u || window.event, Array({ type: "mouse", x: u.clientX + h.scrollLeft, y: u.clientY + h.scrollTop, pageX: u.clientX + h.scrollLeft, pageY: u.clientY + h.scrollTop, identifier: 1 / 0 });
      }, c.getCoords(s);
    }, c.getCoord = function(s) {
      if ("ontouchstart" in window) {
        var u = 0, h = 0;
        c.getCoord = function(d) {
          var m = d.changedTouches;
          return m && m.length ? { x: u = m[0].pageX, y: h = m[0].pageY } : { x: u, y: h };
        };
      } else s.pageX !== void 0 && s.pageY !== void 0 ? c.getCoord = function(d) {
        return { x: d.pageX, y: d.pageY };
      } : c.getCoord = function(d) {
        var m = document.documentElement;
        return { x: (d = d || window.event).clientX + m.scrollLeft, y: d.clientY + m.scrollTop };
      };
      return c.getCoord(s);
    };
    var l, f, i, r = function(s, u) {
      var h = parseFloat(s.getPropertyValue(u), 10);
      return isFinite(h) ? h : 0;
    };
    return c.getBoundingBox = function(s) {
      s !== window && s !== document || (s = document.body);
      var u = {}, h = s.getBoundingClientRect();
      if (u.width = h.width, u.height = h.height, u.x1 = h.left, u.y1 = h.top, u.scaleX = h.width / s.offsetWidth || 1, u.scaleY = h.height / s.offsetHeight || 1, u.scrollLeft = 0, u.scrollTop = 0, (E = window.getComputedStyle(s)).getPropertyValue("box-sizing") !== "border-box") {
        var d = r(E, "border-left-width"), m = r(E, "border-right-width"), y = r(E, "border-bottom-width"), b = r(E, "border-top-width");
        u.border = [d, m, b, y], u.x1 += d, u.y1 += b, u.width -= m + d, u.height -= y + b;
      }
      u.x2 = u.x1 + u.width, u.y2 = u.y1 + u.height;
      for (var S = (A = E.getPropertyValue("position")) === "fixed" ? s : s.parentNode; S !== null && S !== document.body && S.scrollTop !== void 0; ) {
        var E, A;
        if ((A = (E = window.getComputedStyle(S)).getPropertyValue("position")) !== "absolute") {
          if (A === "fixed") {
            u.scrollTop -= S.parentNode.scrollTop, u.scrollLeft -= S.parentNode.scrollLeft;
            break;
          }
          u.scrollLeft += S.scrollLeft, u.scrollTop += S.scrollTop;
        }
        S = S.parentNode;
      }
      return u.scrollBodyLeft = window.pageXOffset !== void 0 ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft, u.scrollBodyTop = window.pageYOffset !== void 0 ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop, u.scrollLeft -= u.scrollBodyLeft, u.scrollTop -= u.scrollBodyTop, u;
    }, f = navigator.userAgent.toLowerCase(), i = f.indexOf("macintosh") !== -1, l = i && f.indexOf("khtml") !== -1 ? { 91: !0, 93: !0 } : i && f.indexOf("firefox") !== -1 ? { 224: !0 } : { 17: !0 }, (c.metaTrackerReset = function() {
      I.fnKey = c.fnKey = !1, I.metaKey = c.metaKey = !1, I.escKey = c.escKey = !1, I.ctrlKey = c.ctrlKey = !1, I.shiftKey = c.shiftKey = !1, I.altKey = c.altKey = !1;
    })(), c.metaTracker = function(s) {
      var u = s.type === "keydown";
      s.keyCode === 27 && (I.escKey = c.escKey = u), l[s.keyCode] && (I.metaKey = c.metaKey = u), I.ctrlKey = c.ctrlKey = s.ctrlKey, I.shiftKey = c.shiftKey = s.shiftKey, I.altKey = c.altKey = s.altKey;
    }, c;
  }(I.proxy), I === void 0 && (I = {}), I.MutationObserver = (e = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver, n = !e && function() {
    var c = document.createElement("p"), o = !1, l = function() {
      o = !0;
    };
    if (c.addEventListener) c.addEventListener("DOMAttrModified", l, !1);
    else {
      if (!c.attachEvent) return !1;
      c.attachEvent("onDOMAttrModified", l);
    }
    return c.setAttribute("id", "target"), o;
  }(), function(c, o) {
    e ? new e(function(l) {
      l.forEach(function(f) {
        o.call(f.target, f.attributeName);
      });
    }).observe(c, { subtree: !1, attributes: !0 }) : n ? I.add(c, "DOMAttrModified", function(l) {
      o.call(c, l.attrName);
    }) : "onpropertychange" in document.body && I.add(c, "propertychange", function(l) {
      o.call(c, window.event.propertyName);
    });
  }), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = ((a = I.proxy).click = function(c) {
    c.gesture = c.gesture || "click", c.maxFingers = c.maxFingers || c.fingers || 1, c.onPointerDown = function(l) {
      a.pointerStart(l, o, c) && I.add(c.target, "mouseup", c.onPointerUp);
    }, c.onPointerUp = function(l) {
      if (a.pointerEnd(l, o, c)) {
        I.remove(c.target, "mouseup", c.onPointerUp);
        var f = (l.changedTouches || a.getCoords(l))[0], i = c.bbox, r = a.getBoundingBox(c.target), s = f.pageY - r.scrollBodyTop, u = f.pageX - r.scrollBodyLeft;
        if (u > i.x1 && s > i.y1 && u < i.x2 && s < i.y2 && i.scrollTop === r.scrollTop) {
          for (var h in c.tracker) break;
          var d = c.tracker[h];
          o.x = d.start.x, o.y = d.start.y, c.listener(l, o);
        }
      }
    };
    var o = a.pointerSetup(c);
    return o.state = "click", I.add(c.target, "mousedown", c.onPointerDown), o;
  }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.click = a.click, a), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.dbltap = c.dblclick = function(o) {
      o.gesture = o.gesture || "dbltap", o.maxFingers = o.maxFingers || o.fingers || 1;
      var l, f, i, r, s;
      o.onPointerDown = function(h) {
        var d = h.changedTouches || c.getCoords(h);
        l && !f ? (s = d[0], f = (/* @__PURE__ */ new Date()).getTime() - l) : (r = d[0], l = (/* @__PURE__ */ new Date()).getTime(), f = 0, clearTimeout(i), i = setTimeout(function() {
          l = 0;
        }, 700)), c.pointerStart(h, u, o) && (I.add(o.target, "mousemove", o.onPointerMove).listener(h), I.add(o.target, "mouseup", o.onPointerUp));
      }, o.onPointerMove = function(h) {
        if (l && !f) {
          var d = h.changedTouches || c.getCoords(h);
          s = d[0];
        }
        var m = o.bbox, y = s.pageX - m.x1, b = s.pageY - m.y1;
        y > 0 && y < m.width && b > 0 && b < m.height && Math.abs(s.pageX - r.pageX) <= 25 && Math.abs(s.pageY - r.pageY) <= 25 || (I.remove(o.target, "mousemove", o.onPointerMove), clearTimeout(i), l = f = 0);
      }, o.onPointerUp = function(h) {
        if (c.pointerEnd(h, u, o) && (I.remove(o.target, "mousemove", o.onPointerMove), I.remove(o.target, "mouseup", o.onPointerUp)), l && f) {
          if (f <= 700) {
            for (var d in u.state = o.gesture, o.tracker) break;
            var m = o.tracker[d];
            u.x = m.start.x, u.y = m.start.y, o.listener(h, u);
          }
          clearTimeout(i), l = f = 0;
        }
      };
      var u = c.pointerSetup(o);
      return u.state = "dblclick", I.add(o.target, "mousedown", o.onPointerDown), u;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.dbltap = c.dbltap, I.Gesture._gestureHandlers.dblclick = c.dblclick, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.dragElement = function(o, l) {
      c.drag({ event: l, target: o, position: "move", listener: function(f, i) {
        o.style.left = i.x + "px", o.style.top = i.y + "px", I.prevent(f);
      } });
    }, c.drag = function(o) {
      o.gesture = "drag", o.onPointerDown = function(f) {
        c.pointerStart(f, l, o) && (o.monitor || (I.add(o.doc, "mousemove", o.onPointerMove), I.add(o.doc, "mouseup", o.onPointerUp))), o.onPointerMove(f, "down");
      }, o.onPointerMove = function(f, i) {
        if (!o.tracker) return o.onPointerDown(f);
        o.bbox;
        for (var r = f.changedTouches || c.getCoords(f), s = r.length, u = 0; u < s; u++) {
          var h = r[u], d = h.identifier || 1 / 0, m = o.tracker[d];
          m && (m.pageX = h.pageX, m.pageY = h.pageY, l.state = i || "move", l.identifier = d, l.start = m.start, l.fingers = o.fingers, o.position === "differenceFromLast" ? (l.x = m.pageX - m.offsetX, l.y = m.pageY - m.offsetY, m.offsetX = m.pageX, m.offsetY = m.pageY) : (l.x = m.pageX - m.offsetX, l.y = m.pageY - m.offsetY), o.listener(f, l));
        }
      }, o.onPointerUp = function(f) {
        c.pointerEnd(f, l, o, o.onPointerMove) && (o.monitor || (I.remove(o.doc, "mousemove", o.onPointerMove), I.remove(o.doc, "mouseup", o.onPointerUp)));
      };
      var l = c.pointerSetup(o);
      return o.event ? o.onPointerDown(o.event) : (I.add(o.target, "mousedown", o.onPointerDown), o.monitor && (I.add(o.doc, "mousemove", o.onPointerMove), I.add(o.doc, "mouseup", o.onPointerUp))), l;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.drag = c.drag, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    var o = Math.PI / 180, l = function(f, i) {
      var r = 0, s = 0, u = 0;
      for (var h in i) {
        var d = i[h];
        d.up || (r += d.move.x, s += d.move.y, u++);
      }
      return f.x = r /= u, f.y = s /= u, f;
    };
    return c.gesture = function(f) {
      f.gesture = f.gesture || "gesture", f.minFingers = f.minFingers || f.fingers || 2, f.onPointerDown = function(r) {
        var s = f.fingers;
        if (c.pointerStart(r, i, f) && (I.add(f.doc, "mousemove", f.onPointerMove), I.add(f.doc, "mouseup", f.onPointerUp)), f.fingers === f.minFingers && s !== f.fingers) {
          i.fingers = f.minFingers, i.scale = 1, i.rotation = 0, i.state = "start";
          var u = "";
          for (var h in f.tracker) u += h;
          i.identifier = parseInt(u), l(i, f.tracker), f.listener(r, i);
        }
      }, f.onPointerMove = function(r, s) {
        for (var u = f.bbox, h = f.tracker, d = (b = r.changedTouches || c.getCoords(r)).length, m = 0; m < d; m++) {
          var y = h[A = (M = b[m]).identifier || 1 / 0];
          y && (y.move.x = M.pageX - u.x1, y.move.y = M.pageY - u.y1);
        }
        if (!(f.fingers < f.minFingers)) {
          var b = [], S = 0, E = 0;
          for (var A in l(i, h), h) {
            var M;
            if (!(M = h[A]).up) {
              var C = M.start;
              if (!C.distance) {
                var O = C.x - i.x, N = C.y - i.y;
                C.distance = Math.sqrt(O * O + N * N), C.angle = Math.atan2(O, N) / o;
              }
              O = M.move.x - i.x, N = M.move.y - i.y, S += Math.sqrt(O * O + N * N) / C.distance;
              var z = Math.atan2(O, N) / o, W = (C.angle - z + 360) % 360 - 180;
              M.DEG2 = M.DEG1, M.DEG1 = W > 0 ? W : -W, M.DEG2 !== void 0 && (W > 0 ? M.rotation += M.DEG1 - M.DEG2 : M.rotation -= M.DEG1 - M.DEG2, E += M.rotation), b.push(M.move);
            }
          }
          i.touches = b, i.fingers = f.fingers, i.scale = S / f.fingers, i.rotation = E / f.fingers, i.state = "change", f.listener(r, i);
        }
      }, f.onPointerUp = function(r) {
        var s = f.fingers;
        c.pointerEnd(r, i, f) && (I.remove(f.doc, "mousemove", f.onPointerMove), I.remove(f.doc, "mouseup", f.onPointerUp)), s === f.minFingers && f.fingers < f.minFingers && (i.fingers = f.fingers, i.state = "end", f.listener(r, i));
      };
      var i = c.pointerSetup(f);
      return I.add(f.target, "mousedown", f.onPointerDown), i;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.gesture = c.gesture, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.pointerdown = c.pointermove = c.pointerup = function(o) {
      if (o.gesture = o.gesture || "pointer", !o.target.isPointerEmitter) {
        var l = !0;
        o.onPointerDown = function(i) {
          l = !1, f.gesture = "pointerdown", o.listener(i, f);
        }, o.onPointerMove = function(i) {
          f.gesture = "pointermove", o.listener(i, f, l);
        }, o.onPointerUp = function(i) {
          l = !0, f.gesture = "pointerup", o.listener(i, f, !0);
        };
        var f = c.pointerSetup(o);
        return I.add(o.target, "mousedown", o.onPointerDown), I.add(o.target, "mousemove", o.onPointerMove), I.add(o.doc, "mouseup", o.onPointerUp), o.target.isPointerEmitter = !0, f;
      }
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.pointerdown = c.pointerdown, I.Gesture._gestureHandlers.pointermove = c.pointermove, I.Gesture._gestureHandlers.pointerup = c.pointerup, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.shake = function(o) {
      var l = { gesture: "devicemotion", acceleration: {}, accelerationIncludingGravity: {}, target: o.target, listener: o.listener, remove: function() {
        window.removeEventListener("devicemotion", s, !1);
      } }, f = (/* @__PURE__ */ new Date()).getTime(), i = { x: 0, y: 0, z: 0 }, r = { x: { count: 0, value: 0 }, y: { count: 0, value: 0 }, z: { count: 0, value: 0 } }, s = function(u) {
        var h = 0.8, d = u.accelerationIncludingGravity;
        if (i.x = h * i.x + (1 - h) * d.x, i.y = h * i.y + (1 - h) * d.y, i.z = h * i.z + (1 - h) * d.z, l.accelerationIncludingGravity = i, l.acceleration.x = d.x - i.x, l.acceleration.y = d.y - i.y, l.acceleration.z = d.z - i.z, o.gesture !== "devicemotion") for (var m = (/* @__PURE__ */ new Date()).getTime(), y = 0; y < 3; y++) {
          var b = "xyz"[y], S = l.acceleration[b], E = r[b], A = Math.abs(S);
          if (!(m - f < 1e3) && A > 4) {
            var M = m * S / A, C = Math.abs(M + E.value);
            E.value && C < 200 ? (E.value = M, E.count++, E.count === 3 && (o.listener(u, l), f = m, E.value = 0, E.count = 0)) : (E.value = M, E.count = 1);
          }
        }
        else o.listener(u, l);
      };
      if (window.addEventListener) return window.addEventListener("devicemotion", s, !1), l;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.shake = c.shake, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    var o = Math.PI / 180;
    return c.swipe = function(l) {
      l.snap = l.snap || 90, l.threshold = l.threshold || 1, l.gesture = l.gesture || "swipe", l.onPointerDown = function(i) {
        c.pointerStart(i, f, l) && (I.add(l.doc, "mousemove", l.onPointerMove).listener(i), I.add(l.doc, "mouseup", l.onPointerUp));
      }, l.onPointerMove = function(i) {
        for (var r = i.changedTouches || c.getCoords(i), s = r.length, u = 0; u < s; u++) {
          var h = r[u], d = h.identifier || 1 / 0, m = l.tracker[d];
          m && (m.move.x = h.pageX, m.move.y = h.pageY, m.moveTime = (/* @__PURE__ */ new Date()).getTime());
        }
      }, l.onPointerUp = function(i) {
        if (c.pointerEnd(i, f, l)) {
          var r, s;
          I.remove(l.doc, "mousemove", l.onPointerMove), I.remove(l.doc, "mouseup", l.onPointerUp);
          var u = { x: 0, y: 0 }, h = 0, d = 0, m = 0;
          for (var y in l.tracker) {
            var b = l.tracker[y], S = b.move.x - b.start.x, E = b.move.y - b.start.y;
            h += b.move.x, d += b.move.y, u.x += b.start.x, u.y += b.start.y, m++;
            var A = Math.sqrt(S * S + E * E), M = b.moveTime - b.startTime, C = Math.atan2(S, E) / o + 180, O = M ? A / M : 0;
            if (s === void 0) s = C, r = O;
            else {
              if (!(Math.abs(C - s) <= 20)) return;
              s = (s + C) / 2, r = (r + O) / 2;
            }
          }
          var N = l.gestureFingers;
          l.minFingers <= N && l.maxFingers >= N && r > l.threshold && (u.x /= m, u.y /= m, f.start = u, f.x = h / m, f.y = d / m, f.angle = -(((s / l.snap + 0.5 >> 0) * l.snap || 360) - 360), f.velocity = r, f.fingers = N, f.state = "swipe", l.listener(i, f));
        }
      };
      var f = c.pointerSetup(l);
      return I.add(l.target, "mousedown", l.onPointerDown), f;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.swipe = c.swipe, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.longpress = function(o) {
      return o.gesture = "longpress", c.tap(o);
    }, c.tap = function(o) {
      var l, f;
      o.delay = o.delay || 500, o.timeout = o.timeout || 250, o.driftDeviance = o.driftDeviance || 10, o.gesture = o.gesture || "tap", o.onPointerDown = function(r) {
        if (c.pointerStart(r, i, o)) {
          if (l = (/* @__PURE__ */ new Date()).getTime(), I.add(o.doc, "mousemove", o.onPointerMove).listener(r), I.add(o.doc, "mouseup", o.onPointerUp), o.gesture !== "longpress") return;
          f = setTimeout(function() {
            if (!(r.cancelBubble && ++r.cancelBubbleCount > 1)) {
              var s = 0;
              for (var u in o.tracker) {
                var h = o.tracker[u];
                if (h.end === !0 || o.cancel) return;
                s++;
              }
              o.minFingers <= s && o.maxFingers >= s && (i.state = "start", i.fingers = s, i.x = h.start.x, i.y = h.start.y, o.listener(r, i));
            }
          }, o.delay);
        }
      }, o.onPointerMove = function(r) {
        for (var s = o.bbox, u = r.changedTouches || c.getCoords(r), h = u.length, d = 0; d < h; d++) {
          var m = u[d], y = m.identifier || 1 / 0, b = o.tracker[y];
          if (b) {
            var S = m.pageX - s.x1, E = m.pageY - s.y1, A = S - b.start.x, M = E - b.start.y, C = Math.sqrt(A * A + M * M);
            if (!(S > 0 && S < s.width && E > 0 && E < s.height && C <= o.driftDeviance)) return I.remove(o.doc, "mousemove", o.onPointerMove), void (o.cancel = !0);
          }
        }
      }, o.onPointerUp = function(r) {
        if (c.pointerEnd(r, i, o)) {
          if (clearTimeout(f), I.remove(o.doc, "mousemove", o.onPointerMove), I.remove(o.doc, "mouseup", o.onPointerUp), r.cancelBubble && ++r.cancelBubbleCount > 1) return;
          if (o.gesture === "longpress") return void (i.state === "start" && (i.state = "end", o.listener(r, i)));
          if (o.cancel || (/* @__PURE__ */ new Date()).getTime() - l > o.timeout) return;
          var s = o.gestureFingers;
          o.minFingers <= s && o.maxFingers >= s && (i.state = "tap", i.fingers = o.gestureFingers, o.listener(r, i));
        }
      };
      var i = c.pointerSetup(o);
      return I.add(o.target, "mousedown", o.onPointerDown), i;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.tap = c.tap, I.Gesture._gestureHandlers.longpress = c.longpress, c;
  }(I.proxy), I === void 0 && (I = {}), I.proxy === void 0 && (I.proxy = {}), I.proxy = function(c) {
    return c.wheelPreventElasticBounce = function(o) {
      o && (typeof o == "string" && (o = document.querySelector(o)), I.add(o, "wheel", function(l, f) {
        f.preventElasticBounce(), I.stop(l);
      }));
    }, c.wheel = function(o) {
      var l, f = o.timeout || 150, i = 0, r = { gesture: "wheel", state: "start", wheelDelta: 0, target: o.target, listener: o.listener, preventElasticBounce: function(m) {
        var y = this.target, b = y.scrollTop;
        (b + y.offsetHeight === y.scrollHeight && this.wheelDelta <= 0 || b === 0 && this.wheelDelta >= 0) && I.cancel(m), I.stop(m);
      }, add: function() {
        o.target[u](d, s, !1);
      }, remove: function() {
        o.target[h](d, s, !1);
      } }, s = function(m) {
        m = m || window.event, r.state = i++ ? "change" : "start", r.wheelDelta = m.detail ? -20 * m.detail : m.wheelDelta, o.listener(m, r), clearTimeout(l), l = setTimeout(function() {
          i = 0, r.state = "end", r.wheelDelta = 0, o.listener(m, r);
        }, f);
      }, u = document.addEventListener ? "addEventListener" : "attachEvent", h = document.removeEventListener ? "removeEventListener" : "detachEvent", d = I.getEventSupport("mousewheel") ? "mousewheel" : "DOMMouseScroll";
      return o.target[u](d, s, !1), r;
    }, I.Gesture = I.Gesture || {}, I.Gesture._gestureHandlers = I.Gesture._gestureHandlers || {}, I.Gesture._gestureHandlers.wheel = c.wheel, c;
  }(I.proxy), Et === void 0) var Et = {};
  function Xt(c, o) {
    var l = c.canvas, f = o.targetCanvas, i = f.getContext("2d");
    i.translate(0, f.height), i.scale(1, -1);
    var r = l.height - f.height;
    i.drawImage(l, 0, r, f.width, f.height, 0, 0, f.width, f.height);
  }
  function zt(c, o) {
    var l = o.targetCanvas.getContext("2d"), f = o.destinationWidth, i = o.destinationHeight, r = f * i * 4, s = new Uint8Array(this.imageBuffer, 0, r), u = new Uint8ClampedArray(this.imageBuffer, 0, r);
    c.readPixels(0, 0, f, i, c.RGBA, c.UNSIGNED_BYTE, s);
    var h = new ImageData(u, f, i);
    l.putImageData(h, 0, 0);
  }
  Et.proxy === void 0 && (Et.proxy = {}), Et.proxy = function(c) {
    return c.orientation = function(o) {
      var l = { gesture: "orientationchange", previous: null, current: window.orientation, target: o.target, listener: o.listener, remove: function() {
        window.removeEventListener("orientationchange", f, !1);
      } }, f = function(i) {
        l.previous = l.current, l.current = window.orientation, l.previous === null || l.previous == l.current || o.listener(i, l);
      };
      return window.DeviceOrientationEvent && window.addEventListener("orientationchange", f, !1), l;
    }, Et.Gesture = Et.Gesture || {}, Et.Gesture._gestureHandlers = Et.Gesture._gestureHandlers || {}, Et.Gesture._gestureHandlers.orientation = c.orientation, c;
  }(Et.proxy), function() {
    function c(l, f) {
      if (this.__eventListeners[l]) {
        var i = this.__eventListeners[l];
        f ? i[i.indexOf(f)] = !1 : v.util.array.fill(i, !1);
      }
    }
    function o(l, f) {
      var i = (function() {
        f.apply(this, arguments), this.off(l, i);
      }).bind(this);
      this.on(l, i);
    }
    v.Observable = { fire: function(l, f) {
      if (!this.__eventListeners) return this;
      var i = this.__eventListeners[l];
      if (!i) return this;
      for (var r = 0, s = i.length; r < s; r++) i[r] && i[r].call(this, f || {});
      return this.__eventListeners[l] = i.filter(function(u) {
        return u !== !1;
      }), this;
    }, on: function(l, f) {
      if (this.__eventListeners || (this.__eventListeners = {}), arguments.length === 1) for (var i in l) this.on(i, l[i]);
      else this.__eventListeners[l] || (this.__eventListeners[l] = []), this.__eventListeners[l].push(f);
      return this;
    }, once: function(l, f) {
      if (arguments.length === 1) for (var i in l) o.call(this, i, l[i]);
      else o.call(this, l, f);
      return this;
    }, off: function(l, f) {
      if (!this.__eventListeners) return this;
      if (arguments.length === 0) for (l in this.__eventListeners) c.call(this, l);
      else if (arguments.length === 1 && typeof arguments[0] == "object") for (var i in l) c.call(this, i, l[i]);
      else c.call(this, l, f);
      return this;
    } };
  }(), v.Collection = { _objects: [], add: function() {
    if (this._objects.push.apply(this._objects, arguments), this._onObjectAdded) for (var c = 0, o = arguments.length; c < o; c++) this._onObjectAdded(arguments[c]);
    return this.renderOnAddRemove && this.requestRenderAll(), this;
  }, insertAt: function(c, o, l) {
    var f = this._objects;
    return l ? f[o] = c : f.splice(o, 0, c), this._onObjectAdded && this._onObjectAdded(c), this.renderOnAddRemove && this.requestRenderAll(), this;
  }, remove: function() {
    for (var c, o = this._objects, l = !1, f = 0, i = arguments.length; f < i; f++) (c = o.indexOf(arguments[f])) !== -1 && (l = !0, o.splice(c, 1), this._onObjectRemoved && this._onObjectRemoved(arguments[f]));
    return this.renderOnAddRemove && l && this.requestRenderAll(), this;
  }, forEachObject: function(c, o) {
    for (var l = this.getObjects(), f = 0, i = l.length; f < i; f++) c.call(o, l[f], f, l);
    return this;
  }, getObjects: function(c) {
    return c === void 0 ? this._objects.concat() : this._objects.filter(function(o) {
      return o.type === c;
    });
  }, item: function(c) {
    return this._objects[c];
  }, isEmpty: function() {
    return this._objects.length === 0;
  }, size: function() {
    return this._objects.length;
  }, contains: function(c, o) {
    return this._objects.indexOf(c) > -1 || !!o && this._objects.some(function(l) {
      return typeof l.contains == "function" && l.contains(c, !0);
    });
  }, complexity: function() {
    return this._objects.reduce(function(c, o) {
      return c += o.complexity ? o.complexity() : 0;
    }, 0);
  } }, v.CommonMethods = { _setOptions: function(c) {
    for (var o in c) this.set(o, c[o]);
  }, _initGradient: function(c, o) {
    !c || !c.colorStops || c instanceof v.Gradient || this.set(o, new v.Gradient(c));
  }, _initPattern: function(c, o, l) {
    !c || !c.source || c instanceof v.Pattern ? l && l() : this.set(o, new v.Pattern(c, l));
  }, _setObject: function(c) {
    for (var o in c) this._set(o, c[o]);
  }, set: function(c, o) {
    return typeof c == "object" ? this._setObject(c) : this._set(c, o), this;
  }, _set: function(c, o) {
    this[c] = o;
  }, toggle: function(c) {
    var o = this.get(c);
    return typeof o == "boolean" && this.set(c, !o), this;
  }, get: function(c) {
    return this[c];
  } }, p = t, g = Math.sqrt, _ = Math.atan2, w = Math.pow, x = Math.PI / 180, T = Math.PI / 2, v.util = { cos: function(c) {
    if (c === 0) return 1;
    switch (c < 0 && (c = -c), c / T) {
      case 1:
      case 3:
        return 0;
      case 2:
        return -1;
    }
    return Math.cos(c);
  }, sin: function(c) {
    if (c === 0) return 0;
    var o = 1;
    switch (c < 0 && (o = -1), c / T) {
      case 1:
        return o;
      case 2:
        return 0;
      case 3:
        return -o;
    }
    return Math.sin(c);
  }, removeFromArray: function(c, o) {
    var l = c.indexOf(o);
    return l !== -1 && c.splice(l, 1), c;
  }, getRandomInt: function(c, o) {
    return Math.floor(Math.random() * (o - c + 1)) + c;
  }, degreesToRadians: function(c) {
    return c * x;
  }, radiansToDegrees: function(c) {
    return c / x;
  }, rotatePoint: function(c, o, l) {
    var f = new v.Point(c.x - o.x, c.y - o.y), i = v.util.rotateVector(f, l);
    return new v.Point(i.x, i.y).addEquals(o);
  }, rotateVector: function(c, o) {
    var l = v.util.sin(o), f = v.util.cos(o);
    return { x: c.x * f - c.y * l, y: c.x * l + c.y * f };
  }, transformPoint: function(c, o, l) {
    return l ? new v.Point(o[0] * c.x + o[2] * c.y, o[1] * c.x + o[3] * c.y) : new v.Point(o[0] * c.x + o[2] * c.y + o[4], o[1] * c.x + o[3] * c.y + o[5]);
  }, makeBoundingBoxFromPoints: function(c, o) {
    if (o) for (var l = 0; l < c.length; l++) c[l] = v.util.transformPoint(c[l], o);
    var f = [c[0].x, c[1].x, c[2].x, c[3].x], i = v.util.array.min(f), r = v.util.array.max(f) - i, s = [c[0].y, c[1].y, c[2].y, c[3].y], u = v.util.array.min(s);
    return { left: i, top: u, width: r, height: v.util.array.max(s) - u };
  }, invertTransform: function(c) {
    var o = 1 / (c[0] * c[3] - c[1] * c[2]), l = [o * c[3], -o * c[1], -o * c[2], o * c[0]], f = v.util.transformPoint({ x: c[4], y: c[5] }, l, !0);
    return l[4] = -f.x, l[5] = -f.y, l;
  }, toFixed: function(c, o) {
    return parseFloat(Number(c).toFixed(o));
  }, parseUnit: function(c, o) {
    var l = /\D{0,2}$/.exec(c), f = parseFloat(c);
    switch (o || (o = v.Text.DEFAULT_SVG_FONT_SIZE), l[0]) {
      case "mm":
        return f * v.DPI / 25.4;
      case "cm":
        return f * v.DPI / 2.54;
      case "in":
        return f * v.DPI;
      case "pt":
        return f * v.DPI / 72;
      case "pc":
        return f * v.DPI / 72 * 12;
      case "em":
        return f * o;
      default:
        return f;
    }
  }, falseFunction: function() {
    return !1;
  }, getKlass: function(c, o) {
    return c = v.util.string.camelize(c.charAt(0).toUpperCase() + c.slice(1)), v.util.resolveNamespace(o)[c];
  }, getSvgAttributes: function(c) {
    var o = ["instantiated_by_use", "style", "id", "class"];
    switch (c) {
      case "linearGradient":
        o = o.concat(["x1", "y1", "x2", "y2", "gradientUnits", "gradientTransform"]);
        break;
      case "radialGradient":
        o = o.concat(["gradientUnits", "gradientTransform", "cx", "cy", "r", "fx", "fy", "fr"]);
        break;
      case "stop":
        o = o.concat(["offset", "stop-color", "stop-opacity"]);
    }
    return o;
  }, resolveNamespace: function(c) {
    if (!c) return v;
    var o, l = c.split("."), f = l.length, i = p || v.window;
    for (o = 0; o < f; ++o) i = i[l[o]];
    return i;
  }, loadImage: function(c, o, l, f) {
    if (c) {
      var i = v.util.createImage(), r = function() {
        o && o.call(l, i, !1), i = i.onload = i.onerror = null;
      };
      i.onload = r, i.onerror = function() {
        v.log("Error loading " + i.src), o && o.call(l, null, !0), i = i.onload = i.onerror = null;
      }, c.indexOf("data") !== 0 && f != null && (i.crossOrigin = f), c.substring(0, 14) === "data:image/svg" && (i.onload = null, v.util.loadImageInDom(i, r)), i.src = c;
    } else o && o.call(l, c);
  }, loadImageInDom: function(c, o) {
    var l = v.document.createElement("div");
    l.style.width = l.style.height = "1px", l.style.left = l.style.top = "-100%", l.style.position = "absolute", l.appendChild(c), v.document.querySelector("body").appendChild(l), c.onload = function() {
      o(), l.parentNode.removeChild(l), l = null;
    };
  }, enlivenObjects: function(c, o, l, f) {
    var i = [], r = 0, s = (c = c || []).length;
    function u() {
      ++r === s && o && o(i.filter(function(h) {
        return h;
      }));
    }
    s ? c.forEach(function(h, d) {
      h && h.type ? v.util.getKlass(h.type, l).fromObject(h, function(m, y) {
        y || (i[d] = m), f && f(h, m, y), u();
      }) : u();
    }) : o && o(i);
  }, enlivenPatterns: function(c, o) {
    function l() {
      ++i === r && o && o(f);
    }
    var f = [], i = 0, r = (c = c || []).length;
    r ? c.forEach(function(s, u) {
      s && s.source ? new v.Pattern(s, function(h) {
        f[u] = h, l();
      }) : (f[u] = s, l());
    }) : o && o(f);
  }, groupSVGElements: function(c, o, l) {
    var f;
    return c && c.length === 1 ? c[0] : (o && (o.width && o.height ? o.centerPoint = { x: o.width / 2, y: o.height / 2 } : (delete o.width, delete o.height)), f = new v.Group(c, o), l !== void 0 && (f.sourcePath = l), f);
  }, populateWithProperties: function(c, o, l) {
    if (l && Object.prototype.toString.call(l) === "[object Array]") for (var f = 0, i = l.length; f < i; f++) l[f] in c && (o[l[f]] = c[l[f]]);
  }, drawDashedLine: function(c, o, l, f, i, r) {
    var s = f - o, u = i - l, h = g(s * s + u * u), d = _(u, s), m = r.length, y = 0, b = !0;
    for (c.save(), c.translate(o, l), c.moveTo(0, 0), c.rotate(d), o = 0; h > o; ) (o += r[y++ % m]) > h && (o = h), c[b ? "lineTo" : "moveTo"](o, 0), b = !b;
    c.restore();
  }, createCanvasElement: function() {
    return v.document.createElement("canvas");
  }, copyCanvasElement: function(c) {
    var o = v.util.createCanvasElement();
    return o.width = c.width, o.height = c.height, o.getContext("2d").drawImage(c, 0, 0), o;
  }, toDataURL: function(c, o, l) {
    return c.toDataURL("image/" + o, l);
  }, createImage: function() {
    return v.document.createElement("img");
  }, multiplyTransformMatrices: function(c, o, l) {
    return [c[0] * o[0] + c[2] * o[1], c[1] * o[0] + c[3] * o[1], c[0] * o[2] + c[2] * o[3], c[1] * o[2] + c[3] * o[3], l ? 0 : c[0] * o[4] + c[2] * o[5] + c[4], l ? 0 : c[1] * o[4] + c[3] * o[5] + c[5]];
  }, qrDecompose: function(c) {
    var o = _(c[1], c[0]), l = w(c[0], 2) + w(c[1], 2), f = g(l), i = (c[0] * c[3] - c[2] * c[1]) / f, r = _(c[0] * c[2] + c[1] * c[3], l);
    return { angle: o / x, scaleX: f, scaleY: i, skewX: r / x, skewY: 0, translateX: c[4], translateY: c[5] };
  }, calcRotateMatrix: function(c) {
    if (!c.angle) return v.iMatrix.concat();
    var o = v.util.degreesToRadians(c.angle), l = v.util.cos(o), f = v.util.sin(o);
    return [l, f, -f, l, 0, 0];
  }, calcDimensionsMatrix: function(c) {
    var o = c.scaleX === void 0 ? 1 : c.scaleX, l = c.scaleY === void 0 ? 1 : c.scaleY, f = [c.flipX ? -o : o, 0, 0, c.flipY ? -l : l, 0, 0], i = v.util.multiplyTransformMatrices, r = v.util.degreesToRadians;
    return c.skewX && (f = i(f, [1, 0, Math.tan(r(c.skewX)), 1], !0)), c.skewY && (f = i(f, [1, Math.tan(r(c.skewY)), 0, 1], !0)), f;
  }, composeMatrix: function(c) {
    var o = [1, 0, 0, 1, c.translateX || 0, c.translateY || 0], l = v.util.multiplyTransformMatrices;
    return c.angle && (o = l(o, v.util.calcRotateMatrix(c))), (c.scaleX !== 1 || c.scaleY !== 1 || c.skewX || c.skewY || c.flipX || c.flipY) && (o = l(o, v.util.calcDimensionsMatrix(c))), o;
  }, resetObjectTransform: function(c) {
    c.scaleX = 1, c.scaleY = 1, c.skewX = 0, c.skewY = 0, c.flipX = !1, c.flipY = !1, c.rotate(0);
  }, saveObjectTransform: function(c) {
    return { scaleX: c.scaleX, scaleY: c.scaleY, skewX: c.skewX, skewY: c.skewY, angle: c.angle, left: c.left, flipX: c.flipX, flipY: c.flipY, top: c.top };
  }, isTransparent: function(c, o, l, f) {
    f > 0 && (o > f ? o -= f : o = 0, l > f ? l -= f : l = 0);
    var i, r = !0, s = c.getImageData(o, l, 2 * f || 1, 2 * f || 1), u = s.data.length;
    for (i = 3; i < u && (r = s.data[i] <= 0); i += 4) ;
    return s = null, r;
  }, parsePreserveAspectRatioAttribute: function(c) {
    var o, l = "meet", f = c.split(" ");
    return f && f.length && ((l = f.pop()) !== "meet" && l !== "slice" ? (o = l, l = "meet") : f.length && (o = f.pop())), { meetOrSlice: l, alignX: o !== "none" ? o.slice(1, 4) : "none", alignY: o !== "none" ? o.slice(5, 8) : "none" };
  }, clearFabricFontCache: function(c) {
    (c = (c || "").toLowerCase()) ? v.charWidthsCache[c] && delete v.charWidthsCache[c] : v.charWidthsCache = {};
  }, limitDimsByArea: function(c, o) {
    var l = Math.sqrt(o * c), f = Math.floor(o / l);
    return { x: Math.floor(l), y: f };
  }, capValue: function(c, o, l) {
    return Math.max(c, Math.min(o, l));
  }, findScaleToFit: function(c, o) {
    return Math.min(o.width / c.width, o.height / c.height);
  }, findScaleToCover: function(c, o) {
    return Math.max(o.width / c.width, o.height / c.height);
  }, matrixToSVG: function(c) {
    return "matrix(" + c.map(function(o) {
      return v.util.toFixed(o, v.Object.NUM_FRACTION_DIGITS);
    }).join(" ") + ")";
  }, removeTransformFromObject: function(c, o) {
    var l = v.util.invertTransform(o), f = v.util.multiplyTransformMatrices(l, c.calcOwnMatrix());
    v.util.applyTransformToObject(c, f);
  }, addTransformToObject: function(c, o) {
    v.util.applyTransformToObject(c, v.util.multiplyTransformMatrices(o, c.calcOwnMatrix()));
  }, applyTransformToObject: function(c, o) {
    var l = v.util.qrDecompose(o), f = new v.Point(l.translateX, l.translateY);
    c.flipX = !1, c.flipY = !1, c.set("scaleX", l.scaleX), c.set("scaleY", l.scaleY), c.skewX = l.skewX, c.skewY = l.skewY, c.angle = l.angle, c.setPositionByOrigin(f, "center", "center");
  }, sizeAfterTransform: function(c, o, l) {
    var f = c / 2, i = o / 2, r = [{ x: -f, y: -i }, { x: f, y: -i }, { x: -f, y: i }, { x: f, y: i }], s = v.util.calcDimensionsMatrix(l), u = v.util.makeBoundingBoxFromPoints(r, s);
    return { x: u.width, y: u.height };
  } }, v.util.createAccessors = function(c) {
    var o, l, f, i, r, s = c.prototype;
    for (o = s.stateProperties.length; o--; ) i = "set" + (f = (l = s.stateProperties[o]).charAt(0).toUpperCase() + l.slice(1)), s[r = "get" + f] || (s[r] = new Function('return this.get("' + l + '")')), s[i] || (s[i] = function(u) {
      return new Function("value", 'return this.set("' + u + '", value)');
    }(l));
  }, function() {
    var c = Array.prototype.join, o = { m: 2, l: 2, h: 1, v: 1, c: 6, s: 4, q: 4, t: 2, a: 7 }, l = { m: "l", M: "L" };
    function f(M, C, O, N, z, W, F, k, B, Z, K) {
      var U = v.util.cos(M), R = v.util.sin(M), H = v.util.cos(C), q = v.util.sin(C), Q = O * z * H - N * W * q + F, nt = N * z * H + O * W * q + k;
      return ["C", Z + B * (-O * z * R - N * W * U), K + B * (-N * z * R + O * W * U), Q + B * (O * z * q + N * W * H), nt + B * (N * z * q - O * W * H), Q, nt];
    }
    function i(M, C, O, N, z, W, F) {
      var k = Math.PI, B = F * k / 180, Z = v.util.sin(B), K = v.util.cos(B), U = 0, R = 0, H = -K * M * 0.5 - Z * C * 0.5, q = -K * C * 0.5 + Z * M * 0.5, Q = (O = Math.abs(O)) * O, nt = (N = Math.abs(N)) * N, gt = q * q, ct = H * H, ft = Q * nt - Q * gt - nt * ct, st = 0;
      if (ft < 0) {
        var lt = Math.sqrt(1 - ft / (Q * nt));
        O *= lt, N *= lt;
      } else st = (z === W ? -1 : 1) * Math.sqrt(ft / (Q * gt + nt * ct));
      var at = st * O * q / N, yt = -st * N * H / O, mt = K * at - Z * yt + 0.5 * M, Mt = Z * at + K * yt + 0.5 * C, Ot = r(1, 0, (H - at) / O, (q - yt) / N), Lt = r((H - at) / O, (q - yt) / N, (-H - at) / O, (-q - yt) / N);
      W === 0 && Lt > 0 ? Lt -= 2 * k : W === 1 && Lt < 0 && (Lt += 2 * k);
      for (var re = Math.ceil(Math.abs(Lt / k * 2)), Ut = [], Ft = Lt / re, oe = 8 / 3 * Math.sin(Ft / 4) * Math.sin(Ft / 4) / Math.sin(Ft / 2), Rt = Ot + Ft, te = 0; te < re; te++) Ut[te] = f(Ot, Rt, K, Z, O, N, mt, Mt, oe, U, R), U = Ut[te][5], R = Ut[te][6], Ot = Rt, Rt += Ft;
      return Ut;
    }
    function r(M, C, O, N) {
      var z = Math.atan2(C, M), W = Math.atan2(N, O);
      return W >= z ? W - z : 2 * Math.PI - (z - W);
    }
    function s(M, C, O, N, z, W, F, k) {
      var B;
      if (v.cachesBoundsOfCurve && (B = c.call(arguments), v.boundsOfCurveCache[B])) return v.boundsOfCurveCache[B];
      var Z, K, U, R, H, q, Q, nt, gt = Math.sqrt, ct = Math.min, ft = Math.max, st = Math.abs, lt = [], at = [[], []];
      K = 6 * M - 12 * O + 6 * z, Z = -3 * M + 9 * O - 9 * z + 3 * F, U = 3 * O - 3 * M;
      for (var yt = 0; yt < 2; ++yt) if (yt > 0 && (K = 6 * C - 12 * N + 6 * W, Z = -3 * C + 9 * N - 9 * W + 3 * k, U = 3 * N - 3 * C), st(Z) < 1e-12) {
        if (st(K) < 1e-12) continue;
        0 < (R = -U / K) && R < 1 && lt.push(R);
      } else (Q = K * K - 4 * U * Z) < 0 || (0 < (H = (-K + (nt = gt(Q))) / (2 * Z)) && H < 1 && lt.push(H), 0 < (q = (-K - nt) / (2 * Z)) && q < 1 && lt.push(q));
      for (var mt, Mt, Ot, Lt = lt.length, re = Lt; Lt--; ) mt = (Ot = 1 - (R = lt[Lt])) * Ot * Ot * M + 3 * Ot * Ot * R * O + 3 * Ot * R * R * z + R * R * R * F, at[0][Lt] = mt, Mt = Ot * Ot * Ot * C + 3 * Ot * Ot * R * N + 3 * Ot * R * R * W + R * R * R * k, at[1][Lt] = Mt;
      at[0][re] = M, at[1][re] = C, at[0][re + 1] = F, at[1][re + 1] = k;
      var Ut = [{ x: ct.apply(null, at[0]), y: ct.apply(null, at[1]) }, { x: ft.apply(null, at[0]), y: ft.apply(null, at[1]) }];
      return v.cachesBoundsOfCurve && (v.boundsOfCurveCache[B] = Ut), Ut;
    }
    function u(M, C, O) {
      for (var N = O[1], z = O[2], W = O[3], F = O[4], k = O[5], B = i(O[6] - M, O[7] - C, N, z, F, k, W), Z = 0, K = B.length; Z < K; Z++) B[Z][1] += M, B[Z][2] += C, B[Z][3] += M, B[Z][4] += C, B[Z][5] += M, B[Z][6] += C;
      return B;
    }
    function h(M, C, O, N) {
      return Math.sqrt((O - M) * (O - M) + (N - C) * (N - C));
    }
    function d(M, C, O, N, z, W, F, k) {
      return function(B) {
        var Z, K = (Z = B) * Z * Z, U = function(q) {
          return 3 * q * q * (1 - q);
        }(B), R = function(q) {
          return 3 * q * (1 - q) * (1 - q);
        }(B), H = function(q) {
          return (1 - q) * (1 - q) * (1 - q);
        }(B);
        return { x: F * K + z * U + O * R + M * H, y: k * K + W * U + N * R + C * H };
      };
    }
    function m(M, C, O, N, z, W, F, k) {
      return function(B) {
        var Z = 1 - B, K = 3 * Z * Z * (O - M) + 6 * Z * B * (z - O) + 3 * B * B * (F - z), U = 3 * Z * Z * (N - C) + 6 * Z * B * (W - N) + 3 * B * B * (k - W);
        return Math.atan2(U, K);
      };
    }
    function y(M, C, O, N, z, W) {
      return function(F) {
        var k, B = (k = F) * k, Z = function(U) {
          return 2 * U * (1 - U);
        }(F), K = function(U) {
          return (1 - U) * (1 - U);
        }(F);
        return { x: z * B + O * Z + M * K, y: W * B + N * Z + C * K };
      };
    }
    function b(M, C, O, N, z, W) {
      return function(F) {
        var k = 1 - F, B = 2 * k * (O - M) + 2 * F * (z - O), Z = 2 * k * (N - C) + 2 * F * (W - N);
        return Math.atan2(Z, B);
      };
    }
    function S(M, C, O) {
      var N, z, W = { x: C, y: O }, F = 0;
      for (z = 1; z <= 100; z += 1) N = M(z / 100), F += h(W.x, W.y, N.x, N.y), W = N;
      return F;
    }
    function E(M, C) {
      for (var O, N, z, W = 0, F = 0, k = M.iterator, B = { x: M.x, y: M.y }, Z = 0.01, K = M.angleFinder; F < C && W <= 1 && Z > 1e-4; ) O = k(W), z = W, (N = h(B.x, B.y, O.x, O.y)) + F > C ? W -= Z /= 2 : (B = O, W += Z, F += N);
      return O.angle = K(z), O;
    }
    function A(M) {
      for (var C, O, N, z, W = 0, F = M.length, k = 0, B = 0, Z = 0, K = 0, U = [], R = 0; R < F; R++) {
        switch (N = { x: k, y: B, command: (C = M[R])[0] }, C[0]) {
          case "M":
            N.length = 0, Z = k = C[1], K = B = C[2];
            break;
          case "L":
            N.length = h(k, B, C[1], C[2]), k = C[1], B = C[2];
            break;
          case "C":
            O = d(k, B, C[1], C[2], C[3], C[4], C[5], C[6]), z = m(k, B, C[1], C[2], C[3], C[4], C[5], C[6]), N.iterator = O, N.angleFinder = z, N.length = S(O, k, B), k = C[5], B = C[6];
            break;
          case "Q":
            O = y(k, B, C[1], C[2], C[3], C[4]), z = b(k, B, C[1], C[2], C[3], C[4]), N.iterator = O, N.angleFinder = z, N.length = S(O, k, B), k = C[3], B = C[4];
            break;
          case "Z":
          case "z":
            N.destX = Z, N.destY = K, N.length = h(k, B, Z, K), k = Z, B = K;
        }
        W += N.length, U.push(N);
      }
      return U.push({ length: W, x: k, y: B }), U;
    }
    v.util.joinPath = function(M) {
      return M.map(function(C) {
        return C.join(" ");
      }).join(" ");
    }, v.util.parsePath = function(M) {
      var C, O, N, z, W, F = [], k = [], B = v.rePathCommand, Z = "[-+]?(?:\\d*\\.\\d+|\\d+\\.?)(?:[eE][-+]?\\d+)?\\s*", K = "(" + Z + ")" + v.commaWsp, U = "([01])" + v.commaWsp + "?", R = new RegExp(K + "?" + K + "?" + K + U + U + K + "?(" + Z + ")", "g");
      if (!M || !M.match) return F;
      for (var H, q = 0, Q = (W = M.match(/[mzlhvcsqta][^mzlhvcsqta]*/gi)).length; q < Q; q++) {
        z = (C = W[q]).slice(1).trim(), k.length = 0;
        var nt = C.charAt(0);
        if (H = [nt], nt.toLowerCase() === "a") for (var gt; gt = R.exec(z); ) for (var ct = 1; ct < gt.length; ct++) k.push(gt[ct]);
        else for (; N = B.exec(z); ) k.push(N[0]);
        ct = 0;
        for (var ft = k.length; ct < ft; ct++) O = parseFloat(k[ct]), isNaN(O) || H.push(O);
        var st = o[nt.toLowerCase()], lt = l[nt] || nt;
        if (H.length - 1 > st) for (var at = 1, yt = H.length; at < yt; at += st) F.push([nt].concat(H.slice(at, at + st))), nt = lt;
        else F.push(H);
      }
      return F;
    }, v.util.makePathSimpler = function(M) {
      var C, O, N, z, W, F, k = 0, B = 0, Z = M.length, K = 0, U = 0, R = [];
      for (O = 0; O < Z; ++O) {
        switch (N = !1, (C = M[O].slice(0))[0]) {
          case "l":
            C[0] = "L", C[1] += k, C[2] += B;
          case "L":
            k = C[1], B = C[2];
            break;
          case "h":
            C[1] += k;
          case "H":
            C[0] = "L", C[2] = B, k = C[1];
            break;
          case "v":
            C[1] += B;
          case "V":
            C[0] = "L", B = C[1], C[1] = k, C[2] = B;
            break;
          case "m":
            C[0] = "M", C[1] += k, C[2] += B;
          case "M":
            k = C[1], B = C[2], K = C[1], U = C[2];
            break;
          case "c":
            C[0] = "C", C[1] += k, C[2] += B, C[3] += k, C[4] += B, C[5] += k, C[6] += B;
          case "C":
            W = C[3], F = C[4], k = C[5], B = C[6];
            break;
          case "s":
            C[0] = "S", C[1] += k, C[2] += B, C[3] += k, C[4] += B;
          case "S":
            z === "C" ? (W = 2 * k - W, F = 2 * B - F) : (W = k, F = B), k = C[3], B = C[4], C[0] = "C", C[5] = C[3], C[6] = C[4], C[3] = C[1], C[4] = C[2], C[1] = W, C[2] = F, W = C[3], F = C[4];
            break;
          case "q":
            C[0] = "Q", C[1] += k, C[2] += B, C[3] += k, C[4] += B;
          case "Q":
            W = C[1], F = C[2], k = C[3], B = C[4];
            break;
          case "t":
            C[0] = "T", C[1] += k, C[2] += B;
          case "T":
            z === "Q" ? (W = 2 * k - W, F = 2 * B - F) : (W = k, F = B), C[0] = "Q", k = C[1], B = C[2], C[1] = W, C[2] = F, C[3] = k, C[4] = B;
            break;
          case "a":
            C[0] = "A", C[6] += k, C[7] += B;
          case "A":
            N = !0, R = R.concat(u(k, B, C)), k = C[6], B = C[7];
            break;
          case "z":
          case "Z":
            k = K, B = U;
        }
        N || R.push(C), z = C[0];
      }
      return R;
    }, v.util.getSmoothPathFromPoints = function(M, C) {
      var O, N = [], z = new v.Point(M[0].x, M[0].y), W = new v.Point(M[1].x, M[1].y), F = M.length, k = 1, B = 0, Z = F > 2;
      for (C = C || 0, Z && (k = M[2].x < W.x ? -1 : M[2].x === W.x ? 0 : 1, B = M[2].y < W.y ? -1 : M[2].y === W.y ? 0 : 1), N.push(["M", z.x - k * C, z.y - B * C]), O = 1; O < F; O++) {
        if (!z.eq(W)) {
          var K = z.midPointFrom(W);
          N.push(["Q", z.x, z.y, K.x, K.y]);
        }
        z = M[O], O + 1 < M.length && (W = M[O + 1]);
      }
      return Z && (k = z.x > M[O - 2].x ? 1 : z.x === M[O - 2].x ? 0 : -1, B = z.y > M[O - 2].y ? 1 : z.y === M[O - 2].y ? 0 : -1), N.push(["L", z.x + k * C, z.y + B * C]), N;
    }, v.util.getPathSegmentsInfo = A, v.util.getBoundsOfCurve = s, v.util.getPointOnPath = function(M, C, O) {
      O || (O = A(M));
      for (var N = 0; C - O[N].length > 0 && N < O.length - 2; ) C -= O[N].length, N++;
      var z, W = O[N], F = C / W.length, k = W.command, B = M[N];
      switch (k) {
        case "M":
          return { x: W.x, y: W.y, angle: 0 };
        case "Z":
        case "z":
          return (z = new v.Point(W.x, W.y).lerp(new v.Point(W.destX, W.destY), F)).angle = Math.atan2(W.destY - W.y, W.destX - W.x), z;
        case "L":
          return (z = new v.Point(W.x, W.y).lerp(new v.Point(B[1], B[2]), F)).angle = Math.atan2(B[2] - W.y, B[1] - W.x), z;
        case "C":
        case "Q":
          return E(W, C);
      }
    }, v.util.transformPath = function(M, C, O) {
      return O && (C = v.util.multiplyTransformMatrices(C, [1, 0, 0, 1, -O.x, -O.y])), M.map(function(N) {
        for (var z = N.slice(0), W = {}, F = 1; F < N.length - 1; F += 2) W.x = N[F], W.y = N[F + 1], W = v.util.transformPoint(W, C), z[F] = W.x, z[F + 1] = W.y;
        return z;
      });
    }, v.util.fromArcToBeizers = u, v.util.getBoundsOfArc = function(M, C, O, N, z, W, F, k, B) {
      for (var Z, K = 0, U = 0, R = [], H = i(k - M, B - C, O, N, W, F, z), q = 0, Q = H.length; q < Q; q++) Z = s(K, U, H[q][1], H[q][2], H[q][3], H[q][4], H[q][5], H[q][6]), R.push({ x: Z[0].x + M, y: Z[0].y + C }), R.push({ x: Z[1].x + M, y: Z[1].y + C }), K = H[q][5], U = H[q][6];
      return R;
    }, v.util.drawArc = function(M, C, O, N) {
      u(C, O, N = N.slice(0).unshift("X")).forEach(function(z) {
        M.bezierCurveTo.apply(M, z.slice(1));
      });
    };
  }(), function() {
    var c = Array.prototype.slice;
    function o(l, f, i) {
      if (l && l.length !== 0) {
        var r = l.length - 1, s = f ? l[r][f] : l[r];
        if (f) for (; r--; ) i(l[r][f], s) && (s = l[r][f]);
        else for (; r--; ) i(l[r], s) && (s = l[r]);
        return s;
      }
    }
    v.util.array = { fill: function(l, f) {
      for (var i = l.length; i--; ) l[i] = f;
      return l;
    }, invoke: function(l, f) {
      for (var i = c.call(arguments, 2), r = [], s = 0, u = l.length; s < u; s++) r[s] = i.length ? l[s][f].apply(l[s], i) : l[s][f].call(l[s]);
      return r;
    }, min: function(l, f) {
      return o(l, f, function(i, r) {
        return i < r;
      });
    }, max: function(l, f) {
      return o(l, f, function(i, r) {
        return i >= r;
      });
    } };
  }(), function() {
    function c(o, l, f) {
      if (f) if (!v.isLikelyNode && l instanceof Element) o = l;
      else if (l instanceof Array) {
        o = [];
        for (var i = 0, r = l.length; i < r; i++) o[i] = c({}, l[i], f);
      } else if (l && typeof l == "object") for (var s in l) s === "canvas" || s === "group" ? o[s] = null : l.hasOwnProperty(s) && (o[s] = c({}, l[s], f));
      else o = l;
      else for (var s in l) o[s] = l[s];
      return o;
    }
    v.util.object = { extend: c, clone: function(o, l) {
      return c({}, o, l);
    } }, v.util.object.extend(v.util, v.Observable);
  }(), function() {
    function c(o, l) {
      var f = o.charCodeAt(l);
      if (isNaN(f)) return "";
      if (f < 55296 || f > 57343) return o.charAt(l);
      if (55296 <= f && f <= 56319) {
        if (o.length <= l + 1) throw "High surrogate without following low surrogate";
        var i = o.charCodeAt(l + 1);
        if (56320 > i || i > 57343) throw "High surrogate without following low surrogate";
        return o.charAt(l) + o.charAt(l + 1);
      }
      if (l === 0) throw "Low surrogate without preceding high surrogate";
      var r = o.charCodeAt(l - 1);
      if (55296 > r || r > 56319) throw "Low surrogate without preceding high surrogate";
      return !1;
    }
    v.util.string = { camelize: function(o) {
      return o.replace(/-+(.)?/g, function(l, f) {
        return f ? f.toUpperCase() : "";
      });
    }, capitalize: function(o, l) {
      return o.charAt(0).toUpperCase() + (l ? o.slice(1) : o.slice(1).toLowerCase());
    }, escapeXml: function(o) {
      return o.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }, graphemeSplit: function(o) {
      var l, f = 0, i = [];
      for (f = 0; f < o.length; f++) (l = c(o, f)) !== !1 && i.push(l);
      return i;
    } };
  }(), function() {
    var c = Array.prototype.slice, o = function() {
    }, l = function() {
      for (var s in { toString: 1 }) if (s === "toString") return !1;
      return !0;
    }(), f = function(s, u, h) {
      for (var d in u) d in s.prototype && typeof s.prototype[d] == "function" && (u[d] + "").indexOf("callSuper") > -1 ? s.prototype[d] = /* @__PURE__ */ function(m) {
        return function() {
          var y = this.constructor.superclass;
          this.constructor.superclass = h;
          var b = u[m].apply(this, arguments);
          if (this.constructor.superclass = y, m !== "initialize") return b;
        };
      }(d) : s.prototype[d] = u[d], l && (u.toString !== Object.prototype.toString && (s.prototype.toString = u.toString), u.valueOf !== Object.prototype.valueOf && (s.prototype.valueOf = u.valueOf));
    };
    function i() {
    }
    function r(s) {
      for (var u = null, h = this; h.constructor.superclass; ) {
        var d = h.constructor.superclass.prototype[s];
        if (h[s] !== d) {
          u = d;
          break;
        }
        h = h.constructor.superclass.prototype;
      }
      return u ? arguments.length > 1 ? u.apply(this, c.call(arguments, 1)) : u.call(this) : console.log("tried to callSuper " + s + ", method not found in prototype chain", this);
    }
    v.util.createClass = function() {
      var s = null, u = c.call(arguments, 0);
      function h() {
        this.initialize.apply(this, arguments);
      }
      typeof u[0] == "function" && (s = u.shift()), h.superclass = s, h.subclasses = [], s && (i.prototype = s.prototype, h.prototype = new i(), s.subclasses.push(h));
      for (var d = 0, m = u.length; d < m; d++) f(h, u[d], s);
      return h.prototype.initialize || (h.prototype.initialize = o), h.prototype.constructor = h, h.prototype.callSuper = r, h;
    };
  }(), L = !!v.document.createElement("div").attachEvent, X = ["touchstart", "touchmove", "touchend"], v.util.addListener = function(c, o, l, f) {
    c && c.addEventListener(o, l, !L && f);
  }, v.util.removeListener = function(c, o, l, f) {
    c && c.removeEventListener(o, l, !L && f);
  }, v.util.getPointer = function(c) {
    var o = c.target, l = v.util.getScrollLeftTop(o), f = function(i) {
      var r = i.changedTouches;
      return r && r[0] ? r[0] : i;
    }(c);
    return { x: f.clientX + l.left, y: f.clientY + l.top };
  }, v.util.isTouchEvent = function(c) {
    return X.indexOf(c.type) > -1 || c.pointerType === "touch";
  }, G = v.document.createElement("div"), J = typeof G.style.opacity == "string", et = typeof G.style.filter == "string", rt = /alpha\s*\(\s*opacity\s*=\s*([^\)]+)\)/, vt = function(c) {
    return c;
  }, J ? vt = function(c, o) {
    return c.style.opacity = o, c;
  } : et && (vt = function(c, o) {
    var l = c.style;
    return c.currentStyle && !c.currentStyle.hasLayout && (l.zoom = 1), rt.test(l.filter) ? (o = o >= 0.9999 ? "" : "alpha(opacity=" + 100 * o + ")", l.filter = l.filter.replace(rt, o)) : l.filter += " alpha(opacity=" + 100 * o + ")", c;
  }), v.util.setStyle = function(c, o) {
    var l = c.style;
    if (!l) return c;
    if (typeof o == "string") return c.style.cssText += ";" + o, o.indexOf("opacity") > -1 ? vt(c, o.match(/opacity:\s*(\d?\.?\d*)/)[1]) : c;
    for (var f in o) f === "opacity" ? vt(c, o[f]) : l[f === "float" || f === "cssFloat" ? l.styleFloat === void 0 ? "cssFloat" : "styleFloat" : f] = o[f];
    return c;
  }, function() {
    var c = Array.prototype.slice, o, l, f, i, r = function(h) {
      return c.call(h, 0);
    };
    try {
      o = r(v.document.childNodes) instanceof Array;
    } catch {
    }
    function s(h, d) {
      var m = v.document.createElement(h);
      for (var y in d) y === "class" ? m.className = d[y] : y === "for" ? m.htmlFor = d[y] : m.setAttribute(y, d[y]);
      return m;
    }
    function u(h) {
      for (var d = 0, m = 0, y = v.document.documentElement, b = v.document.body || { scrollLeft: 0, scrollTop: 0 }; h && (h.parentNode || h.host) && ((h = h.parentNode || h.host) === v.document ? (d = b.scrollLeft || y.scrollLeft || 0, m = b.scrollTop || y.scrollTop || 0) : (d += h.scrollLeft || 0, m += h.scrollTop || 0), h.nodeType !== 1 || h.style.position !== "fixed"); ) ;
      return { left: d, top: m };
    }
    o || (r = function(h) {
      for (var d = new Array(h.length), m = h.length; m--; ) d[m] = h[m];
      return d;
    }), l = v.document.defaultView && v.document.defaultView.getComputedStyle ? function(h, d) {
      var m = v.document.defaultView.getComputedStyle(h, null);
      return m ? m[d] : void 0;
    } : function(h, d) {
      var m = h.style[d];
      return !m && h.currentStyle && (m = h.currentStyle[d]), m;
    }, f = v.document.documentElement.style, i = "userSelect" in f ? "userSelect" : "MozUserSelect" in f ? "MozUserSelect" : "WebkitUserSelect" in f ? "WebkitUserSelect" : "KhtmlUserSelect" in f ? "KhtmlUserSelect" : "", v.util.makeElementUnselectable = function(h) {
      return h.onselectstart !== void 0 && (h.onselectstart = v.util.falseFunction), i ? h.style[i] = "none" : typeof h.unselectable == "string" && (h.unselectable = "on"), h;
    }, v.util.makeElementSelectable = function(h) {
      return h.onselectstart !== void 0 && (h.onselectstart = null), i ? h.style[i] = "" : typeof h.unselectable == "string" && (h.unselectable = ""), h;
    }, v.util.setImageSmoothing = function(h, d) {
      h.imageSmoothingEnabled = h.imageSmoothingEnabled || h.webkitImageSmoothingEnabled || h.mozImageSmoothingEnabled || h.msImageSmoothingEnabled || h.oImageSmoothingEnabled, h.imageSmoothingEnabled = d;
    }, v.util.getById = function(h) {
      return typeof h == "string" ? v.document.getElementById(h) : h;
    }, v.util.toArray = r, v.util.addClass = function(h, d) {
      h && (" " + h.className + " ").indexOf(" " + d + " ") === -1 && (h.className += (h.className ? " " : "") + d);
    }, v.util.makeElement = s, v.util.wrapElement = function(h, d, m) {
      return typeof d == "string" && (d = s(d, m)), h.parentNode && h.parentNode.replaceChild(d, h), d.appendChild(h), d;
    }, v.util.getScrollLeftTop = u, v.util.getElementOffset = function(h) {
      var d, m, y = h && h.ownerDocument, b = { left: 0, top: 0 }, S = { left: 0, top: 0 }, E = { borderLeftWidth: "left", borderTopWidth: "top", paddingLeft: "left", paddingTop: "top" };
      if (!y) return S;
      for (var A in E) S[E[A]] += parseInt(l(h, A), 10) || 0;
      return d = y.documentElement, h.getBoundingClientRect !== void 0 && (b = h.getBoundingClientRect()), m = u(h), { left: b.left + m.left - (d.clientLeft || 0) + S.left, top: b.top + m.top - (d.clientTop || 0) + S.top };
    }, v.util.getNodeCanvas = function(h) {
      var d = v.jsdomImplForWrapper(h);
      return d._canvas || d._image;
    }, v.util.cleanUpJsdomNode = function(h) {
      if (v.isLikelyNode) {
        var d = v.jsdomImplForWrapper(h);
        d && (d._image = null, d._canvas = null, d._currentSrc = null, d._attributes = null, d._classList = null);
      }
    };
  }(), function() {
    function c() {
    }
    v.util.request = function(o, l) {
      l || (l = {});
      var f = l.method ? l.method.toUpperCase() : "GET", i = l.onComplete || function() {
      }, r = new v.window.XMLHttpRequest(), s = l.body || l.parameters;
      return r.onreadystatechange = function() {
        r.readyState === 4 && (i(r), r.onreadystatechange = c);
      }, f === "GET" && (s = null, typeof l.parameters == "string" && (o = function(u, h) {
        return u + (/\?/.test(u) ? "&" : "?") + h;
      }(o, l.parameters))), r.open(f, o, !0), f !== "POST" && f !== "PUT" || r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), r.send(s), r;
    };
  }(), v.log = console.log, v.warn = console.warn, function() {
    function c() {
      return !1;
    }
    function o(r, s, u, h) {
      return -u * Math.cos(r / h * (Math.PI / 2)) + u + s;
    }
    var l = v.window.requestAnimationFrame || v.window.webkitRequestAnimationFrame || v.window.mozRequestAnimationFrame || v.window.oRequestAnimationFrame || v.window.msRequestAnimationFrame || function(r) {
      return v.window.setTimeout(r, 1e3 / 60);
    }, f = v.window.cancelAnimationFrame || v.window.clearTimeout;
    function i() {
      return l.apply(v.window, arguments);
    }
    v.util.animate = function(r) {
      var s = !1;
      return i(function(u) {
        r || (r = {});
        var h, d = u || +/* @__PURE__ */ new Date(), m = r.duration || 500, y = d + m, b = r.onChange || c, S = r.abort || c, E = r.onComplete || c, A = r.easing || o, M = "startValue" in r ? r.startValue : 0, C = "endValue" in r ? r.endValue : 100, O = r.byValue || C - M;
        r.onStart && r.onStart(), function N(z) {
          var W = (h = z || +/* @__PURE__ */ new Date()) > y ? m : h - d, F = W / m, k = A(W, M, O, m), B = Math.abs((k - M) / O);
          if (!s) {
            if (!S(k, B, F)) return h > y ? (b(C, 1, 1), void E(C, 1, 1)) : (b(k, B, F), void i(N));
            E(C, 1, 1);
          }
        }(d);
      }), function() {
        s = !0;
      };
    }, v.util.requestAnimFrame = i, v.util.cancelAnimFrame = function() {
      return f.apply(v.window, arguments);
    };
  }(), function() {
    function c(o, l, f) {
      var i = "rgba(" + parseInt(o[0] + f * (l[0] - o[0]), 10) + "," + parseInt(o[1] + f * (l[1] - o[1]), 10) + "," + parseInt(o[2] + f * (l[2] - o[2]), 10);
      return i += "," + (o && l ? parseFloat(o[3] + f * (l[3] - o[3])) : 1), i += ")";
    }
    v.util.animateColor = function(o, l, f, i) {
      var r = new v.Color(o).getSource(), s = new v.Color(l).getSource(), u = i.onComplete, h = i.onChange;
      return i = i || {}, v.util.animate(v.util.object.extend(i, { duration: f || 500, startValue: r, endValue: s, byValue: s, easing: function(d, m, y, b) {
        return c(m, y, i.colorEasing ? i.colorEasing(d, b) : 1 - Math.cos(d / b * (Math.PI / 2)));
      }, onComplete: function(d, m, y) {
        if (u) return u(c(s, s, 0), m, y);
      }, onChange: function(d, m, y) {
        if (h) {
          if (Array.isArray(d)) return h(c(d, d, 0), m, y);
          h(d, m, y);
        }
      } }));
    };
  }(), function() {
    function c(i, r, s, u) {
      return i < Math.abs(r) ? (i = r, u = s / 4) : u = r === 0 && i === 0 ? s / (2 * Math.PI) * Math.asin(1) : s / (2 * Math.PI) * Math.asin(r / i), { a: i, c: r, p: s, s: u };
    }
    function o(i, r, s) {
      return i.a * Math.pow(2, 10 * (r -= 1)) * Math.sin((r * s - i.s) * (2 * Math.PI) / i.p);
    }
    function l(i, r, s, u) {
      return s - f(u - i, 0, s, u) + r;
    }
    function f(i, r, s, u) {
      return (i /= u) < 1 / 2.75 ? s * (7.5625 * i * i) + r : i < 2 / 2.75 ? s * (7.5625 * (i -= 1.5 / 2.75) * i + 0.75) + r : i < 2.5 / 2.75 ? s * (7.5625 * (i -= 2.25 / 2.75) * i + 0.9375) + r : s * (7.5625 * (i -= 2.625 / 2.75) * i + 0.984375) + r;
    }
    v.util.ease = { easeInQuad: function(i, r, s, u) {
      return s * (i /= u) * i + r;
    }, easeOutQuad: function(i, r, s, u) {
      return -s * (i /= u) * (i - 2) + r;
    }, easeInOutQuad: function(i, r, s, u) {
      return (i /= u / 2) < 1 ? s / 2 * i * i + r : -s / 2 * (--i * (i - 2) - 1) + r;
    }, easeInCubic: function(i, r, s, u) {
      return s * (i /= u) * i * i + r;
    }, easeOutCubic: function(i, r, s, u) {
      return s * ((i = i / u - 1) * i * i + 1) + r;
    }, easeInOutCubic: function(i, r, s, u) {
      return (i /= u / 2) < 1 ? s / 2 * i * i * i + r : s / 2 * ((i -= 2) * i * i + 2) + r;
    }, easeInQuart: function(i, r, s, u) {
      return s * (i /= u) * i * i * i + r;
    }, easeOutQuart: function(i, r, s, u) {
      return -s * ((i = i / u - 1) * i * i * i - 1) + r;
    }, easeInOutQuart: function(i, r, s, u) {
      return (i /= u / 2) < 1 ? s / 2 * i * i * i * i + r : -s / 2 * ((i -= 2) * i * i * i - 2) + r;
    }, easeInQuint: function(i, r, s, u) {
      return s * (i /= u) * i * i * i * i + r;
    }, easeOutQuint: function(i, r, s, u) {
      return s * ((i = i / u - 1) * i * i * i * i + 1) + r;
    }, easeInOutQuint: function(i, r, s, u) {
      return (i /= u / 2) < 1 ? s / 2 * i * i * i * i * i + r : s / 2 * ((i -= 2) * i * i * i * i + 2) + r;
    }, easeInSine: function(i, r, s, u) {
      return -s * Math.cos(i / u * (Math.PI / 2)) + s + r;
    }, easeOutSine: function(i, r, s, u) {
      return s * Math.sin(i / u * (Math.PI / 2)) + r;
    }, easeInOutSine: function(i, r, s, u) {
      return -s / 2 * (Math.cos(Math.PI * i / u) - 1) + r;
    }, easeInExpo: function(i, r, s, u) {
      return i === 0 ? r : s * Math.pow(2, 10 * (i / u - 1)) + r;
    }, easeOutExpo: function(i, r, s, u) {
      return i === u ? r + s : s * (1 - Math.pow(2, -10 * i / u)) + r;
    }, easeInOutExpo: function(i, r, s, u) {
      return i === 0 ? r : i === u ? r + s : (i /= u / 2) < 1 ? s / 2 * Math.pow(2, 10 * (i - 1)) + r : s / 2 * (2 - Math.pow(2, -10 * --i)) + r;
    }, easeInCirc: function(i, r, s, u) {
      return -s * (Math.sqrt(1 - (i /= u) * i) - 1) + r;
    }, easeOutCirc: function(i, r, s, u) {
      return s * Math.sqrt(1 - (i = i / u - 1) * i) + r;
    }, easeInOutCirc: function(i, r, s, u) {
      return (i /= u / 2) < 1 ? -s / 2 * (Math.sqrt(1 - i * i) - 1) + r : s / 2 * (Math.sqrt(1 - (i -= 2) * i) + 1) + r;
    }, easeInElastic: function(i, r, s, u) {
      var h = 0;
      return i === 0 ? r : (i /= u) === 1 ? r + s : (h || (h = 0.3 * u), -o(c(s, s, h, 1.70158), i, u) + r);
    }, easeOutElastic: function(i, r, s, u) {
      var h = 0;
      if (i === 0) return r;
      if ((i /= u) === 1) return r + s;
      h || (h = 0.3 * u);
      var d = c(s, s, h, 1.70158);
      return d.a * Math.pow(2, -10 * i) * Math.sin((i * u - d.s) * (2 * Math.PI) / d.p) + d.c + r;
    }, easeInOutElastic: function(i, r, s, u) {
      var h = 0;
      if (i === 0) return r;
      if ((i /= u / 2) === 2) return r + s;
      h || (h = u * (0.3 * 1.5));
      var d = c(s, s, h, 1.70158);
      return i < 1 ? -0.5 * o(d, i, u) + r : d.a * Math.pow(2, -10 * (i -= 1)) * Math.sin((i * u - d.s) * (2 * Math.PI) / d.p) * 0.5 + d.c + r;
    }, easeInBack: function(i, r, s, u, h) {
      return h === void 0 && (h = 1.70158), s * (i /= u) * i * ((h + 1) * i - h) + r;
    }, easeOutBack: function(i, r, s, u, h) {
      return h === void 0 && (h = 1.70158), s * ((i = i / u - 1) * i * ((h + 1) * i + h) + 1) + r;
    }, easeInOutBack: function(i, r, s, u, h) {
      return h === void 0 && (h = 1.70158), (i /= u / 2) < 1 ? s / 2 * (i * i * ((1 + (h *= 1.525)) * i - h)) + r : s / 2 * ((i -= 2) * i * ((1 + (h *= 1.525)) * i + h) + 2) + r;
    }, easeInBounce: l, easeOutBounce: f, easeInOutBounce: function(i, r, s, u) {
      return i < u / 2 ? 0.5 * l(2 * i, 0, s, u) + r : 0.5 * f(2 * i - u, 0, s, u) + 0.5 * s + r;
    } };
  }(), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.util.object.clone, i = o.util.toFixed, r = o.util.parseUnit, s = o.util.multiplyTransformMatrices, u = { cx: "left", x: "left", r: "radius", cy: "top", y: "top", display: "visible", visibility: "visible", transform: "transformMatrix", "fill-opacity": "fillOpacity", "fill-rule": "fillRule", "font-family": "fontFamily", "font-size": "fontSize", "font-style": "fontStyle", "font-weight": "fontWeight", "letter-spacing": "charSpacing", "paint-order": "paintFirst", "stroke-dasharray": "strokeDashArray", "stroke-dashoffset": "strokeDashOffset", "stroke-linecap": "strokeLineCap", "stroke-linejoin": "strokeLineJoin", "stroke-miterlimit": "strokeMiterLimit", "stroke-opacity": "strokeOpacity", "stroke-width": "strokeWidth", "text-decoration": "textDecoration", "text-anchor": "textAnchor", opacity: "opacity", "clip-path": "clipPath", "clip-rule": "clipRule", "vector-effect": "strokeUniform", "image-rendering": "imageSmoothing" }, h = { stroke: "strokeOpacity", fill: "fillOpacity" }, d = "font-size", m = "clip-path";
    function y(F) {
      return F in u ? u[F] : F;
    }
    function b(F, k, B, Z) {
      var K, U = Object.prototype.toString.call(k) === "[object Array]";
      if (F !== "fill" && F !== "stroke" || k !== "none") {
        if (F === "strokeUniform") return k === "non-scaling-stroke";
        if (F === "strokeDashArray") k = k === "none" ? null : k.replace(/,/g, " ").split(/\s+/).map(parseFloat);
        else if (F === "transformMatrix") k = B && B.transformMatrix ? s(B.transformMatrix, o.parseTransformAttribute(k)) : o.parseTransformAttribute(k);
        else if (F === "visible") k = k !== "none" && k !== "hidden", B && B.visible === !1 && (k = !1);
        else if (F === "opacity") k = parseFloat(k), B && B.opacity !== void 0 && (k *= B.opacity);
        else if (F === "textAnchor") k = k === "start" ? "left" : k === "end" ? "right" : "center";
        else if (F === "charSpacing") K = r(k, Z) / Z * 1e3;
        else if (F === "paintFirst") {
          var R = k.indexOf("fill"), H = k.indexOf("stroke");
          k = "fill", (R > -1 && H > -1 && H < R || R === -1 && H > -1) && (k = "stroke");
        } else {
          if (F === "href" || F === "xlink:href" || F === "font") return k;
          if (F === "imageSmoothing") return k === "optimizeQuality";
          K = U ? k.map(r) : r(k, Z);
        }
      } else k = "";
      return !U && isNaN(K) ? k : K;
    }
    function S(F) {
      return new RegExp("^(" + F.join("|") + ")\\b", "i");
    }
    function E(F, k) {
      var B, Z, K, U, R = [];
      for (K = 0, U = k.length; K < U; K++) B = k[K], Z = F.getElementsByTagName(B), R = R.concat(Array.prototype.slice.call(Z));
      return R;
    }
    function A(F, k) {
      var B, Z = !0;
      return (B = M(F, k.pop())) && k.length && (Z = function(K, U) {
        for (var R, H = !0; K.parentNode && K.parentNode.nodeType === 1 && U.length; ) H && (R = U.pop()), H = M(K = K.parentNode, R);
        return U.length === 0;
      }(F, k)), B && Z && k.length === 0;
    }
    function M(F, k) {
      var B, Z, K = F.nodeName, U = F.getAttribute("class"), R = F.getAttribute("id");
      if (B = new RegExp("^" + K, "i"), k = k.replace(B, ""), R && k.length && (B = new RegExp("#" + R + "(?![a-zA-Z\\-]+)", "i"), k = k.replace(B, "")), U && k.length) for (Z = (U = U.split(" ")).length; Z--; ) B = new RegExp("\\." + U[Z] + "(?![a-zA-Z\\-]+)", "i"), k = k.replace(B, "");
      return k.length === 0;
    }
    function C(F, k) {
      var B;
      if (F.getElementById && (B = F.getElementById(k)), B) return B;
      var Z, K, U, R = F.getElementsByTagName("*");
      for (K = 0, U = R.length; K < U; K++) if (k === (Z = R[K]).getAttribute("id")) return Z;
    }
    o.svgValidTagNamesRegEx = S(["path", "circle", "polygon", "polyline", "ellipse", "rect", "line", "image", "text"]), o.svgViewBoxElementsRegEx = S(["symbol", "image", "marker", "pattern", "view", "svg"]), o.svgInvalidAncestorsRegEx = S(["pattern", "defs", "symbol", "metadata", "clipPath", "mask", "desc"]), o.svgValidParentsRegEx = S(["symbol", "g", "a", "svg", "clipPath", "defs"]), o.cssRules = {}, o.gradientDefs = {}, o.clipPaths = {}, o.parseTransformAttribute = function() {
      function F(H, q, Q) {
        H[Q] = Math.tan(o.util.degreesToRadians(q[0]));
      }
      var k = o.iMatrix, B = o.reNum, Z = o.commaWsp, K = "(?:" + ("(?:(matrix)\\s*\\(\\s*(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")" + Z + "(" + B + ")\\s*\\))") + "|" + ("(?:(translate)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(scale)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(rotate)\\s*\\(\\s*(" + B + ")(?:" + Z + "(" + B + ")" + Z + "(" + B + "))?\\s*\\))") + "|" + ("(?:(skewX)\\s*\\(\\s*(" + B + ")\\s*\\))") + "|" + ("(?:(skewY)\\s*\\(\\s*(" + B + ")\\s*\\))") + ")", U = new RegExp("^\\s*(?:" + ("(?:" + K + "(?:" + Z + "*" + K + ")*)") + "?)\\s*$"), R = new RegExp(K, "g");
      return function(H) {
        var q = k.concat(), Q = [];
        if (!H || H && !U.test(H)) return q;
        H.replace(R, function(gt) {
          var ct = new RegExp(K).exec(gt).filter(function(lt) {
            return !!lt;
          }), ft = ct[1], st = ct.slice(2).map(parseFloat);
          switch (ft) {
            case "translate":
              (function(lt, at) {
                lt[4] = at[0], at.length === 2 && (lt[5] = at[1]);
              })(q, st);
              break;
            case "rotate":
              st[0] = o.util.degreesToRadians(st[0]), function(lt, at) {
                var yt = o.util.cos(at[0]), mt = o.util.sin(at[0]), Mt = 0, Ot = 0;
                at.length === 3 && (Mt = at[1], Ot = at[2]), lt[0] = yt, lt[1] = mt, lt[2] = -mt, lt[3] = yt, lt[4] = Mt - (yt * Mt - mt * Ot), lt[5] = Ot - (mt * Mt + yt * Ot);
              }(q, st);
              break;
            case "scale":
              (function(lt, at) {
                var yt = at[0], mt = at.length === 2 ? at[1] : at[0];
                lt[0] = yt, lt[3] = mt;
              })(q, st);
              break;
            case "skewX":
              F(q, st, 2);
              break;
            case "skewY":
              F(q, st, 1);
              break;
            case "matrix":
              q = st;
          }
          Q.push(q.concat()), q = k.concat();
        });
        for (var nt = Q[0]; Q.length > 1; ) Q.shift(), nt = o.util.multiplyTransformMatrices(nt, Q[0]);
        return nt;
      };
    }();
    var O = new RegExp("^\\s*(" + o.reNum + "+)\\s*,?\\s*(" + o.reNum + "+)\\s*,?\\s*(" + o.reNum + "+)\\s*,?\\s*(" + o.reNum + "+)\\s*$");
    function N(F) {
      if (!o.svgViewBoxElementsRegEx.test(F.nodeName)) return {};
      var k, B, Z, K, U, R, H = F.getAttribute("viewBox"), q = 1, Q = 1, nt = F.getAttribute("width"), gt = F.getAttribute("height"), ct = F.getAttribute("x") || 0, ft = F.getAttribute("y") || 0, st = F.getAttribute("preserveAspectRatio") || "", lt = !H || !(H = H.match(O)), at = !nt || !gt || nt === "100%" || gt === "100%", yt = lt && at, mt = {}, Mt = "", Ot = 0, Lt = 0;
      if (mt.width = 0, mt.height = 0, mt.toBeParsed = yt, lt && (ct || ft) && F.parentNode && F.parentNode.nodeName !== "#document" && (Mt = " translate(" + r(ct) + " " + r(ft) + ") ", U = (F.getAttribute("transform") || "") + Mt, F.setAttribute("transform", U), F.removeAttribute("x"), F.removeAttribute("y")), yt) return mt;
      if (lt) return mt.width = r(nt), mt.height = r(gt), mt;
      if (k = -parseFloat(H[1]), B = -parseFloat(H[2]), Z = parseFloat(H[3]), K = parseFloat(H[4]), mt.minX = k, mt.minY = B, mt.viewBoxWidth = Z, mt.viewBoxHeight = K, at ? (mt.width = Z, mt.height = K) : (mt.width = r(nt), mt.height = r(gt), q = mt.width / Z, Q = mt.height / K), (st = o.util.parsePreserveAspectRatioAttribute(st)).alignX !== "none" && (st.meetOrSlice === "meet" && (Q = q = q > Q ? Q : q), st.meetOrSlice === "slice" && (Q = q = q > Q ? q : Q), Ot = mt.width - Z * q, Lt = mt.height - K * q, st.alignX === "Mid" && (Ot /= 2), st.alignY === "Mid" && (Lt /= 2), st.alignX === "Min" && (Ot = 0), st.alignY === "Min" && (Lt = 0)), q === 1 && Q === 1 && k === 0 && B === 0 && ct === 0 && ft === 0) return mt;
      if ((ct || ft) && F.parentNode.nodeName !== "#document" && (Mt = " translate(" + r(ct) + " " + r(ft) + ") "), U = Mt + " matrix(" + q + " 0 0 " + Q + " " + (k * q + Ot) + " " + (B * Q + Lt) + ") ", F.nodeName === "svg") {
        for (R = F.ownerDocument.createElementNS(o.svgNS, "g"); F.firstChild; ) R.appendChild(F.firstChild);
        F.appendChild(R);
      } else (R = F).removeAttribute("x"), R.removeAttribute("y"), U = R.getAttribute("transform") + U;
      return R.setAttribute("transform", U), mt;
    }
    function z(F, k) {
      var B = "xlink:href", Z = C(F, k.getAttribute(B).substr(1));
      if (Z && Z.getAttribute(B) && z(F, Z), ["gradientTransform", "x1", "x2", "y1", "y2", "gradientUnits", "cx", "cy", "r", "fx", "fy"].forEach(function(U) {
        Z && !k.hasAttribute(U) && Z.hasAttribute(U) && k.setAttribute(U, Z.getAttribute(U));
      }), !k.children.length) for (var K = Z.cloneNode(!0); K.firstChild; ) k.appendChild(K.firstChild);
      k.removeAttribute(B);
    }
    o.parseSVGDocument = function(F, k, B, Z) {
      if (F) {
        (function(ct) {
          for (var ft = E(ct, ["use", "svg:use"]), st = 0; ft.length && st < ft.length; ) {
            var lt = ft[st], at = lt.getAttribute("xlink:href") || lt.getAttribute("href");
            if (at === null) return;
            var yt, mt, Mt, Ot, Lt = at.substr(1), re = lt.getAttribute("x") || 0, Ut = lt.getAttribute("y") || 0, Ft = C(ct, Lt).cloneNode(!0), oe = (Ft.getAttribute("transform") || "") + " translate(" + re + ", " + Ut + ")", Rt = ft.length, te = o.svgNS;
            if (N(Ft), /^svg$/i.test(Ft.nodeName)) {
              var hi = Ft.ownerDocument.createElementNS(te, "g");
              for (mt = 0, Ot = (Mt = Ft.attributes).length; mt < Ot; mt++) yt = Mt.item(mt), hi.setAttributeNS(te, yt.nodeName, yt.nodeValue);
              for (; Ft.firstChild; ) hi.appendChild(Ft.firstChild);
              Ft = hi;
            }
            for (mt = 0, Ot = (Mt = lt.attributes).length; mt < Ot; mt++) (yt = Mt.item(mt)).nodeName !== "x" && yt.nodeName !== "y" && yt.nodeName !== "xlink:href" && yt.nodeName !== "href" && (yt.nodeName === "transform" ? oe = yt.nodeValue + " " + oe : Ft.setAttribute(yt.nodeName, yt.nodeValue));
            Ft.setAttribute("transform", oe), Ft.setAttribute("instantiated_by_use", "1"), Ft.removeAttribute("id"), lt.parentNode.replaceChild(Ft, lt), ft.length === Rt && st++;
          }
        })(F);
        var K, U, R = o.Object.__uid++, H = N(F), q = o.util.toArray(F.getElementsByTagName("*"));
        if (H.crossOrigin = Z && Z.crossOrigin, H.svgUid = R, q.length === 0 && o.isLikelyNode) {
          var Q = [];
          for (K = 0, U = (q = F.selectNodes('//*[name(.)!="svg"]')).length; K < U; K++) Q[K] = q[K];
          q = Q;
        }
        var nt = q.filter(function(ct) {
          return N(ct), o.svgValidTagNamesRegEx.test(ct.nodeName.replace("svg:", "")) && !function(ft, st) {
            for (; ft && (ft = ft.parentNode); ) if (ft.nodeName && st.test(ft.nodeName.replace("svg:", "")) && !ft.getAttribute("instantiated_by_use")) return !0;
            return !1;
          }(ct, o.svgInvalidAncestorsRegEx);
        });
        if (!nt || nt && !nt.length) k && k([], {});
        else {
          var gt = {};
          q.filter(function(ct) {
            return ct.nodeName.replace("svg:", "") === "clipPath";
          }).forEach(function(ct) {
            var ft = ct.getAttribute("id");
            gt[ft] = o.util.toArray(ct.getElementsByTagName("*")).filter(function(st) {
              return o.svgValidTagNamesRegEx.test(st.nodeName.replace("svg:", ""));
            });
          }), o.gradientDefs[R] = o.getGradientDefs(F), o.cssRules[R] = o.getCSSRules(F), o.clipPaths[R] = gt, o.parseElements(nt, function(ct, ft) {
            k && (k(ct, H, ft, q), delete o.gradientDefs[R], delete o.cssRules[R], delete o.clipPaths[R]);
          }, f(H), B, Z);
        }
      }
    };
    var W = new RegExp("(normal|italic)?\\s*(normal|small-caps)?\\s*(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)?\\s*(" + o.reNum + "(?:px|cm|mm|em|pt|pc|in)*)(?:\\/(normal|" + o.reNum + "))?\\s+(.*)");
    l(o, { parseFontDeclaration: function(F, k) {
      var B = F.match(W);
      if (B) {
        var Z = B[1], K = B[3], U = B[4], R = B[5], H = B[6];
        Z && (k.fontStyle = Z), K && (k.fontWeight = isNaN(parseFloat(K)) ? K : parseFloat(K)), U && (k.fontSize = r(U)), H && (k.fontFamily = H), R && (k.lineHeight = R === "normal" ? 1 : R);
      }
    }, getGradientDefs: function(F) {
      var k, B = E(F, ["linearGradient", "radialGradient", "svg:linearGradient", "svg:radialGradient"]), Z = 0, K = {};
      for (Z = B.length; Z--; ) (k = B[Z]).getAttribute("xlink:href") && z(F, k), K[k.getAttribute("id")] = k;
      return K;
    }, parseAttributes: function(F, k, B) {
      if (F) {
        var Z, K, U, R = {};
        B === void 0 && (B = F.getAttribute("svgUid")), F.parentNode && o.svgValidParentsRegEx.test(F.parentNode.nodeName) && (R = o.parseAttributes(F.parentNode, k, B));
        var H = k.reduce(function(st, lt) {
          return (Z = F.getAttribute(lt)) && (st[lt] = Z), st;
        }, {}), q = l(function(st, lt) {
          var at = {};
          for (var yt in o.cssRules[lt]) if (A(st, yt.split(" "))) for (var mt in o.cssRules[lt][yt]) at[mt] = o.cssRules[lt][yt][mt];
          return at;
        }(F, B), o.parseStyleAttribute(F));
        H = l(H, q), q[m] && F.setAttribute(m, q[m]), K = U = R.fontSize || o.Text.DEFAULT_SVG_FONT_SIZE, H[d] && (H[d] = K = r(H[d], U));
        var Q, nt, gt = {};
        for (var ct in H) nt = b(Q = y(ct), H[ct], R, K), gt[Q] = nt;
        gt && gt.font && o.parseFontDeclaration(gt.font, gt);
        var ft = l(R, gt);
        return o.svgValidParentsRegEx.test(F.nodeName) ? ft : function(st) {
          for (var lt in h) if (st[h[lt]] !== void 0 && st[lt] !== "") {
            if (st[lt] === void 0) {
              if (!o.Object.prototype[lt]) continue;
              st[lt] = o.Object.prototype[lt];
            }
            if (st[lt].indexOf("url(") !== 0) {
              var at = new o.Color(st[lt]);
              st[lt] = at.setAlpha(i(at.getAlpha() * st[h[lt]], 2)).toRgba();
            }
          }
          return st;
        }(ft);
      }
    }, parseElements: function(F, k, B, Z, K) {
      new o.ElementsParser(F, k, B, Z, K).parse();
    }, parseStyleAttribute: function(F) {
      var k = {}, B = F.getAttribute("style");
      return B && (typeof B == "string" ? function(Z, K) {
        var U, R;
        Z.replace(/;\s*$/, "").split(";").forEach(function(H) {
          var q = H.split(":");
          U = q[0].trim().toLowerCase(), R = q[1].trim(), K[U] = R;
        });
      }(B, k) : function(Z, K) {
        var U, R;
        for (var H in Z) Z[H] !== void 0 && (U = H.toLowerCase(), R = Z[H], K[U] = R);
      }(B, k)), k;
    }, parsePointsAttribute: function(F) {
      if (!F) return null;
      var k, B, Z = [];
      for (k = 0, B = (F = (F = F.replace(/,/g, " ").trim()).split(/\s+/)).length; k < B; k += 2) Z.push({ x: parseFloat(F[k]), y: parseFloat(F[k + 1]) });
      return Z;
    }, getCSSRules: function(F) {
      var k, B, Z = F.getElementsByTagName("style"), K = {};
      for (k = 0, B = Z.length; k < B; k++) {
        var U = Z[k].textContent;
        (U = U.replace(/\/\*[\s\S]*?\*\//g, "")).trim() !== "" && U.match(/[^{]*\{[\s\S]*?\}/g).map(function(R) {
          return R.trim();
        }).forEach(function(R) {
          var H = R.match(/([\s\S]*?)\s*\{([^}]*)\}/), q = {}, Q = H[2].trim().replace(/;$/, "").split(/\s*;\s*/);
          for (k = 0, B = Q.length; k < B; k++) {
            var nt = Q[k].split(/\s*:\s*/), gt = nt[0], ct = nt[1];
            q[gt] = ct;
          }
          (R = H[1]).split(",").forEach(function(ft) {
            (ft = ft.replace(/^svg/i, "").trim()) !== "" && (K[ft] ? o.util.object.extend(K[ft], q) : K[ft] = o.util.object.clone(q));
          });
        });
      }
      return K;
    }, loadSVGFromURL: function(F, k, B, Z) {
      F = F.replace(/^\n\s*/, "").trim(), new o.util.request(F, { method: "get", onComplete: function(K) {
        var U = K.responseXML;
        if (!U || !U.documentElement) return k && k(null), !1;
        o.parseSVGDocument(U.documentElement, function(R, H, q, Q) {
          k && k(R, H, q, Q);
        }, B, Z);
      } });
    }, loadSVGFromString: function(F, k, B, Z) {
      var K = new o.window.DOMParser().parseFromString(F.trim(), "text/xml");
      o.parseSVGDocument(K.documentElement, function(U, R, H, q) {
        k(U, R, H, q);
      }, B, Z);
    } });
  }(t), v.ElementsParser = function(c, o, l, f, i, r) {
    this.elements = c, this.callback = o, this.options = l, this.reviver = f, this.svgUid = l && l.svgUid || 0, this.parsingOptions = i, this.regexUrl = /^url\(['"]?#([^'"]+)['"]?\)/g, this.doc = r;
  }, (Y = v.ElementsParser.prototype).parse = function() {
    this.instances = new Array(this.elements.length), this.numElements = this.elements.length, this.createObjects();
  }, Y.createObjects = function() {
    var c = this;
    this.elements.forEach(function(o, l) {
      o.setAttribute("svgUid", c.svgUid), c.createObject(o, l);
    });
  }, Y.findTag = function(c) {
    return v[v.util.string.capitalize(c.tagName.replace("svg:", ""))];
  }, Y.createObject = function(c, o) {
    var l = this.findTag(c);
    if (l && l.fromElement) try {
      l.fromElement(c, this.createCallback(o, c), this.options);
    } catch (f) {
      v.log(f);
    }
    else this.checkIfDone();
  }, Y.createCallback = function(c, o) {
    var l = this;
    return function(f) {
      var i;
      l.resolveGradient(f, o, "fill"), l.resolveGradient(f, o, "stroke"), f instanceof v.Image && f._originalElement && (i = f.parsePreserveAspectRatioAttribute(o)), f._removeTransformMatrix(i), l.resolveClipPath(f, o), l.reviver && l.reviver(o, f), l.instances[c] = f, l.checkIfDone();
    };
  }, Y.extractPropertyDefinition = function(c, o, l) {
    var f = c[o], i = this.regexUrl;
    if (i.test(f)) {
      i.lastIndex = 0;
      var r = i.exec(f)[1];
      return i.lastIndex = 0, v[l][this.svgUid][r];
    }
  }, Y.resolveGradient = function(c, o, l) {
    var f = this.extractPropertyDefinition(c, l, "gradientDefs");
    if (f) {
      var i = o.getAttribute(l + "-opacity"), r = v.Gradient.fromElement(f, c, i, this.options);
      c.set(l, r);
    }
  }, Y.createClipPathCallback = function(c, o) {
    return function(l) {
      l._removeTransformMatrix(), l.fillRule = l.clipRule, o.push(l);
    };
  }, Y.resolveClipPath = function(c, o) {
    var l, f, i, r, s = this.extractPropertyDefinition(c, "clipPath", "clipPaths");
    if (s) {
      i = [], f = v.util.invertTransform(c.calcTransformMatrix());
      for (var u = s[0].parentNode, h = o; h.parentNode && h.getAttribute("clip-path") !== c.clipPath; ) h = h.parentNode;
      h.parentNode.appendChild(u);
      for (var d = 0; d < s.length; d++) l = s[d], this.findTag(l).fromElement(l, this.createClipPathCallback(c, i), this.options);
      s = i.length === 1 ? i[0] : new v.Group(i), r = v.util.multiplyTransformMatrices(f, s.calcTransformMatrix()), s.clipPath && this.resolveClipPath(s, h);
      var m = v.util.qrDecompose(r);
      s.flipX = !1, s.flipY = !1, s.set("scaleX", m.scaleX), s.set("scaleY", m.scaleY), s.angle = m.angle, s.skewX = m.skewX, s.skewY = 0, s.setPositionByOrigin({ x: m.translateX, y: m.translateY }, "center", "center"), c.clipPath = s;
    } else delete c.clipPath;
  }, Y.checkIfDone = function() {
    --this.numElements == 0 && (this.instances = this.instances.filter(function(c) {
      return c != null;
    }), this.callback(this.instances, this.elements));
  }, function(c) {
    var o = c.fabric || (c.fabric = {});
    function l(f, i) {
      this.x = f, this.y = i;
    }
    o.Point ? o.warn("fabric.Point is already defined") : (o.Point = l, l.prototype = { type: "point", constructor: l, add: function(f) {
      return new l(this.x + f.x, this.y + f.y);
    }, addEquals: function(f) {
      return this.x += f.x, this.y += f.y, this;
    }, scalarAdd: function(f) {
      return new l(this.x + f, this.y + f);
    }, scalarAddEquals: function(f) {
      return this.x += f, this.y += f, this;
    }, subtract: function(f) {
      return new l(this.x - f.x, this.y - f.y);
    }, subtractEquals: function(f) {
      return this.x -= f.x, this.y -= f.y, this;
    }, scalarSubtract: function(f) {
      return new l(this.x - f, this.y - f);
    }, scalarSubtractEquals: function(f) {
      return this.x -= f, this.y -= f, this;
    }, multiply: function(f) {
      return new l(this.x * f, this.y * f);
    }, multiplyEquals: function(f) {
      return this.x *= f, this.y *= f, this;
    }, divide: function(f) {
      return new l(this.x / f, this.y / f);
    }, divideEquals: function(f) {
      return this.x /= f, this.y /= f, this;
    }, eq: function(f) {
      return this.x === f.x && this.y === f.y;
    }, lt: function(f) {
      return this.x < f.x && this.y < f.y;
    }, lte: function(f) {
      return this.x <= f.x && this.y <= f.y;
    }, gt: function(f) {
      return this.x > f.x && this.y > f.y;
    }, gte: function(f) {
      return this.x >= f.x && this.y >= f.y;
    }, lerp: function(f, i) {
      return i === void 0 && (i = 0.5), i = Math.max(Math.min(1, i), 0), new l(this.x + (f.x - this.x) * i, this.y + (f.y - this.y) * i);
    }, distanceFrom: function(f) {
      var i = this.x - f.x, r = this.y - f.y;
      return Math.sqrt(i * i + r * r);
    }, midPointFrom: function(f) {
      return this.lerp(f);
    }, min: function(f) {
      return new l(Math.min(this.x, f.x), Math.min(this.y, f.y));
    }, max: function(f) {
      return new l(Math.max(this.x, f.x), Math.max(this.y, f.y));
    }, toString: function() {
      return this.x + "," + this.y;
    }, setXY: function(f, i) {
      return this.x = f, this.y = i, this;
    }, setX: function(f) {
      return this.x = f, this;
    }, setY: function(f) {
      return this.y = f, this;
    }, setFromPoint: function(f) {
      return this.x = f.x, this.y = f.y, this;
    }, swap: function(f) {
      var i = this.x, r = this.y;
      this.x = f.x, this.y = f.y, f.x = i, f.y = r;
    }, clone: function() {
      return new l(this.x, this.y);
    } });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    function l(f) {
      this.status = f, this.points = [];
    }
    o.Intersection ? o.warn("fabric.Intersection is already defined") : (o.Intersection = l, o.Intersection.prototype = { constructor: l, appendPoint: function(f) {
      return this.points.push(f), this;
    }, appendPoints: function(f) {
      return this.points = this.points.concat(f), this;
    } }, o.Intersection.intersectLineLine = function(f, i, r, s) {
      var u, h = (s.x - r.x) * (f.y - r.y) - (s.y - r.y) * (f.x - r.x), d = (i.x - f.x) * (f.y - r.y) - (i.y - f.y) * (f.x - r.x), m = (s.y - r.y) * (i.x - f.x) - (s.x - r.x) * (i.y - f.y);
      if (m !== 0) {
        var y = h / m, b = d / m;
        0 <= y && y <= 1 && 0 <= b && b <= 1 ? (u = new l("Intersection")).appendPoint(new o.Point(f.x + y * (i.x - f.x), f.y + y * (i.y - f.y))) : u = new l();
      } else u = new l(h === 0 || d === 0 ? "Coincident" : "Parallel");
      return u;
    }, o.Intersection.intersectLinePolygon = function(f, i, r) {
      var s, u, h, d, m = new l(), y = r.length;
      for (d = 0; d < y; d++) s = r[d], u = r[(d + 1) % y], h = l.intersectLineLine(f, i, s, u), m.appendPoints(h.points);
      return m.points.length > 0 && (m.status = "Intersection"), m;
    }, o.Intersection.intersectPolygonPolygon = function(f, i) {
      var r, s = new l(), u = f.length;
      for (r = 0; r < u; r++) {
        var h = f[r], d = f[(r + 1) % u], m = l.intersectLinePolygon(h, d, i);
        s.appendPoints(m.points);
      }
      return s.points.length > 0 && (s.status = "Intersection"), s;
    }, o.Intersection.intersectPolygonRectangle = function(f, i, r) {
      var s = i.min(r), u = i.max(r), h = new o.Point(u.x, s.y), d = new o.Point(s.x, u.y), m = l.intersectLinePolygon(s, h, f), y = l.intersectLinePolygon(h, u, f), b = l.intersectLinePolygon(u, d, f), S = l.intersectLinePolygon(d, s, f), E = new l();
      return E.appendPoints(m.points), E.appendPoints(y.points), E.appendPoints(b.points), E.appendPoints(S.points), E.points.length > 0 && (E.status = "Intersection"), E;
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    function l(i) {
      i ? this._tryParsingColor(i) : this.setSource([0, 0, 0, 1]);
    }
    function f(i, r, s) {
      return s < 0 && (s += 1), s > 1 && (s -= 1), s < 1 / 6 ? i + 6 * (r - i) * s : s < 0.5 ? r : s < 2 / 3 ? i + (r - i) * (2 / 3 - s) * 6 : i;
    }
    o.Color ? o.warn("fabric.Color is already defined.") : (o.Color = l, o.Color.prototype = { _tryParsingColor: function(i) {
      var r;
      i in l.colorNameMap && (i = l.colorNameMap[i]), i === "transparent" && (r = [255, 255, 255, 0]), r || (r = l.sourceFromHex(i)), r || (r = l.sourceFromRgb(i)), r || (r = l.sourceFromHsl(i)), r || (r = [0, 0, 0, 1]), r && this.setSource(r);
    }, _rgbToHsl: function(i, r, s) {
      i /= 255, r /= 255, s /= 255;
      var u, h, d, m = o.util.array.max([i, r, s]), y = o.util.array.min([i, r, s]);
      if (d = (m + y) / 2, m === y) u = h = 0;
      else {
        var b = m - y;
        switch (h = d > 0.5 ? b / (2 - m - y) : b / (m + y), m) {
          case i:
            u = (r - s) / b + (r < s ? 6 : 0);
            break;
          case r:
            u = (s - i) / b + 2;
            break;
          case s:
            u = (i - r) / b + 4;
        }
        u /= 6;
      }
      return [Math.round(360 * u), Math.round(100 * h), Math.round(100 * d)];
    }, getSource: function() {
      return this._source;
    }, setSource: function(i) {
      this._source = i;
    }, toRgb: function() {
      var i = this.getSource();
      return "rgb(" + i[0] + "," + i[1] + "," + i[2] + ")";
    }, toRgba: function() {
      var i = this.getSource();
      return "rgba(" + i[0] + "," + i[1] + "," + i[2] + "," + i[3] + ")";
    }, toHsl: function() {
      var i = this.getSource(), r = this._rgbToHsl(i[0], i[1], i[2]);
      return "hsl(" + r[0] + "," + r[1] + "%," + r[2] + "%)";
    }, toHsla: function() {
      var i = this.getSource(), r = this._rgbToHsl(i[0], i[1], i[2]);
      return "hsla(" + r[0] + "," + r[1] + "%," + r[2] + "%," + i[3] + ")";
    }, toHex: function() {
      var i, r, s, u = this.getSource();
      return i = (i = u[0].toString(16)).length === 1 ? "0" + i : i, r = (r = u[1].toString(16)).length === 1 ? "0" + r : r, s = (s = u[2].toString(16)).length === 1 ? "0" + s : s, i.toUpperCase() + r.toUpperCase() + s.toUpperCase();
    }, toHexa: function() {
      var i, r = this.getSource();
      return i = (i = (i = Math.round(255 * r[3])).toString(16)).length === 1 ? "0" + i : i, this.toHex() + i.toUpperCase();
    }, getAlpha: function() {
      return this.getSource()[3];
    }, setAlpha: function(i) {
      var r = this.getSource();
      return r[3] = i, this.setSource(r), this;
    }, toGrayscale: function() {
      var i = this.getSource(), r = parseInt((0.3 * i[0] + 0.59 * i[1] + 0.11 * i[2]).toFixed(0), 10), s = i[3];
      return this.setSource([r, r, r, s]), this;
    }, toBlackWhite: function(i) {
      var r = this.getSource(), s = (0.3 * r[0] + 0.59 * r[1] + 0.11 * r[2]).toFixed(0), u = r[3];
      return i = i || 127, s = Number(s) < Number(i) ? 0 : 255, this.setSource([s, s, s, u]), this;
    }, overlayWith: function(i) {
      i instanceof l || (i = new l(i));
      var r, s = [], u = this.getAlpha(), h = this.getSource(), d = i.getSource();
      for (r = 0; r < 3; r++) s.push(Math.round(0.5 * h[r] + 0.5 * d[r]));
      return s[3] = u, this.setSource(s), this;
    } }, o.Color.reRGBa = /^rgba?\(\s*(\d{1,3}(?:\.\d+)?\%?)\s*,\s*(\d{1,3}(?:\.\d+)?\%?)\s*,\s*(\d{1,3}(?:\.\d+)?\%?)\s*(?:\s*,\s*((?:\d*\.?\d+)?)\s*)?\)$/i, o.Color.reHSLa = /^hsla?\(\s*(\d{1,3})\s*,\s*(\d{1,3}\%)\s*,\s*(\d{1,3}\%)\s*(?:\s*,\s*(\d+(?:\.\d+)?)\s*)?\)$/i, o.Color.reHex = /^#?([0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})$/i, o.Color.colorNameMap = { aliceblue: "#F0F8FF", antiquewhite: "#FAEBD7", aqua: "#00FFFF", aquamarine: "#7FFFD4", azure: "#F0FFFF", beige: "#F5F5DC", bisque: "#FFE4C4", black: "#000000", blanchedalmond: "#FFEBCD", blue: "#0000FF", blueviolet: "#8A2BE2", brown: "#A52A2A", burlywood: "#DEB887", cadetblue: "#5F9EA0", chartreuse: "#7FFF00", chocolate: "#D2691E", coral: "#FF7F50", cornflowerblue: "#6495ED", cornsilk: "#FFF8DC", crimson: "#DC143C", cyan: "#00FFFF", darkblue: "#00008B", darkcyan: "#008B8B", darkgoldenrod: "#B8860B", darkgray: "#A9A9A9", darkgrey: "#A9A9A9", darkgreen: "#006400", darkkhaki: "#BDB76B", darkmagenta: "#8B008B", darkolivegreen: "#556B2F", darkorange: "#FF8C00", darkorchid: "#9932CC", darkred: "#8B0000", darksalmon: "#E9967A", darkseagreen: "#8FBC8F", darkslateblue: "#483D8B", darkslategray: "#2F4F4F", darkslategrey: "#2F4F4F", darkturquoise: "#00CED1", darkviolet: "#9400D3", deeppink: "#FF1493", deepskyblue: "#00BFFF", dimgray: "#696969", dimgrey: "#696969", dodgerblue: "#1E90FF", firebrick: "#B22222", floralwhite: "#FFFAF0", forestgreen: "#228B22", fuchsia: "#FF00FF", gainsboro: "#DCDCDC", ghostwhite: "#F8F8FF", gold: "#FFD700", goldenrod: "#DAA520", gray: "#808080", grey: "#808080", green: "#008000", greenyellow: "#ADFF2F", honeydew: "#F0FFF0", hotpink: "#FF69B4", indianred: "#CD5C5C", indigo: "#4B0082", ivory: "#FFFFF0", khaki: "#F0E68C", lavender: "#E6E6FA", lavenderblush: "#FFF0F5", lawngreen: "#7CFC00", lemonchiffon: "#FFFACD", lightblue: "#ADD8E6", lightcoral: "#F08080", lightcyan: "#E0FFFF", lightgoldenrodyellow: "#FAFAD2", lightgray: "#D3D3D3", lightgrey: "#D3D3D3", lightgreen: "#90EE90", lightpink: "#FFB6C1", lightsalmon: "#FFA07A", lightseagreen: "#20B2AA", lightskyblue: "#87CEFA", lightslategray: "#778899", lightslategrey: "#778899", lightsteelblue: "#B0C4DE", lightyellow: "#FFFFE0", lime: "#00FF00", limegreen: "#32CD32", linen: "#FAF0E6", magenta: "#FF00FF", maroon: "#800000", mediumaquamarine: "#66CDAA", mediumblue: "#0000CD", mediumorchid: "#BA55D3", mediumpurple: "#9370DB", mediumseagreen: "#3CB371", mediumslateblue: "#7B68EE", mediumspringgreen: "#00FA9A", mediumturquoise: "#48D1CC", mediumvioletred: "#C71585", midnightblue: "#191970", mintcream: "#F5FFFA", mistyrose: "#FFE4E1", moccasin: "#FFE4B5", navajowhite: "#FFDEAD", navy: "#000080", oldlace: "#FDF5E6", olive: "#808000", olivedrab: "#6B8E23", orange: "#FFA500", orangered: "#FF4500", orchid: "#DA70D6", palegoldenrod: "#EEE8AA", palegreen: "#98FB98", paleturquoise: "#AFEEEE", palevioletred: "#DB7093", papayawhip: "#FFEFD5", peachpuff: "#FFDAB9", peru: "#CD853F", pink: "#FFC0CB", plum: "#DDA0DD", powderblue: "#B0E0E6", purple: "#800080", rebeccapurple: "#663399", red: "#FF0000", rosybrown: "#BC8F8F", royalblue: "#4169E1", saddlebrown: "#8B4513", salmon: "#FA8072", sandybrown: "#F4A460", seagreen: "#2E8B57", seashell: "#FFF5EE", sienna: "#A0522D", silver: "#C0C0C0", skyblue: "#87CEEB", slateblue: "#6A5ACD", slategray: "#708090", slategrey: "#708090", snow: "#FFFAFA", springgreen: "#00FF7F", steelblue: "#4682B4", tan: "#D2B48C", teal: "#008080", thistle: "#D8BFD8", tomato: "#FF6347", turquoise: "#40E0D0", violet: "#EE82EE", wheat: "#F5DEB3", white: "#FFFFFF", whitesmoke: "#F5F5F5", yellow: "#FFFF00", yellowgreen: "#9ACD32" }, o.Color.fromRgb = function(i) {
      return l.fromSource(l.sourceFromRgb(i));
    }, o.Color.sourceFromRgb = function(i) {
      var r = i.match(l.reRGBa);
      if (r) {
        var s = parseInt(r[1], 10) / (/%$/.test(r[1]) ? 100 : 1) * (/%$/.test(r[1]) ? 255 : 1), u = parseInt(r[2], 10) / (/%$/.test(r[2]) ? 100 : 1) * (/%$/.test(r[2]) ? 255 : 1), h = parseInt(r[3], 10) / (/%$/.test(r[3]) ? 100 : 1) * (/%$/.test(r[3]) ? 255 : 1);
        return [parseInt(s, 10), parseInt(u, 10), parseInt(h, 10), r[4] ? parseFloat(r[4]) : 1];
      }
    }, o.Color.fromRgba = l.fromRgb, o.Color.fromHsl = function(i) {
      return l.fromSource(l.sourceFromHsl(i));
    }, o.Color.sourceFromHsl = function(i) {
      var r = i.match(l.reHSLa);
      if (r) {
        var s, u, h, d = (parseFloat(r[1]) % 360 + 360) % 360 / 360, m = parseFloat(r[2]) / (/%$/.test(r[2]) ? 100 : 1), y = parseFloat(r[3]) / (/%$/.test(r[3]) ? 100 : 1);
        if (m === 0) s = u = h = y;
        else {
          var b = y <= 0.5 ? y * (m + 1) : y + m - y * m, S = 2 * y - b;
          s = f(S, b, d + 1 / 3), u = f(S, b, d), h = f(S, b, d - 1 / 3);
        }
        return [Math.round(255 * s), Math.round(255 * u), Math.round(255 * h), r[4] ? parseFloat(r[4]) : 1];
      }
    }, o.Color.fromHsla = l.fromHsl, o.Color.fromHex = function(i) {
      return l.fromSource(l.sourceFromHex(i));
    }, o.Color.sourceFromHex = function(i) {
      if (i.match(l.reHex)) {
        var r = i.slice(i.indexOf("#") + 1), s = r.length === 3 || r.length === 4, u = r.length === 8 || r.length === 4, h = s ? r.charAt(0) + r.charAt(0) : r.substring(0, 2), d = s ? r.charAt(1) + r.charAt(1) : r.substring(2, 4), m = s ? r.charAt(2) + r.charAt(2) : r.substring(4, 6), y = u ? s ? r.charAt(3) + r.charAt(3) : r.substring(6, 8) : "FF";
        return [parseInt(h, 16), parseInt(d, 16), parseInt(m, 16), parseFloat((parseInt(y, 16) / 255).toFixed(2))];
      }
    }, o.Color.fromSource = function(i) {
      var r = new l();
      return r.setSource(i), r;
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = ["e", "se", "s", "sw", "w", "nw", "n", "ne", "e"], f = ["ns", "nesw", "ew", "nwse"], i = {}, r = "left", s = "top", u = "right", h = "bottom", d = "center", m = { top: h, bottom: s, left: u, right: r, center: d }, y = o.util.radiansToDegrees, b = Math.sign || function(U) {
      return (U > 0) - (U < 0) || +U;
    };
    function S(U, R) {
      var H = U.angle + y(Math.atan2(R.y, R.x)) + 360;
      return Math.round(H % 360 / 45);
    }
    function E(U, R) {
      var H = R.transform.target, q = H.canvas, Q = o.util.object.clone(R);
      Q.target = H, q && q.fire("object:" + U, Q), H.fire(U, R);
    }
    function A(U, R) {
      var H = R.canvas, q = U[H.uniScaleKey];
      return H.uniformScaling && !q || !H.uniformScaling && q;
    }
    function M(U) {
      return U.originX === d && U.originY === d;
    }
    function C(U, R, H) {
      var q = U.lockScalingX, Q = U.lockScalingY;
      return !(!q || !Q) || !(R || !q && !Q || !H) || !(!q || R !== "x") || !(!Q || R !== "y");
    }
    function O(U, R, H, q) {
      return { e: U, transform: R, pointer: { x: H, y: q } };
    }
    function N(U) {
      return function(R, H, q, Q) {
        var nt = H.target, gt = nt.getCenterPoint(), ct = nt.translateToOriginPoint(gt, H.originX, H.originY), ft = U(R, H, q, Q);
        return nt.setPositionByOrigin(ct, H.originX, H.originY), ft;
      };
    }
    function z(U, R) {
      return function(H, q, Q, nt) {
        var gt = R(H, q, Q, nt);
        return gt && E(U, O(H, q, Q, nt)), gt;
      };
    }
    function W(U, R, H, q, Q) {
      var nt = U.target, gt = nt.controls[U.corner], ct = nt.canvas.getZoom(), ft = nt.padding / ct, st = nt.toLocalPoint(new o.Point(q, Q), R, H);
      return st.x >= ft && (st.x -= ft), st.x <= -ft && (st.x += ft), st.y >= ft && (st.y -= ft), st.y <= ft && (st.y += ft), st.x -= gt.offsetX, st.y -= gt.offsetY, st;
    }
    function F(U) {
      return U.flipX !== U.flipY;
    }
    function k(U, R, H, q, Q) {
      if (U[R] !== 0) {
        var nt = Q / U._getTransformedDimensions()[q] * U[H];
        U.set(H, nt);
      }
    }
    function B(U, R, H, q) {
      var Q, nt = R.target, gt = nt._getTransformedDimensions(0, nt.skewY), ct = W(R, R.originX, R.originY, H, q), ft = Math.abs(2 * ct.x) - gt.x, st = nt.skewX;
      ft < 2 ? Q = 0 : (Q = y(Math.atan2(ft / nt.scaleX, gt.y / nt.scaleY)), R.originX === r && R.originY === h && (Q = -Q), R.originX === u && R.originY === s && (Q = -Q), F(nt) && (Q = -Q));
      var lt = st !== Q;
      if (lt) {
        var at = nt._getTransformedDimensions().y;
        nt.set("skewX", Q), k(nt, "skewY", "scaleY", "y", at);
      }
      return lt;
    }
    function Z(U, R, H, q) {
      var Q, nt = R.target, gt = nt._getTransformedDimensions(nt.skewX, 0), ct = W(R, R.originX, R.originY, H, q), ft = Math.abs(2 * ct.y) - gt.y, st = nt.skewY;
      ft < 2 ? Q = 0 : (Q = y(Math.atan2(ft / nt.scaleY, gt.x / nt.scaleX)), R.originX === r && R.originY === h && (Q = -Q), R.originX === u && R.originY === s && (Q = -Q), F(nt) && (Q = -Q));
      var lt = st !== Q;
      if (lt) {
        var at = nt._getTransformedDimensions().x;
        nt.set("skewY", Q), k(nt, "skewX", "scaleX", "x", at);
      }
      return lt;
    }
    function K(U, R, H, q, Q) {
      Q = Q || {};
      var nt, gt, ct, ft, st, lt, at = R.target, yt = at.lockScalingX, mt = at.lockScalingY, Mt = Q.by, Ot = A(U, at), Lt = C(at, Mt, Ot), re = R.gestureScale;
      if (Lt) return !1;
      if (re) gt = R.scaleX * re, ct = R.scaleY * re;
      else {
        if (nt = W(R, R.originX, R.originY, H, q), st = Mt !== "y" ? b(nt.x) : 1, lt = Mt !== "x" ? b(nt.y) : 1, R.signX || (R.signX = st), R.signY || (R.signY = lt), at.lockScalingFlip && (R.signX !== st || R.signY !== lt)) return !1;
        if (ft = at._getTransformedDimensions(), Ot && !Mt) {
          var Ut = Math.abs(nt.x) + Math.abs(nt.y), Ft = R.original, oe = Ut / (Math.abs(ft.x * Ft.scaleX / at.scaleX) + Math.abs(ft.y * Ft.scaleY / at.scaleY));
          gt = Ft.scaleX * oe, ct = Ft.scaleY * oe;
        } else gt = Math.abs(nt.x * at.scaleX / ft.x), ct = Math.abs(nt.y * at.scaleY / ft.y);
        M(R) && (gt *= 2, ct *= 2), R.signX !== st && Mt !== "y" && (R.originX = m[R.originX], gt *= -1, R.signX = st), R.signY !== lt && Mt !== "x" && (R.originY = m[R.originY], ct *= -1, R.signY = lt);
      }
      var Rt = at.scaleX, te = at.scaleY;
      return Mt ? (Mt === "x" && at.set("scaleX", gt), Mt === "y" && at.set("scaleY", ct)) : (!yt && at.set("scaleX", gt), !mt && at.set("scaleY", ct)), Rt !== at.scaleX || te !== at.scaleY;
    }
    i.scaleCursorStyleHandler = function(U, R, H) {
      var q = A(U, H), Q = "";
      if (R.x !== 0 && R.y === 0 ? Q = "x" : R.x === 0 && R.y !== 0 && (Q = "y"), C(H, Q, q)) return "not-allowed";
      var nt = S(H, R);
      return l[nt] + "-resize";
    }, i.skewCursorStyleHandler = function(U, R, H) {
      var q = "not-allowed";
      if (R.x !== 0 && H.lockSkewingY || R.y !== 0 && H.lockSkewingX) return q;
      var Q = S(H, R) % 4;
      return f[Q] + "-resize";
    }, i.scaleSkewCursorStyleHandler = function(U, R, H) {
      return U[H.canvas.altActionKey] ? i.skewCursorStyleHandler(U, R, H) : i.scaleCursorStyleHandler(U, R, H);
    }, i.rotationWithSnapping = z("rotating", N(function(U, R, H, q) {
      var Q = R, nt = Q.target, gt = nt.translateToOriginPoint(nt.getCenterPoint(), Q.originX, Q.originY);
      if (nt.lockRotation) return !1;
      var ct, ft = Math.atan2(Q.ey - gt.y, Q.ex - gt.x), st = Math.atan2(q - gt.y, H - gt.x), lt = y(st - ft + Q.theta);
      if (nt.snapAngle > 0) {
        var at = nt.snapAngle, yt = nt.snapThreshold || at, mt = Math.ceil(lt / at) * at, Mt = Math.floor(lt / at) * at;
        Math.abs(lt - Mt) < yt ? lt = Mt : Math.abs(lt - mt) < yt && (lt = mt);
      }
      return lt < 0 && (lt = 360 + lt), lt %= 360, ct = nt.angle !== lt, nt.angle = lt, ct;
    })), i.scalingEqually = z("scaling", N(function(U, R, H, q) {
      return K(U, R, H, q);
    })), i.scalingX = z("scaling", N(function(U, R, H, q) {
      return K(U, R, H, q, { by: "x" });
    })), i.scalingY = z("scaling", N(function(U, R, H, q) {
      return K(U, R, H, q, { by: "y" });
    })), i.scalingYOrSkewingX = function(U, R, H, q) {
      return U[R.target.canvas.altActionKey] ? i.skewHandlerX(U, R, H, q) : i.scalingY(U, R, H, q);
    }, i.scalingXOrSkewingY = function(U, R, H, q) {
      return U[R.target.canvas.altActionKey] ? i.skewHandlerY(U, R, H, q) : i.scalingX(U, R, H, q);
    }, i.changeWidth = z("resizing", N(function(U, R, H, q) {
      var Q = R.target, nt = W(R, R.originX, R.originY, H, q), gt = Q.strokeWidth / (Q.strokeUniform ? Q.scaleX : 1), ct = M(R) ? 2 : 1, ft = Q.width, st = Math.abs(nt.x * ct / Q.scaleX) - gt;
      return Q.set("width", Math.max(st, 0)), ft !== st;
    })), i.skewHandlerX = function(U, R, H, q) {
      var Q, nt = R.target, gt = nt.skewX, ct = R.originY;
      return !nt.lockSkewingX && (gt === 0 ? Q = W(R, d, d, H, q).x > 0 ? r : u : (gt > 0 && (Q = ct === s ? r : u), gt < 0 && (Q = ct === s ? u : r), F(nt) && (Q = Q === r ? u : r)), R.originX = Q, z("skewing", N(B))(U, R, H, q));
    }, i.skewHandlerY = function(U, R, H, q) {
      var Q, nt = R.target, gt = nt.skewY, ct = R.originX;
      return !nt.lockSkewingY && (gt === 0 ? Q = W(R, d, d, H, q).y > 0 ? s : h : (gt > 0 && (Q = ct === r ? s : h), gt < 0 && (Q = ct === r ? h : s), F(nt) && (Q = Q === s ? h : s)), R.originY = Q, z("skewing", N(Z))(U, R, H, q));
    }, i.dragHandler = function(U, R, H, q) {
      var Q = R.target, nt = H - R.offsetX, gt = q - R.offsetY, ct = !Q.get("lockMovementX") && Q.left !== nt, ft = !Q.get("lockMovementY") && Q.top !== gt;
      return ct && Q.set("left", nt), ft && Q.set("top", gt), (ct || ft) && E("moving", O(U, R, H, q)), ct || ft;
    }, i.scaleOrSkewActionName = function(U, R, H) {
      var q = U[H.canvas.altActionKey];
      return R.x === 0 ? q ? "skewX" : "scaleY" : R.y === 0 ? q ? "skewY" : "scaleX" : void 0;
    }, i.rotationStyleHandler = function(U, R, H) {
      return H.lockRotation ? "not-allowed" : R.cursorStyle;
    }, i.fireEvent = E, i.wrapWithFixedAnchor = N, i.wrapWithFireEvent = z, i.getLocalPoint = W, o.controlsUtils = i;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.degreesToRadians, f = o.controlsUtils;
    f.renderCircleControl = function(i, r, s, u, h) {
      u = u || {};
      var d, m = this.sizeX || u.cornerSize || h.cornerSize, y = this.sizeY || u.cornerSize || h.cornerSize, b = u.transparentCorners !== void 0 ? u.transparentCorners : h.transparentCorners, S = b ? "stroke" : "fill", E = !b && (u.cornerStrokeColor || h.cornerStrokeColor), A = r, M = s;
      i.save(), i.fillStyle = u.cornerColor || h.cornerColor, i.strokeStyle = u.cornerStrokeColor || h.cornerStrokeColor, m > y ? (d = m, i.scale(1, y / m), M = s * m / y) : y > m ? (d = y, i.scale(m / y, 1), A = r * y / m) : d = m, i.lineWidth = 1, i.beginPath(), i.arc(A, M, d / 2, 0, 2 * Math.PI, !1), i[S](), E && i.stroke(), i.restore();
    }, f.renderSquareControl = function(i, r, s, u, h) {
      u = u || {};
      var d = this.sizeX || u.cornerSize || h.cornerSize, m = this.sizeY || u.cornerSize || h.cornerSize, y = u.transparentCorners !== void 0 ? u.transparentCorners : h.transparentCorners, b = y ? "stroke" : "fill", S = !y && (u.cornerStrokeColor || h.cornerStrokeColor), E = d / 2, A = m / 2;
      i.save(), i.fillStyle = u.cornerColor || h.cornerColor, i.strokeStyle = u.cornerStrokeColor || h.cornerStrokeColor, i.lineWidth = 1, i.translate(r, s), i.rotate(l(h.angle)), i[b + "Rect"](-E, -A, d, m), S && i.strokeRect(-E, -A, d, m), i.restore();
    };
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    o.Control = function(l) {
      for (var f in l) this[f] = l[f];
    }, o.Control.prototype = { visible: !0, actionName: "scale", angle: 0, x: 0, y: 0, offsetX: 0, offsetY: 0, sizeX: null, sizeY: null, touchSizeX: null, touchSizeY: null, cursorStyle: "crosshair", withConnection: !1, actionHandler: function() {
    }, mouseDownHandler: function() {
    }, mouseUpHandler: function() {
    }, getActionHandler: function() {
      return this.actionHandler;
    }, getMouseDownHandler: function() {
      return this.mouseDownHandler;
    }, getMouseUpHandler: function() {
      return this.mouseUpHandler;
    }, cursorStyleHandler: function(l, f) {
      return f.cursorStyle;
    }, getActionName: function(l, f) {
      return f.actionName;
    }, getVisibility: function(l, f) {
      var i = l._controlsVisibility;
      return i && i[f] !== void 0 ? i[f] : this.visible;
    }, setVisibility: function(l) {
      this.visible = l;
    }, positionHandler: function(l, f) {
      return o.util.transformPoint({ x: this.x * l.x + this.offsetX, y: this.y * l.y + this.offsetY }, f);
    }, calcCornerCoords: function(l, f, i, r, s) {
      var u, h, d, m, y = s ? this.touchSizeX : this.sizeX, b = s ? this.touchSizeY : this.sizeY;
      if (y && b && y !== b) {
        var S = Math.atan2(b, y), E = Math.sqrt(y * y + b * b) / 2, A = S - o.util.degreesToRadians(l), M = Math.PI / 2 - S - o.util.degreesToRadians(l);
        u = E * o.util.cos(A), h = E * o.util.sin(A), d = E * o.util.cos(M), m = E * o.util.sin(M);
      } else
        E = 0.7071067812 * (y && b ? y : f), A = o.util.degreesToRadians(45 - l), u = d = E * o.util.cos(A), h = m = E * o.util.sin(A);
      return { tl: { x: i - m, y: r - d }, tr: { x: i + u, y: r - h }, bl: { x: i - u, y: r + h }, br: { x: i + m, y: r + d } };
    }, render: function(l, f, i, r, s) {
      ((r = r || {}).cornerStyle || s.cornerStyle) === "circle" ? o.controlsUtils.renderCircleControl.call(this, l, f, i, r, s) : o.controlsUtils.renderSquareControl.call(this, l, f, i, r, s);
    } };
  }(t), function() {
    function c(l, f) {
      var i, r, s, u, h = l.getAttribute("style"), d = l.getAttribute("offset") || 0;
      if (d = (d = parseFloat(d) / (/%$/.test(d) ? 100 : 1)) < 0 ? 0 : d > 1 ? 1 : d, h) {
        var m = h.split(/\s*;\s*/);
        for (m[m.length - 1] === "" && m.pop(), u = m.length; u--; ) {
          var y = m[u].split(/\s*:\s*/), b = y[0].trim(), S = y[1].trim();
          b === "stop-color" ? i = S : b === "stop-opacity" && (s = S);
        }
      }
      return i || (i = l.getAttribute("stop-color") || "rgb(0,0,0)"), s || (s = l.getAttribute("stop-opacity")), r = (i = new v.Color(i)).getAlpha(), s = isNaN(parseFloat(s)) ? 1 : parseFloat(s), s *= r * f, { offset: d, color: i.toRgb(), opacity: s };
    }
    var o = v.util.object.clone;
    v.Gradient = v.util.createClass({ offsetX: 0, offsetY: 0, gradientTransform: null, gradientUnits: "pixels", type: "linear", initialize: function(l) {
      l || (l = {}), l.coords || (l.coords = {});
      var f, i = this;
      Object.keys(l).forEach(function(r) {
        i[r] = l[r];
      }), this.id ? this.id += "_" + v.Object.__uid++ : this.id = v.Object.__uid++, f = { x1: l.coords.x1 || 0, y1: l.coords.y1 || 0, x2: l.coords.x2 || 0, y2: l.coords.y2 || 0 }, this.type === "radial" && (f.r1 = l.coords.r1 || 0, f.r2 = l.coords.r2 || 0), this.coords = f, this.colorStops = l.colorStops.slice();
    }, addColorStop: function(l) {
      for (var f in l) {
        var i = new v.Color(l[f]);
        this.colorStops.push({ offset: parseFloat(f), color: i.toRgb(), opacity: i.getAlpha() });
      }
      return this;
    }, toObject: function(l) {
      var f = { type: this.type, coords: this.coords, colorStops: this.colorStops, offsetX: this.offsetX, offsetY: this.offsetY, gradientUnits: this.gradientUnits, gradientTransform: this.gradientTransform ? this.gradientTransform.concat() : this.gradientTransform };
      return v.util.populateWithProperties(this, f, l), f;
    }, toSVG: function(l, f) {
      var i, r, s, u, h = o(this.coords, !0), d = (f = f || {}, o(this.colorStops, !0)), m = h.r1 > h.r2, y = this.gradientTransform ? this.gradientTransform.concat() : v.iMatrix.concat(), b = -this.offsetX, S = -this.offsetY, E = !!f.additionalTransform, A = this.gradientUnits === "pixels" ? "userSpaceOnUse" : "objectBoundingBox";
      if (d.sort(function(N, z) {
        return N.offset - z.offset;
      }), A === "objectBoundingBox" ? (b /= l.width, S /= l.height) : (b += l.width / 2, S += l.height / 2), l.type === "path" && this.gradientUnits !== "percentage" && (b -= l.pathOffset.x, S -= l.pathOffset.y), y[4] -= b, y[5] -= S, u = 'id="SVGID_' + this.id + '" gradientUnits="' + A + '"', u += ' gradientTransform="' + (E ? f.additionalTransform + " " : "") + v.util.matrixToSVG(y) + '" ', this.type === "linear" ? s = ["<linearGradient ", u, ' x1="', h.x1, '" y1="', h.y1, '" x2="', h.x2, '" y2="', h.y2, `">
`] : this.type === "radial" && (s = ["<radialGradient ", u, ' cx="', m ? h.x1 : h.x2, '" cy="', m ? h.y1 : h.y2, '" r="', m ? h.r1 : h.r2, '" fx="', m ? h.x2 : h.x1, '" fy="', m ? h.y2 : h.y1, `">
`]), this.type === "radial") {
        if (m) for ((d = d.concat()).reverse(), i = 0, r = d.length; i < r; i++) d[i].offset = 1 - d[i].offset;
        var M = Math.min(h.r1, h.r2);
        if (M > 0) {
          var C = M / Math.max(h.r1, h.r2);
          for (i = 0, r = d.length; i < r; i++) d[i].offset += C * (1 - d[i].offset);
        }
      }
      for (i = 0, r = d.length; i < r; i++) {
        var O = d[i];
        s.push("<stop ", 'offset="', 100 * O.offset + "%", '" style="stop-color:', O.color, O.opacity !== void 0 ? ";stop-opacity: " + O.opacity : ";", `"/>
`);
      }
      return s.push(this.type === "linear" ? `</linearGradient>
` : `</radialGradient>
`), s.join("");
    }, toLive: function(l) {
      var f, i, r, s = v.util.object.clone(this.coords);
      if (this.type) {
        for (this.type === "linear" ? f = l.createLinearGradient(s.x1, s.y1, s.x2, s.y2) : this.type === "radial" && (f = l.createRadialGradient(s.x1, s.y1, s.r1, s.x2, s.y2, s.r2)), i = 0, r = this.colorStops.length; i < r; i++) {
          var u = this.colorStops[i].color, h = this.colorStops[i].opacity, d = this.colorStops[i].offset;
          h !== void 0 && (u = new v.Color(u).setAlpha(h).toRgba()), f.addColorStop(d, u);
        }
        return f;
      }
    } }), v.util.object.extend(v.Gradient, { fromElement: function(l, f, i, r) {
      var s = parseFloat(i) / (/%$/.test(i) ? 100 : 1);
      s = s < 0 ? 0 : s > 1 ? 1 : s, isNaN(s) && (s = 1);
      var u, h, d, m, y = l.getElementsByTagName("stop"), b = l.getAttribute("gradientUnits") === "userSpaceOnUse" ? "pixels" : "percentage", S = l.getAttribute("gradientTransform") || "", E = [], A = 0, M = 0;
      for (l.nodeName === "linearGradient" || l.nodeName === "LINEARGRADIENT" ? (u = "linear", h = function(C) {
        return { x1: C.getAttribute("x1") || 0, y1: C.getAttribute("y1") || 0, x2: C.getAttribute("x2") || "100%", y2: C.getAttribute("y2") || 0 };
      }(l)) : (u = "radial", h = function(C) {
        return { x1: C.getAttribute("fx") || C.getAttribute("cx") || "50%", y1: C.getAttribute("fy") || C.getAttribute("cy") || "50%", r1: 0, x2: C.getAttribute("cx") || "50%", y2: C.getAttribute("cy") || "50%", r2: C.getAttribute("r") || "50%" };
      }(l)), d = y.length; d--; ) E.push(c(y[d], s));
      return m = v.parseTransformAttribute(S), function(C, O, N, z) {
        var W, F;
        Object.keys(O).forEach(function(k) {
          (W = O[k]) === "Infinity" ? F = 1 : W === "-Infinity" ? F = 0 : (F = parseFloat(O[k], 10), typeof W == "string" && /^(\d+\.\d+)%|(\d+)%$/.test(W) && (F *= 0.01, z === "pixels" && (k !== "x1" && k !== "x2" && k !== "r2" || (F *= N.viewBoxWidth || N.width), k !== "y1" && k !== "y2" || (F *= N.viewBoxHeight || N.height)))), O[k] = F;
        });
      }(0, h, r, b), b === "pixels" && (A = -f.left, M = -f.top), new v.Gradient({ id: l.getAttribute("id"), type: u, coords: h, colorStops: E, gradientUnits: b, gradientTransform: m, offsetX: A, offsetY: M });
    } });
  }(), j = v.util.toFixed, v.Pattern = v.util.createClass({ repeat: "repeat", offsetX: 0, offsetY: 0, crossOrigin: "", patternTransform: null, initialize: function(c, o) {
    if (c || (c = {}), this.id = v.Object.__uid++, this.setOptions(c), !c.source || c.source && typeof c.source != "string") o && o(this);
    else {
      var l = this;
      this.source = v.util.createImage(), v.util.loadImage(c.source, function(f, i) {
        l.source = f, o && o(l, i);
      }, null, this.crossOrigin);
    }
  }, toObject: function(c) {
    var o, l, f = v.Object.NUM_FRACTION_DIGITS;
    return typeof this.source.src == "string" ? o = this.source.src : typeof this.source == "object" && this.source.toDataURL && (o = this.source.toDataURL()), l = { type: "pattern", source: o, repeat: this.repeat, crossOrigin: this.crossOrigin, offsetX: j(this.offsetX, f), offsetY: j(this.offsetY, f), patternTransform: this.patternTransform ? this.patternTransform.concat() : null }, v.util.populateWithProperties(this, l, c), l;
  }, toSVG: function(c) {
    var o = typeof this.source == "function" ? this.source() : this.source, l = o.width / c.width, f = o.height / c.height, i = this.offsetX / c.width, r = this.offsetY / c.height, s = "";
    return this.repeat !== "repeat-x" && this.repeat !== "no-repeat" || (f = 1, r && (f += Math.abs(r))), this.repeat !== "repeat-y" && this.repeat !== "no-repeat" || (l = 1, i && (l += Math.abs(i))), o.src ? s = o.src : o.toDataURL && (s = o.toDataURL()), '<pattern id="SVGID_' + this.id + '" x="' + i + '" y="' + r + '" width="' + l + '" height="' + f + `">
<image x="0" y="0" width="` + o.width + '" height="' + o.height + '" xlink:href="' + s + `"></image>
</pattern>
`;
  }, setOptions: function(c) {
    for (var o in c) this[o] = c[o];
  }, toLive: function(c) {
    var o = this.source;
    return !o || o.src !== void 0 && (!o.complete || o.naturalWidth === 0 || o.naturalHeight === 0) ? "" : c.createPattern(o, this.repeat);
  } }), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.toFixed;
    o.Shadow ? o.warn("fabric.Shadow is already defined.") : (o.Shadow = o.util.createClass({ color: "rgb(0,0,0)", blur: 0, offsetX: 0, offsetY: 0, affectStroke: !1, includeDefaultValues: !0, nonScaling: !1, initialize: function(f) {
      for (var i in typeof f == "string" && (f = this._parseShadow(f)), f) this[i] = f[i];
      this.id = o.Object.__uid++;
    }, _parseShadow: function(f) {
      var i = f.trim(), r = o.Shadow.reOffsetsAndBlur.exec(i) || [];
      return { color: (i.replace(o.Shadow.reOffsetsAndBlur, "") || "rgb(0,0,0)").trim(), offsetX: parseFloat(r[1], 10) || 0, offsetY: parseFloat(r[2], 10) || 0, blur: parseFloat(r[3], 10) || 0 };
    }, toString: function() {
      return [this.offsetX, this.offsetY, this.blur, this.color].join("px ");
    }, toSVG: function(f) {
      var i = 40, r = 40, s = o.Object.NUM_FRACTION_DIGITS, u = o.util.rotateVector({ x: this.offsetX, y: this.offsetY }, o.util.degreesToRadians(-f.angle)), h = new o.Color(this.color);
      return f.width && f.height && (i = 100 * l((Math.abs(u.x) + this.blur) / f.width, s) + 20, r = 100 * l((Math.abs(u.y) + this.blur) / f.height, s) + 20), f.flipX && (u.x *= -1), f.flipY && (u.y *= -1), '<filter id="SVGID_' + this.id + '" y="-' + r + '%" height="' + (100 + 2 * r) + '%" x="-' + i + '%" width="' + (100 + 2 * i) + `%" >
	<feGaussianBlur in="SourceAlpha" stdDeviation="` + l(this.blur ? this.blur / 2 : 0, s) + `"></feGaussianBlur>
	<feOffset dx="` + l(u.x, s) + '" dy="' + l(u.y, s) + `" result="oBlur" ></feOffset>
	<feFlood flood-color="` + h.toRgb() + '" flood-opacity="' + h.getAlpha() + `"/>
	<feComposite in2="oBlur" operator="in" />
	<feMerge>
		<feMergeNode></feMergeNode>
		<feMergeNode in="SourceGraphic"></feMergeNode>
	</feMerge>
</filter>
`;
    }, toObject: function() {
      if (this.includeDefaultValues) return { color: this.color, blur: this.blur, offsetX: this.offsetX, offsetY: this.offsetY, affectStroke: this.affectStroke, nonScaling: this.nonScaling };
      var f = {}, i = o.Shadow.prototype;
      return ["color", "blur", "offsetX", "offsetY", "affectStroke", "nonScaling"].forEach(function(r) {
        this[r] !== i[r] && (f[r] = this[r]);
      }, this), f;
    } }), o.Shadow.reOffsetsAndBlur = /(?:\s|^)(-?\d+(?:\.\d*)?(?:px)?(?:\s?|$))?(-?\d+(?:\.\d*)?(?:px)?(?:\s?|$))?(\d+(?:\.\d*)?(?:px)?)?(?:\s?|$)(?:$|\s)/);
  }(t), function() {
    if (v.StaticCanvas) v.warn("fabric.StaticCanvas is already defined.");
    else {
      var c = v.util.object.extend, o = v.util.getElementOffset, l = v.util.removeFromArray, f = v.util.toFixed, i = v.util.transformPoint, r = v.util.invertTransform, s = v.util.getNodeCanvas, u = v.util.createCanvasElement, h = new Error("Could not initialize `canvas` element");
      v.StaticCanvas = v.util.createClass(v.CommonMethods, { initialize: function(d, m) {
        m || (m = {}), this.renderAndResetBound = this.renderAndReset.bind(this), this.requestRenderAllBound = this.requestRenderAll.bind(this), this._initStatic(d, m);
      }, backgroundColor: "", backgroundImage: null, overlayColor: "", overlayImage: null, includeDefaultValues: !0, stateful: !1, renderOnAddRemove: !0, controlsAboveOverlay: !1, allowTouchScrolling: !1, imageSmoothingEnabled: !0, viewportTransform: v.iMatrix.concat(), backgroundVpt: !0, overlayVpt: !0, enableRetinaScaling: !0, vptCoords: {}, skipOffscreen: !0, clipPath: void 0, _initStatic: function(d, m) {
        var y = this.requestRenderAllBound;
        this._objects = [], this._createLowerCanvas(d), this._initOptions(m), this.interactive || this._initRetinaScaling(), m.overlayImage && this.setOverlayImage(m.overlayImage, y), m.backgroundImage && this.setBackgroundImage(m.backgroundImage, y), m.backgroundColor && this.setBackgroundColor(m.backgroundColor, y), m.overlayColor && this.setOverlayColor(m.overlayColor, y), this.calcOffset();
      }, _isRetinaScaling: function() {
        return v.devicePixelRatio !== 1 && this.enableRetinaScaling;
      }, getRetinaScaling: function() {
        return this._isRetinaScaling() ? v.devicePixelRatio : 1;
      }, _initRetinaScaling: function() {
        if (this._isRetinaScaling()) {
          var d = v.devicePixelRatio;
          this.__initRetinaScaling(d, this.lowerCanvasEl, this.contextContainer), this.upperCanvasEl && this.__initRetinaScaling(d, this.upperCanvasEl, this.contextTop);
        }
      }, __initRetinaScaling: function(d, m, y) {
        m.setAttribute("width", this.width * d), m.setAttribute("height", this.height * d), y.scale(d, d);
      }, calcOffset: function() {
        return this._offset = o(this.lowerCanvasEl), this;
      }, setOverlayImage: function(d, m, y) {
        return this.__setBgOverlayImage("overlayImage", d, m, y);
      }, setBackgroundImage: function(d, m, y) {
        return this.__setBgOverlayImage("backgroundImage", d, m, y);
      }, setOverlayColor: function(d, m) {
        return this.__setBgOverlayColor("overlayColor", d, m);
      }, setBackgroundColor: function(d, m) {
        return this.__setBgOverlayColor("backgroundColor", d, m);
      }, __setBgOverlayImage: function(d, m, y, b) {
        return typeof m == "string" ? v.util.loadImage(m, function(S, E) {
          if (S) {
            var A = new v.Image(S, b);
            this[d] = A, A.canvas = this;
          }
          y && y(S, E);
        }, this, b && b.crossOrigin) : (b && m.setOptions(b), this[d] = m, m && (m.canvas = this), y && y(m, !1)), this;
      }, __setBgOverlayColor: function(d, m, y) {
        return this[d] = m, this._initGradient(m, d), this._initPattern(m, d, y), this;
      }, _createCanvasElement: function() {
        var d = u();
        if (!d || (d.style || (d.style = {}), d.getContext === void 0)) throw h;
        return d;
      }, _initOptions: function(d) {
        var m = this.lowerCanvasEl;
        this._setOptions(d), this.width = this.width || parseInt(m.width, 10) || 0, this.height = this.height || parseInt(m.height, 10) || 0, this.lowerCanvasEl.style && (m.width = this.width, m.height = this.height, m.style.width = this.width + "px", m.style.height = this.height + "px", this.viewportTransform = this.viewportTransform.slice());
      }, _createLowerCanvas: function(d) {
        d && d.getContext ? this.lowerCanvasEl = d : this.lowerCanvasEl = v.util.getById(d) || this._createCanvasElement(), v.util.addClass(this.lowerCanvasEl, "lower-canvas"), this._originalCanvasStyle = this.lowerCanvasEl.style, this.interactive && this._applyCanvasStyle(this.lowerCanvasEl), this.contextContainer = this.lowerCanvasEl.getContext("2d");
      }, getWidth: function() {
        return this.width;
      }, getHeight: function() {
        return this.height;
      }, setWidth: function(d, m) {
        return this.setDimensions({ width: d }, m);
      }, setHeight: function(d, m) {
        return this.setDimensions({ height: d }, m);
      }, setDimensions: function(d, m) {
        var y;
        for (var b in m = m || {}, d) y = d[b], m.cssOnly || (this._setBackstoreDimension(b, d[b]), y += "px", this.hasLostContext = !0), m.backstoreOnly || this._setCssDimension(b, y);
        return this._isCurrentlyDrawing && this.freeDrawingBrush && this.freeDrawingBrush._setBrushStyles(), this._initRetinaScaling(), this.calcOffset(), m.cssOnly || this.requestRenderAll(), this;
      }, _setBackstoreDimension: function(d, m) {
        return this.lowerCanvasEl[d] = m, this.upperCanvasEl && (this.upperCanvasEl[d] = m), this.cacheCanvasEl && (this.cacheCanvasEl[d] = m), this[d] = m, this;
      }, _setCssDimension: function(d, m) {
        return this.lowerCanvasEl.style[d] = m, this.upperCanvasEl && (this.upperCanvasEl.style[d] = m), this.wrapperEl && (this.wrapperEl.style[d] = m), this;
      }, getZoom: function() {
        return this.viewportTransform[0];
      }, setViewportTransform: function(d) {
        var m, y, b, S = this._activeObject, E = this.backgroundImage, A = this.overlayImage;
        for (this.viewportTransform = d, y = 0, b = this._objects.length; y < b; y++) (m = this._objects[y]).group || m.setCoords(!0);
        return S && S.setCoords(), E && E.setCoords(!0), A && A.setCoords(!0), this.calcViewportBoundaries(), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, zoomToPoint: function(d, m) {
        var y = d, b = this.viewportTransform.slice(0);
        d = i(d, r(this.viewportTransform)), b[0] = m, b[3] = m;
        var S = i(d, b);
        return b[4] += y.x - S.x, b[5] += y.y - S.y, this.setViewportTransform(b);
      }, setZoom: function(d) {
        return this.zoomToPoint(new v.Point(0, 0), d), this;
      }, absolutePan: function(d) {
        var m = this.viewportTransform.slice(0);
        return m[4] = -d.x, m[5] = -d.y, this.setViewportTransform(m);
      }, relativePan: function(d) {
        return this.absolutePan(new v.Point(-d.x - this.viewportTransform[4], -d.y - this.viewportTransform[5]));
      }, getElement: function() {
        return this.lowerCanvasEl;
      }, _onObjectAdded: function(d) {
        this.stateful && d.setupState(), d._set("canvas", this), d.setCoords(), this.fire("object:added", { target: d }), d.fire("added");
      }, _onObjectRemoved: function(d) {
        this.fire("object:removed", { target: d }), d.fire("removed"), delete d.canvas;
      }, clearContext: function(d) {
        return d.clearRect(0, 0, this.width, this.height), this;
      }, getContext: function() {
        return this.contextContainer;
      }, clear: function() {
        return this.remove.apply(this, this.getObjects()), this.backgroundImage = null, this.overlayImage = null, this.backgroundColor = "", this.overlayColor = "", this._hasITextHandlers && (this.off("mouse:up", this._mouseUpITextHandler), this._iTextInstances = null, this._hasITextHandlers = !1), this.clearContext(this.contextContainer), this.fire("canvas:cleared"), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, renderAll: function() {
        var d = this.contextContainer;
        return this.renderCanvas(d, this._objects), this;
      }, renderAndReset: function() {
        this.isRendering = 0, this.renderAll();
      }, requestRenderAll: function() {
        return this.isRendering || (this.isRendering = v.util.requestAnimFrame(this.renderAndResetBound)), this;
      }, calcViewportBoundaries: function() {
        var d = {}, m = this.width, y = this.height, b = r(this.viewportTransform);
        return d.tl = i({ x: 0, y: 0 }, b), d.br = i({ x: m, y }, b), d.tr = new v.Point(d.br.x, d.tl.y), d.bl = new v.Point(d.tl.x, d.br.y), this.vptCoords = d, d;
      }, cancelRequestedRender: function() {
        this.isRendering && (v.util.cancelAnimFrame(this.isRendering), this.isRendering = 0);
      }, renderCanvas: function(d, m) {
        var y = this.viewportTransform, b = this.clipPath;
        this.cancelRequestedRender(), this.calcViewportBoundaries(), this.clearContext(d), v.util.setImageSmoothing(d, this.imageSmoothingEnabled), this.fire("before:render", { ctx: d }), this._renderBackground(d), d.save(), d.transform(y[0], y[1], y[2], y[3], y[4], y[5]), this._renderObjects(d, m), d.restore(), !this.controlsAboveOverlay && this.interactive && this.drawControls(d), b && (b.canvas = this, b.shouldCache(), b._transformDone = !0, b.renderCache({ forClipping: !0 }), this.drawClipPathOnCanvas(d)), this._renderOverlay(d), this.controlsAboveOverlay && this.interactive && this.drawControls(d), this.fire("after:render", { ctx: d });
      }, drawClipPathOnCanvas: function(d) {
        var m = this.viewportTransform, y = this.clipPath;
        d.save(), d.transform(m[0], m[1], m[2], m[3], m[4], m[5]), d.globalCompositeOperation = "destination-in", y.transform(d), d.scale(1 / y.zoomX, 1 / y.zoomY), d.drawImage(y._cacheCanvas, -y.cacheTranslationX, -y.cacheTranslationY), d.restore();
      }, _renderObjects: function(d, m) {
        var y, b;
        for (y = 0, b = m.length; y < b; ++y) m[y] && m[y].render(d);
      }, _renderBackgroundOrOverlay: function(d, m) {
        var y = this[m + "Color"], b = this[m + "Image"], S = this.viewportTransform, E = this[m + "Vpt"];
        if (y || b) {
          if (y) {
            d.save(), d.beginPath(), d.moveTo(0, 0), d.lineTo(this.width, 0), d.lineTo(this.width, this.height), d.lineTo(0, this.height), d.closePath(), d.fillStyle = y.toLive ? y.toLive(d, this) : y, E && d.transform(S[0], S[1], S[2], S[3], S[4], S[5]), d.transform(1, 0, 0, 1, y.offsetX || 0, y.offsetY || 0);
            var A = y.gradientTransform || y.patternTransform;
            A && d.transform(A[0], A[1], A[2], A[3], A[4], A[5]), d.fill(), d.restore();
          }
          b && (d.save(), E && d.transform(S[0], S[1], S[2], S[3], S[4], S[5]), b.render(d), d.restore());
        }
      }, _renderBackground: function(d) {
        this._renderBackgroundOrOverlay(d, "background");
      }, _renderOverlay: function(d) {
        this._renderBackgroundOrOverlay(d, "overlay");
      }, getCenter: function() {
        return { top: this.height / 2, left: this.width / 2 };
      }, centerObjectH: function(d) {
        return this._centerObject(d, new v.Point(this.getCenter().left, d.getCenterPoint().y));
      }, centerObjectV: function(d) {
        return this._centerObject(d, new v.Point(d.getCenterPoint().x, this.getCenter().top));
      }, centerObject: function(d) {
        var m = this.getCenter();
        return this._centerObject(d, new v.Point(m.left, m.top));
      }, viewportCenterObject: function(d) {
        var m = this.getVpCenter();
        return this._centerObject(d, m);
      }, viewportCenterObjectH: function(d) {
        var m = this.getVpCenter();
        return this._centerObject(d, new v.Point(m.x, d.getCenterPoint().y)), this;
      }, viewportCenterObjectV: function(d) {
        var m = this.getVpCenter();
        return this._centerObject(d, new v.Point(d.getCenterPoint().x, m.y));
      }, getVpCenter: function() {
        var d = this.getCenter(), m = r(this.viewportTransform);
        return i({ x: d.left, y: d.top }, m);
      }, _centerObject: function(d, m) {
        return d.setPositionByOrigin(m, "center", "center"), d.setCoords(), this.renderOnAddRemove && this.requestRenderAll(), this;
      }, toDatalessJSON: function(d) {
        return this.toDatalessObject(d);
      }, toObject: function(d) {
        return this._toObjectMethod("toObject", d);
      }, toDatalessObject: function(d) {
        return this._toObjectMethod("toDatalessObject", d);
      }, _toObjectMethod: function(d, m) {
        var y = this.clipPath, b = { version: v.version, objects: this._toObjects(d, m) };
        return y && !y.excludeFromExport && (b.clipPath = this._toObject(this.clipPath, d, m)), c(b, this.__serializeBgOverlay(d, m)), v.util.populateWithProperties(this, b, m), b;
      }, _toObjects: function(d, m) {
        return this._objects.filter(function(y) {
          return !y.excludeFromExport;
        }).map(function(y) {
          return this._toObject(y, d, m);
        }, this);
      }, _toObject: function(d, m, y) {
        var b;
        this.includeDefaultValues || (b = d.includeDefaultValues, d.includeDefaultValues = !1);
        var S = d[m](y);
        return this.includeDefaultValues || (d.includeDefaultValues = b), S;
      }, __serializeBgOverlay: function(d, m) {
        var y = {}, b = this.backgroundImage, S = this.overlayImage, E = this.backgroundColor, A = this.overlayColor;
        return E && E.toObject ? E.excludeFromExport || (y.background = E.toObject(m)) : E && (y.background = E), A && A.toObject ? A.excludeFromExport || (y.overlay = A.toObject(m)) : A && (y.overlay = A), b && !b.excludeFromExport && (y.backgroundImage = this._toObject(b, d, m)), S && !S.excludeFromExport && (y.overlayImage = this._toObject(S, d, m)), y;
      }, svgViewportTransformation: !0, toSVG: function(d, m) {
        d || (d = {}), d.reviver = m;
        var y = [];
        return this._setSVGPreamble(y, d), this._setSVGHeader(y, d), this.clipPath && y.push('<g clip-path="url(#' + this.clipPath.clipPathId + `)" >
`), this._setSVGBgOverlayColor(y, "background"), this._setSVGBgOverlayImage(y, "backgroundImage", m), this._setSVGObjects(y, m), this.clipPath && y.push(`</g>
`), this._setSVGBgOverlayColor(y, "overlay"), this._setSVGBgOverlayImage(y, "overlayImage", m), y.push("</svg>"), y.join("");
      }, _setSVGPreamble: function(d, m) {
        m.suppressPreamble || d.push('<?xml version="1.0" encoding="', m.encoding || "UTF-8", `" standalone="no" ?>
`, '<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" ', `"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
`);
      }, _setSVGHeader: function(d, m) {
        var y, b = m.width || this.width, S = m.height || this.height, E = 'viewBox="0 0 ' + this.width + " " + this.height + '" ', A = v.Object.NUM_FRACTION_DIGITS;
        m.viewBox ? E = 'viewBox="' + m.viewBox.x + " " + m.viewBox.y + " " + m.viewBox.width + " " + m.viewBox.height + '" ' : this.svgViewportTransformation && (y = this.viewportTransform, E = 'viewBox="' + f(-y[4] / y[0], A) + " " + f(-y[5] / y[3], A) + " " + f(this.width / y[0], A) + " " + f(this.height / y[3], A) + '" '), d.push("<svg ", 'xmlns="http://www.w3.org/2000/svg" ', 'xmlns:xlink="http://www.w3.org/1999/xlink" ', 'version="1.1" ', 'width="', b, '" ', 'height="', S, '" ', E, `xml:space="preserve">
`, "<desc>Created with Fabric.js ", v.version, `</desc>
`, `<defs>
`, this.createSVGFontFacesMarkup(), this.createSVGRefElementsMarkup(), this.createSVGClipPathMarkup(m), `</defs>
`);
      }, createSVGClipPathMarkup: function(d) {
        var m = this.clipPath;
        return m ? (m.clipPathId = "CLIPPATH_" + v.Object.__uid++, '<clipPath id="' + m.clipPathId + `" >
` + this.clipPath.toClipPathSVG(d.reviver) + `</clipPath>
`) : "";
      }, createSVGRefElementsMarkup: function() {
        var d = this;
        return ["background", "overlay"].map(function(m) {
          var y = d[m + "Color"];
          if (y && y.toLive) {
            var b = d[m + "Vpt"], S = d.viewportTransform, E = { width: d.width / (b ? S[0] : 1), height: d.height / (b ? S[3] : 1) };
            return y.toSVG(E, { additionalTransform: b ? v.util.matrixToSVG(S) : "" });
          }
        }).join("");
      }, createSVGFontFacesMarkup: function() {
        var d, m, y, b, S, E, A, M, C = "", O = {}, N = v.fontPaths, z = [];
        for (this._objects.forEach(function F(k) {
          z.push(k), k._objects && k._objects.forEach(F);
        }), A = 0, M = z.length; A < M; A++) if (m = (d = z[A]).fontFamily, d.type.indexOf("text") !== -1 && !O[m] && N[m] && (O[m] = !0, d.styles)) for (S in y = d.styles) for (E in b = y[S]) !O[m = b[E].fontFamily] && N[m] && (O[m] = !0);
        for (var W in O) C += [`		@font-face {
`, "			font-family: '", W, `';
`, "			src: url('", N[W], `');
`, `		}
`].join("");
        return C && (C = ['	<style type="text/css">', `<![CDATA[
`, C, "]]>", `</style>
`].join("")), C;
      }, _setSVGObjects: function(d, m) {
        var y, b, S, E = this._objects;
        for (b = 0, S = E.length; b < S; b++) (y = E[b]).excludeFromExport || this._setSVGObject(d, y, m);
      }, _setSVGObject: function(d, m, y) {
        d.push(m.toSVG(y));
      }, _setSVGBgOverlayImage: function(d, m, y) {
        this[m] && !this[m].excludeFromExport && this[m].toSVG && d.push(this[m].toSVG(y));
      }, _setSVGBgOverlayColor: function(d, m) {
        var y = this[m + "Color"], b = this.viewportTransform, S = this.width, E = this.height;
        if (y) if (y.toLive) {
          var A = y.repeat, M = v.util.invertTransform(b), C = this[m + "Vpt"] ? v.util.matrixToSVG(M) : "";
          d.push('<rect transform="' + C + " translate(", S / 2, ",", E / 2, ')"', ' x="', y.offsetX - S / 2, '" y="', y.offsetY - E / 2, '" ', 'width="', A === "repeat-y" || A === "no-repeat" ? y.source.width : S, '" height="', A === "repeat-x" || A === "no-repeat" ? y.source.height : E, '" fill="url(#SVGID_' + y.id + ')"', `></rect>
`);
        } else d.push('<rect x="0" y="0" width="100%" height="100%" ', 'fill="', y, '"', `></rect>
`);
      }, sendToBack: function(d) {
        if (!d) return this;
        var m, y, b, S = this._activeObject;
        if (d === S && d.type === "activeSelection") for (m = (b = S._objects).length; m--; ) y = b[m], l(this._objects, y), this._objects.unshift(y);
        else l(this._objects, d), this._objects.unshift(d);
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, bringToFront: function(d) {
        if (!d) return this;
        var m, y, b, S = this._activeObject;
        if (d === S && d.type === "activeSelection") for (b = S._objects, m = 0; m < b.length; m++) y = b[m], l(this._objects, y), this._objects.push(y);
        else l(this._objects, d), this._objects.push(d);
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, sendBackwards: function(d, m) {
        if (!d) return this;
        var y, b, S, E, A, M = this._activeObject, C = 0;
        if (d === M && d.type === "activeSelection") for (A = M._objects, y = 0; y < A.length; y++) b = A[y], (S = this._objects.indexOf(b)) > 0 + C && (E = S - 1, l(this._objects, b), this._objects.splice(E, 0, b)), C++;
        else (S = this._objects.indexOf(d)) !== 0 && (E = this._findNewLowerIndex(d, S, m), l(this._objects, d), this._objects.splice(E, 0, d));
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, _findNewLowerIndex: function(d, m, y) {
        var b, S;
        if (y) {
          for (b = m, S = m - 1; S >= 0; --S)
            if (d.intersectsWithObject(this._objects[S]) || d.isContainedWithinObject(this._objects[S]) || this._objects[S].isContainedWithinObject(d)) {
              b = S;
              break;
            }
        } else b = m - 1;
        return b;
      }, bringForward: function(d, m) {
        if (!d) return this;
        var y, b, S, E, A, M = this._activeObject, C = 0;
        if (d === M && d.type === "activeSelection") for (y = (A = M._objects).length; y--; ) b = A[y], (S = this._objects.indexOf(b)) < this._objects.length - 1 - C && (E = S + 1, l(this._objects, b), this._objects.splice(E, 0, b)), C++;
        else (S = this._objects.indexOf(d)) !== this._objects.length - 1 && (E = this._findNewUpperIndex(d, S, m), l(this._objects, d), this._objects.splice(E, 0, d));
        return this.renderOnAddRemove && this.requestRenderAll(), this;
      }, _findNewUpperIndex: function(d, m, y) {
        var b, S, E;
        if (y) {
          for (b = m, S = m + 1, E = this._objects.length; S < E; ++S)
            if (d.intersectsWithObject(this._objects[S]) || d.isContainedWithinObject(this._objects[S]) || this._objects[S].isContainedWithinObject(d)) {
              b = S;
              break;
            }
        } else b = m + 1;
        return b;
      }, moveTo: function(d, m) {
        return l(this._objects, d), this._objects.splice(m, 0, d), this.renderOnAddRemove && this.requestRenderAll();
      }, dispose: function() {
        return this.isRendering && (v.util.cancelAnimFrame(this.isRendering), this.isRendering = 0), this.forEachObject(function(d) {
          d.dispose && d.dispose();
        }), this._objects = [], this.backgroundImage && this.backgroundImage.dispose && this.backgroundImage.dispose(), this.backgroundImage = null, this.overlayImage && this.overlayImage.dispose && this.overlayImage.dispose(), this.overlayImage = null, this._iTextInstances = null, this.contextContainer = null, this.lowerCanvasEl.classList.remove("lower-canvas"), this.lowerCanvasEl.style = this._originalCanvasStyle, delete this._originalCanvasStyle, this.lowerCanvasEl.setAttribute("width", this.width), this.lowerCanvasEl.setAttribute("height", this.height), v.util.cleanUpJsdomNode(this.lowerCanvasEl), this.lowerCanvasEl = void 0, this;
      }, toString: function() {
        return "#<fabric.Canvas (" + this.complexity() + "): { objects: " + this._objects.length + " }>";
      } }), c(v.StaticCanvas.prototype, v.Observable), c(v.StaticCanvas.prototype, v.Collection), c(v.StaticCanvas.prototype, v.DataURLExporter), c(v.StaticCanvas, { EMPTY_JSON: '{"objects": [], "background": "white"}', supports: function(d) {
        var m = u();
        if (!m || !m.getContext) return null;
        var y = m.getContext("2d");
        return y && d === "setLineDash" ? y.setLineDash !== void 0 : null;
      } }), v.StaticCanvas.prototype.toJSON = v.StaticCanvas.prototype.toObject, v.isLikelyNode && (v.StaticCanvas.prototype.createPNGStream = function() {
        var d = s(this.lowerCanvasEl);
        return d && d.createPNGStream();
      }, v.StaticCanvas.prototype.createJPEGStream = function(d) {
        var m = s(this.lowerCanvasEl);
        return m && m.createJPEGStream(d);
      });
    }
  }(), v.BaseBrush = v.util.createClass({ color: "rgb(0, 0, 0)", width: 1, shadow: null, strokeLineCap: "round", strokeLineJoin: "round", strokeMiterLimit: 10, strokeDashArray: null, limitedToCanvasSize: !1, _setBrushStyles: function() {
    var c = this.canvas.contextTop;
    c.strokeStyle = this.color, c.lineWidth = this.width, c.lineCap = this.strokeLineCap, c.miterLimit = this.strokeMiterLimit, c.lineJoin = this.strokeLineJoin, c.setLineDash(this.strokeDashArray || []);
  }, _saveAndTransform: function(c) {
    var o = this.canvas.viewportTransform;
    c.save(), c.transform(o[0], o[1], o[2], o[3], o[4], o[5]);
  }, _setShadow: function() {
    if (this.shadow) {
      var c = this.canvas, o = this.shadow, l = c.contextTop, f = c.getZoom();
      c && c._isRetinaScaling() && (f *= v.devicePixelRatio), l.shadowColor = o.color, l.shadowBlur = o.blur * f, l.shadowOffsetX = o.offsetX * f, l.shadowOffsetY = o.offsetY * f;
    }
  }, needsFullRender: function() {
    return new v.Color(this.color).getAlpha() < 1 || !!this.shadow;
  }, _resetShadow: function() {
    var c = this.canvas.contextTop;
    c.shadowColor = "", c.shadowBlur = c.shadowOffsetX = c.shadowOffsetY = 0;
  }, _isOutSideCanvas: function(c) {
    return c.x < 0 || c.x > this.canvas.getWidth() || c.y < 0 || c.y > this.canvas.getHeight();
  } }), v.PencilBrush = v.util.createClass(v.BaseBrush, { decimate: 0.4, initialize: function(c) {
    this.canvas = c, this._points = [];
  }, _drawSegment: function(c, o, l) {
    var f = o.midPointFrom(l);
    return c.quadraticCurveTo(o.x, o.y, f.x, f.y), f;
  }, onMouseDown: function(c, o) {
    this.canvas._isMainEvent(o.e) && (this._prepareForDrawing(c), this._captureDrawingPath(c), this._render());
  }, onMouseMove: function(c, o) {
    if (this.canvas._isMainEvent(o.e) && (this.limitedToCanvasSize !== !0 || !this._isOutSideCanvas(c)) && this._captureDrawingPath(c) && this._points.length > 1) if (this.needsFullRender()) this.canvas.clearContext(this.canvas.contextTop), this._render();
    else {
      var l = this._points, f = l.length, i = this.canvas.contextTop;
      this._saveAndTransform(i), this.oldEnd && (i.beginPath(), i.moveTo(this.oldEnd.x, this.oldEnd.y)), this.oldEnd = this._drawSegment(i, l[f - 2], l[f - 1], !0), i.stroke(), i.restore();
    }
  }, onMouseUp: function(c) {
    return !this.canvas._isMainEvent(c.e) || (this.oldEnd = void 0, this._finalizeAndAddPath(), !1);
  }, _prepareForDrawing: function(c) {
    var o = new v.Point(c.x, c.y);
    this._reset(), this._addPoint(o), this.canvas.contextTop.moveTo(o.x, o.y);
  }, _addPoint: function(c) {
    return !(this._points.length > 1 && c.eq(this._points[this._points.length - 1]) || (this._points.push(c), 0));
  }, _reset: function() {
    this._points = [], this._setBrushStyles(), this._setShadow();
  }, _captureDrawingPath: function(c) {
    var o = new v.Point(c.x, c.y);
    return this._addPoint(o);
  }, _render: function() {
    var c, o, l = this.canvas.contextTop, f = this._points[0], i = this._points[1];
    if (this._saveAndTransform(l), l.beginPath(), this._points.length === 2 && f.x === i.x && f.y === i.y) {
      var r = this.width / 1e3;
      f = new v.Point(f.x, f.y), i = new v.Point(i.x, i.y), f.x -= r, i.x += r;
    }
    for (l.moveTo(f.x, f.y), c = 1, o = this._points.length; c < o; c++) this._drawSegment(l, f, i), f = this._points[c], i = this._points[c + 1];
    l.lineTo(f.x, f.y), l.stroke(), l.restore();
  }, convertPointsToSVGPath: function(c) {
    var o = this.width / 1e3;
    return v.util.getSmoothPathFromPoints(c, o);
  }, _isEmptySVGPath: function(c) {
    return v.util.joinPath(c) === "M 0 0 Q 0 0 0 0 L 0 0";
  }, createPath: function(c) {
    var o = new v.Path(c, { fill: null, stroke: this.color, strokeWidth: this.width, strokeLineCap: this.strokeLineCap, strokeMiterLimit: this.strokeMiterLimit, strokeLineJoin: this.strokeLineJoin, strokeDashArray: this.strokeDashArray });
    return this.shadow && (this.shadow.affectStroke = !0, o.shadow = new v.Shadow(this.shadow)), o;
  }, decimatePoints: function(c, o) {
    if (c.length <= 2) return c;
    var l, f = this.canvas.getZoom(), i = Math.pow(o / f, 2), r = c.length - 1, s = c[0], u = [s];
    for (l = 1; l < r - 1; l++) Math.pow(s.x - c[l].x, 2) + Math.pow(s.y - c[l].y, 2) >= i && (s = c[l], u.push(s));
    return u.push(c[r]), u;
  }, _finalizeAndAddPath: function() {
    this.canvas.contextTop.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate));
    var c = this.convertPointsToSVGPath(this._points);
    if (this._isEmptySVGPath(c)) this.canvas.requestRenderAll();
    else {
      var o = this.createPath(c);
      this.canvas.clearContext(this.canvas.contextTop), this.canvas.fire("before:path:created", { path: o }), this.canvas.add(o), this.canvas.requestRenderAll(), o.setCoords(), this._resetShadow(), this.canvas.fire("path:created", { path: o });
    }
  } }), v.CircleBrush = v.util.createClass(v.BaseBrush, { width: 10, initialize: function(c) {
    this.canvas = c, this.points = [];
  }, drawDot: function(c) {
    var o = this.addPoint(c), l = this.canvas.contextTop;
    this._saveAndTransform(l), this.dot(l, o), l.restore();
  }, dot: function(c, o) {
    c.fillStyle = o.fill, c.beginPath(), c.arc(o.x, o.y, o.radius, 0, 2 * Math.PI, !1), c.closePath(), c.fill();
  }, onMouseDown: function(c) {
    this.points.length = 0, this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.drawDot(c);
  }, _render: function() {
    var c, o, l = this.canvas.contextTop, f = this.points;
    for (this._saveAndTransform(l), c = 0, o = f.length; c < o; c++) this.dot(l, f[c]);
    l.restore();
  }, onMouseMove: function(c) {
    this.limitedToCanvasSize === !0 && this._isOutSideCanvas(c) || (this.needsFullRender() ? (this.canvas.clearContext(this.canvas.contextTop), this.addPoint(c), this._render()) : this.drawDot(c));
  }, onMouseUp: function() {
    var c, o, l = this.canvas.renderOnAddRemove;
    this.canvas.renderOnAddRemove = !1;
    var f = [];
    for (c = 0, o = this.points.length; c < o; c++) {
      var i = this.points[c], r = new v.Circle({ radius: i.radius, left: i.x, top: i.y, originX: "center", originY: "center", fill: i.fill });
      this.shadow && (r.shadow = new v.Shadow(this.shadow)), f.push(r);
    }
    var s = new v.Group(f);
    s.canvas = this.canvas, this.canvas.fire("before:path:created", { path: s }), this.canvas.add(s), this.canvas.fire("path:created", { path: s }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = l, this.canvas.requestRenderAll();
  }, addPoint: function(c) {
    var o = new v.Point(c.x, c.y), l = v.util.getRandomInt(Math.max(0, this.width - 20), this.width + 20) / 2, f = new v.Color(this.color).setAlpha(v.util.getRandomInt(0, 100) / 100).toRgba();
    return o.radius = l, o.fill = f, this.points.push(o), o;
  } }), v.SprayBrush = v.util.createClass(v.BaseBrush, { width: 10, density: 20, dotWidth: 1, dotWidthVariance: 1, randomOpacity: !1, optimizeOverlapping: !0, initialize: function(c) {
    this.canvas = c, this.sprayChunks = [];
  }, onMouseDown: function(c) {
    this.sprayChunks.length = 0, this.canvas.clearContext(this.canvas.contextTop), this._setShadow(), this.addSprayChunk(c), this.render(this.sprayChunkPoints);
  }, onMouseMove: function(c) {
    this.limitedToCanvasSize === !0 && this._isOutSideCanvas(c) || (this.addSprayChunk(c), this.render(this.sprayChunkPoints));
  }, onMouseUp: function() {
    var c = this.canvas.renderOnAddRemove;
    this.canvas.renderOnAddRemove = !1;
    for (var o = [], l = 0, f = this.sprayChunks.length; l < f; l++) for (var i = this.sprayChunks[l], r = 0, s = i.length; r < s; r++) {
      var u = new v.Rect({ width: i[r].width, height: i[r].width, left: i[r].x + 1, top: i[r].y + 1, originX: "center", originY: "center", fill: this.color });
      o.push(u);
    }
    this.optimizeOverlapping && (o = this._getOptimizedRects(o));
    var h = new v.Group(o);
    this.shadow && h.set("shadow", new v.Shadow(this.shadow)), this.canvas.fire("before:path:created", { path: h }), this.canvas.add(h), this.canvas.fire("path:created", { path: h }), this.canvas.clearContext(this.canvas.contextTop), this._resetShadow(), this.canvas.renderOnAddRemove = c, this.canvas.requestRenderAll();
  }, _getOptimizedRects: function(c) {
    var o, l, f, i = {};
    for (l = 0, f = c.length; l < f; l++) i[o = c[l].left + "" + c[l].top] || (i[o] = c[l]);
    var r = [];
    for (o in i) r.push(i[o]);
    return r;
  }, render: function(c) {
    var o, l, f = this.canvas.contextTop;
    for (f.fillStyle = this.color, this._saveAndTransform(f), o = 0, l = c.length; o < l; o++) {
      var i = c[o];
      i.opacity !== void 0 && (f.globalAlpha = i.opacity), f.fillRect(i.x, i.y, i.width, i.width);
    }
    f.restore();
  }, _render: function() {
    var c, o, l = this.canvas.contextTop;
    for (l.fillStyle = this.color, this._saveAndTransform(l), c = 0, o = this.sprayChunks.length; c < o; c++) this.render(this.sprayChunks[c]);
    l.restore();
  }, addSprayChunk: function(c) {
    this.sprayChunkPoints = [];
    var o, l, f, i, r = this.width / 2;
    for (i = 0; i < this.density; i++) {
      o = v.util.getRandomInt(c.x - r, c.x + r), l = v.util.getRandomInt(c.y - r, c.y + r), f = this.dotWidthVariance ? v.util.getRandomInt(Math.max(1, this.dotWidth - this.dotWidthVariance), this.dotWidth + this.dotWidthVariance) : this.dotWidth;
      var s = new v.Point(o, l);
      s.width = f, this.randomOpacity && (s.opacity = v.util.getRandomInt(0, 100) / 100), this.sprayChunkPoints.push(s);
    }
    this.sprayChunks.push(this.sprayChunkPoints);
  } }), v.PatternBrush = v.util.createClass(v.PencilBrush, { getPatternSrc: function() {
    var c = v.util.createCanvasElement(), o = c.getContext("2d");
    return c.width = c.height = 25, o.fillStyle = this.color, o.beginPath(), o.arc(10, 10, 10, 0, 2 * Math.PI, !1), o.closePath(), o.fill(), c;
  }, getPatternSrcFunction: function() {
    return String(this.getPatternSrc).replace("this.color", '"' + this.color + '"');
  }, getPattern: function() {
    return this.canvas.contextTop.createPattern(this.source || this.getPatternSrc(), "repeat");
  }, _setBrushStyles: function() {
    this.callSuper("_setBrushStyles"), this.canvas.contextTop.strokeStyle = this.getPattern();
  }, createPath: function(c) {
    var o = this.callSuper("createPath", c), l = o._getLeftTopCoords().scalarAdd(o.strokeWidth / 2);
    return o.stroke = new v.Pattern({ source: this.source || this.getPatternSrcFunction(), offsetX: -l.x, offsetY: -l.y }), o;
  } }), function() {
    var c = v.util.getPointer, o = v.util.degreesToRadians, l = v.util.isTouchEvent;
    for (var f in v.Canvas = v.util.createClass(v.StaticCanvas, { initialize: function(i, r) {
      r || (r = {}), this.renderAndResetBound = this.renderAndReset.bind(this), this.requestRenderAllBound = this.requestRenderAll.bind(this), this._initStatic(i, r), this._initInteractive(), this._createCacheCanvas();
    }, uniformScaling: !0, uniScaleKey: "shiftKey", centeredScaling: !1, centeredRotation: !1, centeredKey: "altKey", altActionKey: "shiftKey", interactive: !0, selection: !0, selectionKey: "shiftKey", altSelectionKey: null, selectionColor: "rgba(100, 100, 255, 0.3)", selectionDashArray: [], selectionBorderColor: "rgba(255, 255, 255, 0.3)", selectionLineWidth: 1, selectionFullyContained: !1, hoverCursor: "move", moveCursor: "move", defaultCursor: "default", freeDrawingCursor: "crosshair", rotationCursor: "crosshair", notAllowedCursor: "not-allowed", containerClass: "canvas-container", perPixelTargetFind: !1, targetFindTolerance: 0, skipTargetFind: !1, isDrawingMode: !1, preserveObjectStacking: !1, snapAngle: 0, snapThreshold: null, stopContextMenu: !1, fireRightClick: !1, fireMiddleClick: !1, targets: [], _hoveredTarget: null, _hoveredTargets: [], _initInteractive: function() {
      this._currentTransform = null, this._groupSelector = null, this._initWrapperElement(), this._createUpperCanvas(), this._initEventListeners(), this._initRetinaScaling(), this.freeDrawingBrush = v.PencilBrush && new v.PencilBrush(this), this.calcOffset();
    }, _chooseObjectsToRender: function() {
      var i, r, s, u = this.getActiveObjects();
      if (u.length > 0 && !this.preserveObjectStacking) {
        r = [], s = [];
        for (var h = 0, d = this._objects.length; h < d; h++) i = this._objects[h], u.indexOf(i) === -1 ? r.push(i) : s.push(i);
        u.length > 1 && (this._activeObject._objects = s), r.push.apply(r, s);
      } else r = this._objects;
      return r;
    }, renderAll: function() {
      !this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), this.hasLostContext && this.renderTopLayer(this.contextTop);
      var i = this.contextContainer;
      return this.renderCanvas(i, this._chooseObjectsToRender()), this;
    }, renderTopLayer: function(i) {
      i.save(), this.isDrawingMode && this._isCurrentlyDrawing && (this.freeDrawingBrush && this.freeDrawingBrush._render(), this.contextTopDirty = !0), this.selection && this._groupSelector && (this._drawSelection(i), this.contextTopDirty = !0), i.restore();
    }, renderTop: function() {
      var i = this.contextTop;
      return this.clearContext(i), this.renderTopLayer(i), this.fire("after:render"), this;
    }, _normalizePointer: function(i, r) {
      var s = i.calcTransformMatrix(), u = v.util.invertTransform(s), h = this.restorePointerVpt(r);
      return v.util.transformPoint(h, u);
    }, isTargetTransparent: function(i, r, s) {
      if (i.shouldCache() && i._cacheCanvas && i !== this._activeObject) {
        var u = this._normalizePointer(i, { x: r, y: s }), h = Math.max(i.cacheTranslationX + u.x * i.zoomX, 0), d = Math.max(i.cacheTranslationY + u.y * i.zoomY, 0);
        return v.util.isTransparent(i._cacheContext, Math.round(h), Math.round(d), this.targetFindTolerance);
      }
      var m = this.contextCache, y = i.selectionBackgroundColor, b = this.viewportTransform;
      return i.selectionBackgroundColor = "", this.clearContext(m), m.save(), m.transform(b[0], b[1], b[2], b[3], b[4], b[5]), i.render(m), m.restore(), i.selectionBackgroundColor = y, v.util.isTransparent(m, r, s, this.targetFindTolerance);
    }, _isSelectionKeyPressed: function(i) {
      return Object.prototype.toString.call(this.selectionKey) === "[object Array]" ? !!this.selectionKey.find(function(r) {
        return i[r] === !0;
      }) : i[this.selectionKey];
    }, _shouldClearSelection: function(i, r) {
      var s = this.getActiveObjects(), u = this._activeObject;
      return !r || r && u && s.length > 1 && s.indexOf(r) === -1 && u !== r && !this._isSelectionKeyPressed(i) || r && !r.evented || r && !r.selectable && u && u !== r;
    }, _shouldCenterTransform: function(i, r, s) {
      var u;
      if (i) return r === "scale" || r === "scaleX" || r === "scaleY" || r === "resizing" ? u = this.centeredScaling || i.centeredScaling : r === "rotate" && (u = this.centeredRotation || i.centeredRotation), u ? !s : s;
    }, _getOriginFromCorner: function(i, r) {
      var s = { x: i.originX, y: i.originY };
      return r === "ml" || r === "tl" || r === "bl" ? s.x = "right" : r !== "mr" && r !== "tr" && r !== "br" || (s.x = "left"), r === "tl" || r === "mt" || r === "tr" ? s.y = "bottom" : r !== "bl" && r !== "mb" && r !== "br" || (s.y = "top"), s;
    }, _getActionFromCorner: function(i, r, s, u) {
      if (!r || !i) return "drag";
      var h = u.controls[r];
      return h.getActionName(s, h, u);
    }, _setupCurrentTransform: function(i, r, s) {
      if (r) {
        var u = this.getPointer(i), h = r.__corner, d = r.controls[h], m = s && h ? d.getActionHandler(i, r, d) : v.controlsUtils.dragHandler, y = this._getActionFromCorner(s, h, i, r), b = this._getOriginFromCorner(r, h), S = i[this.centeredKey], E = { target: r, action: y, actionHandler: m, corner: h, scaleX: r.scaleX, scaleY: r.scaleY, skewX: r.skewX, skewY: r.skewY, offsetX: u.x - r.left, offsetY: u.y - r.top, originX: b.x, originY: b.y, ex: u.x, ey: u.y, lastX: u.x, lastY: u.y, theta: o(r.angle), width: r.width * r.scaleX, shiftKey: i.shiftKey, altKey: S, original: v.util.saveObjectTransform(r) };
        this._shouldCenterTransform(r, y, S) && (E.originX = "center", E.originY = "center"), E.original.originX = b.x, E.original.originY = b.y, this._currentTransform = E, this._beforeTransform(i);
      }
    }, setCursor: function(i) {
      this.upperCanvasEl.style.cursor = i;
    }, _drawSelection: function(i) {
      var r = this._groupSelector, s = new v.Point(r.ex, r.ey), u = v.util.transformPoint(s, this.viewportTransform), h = new v.Point(r.ex + r.left, r.ey + r.top), d = v.util.transformPoint(h, this.viewportTransform), m = Math.min(u.x, d.x), y = Math.min(u.y, d.y), b = Math.max(u.x, d.x), S = Math.max(u.y, d.y), E = this.selectionLineWidth / 2;
      this.selectionColor && (i.fillStyle = this.selectionColor, i.fillRect(m, y, b - m, S - y)), this.selectionLineWidth && this.selectionBorderColor && (i.lineWidth = this.selectionLineWidth, i.strokeStyle = this.selectionBorderColor, m += E, y += E, b -= E, S -= E, v.Object.prototype._setLineDash.call(this, i, this.selectionDashArray), i.strokeRect(m, y, b - m, S - y));
    }, findTarget: function(i, r) {
      if (!this.skipTargetFind) {
        var s, u, h = this.getPointer(i, !0), d = this._activeObject, m = this.getActiveObjects(), y = l(i), b = m.length > 1 && !r || m.length === 1;
        if (this.targets = [], b && d._findTargetCorner(h, y) || m.length > 1 && !r && d === this._searchPossibleTargets([d], h)) return d;
        if (m.length === 1 && d === this._searchPossibleTargets([d], h)) {
          if (!this.preserveObjectStacking) return d;
          s = d, u = this.targets, this.targets = [];
        }
        var S = this._searchPossibleTargets(this._objects, h);
        return i[this.altSelectionKey] && S && s && S !== s && (S = s, this.targets = u), S;
      }
    }, _checkTarget: function(i, r, s) {
      if (r && r.visible && r.evented && r.containsPoint(i) && (!this.perPixelTargetFind && !r.perPixelTargetFind || r.isEditing || !this.isTargetTransparent(r, s.x, s.y)))
        return !0;
    }, _searchPossibleTargets: function(i, r) {
      for (var s, u, h = i.length; h--; ) {
        var d = i[h], m = d.group ? this._normalizePointer(d.group, r) : r;
        if (this._checkTarget(m, d, r)) {
          (s = i[h]).subTargetCheck && s instanceof v.Group && (u = this._searchPossibleTargets(s._objects, r)) && this.targets.push(u);
          break;
        }
      }
      return s;
    }, restorePointerVpt: function(i) {
      return v.util.transformPoint(i, v.util.invertTransform(this.viewportTransform));
    }, getPointer: function(i, r) {
      if (this._absolutePointer && !r) return this._absolutePointer;
      if (this._pointer && r) return this._pointer;
      var s, u = c(i), h = this.upperCanvasEl, d = h.getBoundingClientRect(), m = d.width || 0, y = d.height || 0;
      m && y || ("top" in d && "bottom" in d && (y = Math.abs(d.top - d.bottom)), "right" in d && "left" in d && (m = Math.abs(d.right - d.left))), this.calcOffset(), u.x = u.x - this._offset.left, u.y = u.y - this._offset.top, r || (u = this.restorePointerVpt(u));
      var b = this.getRetinaScaling();
      return b !== 1 && (u.x /= b, u.y /= b), s = m === 0 || y === 0 ? { width: 1, height: 1 } : { width: h.width / m, height: h.height / y }, { x: u.x * s.width, y: u.y * s.height };
    }, _createUpperCanvas: function() {
      var i = this.lowerCanvasEl.className.replace(/\s*lower-canvas\s*/, ""), r = this.lowerCanvasEl, s = this.upperCanvasEl;
      s ? s.className = "" : (s = this._createCanvasElement(), this.upperCanvasEl = s), v.util.addClass(s, "upper-canvas " + i), this.wrapperEl.appendChild(s), this._copyCanvasStyle(r, s), this._applyCanvasStyle(s), this.contextTop = s.getContext("2d");
    }, _createCacheCanvas: function() {
      this.cacheCanvasEl = this._createCanvasElement(), this.cacheCanvasEl.setAttribute("width", this.width), this.cacheCanvasEl.setAttribute("height", this.height), this.contextCache = this.cacheCanvasEl.getContext("2d");
    }, _initWrapperElement: function() {
      this.wrapperEl = v.util.wrapElement(this.lowerCanvasEl, "div", { class: this.containerClass }), v.util.setStyle(this.wrapperEl, { width: this.width + "px", height: this.height + "px", position: "relative" }), v.util.makeElementUnselectable(this.wrapperEl);
    }, _applyCanvasStyle: function(i) {
      var r = this.width || i.width, s = this.height || i.height;
      v.util.setStyle(i, { position: "absolute", width: r + "px", height: s + "px", left: 0, top: 0, "touch-action": this.allowTouchScrolling ? "manipulation" : "none", "-ms-touch-action": this.allowTouchScrolling ? "manipulation" : "none" }), i.width = r, i.height = s, v.util.makeElementUnselectable(i);
    }, _copyCanvasStyle: function(i, r) {
      r.style.cssText = i.style.cssText;
    }, getSelectionContext: function() {
      return this.contextTop;
    }, getSelectionElement: function() {
      return this.upperCanvasEl;
    }, getActiveObject: function() {
      return this._activeObject;
    }, getActiveObjects: function() {
      var i = this._activeObject;
      return i ? i.type === "activeSelection" && i._objects ? i._objects.slice(0) : [i] : [];
    }, _onObjectRemoved: function(i) {
      i === this._activeObject && (this.fire("before:selection:cleared", { target: i }), this._discardActiveObject(), this.fire("selection:cleared", { target: i }), i.fire("deselected")), i === this._hoveredTarget && (this._hoveredTarget = null, this._hoveredTargets = []), this.callSuper("_onObjectRemoved", i);
    }, _fireSelectionEvents: function(i, r) {
      var s = !1, u = this.getActiveObjects(), h = [], d = [];
      i.forEach(function(m) {
        u.indexOf(m) === -1 && (s = !0, m.fire("deselected", { e: r, target: m }), d.push(m));
      }), u.forEach(function(m) {
        i.indexOf(m) === -1 && (s = !0, m.fire("selected", { e: r, target: m }), h.push(m));
      }), i.length > 0 && u.length > 0 ? s && this.fire("selection:updated", { e: r, selected: h, deselected: d, updated: h[0] || d[0], target: this._activeObject }) : u.length > 0 ? this.fire("selection:created", { e: r, selected: h, target: this._activeObject }) : i.length > 0 && this.fire("selection:cleared", { e: r, deselected: d });
    }, setActiveObject: function(i, r) {
      var s = this.getActiveObjects();
      return this._setActiveObject(i, r), this._fireSelectionEvents(s, r), this;
    }, _setActiveObject: function(i, r) {
      return this._activeObject !== i && !!this._discardActiveObject(r, i) && !i.onSelect({ e: r }) && (this._activeObject = i, !0);
    }, _discardActiveObject: function(i, r) {
      var s = this._activeObject;
      if (s) {
        if (s.onDeselect({ e: i, object: r })) return !1;
        this._activeObject = null;
      }
      return !0;
    }, discardActiveObject: function(i) {
      var r = this.getActiveObjects(), s = this.getActiveObject();
      return r.length && this.fire("before:selection:cleared", { target: s, e: i }), this._discardActiveObject(i), this._fireSelectionEvents(r, i), this;
    }, dispose: function() {
      var i = this.wrapperEl;
      return this.removeListeners(), i.removeChild(this.upperCanvasEl), i.removeChild(this.lowerCanvasEl), this.contextCache = null, this.contextTop = null, ["upperCanvasEl", "cacheCanvasEl"].forEach((function(r) {
        v.util.cleanUpJsdomNode(this[r]), this[r] = void 0;
      }).bind(this)), i.parentNode && i.parentNode.replaceChild(this.lowerCanvasEl, this.wrapperEl), delete this.wrapperEl, v.StaticCanvas.prototype.dispose.call(this), this;
    }, clear: function() {
      return this.discardActiveObject(), this.clearContext(this.contextTop), this.callSuper("clear");
    }, drawControls: function(i) {
      var r = this._activeObject;
      r && r._renderControls(i);
    }, _toObject: function(i, r, s) {
      var u = this._realizeGroupTransformOnObject(i), h = this.callSuper("_toObject", i, r, s);
      return this._unwindGroupTransformOnObject(i, u), h;
    }, _realizeGroupTransformOnObject: function(i) {
      if (i.group && i.group.type === "activeSelection" && this._activeObject === i.group) {
        var r = {};
        return ["angle", "flipX", "flipY", "left", "scaleX", "scaleY", "skewX", "skewY", "top"].forEach(function(s) {
          r[s] = i[s];
        }), v.util.addTransformToObject(i, this._activeObject.calcOwnMatrix()), r;
      }
      return null;
    }, _unwindGroupTransformOnObject: function(i, r) {
      r && i.set(r);
    }, _setSVGObject: function(i, r, s) {
      var u = this._realizeGroupTransformOnObject(r);
      this.callSuper("_setSVGObject", i, r, s), this._unwindGroupTransformOnObject(r, u);
    }, setViewportTransform: function(i) {
      this.renderOnAddRemove && this._activeObject && this._activeObject.isEditing && this._activeObject.clearContextTop(), v.StaticCanvas.prototype.setViewportTransform.call(this, i);
    } }), v.StaticCanvas) f !== "prototype" && (v.Canvas[f] = v.StaticCanvas[f]);
  }(), function() {
    var c = v.util.addListener, o = v.util.removeListener, l = { passive: !1 };
    function f(i, r) {
      return i.button && i.button === r - 1;
    }
    v.util.object.extend(v.Canvas.prototype, { mainTouchId: null, _initEventListeners: function() {
      this.removeListeners(), this._bindEvents(), this.addOrRemove(c, "add");
    }, _getEventPrefix: function() {
      return this.enablePointerEvents ? "pointer" : "mouse";
    }, addOrRemove: function(i, r) {
      var s = this.upperCanvasEl, u = this._getEventPrefix();
      i(v.window, "resize", this._onResize), i(s, u + "down", this._onMouseDown), i(s, u + "move", this._onMouseMove, l), i(s, u + "out", this._onMouseOut), i(s, u + "enter", this._onMouseEnter), i(s, "wheel", this._onMouseWheel), i(s, "contextmenu", this._onContextMenu), i(s, "dblclick", this._onDoubleClick), i(s, "dragover", this._onDragOver), i(s, "dragenter", this._onDragEnter), i(s, "dragleave", this._onDragLeave), i(s, "drop", this._onDrop), this.enablePointerEvents || i(s, "touchstart", this._onTouchStart, l), I !== void 0 && r in I && (I[r](s, "gesture", this._onGesture), I[r](s, "drag", this._onDrag), I[r](s, "orientation", this._onOrientationChange), I[r](s, "shake", this._onShake), I[r](s, "longpress", this._onLongPress));
    }, removeListeners: function() {
      this.addOrRemove(o, "remove");
      var i = this._getEventPrefix();
      o(v.document, i + "up", this._onMouseUp), o(v.document, "touchend", this._onTouchEnd, l), o(v.document, i + "move", this._onMouseMove, l), o(v.document, "touchmove", this._onMouseMove, l);
    }, _bindEvents: function() {
      this.eventsBound || (this._onMouseDown = this._onMouseDown.bind(this), this._onTouchStart = this._onTouchStart.bind(this), this._onMouseMove = this._onMouseMove.bind(this), this._onMouseUp = this._onMouseUp.bind(this), this._onTouchEnd = this._onTouchEnd.bind(this), this._onResize = this._onResize.bind(this), this._onGesture = this._onGesture.bind(this), this._onDrag = this._onDrag.bind(this), this._onShake = this._onShake.bind(this), this._onLongPress = this._onLongPress.bind(this), this._onOrientationChange = this._onOrientationChange.bind(this), this._onMouseWheel = this._onMouseWheel.bind(this), this._onMouseOut = this._onMouseOut.bind(this), this._onMouseEnter = this._onMouseEnter.bind(this), this._onContextMenu = this._onContextMenu.bind(this), this._onDoubleClick = this._onDoubleClick.bind(this), this._onDragOver = this._onDragOver.bind(this), this._onDragEnter = this._simpleEventHandler.bind(this, "dragenter"), this._onDragLeave = this._simpleEventHandler.bind(this, "dragleave"), this._onDrop = this._simpleEventHandler.bind(this, "drop"), this.eventsBound = !0);
    }, _onGesture: function(i, r) {
      this.__onTransformGesture && this.__onTransformGesture(i, r);
    }, _onDrag: function(i, r) {
      this.__onDrag && this.__onDrag(i, r);
    }, _onMouseWheel: function(i) {
      this.__onMouseWheel(i);
    }, _onMouseOut: function(i) {
      var r = this._hoveredTarget;
      this.fire("mouse:out", { target: r, e: i }), this._hoveredTarget = null, r && r.fire("mouseout", { e: i });
      var s = this;
      this._hoveredTargets.forEach(function(u) {
        s.fire("mouse:out", { target: r, e: i }), u && r.fire("mouseout", { e: i });
      }), this._hoveredTargets = [], this._iTextInstances && this._iTextInstances.forEach(function(u) {
        u.isEditing && u.hiddenTextarea.focus();
      });
    }, _onMouseEnter: function(i) {
      this._currentTransform || this.findTarget(i) || (this.fire("mouse:over", { target: null, e: i }), this._hoveredTarget = null, this._hoveredTargets = []);
    }, _onOrientationChange: function(i, r) {
      this.__onOrientationChange && this.__onOrientationChange(i, r);
    }, _onShake: function(i, r) {
      this.__onShake && this.__onShake(i, r);
    }, _onLongPress: function(i, r) {
      this.__onLongPress && this.__onLongPress(i, r);
    }, _onDragOver: function(i) {
      i.preventDefault();
      var r = this._simpleEventHandler("dragover", i);
      this._fireEnterLeaveEvents(r, i);
    }, _onContextMenu: function(i) {
      return this.stopContextMenu && (i.stopPropagation(), i.preventDefault()), !1;
    }, _onDoubleClick: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "dblclick"), this._resetTransformEventData(i);
    }, getPointerId: function(i) {
      var r = i.changedTouches;
      return r ? r[0] && r[0].identifier : this.enablePointerEvents ? i.pointerId : -1;
    }, _isMainEvent: function(i) {
      return i.isPrimary === !0 || i.isPrimary !== !1 && (i.type === "touchend" && i.touches.length === 0 || !i.changedTouches || i.changedTouches[0].identifier === this.mainTouchId);
    }, _onTouchStart: function(i) {
      i.preventDefault(), this.mainTouchId === null && (this.mainTouchId = this.getPointerId(i)), this.__onMouseDown(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      c(v.document, "touchend", this._onTouchEnd, l), c(v.document, "touchmove", this._onMouseMove, l), o(r, s + "down", this._onMouseDown);
    }, _onMouseDown: function(i) {
      this.__onMouseDown(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      o(r, s + "move", this._onMouseMove, l), c(v.document, s + "up", this._onMouseUp), c(v.document, s + "move", this._onMouseMove, l);
    }, _onTouchEnd: function(i) {
      if (!(i.touches.length > 0)) {
        this.__onMouseUp(i), this._resetTransformEventData(), this.mainTouchId = null;
        var r = this._getEventPrefix();
        o(v.document, "touchend", this._onTouchEnd, l), o(v.document, "touchmove", this._onMouseMove, l);
        var s = this;
        this._willAddMouseDown && clearTimeout(this._willAddMouseDown), this._willAddMouseDown = setTimeout(function() {
          c(s.upperCanvasEl, r + "down", s._onMouseDown), s._willAddMouseDown = 0;
        }, 400);
      }
    }, _onMouseUp: function(i) {
      this.__onMouseUp(i), this._resetTransformEventData();
      var r = this.upperCanvasEl, s = this._getEventPrefix();
      this._isMainEvent(i) && (o(v.document, s + "up", this._onMouseUp), o(v.document, s + "move", this._onMouseMove, l), c(r, s + "move", this._onMouseMove, l));
    }, _onMouseMove: function(i) {
      !this.allowTouchScrolling && i.preventDefault && i.preventDefault(), this.__onMouseMove(i);
    }, _onResize: function() {
      this.calcOffset();
    }, _shouldRender: function(i) {
      var r = this._activeObject;
      return !!(!!r != !!i || r && i && r !== i) || (r && r.isEditing, !1);
    }, __onMouseUp: function(i) {
      var r, s = this._currentTransform, u = this._groupSelector, h = !1, d = !u || u.left === 0 && u.top === 0;
      if (this._cacheTransformEventData(i), r = this._target, this._handleEvent(i, "up:before"), f(i, 3)) this.fireRightClick && this._handleEvent(i, "up", 3, d);
      else {
        if (f(i, 2)) return this.fireMiddleClick && this._handleEvent(i, "up", 2, d), void this._resetTransformEventData();
        if (this.isDrawingMode && this._isCurrentlyDrawing) this._onMouseUpInDrawingMode(i);
        else if (this._isMainEvent(i)) {
          if (s && (this._finalizeCurrentTransform(i), h = s.actionPerformed), !d) {
            var m = r === this._activeObject;
            this._maybeGroupObjects(i), h || (h = this._shouldRender(r) || !m && r === this._activeObject);
          }
          if (r) {
            if (r.selectable && r !== this._activeObject && r.activeOn === "up") this.setActiveObject(r, i), h = !0;
            else {
              var y = r._findTargetCorner(this.getPointer(i, !0), v.util.isTouchEvent(i)), b = r.controls[y], S = b && b.getMouseUpHandler(i, r, b);
              if (S) {
                var E = this.getPointer(i);
                S(i, s, E.x, E.y);
              }
            }
            r.isMoving = !1;
          }
          this._setCursorFromEvent(i, r), this._handleEvent(i, "up", 1, d), this._groupSelector = null, this._currentTransform = null, r && (r.__corner = 0), h ? this.requestRenderAll() : d || this.renderTop();
        }
      }
    }, _simpleEventHandler: function(i, r) {
      var s = this.findTarget(r), u = this.targets, h = { e: r, target: s, subTargets: u };
      if (this.fire(i, h), s && s.fire(i, h), !u) return s;
      for (var d = 0; d < u.length; d++) u[d].fire(i, h);
      return s;
    }, _handleEvent: function(i, r, s, u) {
      var h = this._target, d = this.targets || [], m = { e: i, target: h, subTargets: d, button: s || 1, isClick: u || !1, pointer: this._pointer, absolutePointer: this._absolutePointer, transform: this._currentTransform };
      r === "up" && (m.currentTarget = this.findTarget(i), m.currentSubTargets = this.targets), this.fire("mouse:" + r, m), h && h.fire("mouse" + r, m);
      for (var y = 0; y < d.length; y++) d[y].fire("mouse" + r, m);
    }, _finalizeCurrentTransform: function(i) {
      var r, s = this._currentTransform, u = s.target, h = { e: i, target: u, transform: s, action: s.action };
      u._scaling && (u._scaling = !1), u.setCoords(), (s.actionPerformed || this.stateful && u.hasStateChanged()) && (s.actionPerformed && (r = this._addEventOptions(h, s), this._fire(r, h)), this._fire("modified", h));
    }, _addEventOptions: function(i, r) {
      var s, u;
      switch (r.action) {
        case "scaleX":
          s = "scaled", u = "x";
          break;
        case "scaleY":
          s = "scaled", u = "y";
          break;
        case "skewX":
          s = "skewed", u = "x";
          break;
        case "skewY":
          s = "skewed", u = "y";
          break;
        case "scale":
          s = "scaled", u = "equally";
          break;
        case "rotate":
          s = "rotated";
          break;
        case "drag":
          s = "moved";
      }
      return i.by = u, s;
    }, _onMouseDownInDrawingMode: function(i) {
      this._isCurrentlyDrawing = !0, this.getActiveObject() && this.discardActiveObject(i).requestRenderAll();
      var r = this.getPointer(i);
      this.freeDrawingBrush.onMouseDown(r, { e: i, pointer: r }), this._handleEvent(i, "down");
    }, _onMouseMoveInDrawingMode: function(i) {
      if (this._isCurrentlyDrawing) {
        var r = this.getPointer(i);
        this.freeDrawingBrush.onMouseMove(r, { e: i, pointer: r });
      }
      this.setCursor(this.freeDrawingCursor), this._handleEvent(i, "move");
    }, _onMouseUpInDrawingMode: function(i) {
      var r = this.getPointer(i);
      this._isCurrentlyDrawing = this.freeDrawingBrush.onMouseUp({ e: i, pointer: r }), this._handleEvent(i, "up");
    }, __onMouseDown: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "down:before");
      var r = this._target;
      if (f(i, 3)) this.fireRightClick && this._handleEvent(i, "down", 3);
      else if (f(i, 2)) this.fireMiddleClick && this._handleEvent(i, "down", 2);
      else if (this.isDrawingMode) this._onMouseDownInDrawingMode(i);
      else if (this._isMainEvent(i) && !this._currentTransform) {
        var s = this._pointer;
        this._previousPointer = s;
        var u = this._shouldRender(r), h = this._shouldGroup(i, r);
        if (this._shouldClearSelection(i, r) ? this.discardActiveObject(i) : h && (this._handleGrouping(i, r), r = this._activeObject), !this.selection || r && (r.selectable || r.isEditing || r === this._activeObject) || (this._groupSelector = { ex: this._absolutePointer.x, ey: this._absolutePointer.y, top: 0, left: 0 }), r) {
          var d = r === this._activeObject;
          r.selectable && r.activeOn === "down" && this.setActiveObject(r, i);
          var m = r._findTargetCorner(this.getPointer(i, !0), v.util.isTouchEvent(i));
          if (r.__corner = m, r === this._activeObject && (m || !h)) {
            this._setupCurrentTransform(i, r, d);
            var y = r.controls[m], b = (s = this.getPointer(i), y && y.getMouseDownHandler(i, r, y));
            b && b(i, this._currentTransform, s.x, s.y);
          }
        }
        this._handleEvent(i, "down"), (u || h) && this.requestRenderAll();
      }
    }, _resetTransformEventData: function() {
      this._target = null, this._pointer = null, this._absolutePointer = null;
    }, _cacheTransformEventData: function(i) {
      this._resetTransformEventData(), this._pointer = this.getPointer(i, !0), this._absolutePointer = this.restorePointerVpt(this._pointer), this._target = this._currentTransform ? this._currentTransform.target : this.findTarget(i) || null;
    }, _beforeTransform: function(i) {
      var r = this._currentTransform;
      this.stateful && r.target.saveState(), this.fire("before:transform", { e: i, transform: r });
    }, __onMouseMove: function(i) {
      var r, s;
      if (this._handleEvent(i, "move:before"), this._cacheTransformEventData(i), this.isDrawingMode) this._onMouseMoveInDrawingMode(i);
      else if (this._isMainEvent(i)) {
        var u = this._groupSelector;
        u ? (s = this._absolutePointer, u.left = s.x - u.ex, u.top = s.y - u.ey, this.renderTop()) : this._currentTransform ? this._transformObject(i) : (r = this.findTarget(i) || null, this._setCursorFromEvent(i, r), this._fireOverOutEvents(r, i)), this._handleEvent(i, "move"), this._resetTransformEventData();
      }
    }, _fireOverOutEvents: function(i, r) {
      var s = this._hoveredTarget, u = this._hoveredTargets, h = this.targets, d = Math.max(u.length, h.length);
      this.fireSyntheticInOutEvents(i, r, { oldTarget: s, evtOut: "mouseout", canvasEvtOut: "mouse:out", evtIn: "mouseover", canvasEvtIn: "mouse:over" });
      for (var m = 0; m < d; m++) this.fireSyntheticInOutEvents(h[m], r, { oldTarget: u[m], evtOut: "mouseout", evtIn: "mouseover" });
      this._hoveredTarget = i, this._hoveredTargets = this.targets.concat();
    }, _fireEnterLeaveEvents: function(i, r) {
      var s = this._draggedoverTarget, u = this._hoveredTargets, h = this.targets, d = Math.max(u.length, h.length);
      this.fireSyntheticInOutEvents(i, r, { oldTarget: s, evtOut: "dragleave", evtIn: "dragenter" });
      for (var m = 0; m < d; m++) this.fireSyntheticInOutEvents(h[m], r, { oldTarget: u[m], evtOut: "dragleave", evtIn: "dragenter" });
      this._draggedoverTarget = i;
    }, fireSyntheticInOutEvents: function(i, r, s) {
      var u, h, d, m = s.oldTarget, y = m !== i, b = s.canvasEvtIn, S = s.canvasEvtOut;
      y && (u = { e: r, target: i, previousTarget: m }, h = { e: r, target: m, nextTarget: i }), d = i && y, m && y && (S && this.fire(S, h), m.fire(s.evtOut, h)), d && (b && this.fire(b, u), i.fire(s.evtIn, u));
    }, __onMouseWheel: function(i) {
      this._cacheTransformEventData(i), this._handleEvent(i, "wheel"), this._resetTransformEventData();
    }, _transformObject: function(i) {
      var r = this.getPointer(i), s = this._currentTransform;
      s.reset = !1, s.shiftKey = i.shiftKey, s.altKey = i[this.centeredKey], this._performTransformAction(i, s, r), s.actionPerformed && this.requestRenderAll();
    }, _performTransformAction: function(i, r, s) {
      var u = s.x, h = s.y, d = r.action, m = !1, y = r.actionHandler;
      y && (m = y(i, r, u, h)), d === "drag" && m && (r.target.isMoving = !0, this.setCursor(r.target.moveCursor || this.moveCursor)), r.actionPerformed = r.actionPerformed || m;
    }, _fire: v.controlsUtils.fireEvent, _setCursorFromEvent: function(i, r) {
      if (!r) return this.setCursor(this.defaultCursor), !1;
      var s = r.hoverCursor || this.hoverCursor, u = this._activeObject && this._activeObject.type === "activeSelection" ? this._activeObject : null, h = (!u || !u.contains(r)) && r._findTargetCorner(this.getPointer(i, !0));
      h ? this.setCursor(this.getCornerCursor(h, r, i)) : (r.subTargetCheck && this.targets.concat().reverse().map(function(d) {
        s = d.hoverCursor || s;
      }), this.setCursor(s));
    }, getCornerCursor: function(i, r, s) {
      var u = r.controls[i];
      return u.cursorStyleHandler(s, u, r);
    } });
  }(), P = Math.min, $ = Math.max, v.util.object.extend(v.Canvas.prototype, { _shouldGroup: function(c, o) {
    var l = this._activeObject;
    return l && this._isSelectionKeyPressed(c) && o && o.selectable && this.selection && (l !== o || l.type === "activeSelection") && !o.onSelect({ e: c });
  }, _handleGrouping: function(c, o) {
    var l = this._activeObject;
    l.__corner || (o !== l || (o = this.findTarget(c, !0)) && o.selectable) && (l && l.type === "activeSelection" ? this._updateActiveSelection(o, c) : this._createActiveSelection(o, c));
  }, _updateActiveSelection: function(c, o) {
    var l = this._activeObject, f = l._objects.slice(0);
    l.contains(c) ? (l.removeWithUpdate(c), this._hoveredTarget = c, this._hoveredTargets = this.targets.concat(), l.size() === 1 && this._setActiveObject(l.item(0), o)) : (l.addWithUpdate(c), this._hoveredTarget = l, this._hoveredTargets = this.targets.concat()), this._fireSelectionEvents(f, o);
  }, _createActiveSelection: function(c, o) {
    var l = this.getActiveObjects(), f = this._createGroup(c);
    this._hoveredTarget = f, this._setActiveObject(f, o), this._fireSelectionEvents(l, o);
  }, _createGroup: function(c) {
    var o = this._objects, l = o.indexOf(this._activeObject) < o.indexOf(c) ? [this._activeObject, c] : [c, this._activeObject];
    return this._activeObject.isEditing && this._activeObject.exitEditing(), new v.ActiveSelection(l, { canvas: this });
  }, _groupSelectedObjects: function(c) {
    var o, l = this._collectObjects(c);
    l.length === 1 ? this.setActiveObject(l[0], c) : l.length > 1 && (o = new v.ActiveSelection(l.reverse(), { canvas: this }), this.setActiveObject(o, c));
  }, _collectObjects: function(c) {
    for (var o, l = [], f = this._groupSelector.ex, i = this._groupSelector.ey, r = f + this._groupSelector.left, s = i + this._groupSelector.top, u = new v.Point(P(f, r), P(i, s)), h = new v.Point($(f, r), $(i, s)), d = !this.selectionFullyContained, m = f === r && i === s, y = this._objects.length; y-- && !((o = this._objects[y]) && o.selectable && o.visible && (d && o.intersectsWithRect(u, h, !0) || o.isContainedWithinRect(u, h, !0) || d && o.containsPoint(u, null, !0) || d && o.containsPoint(h, null, !0)) && (l.push(o), m)); ) ;
    return l.length > 1 && (l = l.filter(function(b) {
      return !b.onSelect({ e: c });
    })), l;
  }, _maybeGroupObjects: function(c) {
    this.selection && this._groupSelector && this._groupSelectedObjects(c), this.setCursor(this.defaultCursor), this._groupSelector = null;
  } }), v.util.object.extend(v.StaticCanvas.prototype, { toDataURL: function(c) {
    c || (c = {});
    var o = c.format || "png", l = c.quality || 1, f = (c.multiplier || 1) * (c.enableRetinaScaling ? this.getRetinaScaling() : 1), i = this.toCanvasElement(f, c);
    return v.util.toDataURL(i, o, l);
  }, toCanvasElement: function(c, o) {
    c = c || 1;
    var l = ((o = o || {}).width || this.width) * c, f = (o.height || this.height) * c, i = this.getZoom(), r = this.width, s = this.height, u = i * c, h = this.viewportTransform, d = (h[4] - (o.left || 0)) * c, m = (h[5] - (o.top || 0)) * c, y = this.interactive, b = [u, 0, 0, u, d, m], S = this.enableRetinaScaling, E = v.util.createCanvasElement(), A = this.contextTop;
    return E.width = l, E.height = f, this.contextTop = null, this.enableRetinaScaling = !1, this.interactive = !1, this.viewportTransform = b, this.width = l, this.height = f, this.calcViewportBoundaries(), this.renderCanvas(E.getContext("2d"), this._objects), this.viewportTransform = h, this.width = r, this.height = s, this.calcViewportBoundaries(), this.interactive = y, this.enableRetinaScaling = S, this.contextTop = A, E;
  } }), v.util.object.extend(v.StaticCanvas.prototype, { loadFromJSON: function(c, o, l) {
    if (c) {
      var f = typeof c == "string" ? JSON.parse(c) : v.util.object.clone(c), i = this, r = f.clipPath, s = this.renderOnAddRemove;
      return this.renderOnAddRemove = !1, delete f.clipPath, this._enlivenObjects(f.objects, function(u) {
        i.clear(), i._setBgOverlay(f, function() {
          r ? i._enlivenObjects([r], function(h) {
            i.clipPath = h[0], i.__setupCanvas.call(i, f, u, s, o);
          }) : i.__setupCanvas.call(i, f, u, s, o);
        });
      }, l), this;
    }
  }, __setupCanvas: function(c, o, l, f) {
    var i = this;
    o.forEach(function(r, s) {
      i.insertAt(r, s);
    }), this.renderOnAddRemove = l, delete c.objects, delete c.backgroundImage, delete c.overlayImage, delete c.background, delete c.overlay, this._setOptions(c), this.renderAll(), f && f();
  }, _setBgOverlay: function(c, o) {
    var l = { backgroundColor: !1, overlayColor: !1, backgroundImage: !1, overlayImage: !1 };
    if (c.backgroundImage || c.overlayImage || c.background || c.overlay) {
      var f = function() {
        l.backgroundImage && l.overlayImage && l.backgroundColor && l.overlayColor && o && o();
      };
      this.__setBgOverlay("backgroundImage", c.backgroundImage, l, f), this.__setBgOverlay("overlayImage", c.overlayImage, l, f), this.__setBgOverlay("backgroundColor", c.background, l, f), this.__setBgOverlay("overlayColor", c.overlay, l, f);
    } else o && o();
  }, __setBgOverlay: function(c, o, l, f) {
    var i = this;
    if (!o) return l[c] = !0, void (f && f());
    c === "backgroundImage" || c === "overlayImage" ? v.util.enlivenObjects([o], function(r) {
      i[c] = r[0], l[c] = !0, f && f();
    }) : this["set" + v.util.string.capitalize(c, !0)](o, function() {
      l[c] = !0, f && f();
    });
  }, _enlivenObjects: function(c, o, l) {
    c && c.length !== 0 ? v.util.enlivenObjects(c, function(f) {
      o && o(f);
    }, null, l) : o && o([]);
  }, _toDataURL: function(c, o) {
    this.clone(function(l) {
      o(l.toDataURL(c));
    });
  }, _toDataURLWithMultiplier: function(c, o, l) {
    this.clone(function(f) {
      l(f.toDataURLWithMultiplier(c, o));
    });
  }, clone: function(c, o) {
    var l = JSON.stringify(this.toJSON(o));
    this.cloneWithoutData(function(f) {
      f.loadFromJSON(l, function() {
        c && c(f);
      });
    });
  }, cloneWithoutData: function(c) {
    var o = v.util.createCanvasElement();
    o.width = this.width, o.height = this.height;
    var l = new v.Canvas(o);
    this.backgroundImage ? (l.setBackgroundImage(this.backgroundImage.src, function() {
      l.renderAll(), c && c(l);
    }), l.backgroundImageOpacity = this.backgroundImageOpacity, l.backgroundImageStretch = this.backgroundImageStretch) : c && c(l);
  } }), ht = v.util.degreesToRadians, it = v.util.radiansToDegrees, v.util.object.extend(v.Canvas.prototype, { __onTransformGesture: function(c, o) {
    if (!this.isDrawingMode && c.touches && c.touches.length === 2 && o.gesture === "gesture") {
      var l = this.findTarget(c);
      l !== void 0 && (this.__gesturesParams = { e: c, self: o, target: l }, this.__gesturesRenderer()), this.fire("touch:gesture", { target: l, e: c, self: o });
    }
  }, __gesturesParams: null, __gesturesRenderer: function() {
    if (this.__gesturesParams !== null && this._currentTransform !== null) {
      var c = this.__gesturesParams.self, o = this._currentTransform, l = this.__gesturesParams.e;
      o.action = "scale", o.originX = o.originY = "center", this._scaleObjectBy(c.scale, l), c.rotation !== 0 && (o.action = "rotate", this._rotateObjectByAngle(c.rotation, l)), this.requestRenderAll(), o.action = "drag";
    }
  }, __onDrag: function(c, o) {
    this.fire("touch:drag", { e: c, self: o });
  }, __onOrientationChange: function(c, o) {
    this.fire("touch:orientation", { e: c, self: o });
  }, __onShake: function(c, o) {
    this.fire("touch:shake", { e: c, self: o });
  }, __onLongPress: function(c, o) {
    this.fire("touch:longpress", { e: c, self: o });
  }, _scaleObjectBy: function(c, o) {
    var l = this._currentTransform, f = l.target;
    return l.gestureScale = c, f._scaling = !0, v.controlsUtils.scalingEqually(o, l, 0, 0);
  }, _rotateObjectByAngle: function(c, o) {
    var l = this._currentTransform;
    l.target.get("lockRotation") || (l.target.rotate(it(ht(c) + l.theta)), this._fire("rotating", { target: l.target, e: o, transform: l }));
  } }), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.util.object.clone, i = o.util.toFixed, r = o.util.string.capitalize, s = o.util.degreesToRadians, u = !o.isLikelyNode;
    o.Object || (o.Object = o.util.createClass(o.CommonMethods, { type: "object", originX: "left", originY: "top", top: 0, left: 0, width: 0, height: 0, scaleX: 1, scaleY: 1, flipX: !1, flipY: !1, opacity: 1, angle: 0, skewX: 0, skewY: 0, cornerSize: 13, touchCornerSize: 24, transparentCorners: !0, hoverCursor: null, moveCursor: null, padding: 0, borderColor: "rgb(178,204,255)", borderDashArray: null, cornerColor: "rgb(178,204,255)", cornerStrokeColor: null, cornerStyle: "rect", cornerDashArray: null, centeredScaling: !1, centeredRotation: !0, fill: "rgb(0,0,0)", fillRule: "nonzero", globalCompositeOperation: "source-over", backgroundColor: "", selectionBackgroundColor: "", stroke: null, strokeWidth: 1, strokeDashArray: null, strokeDashOffset: 0, strokeLineCap: "butt", strokeLineJoin: "miter", strokeMiterLimit: 4, shadow: null, borderOpacityWhenMoving: 0.4, borderScaleFactor: 1, minScaleLimit: 0, selectable: !0, evented: !0, visible: !0, hasControls: !0, hasBorders: !0, perPixelTargetFind: !1, includeDefaultValues: !0, lockMovementX: !1, lockMovementY: !1, lockRotation: !1, lockScalingX: !1, lockScalingY: !1, lockSkewingX: !1, lockSkewingY: !1, lockScalingFlip: !1, excludeFromExport: !1, objectCaching: u, statefullCache: !1, noScaleCache: !0, strokeUniform: !1, dirty: !0, __corner: 0, paintFirst: "fill", activeOn: "down", stateProperties: "top left width height scaleX scaleY flipX flipY originX originY transformMatrix stroke strokeWidth strokeDashArray strokeLineCap strokeDashOffset strokeLineJoin strokeMiterLimit angle opacity fill globalCompositeOperation shadow visible backgroundColor skewX skewY fillRule paintFirst clipPath strokeUniform".split(" "), cacheProperties: "fill stroke strokeWidth strokeDashArray width height paintFirst strokeUniform strokeLineCap strokeDashOffset strokeLineJoin strokeMiterLimit backgroundColor clipPath".split(" "), colorProperties: "fill stroke backgroundColor".split(" "), clipPath: void 0, inverted: !1, absolutePositioned: !1, initialize: function(h) {
      h && this.setOptions(h);
    }, _createCacheCanvas: function() {
      this._cacheProperties = {}, this._cacheCanvas = o.util.createCanvasElement(), this._cacheContext = this._cacheCanvas.getContext("2d"), this._updateCacheCanvas(), this.dirty = !0;
    }, _limitCacheSize: function(h) {
      var d = o.perfLimitSizeTotal, m = h.width, y = h.height, b = o.maxCacheSideLimit, S = o.minCacheSideLimit;
      if (m <= b && y <= b && m * y <= d) return m < S && (h.width = S), y < S && (h.height = S), h;
      var E = m / y, A = o.util.limitDimsByArea(E, d), M = o.util.capValue, C = M(S, A.x, b), O = M(S, A.y, b);
      return m > C && (h.zoomX /= m / C, h.width = C, h.capped = !0), y > O && (h.zoomY /= y / O, h.height = O, h.capped = !0), h;
    }, _getCacheCanvasDimensions: function() {
      var h = this.getTotalObjectScaling(), d = this._getTransformedDimensions(0, 0), m = d.x * h.scaleX / this.scaleX, y = d.y * h.scaleY / this.scaleY;
      return { width: m + 2, height: y + 2, zoomX: h.scaleX, zoomY: h.scaleY, x: m, y };
    }, _updateCacheCanvas: function() {
      var h = this.canvas;
      if (this.noScaleCache && h && h._currentTransform) {
        var d = h._currentTransform.target, m = h._currentTransform.action;
        if (this === d && m.slice && m.slice(0, 5) === "scale") return !1;
      }
      var y, b, S = this._cacheCanvas, E = this._limitCacheSize(this._getCacheCanvasDimensions()), A = o.minCacheSideLimit, M = E.width, C = E.height, O = E.zoomX, N = E.zoomY, z = M !== this.cacheWidth || C !== this.cacheHeight, W = this.zoomX !== O || this.zoomY !== N, F = z || W, k = 0, B = 0, Z = !1;
      if (z) {
        var K = this._cacheCanvas.width, U = this._cacheCanvas.height, R = M > K || C > U;
        Z = R || (M < 0.9 * K || C < 0.9 * U) && K > A && U > A, R && !E.capped && (M > A || C > A) && (k = 0.1 * M, B = 0.1 * C);
      }
      return this instanceof o.Text && this.path && (F = !0, Z = !0, k += this.getHeightOfLine(0) * this.zoomX, B += this.getHeightOfLine(0) * this.zoomY), !!F && (Z ? (S.width = Math.ceil(M + k), S.height = Math.ceil(C + B)) : (this._cacheContext.setTransform(1, 0, 0, 1, 0, 0), this._cacheContext.clearRect(0, 0, S.width, S.height)), y = E.x / 2, b = E.y / 2, this.cacheTranslationX = Math.round(S.width / 2 - y) + y, this.cacheTranslationY = Math.round(S.height / 2 - b) + b, this.cacheWidth = M, this.cacheHeight = C, this._cacheContext.translate(this.cacheTranslationX, this.cacheTranslationY), this._cacheContext.scale(O, N), this.zoomX = O, this.zoomY = N, !0);
    }, setOptions: function(h) {
      this._setOptions(h), this._initGradient(h.fill, "fill"), this._initGradient(h.stroke, "stroke"), this._initPattern(h.fill, "fill"), this._initPattern(h.stroke, "stroke");
    }, transform: function(h) {
      var d = this.group && !this.group._transformDone || this.group && this.canvas && h === this.canvas.contextTop, m = this.calcTransformMatrix(!d);
      h.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
    }, toObject: function(h) {
      var d = o.Object.NUM_FRACTION_DIGITS, m = { type: this.type, version: o.version, originX: this.originX, originY: this.originY, left: i(this.left, d), top: i(this.top, d), width: i(this.width, d), height: i(this.height, d), fill: this.fill && this.fill.toObject ? this.fill.toObject() : this.fill, stroke: this.stroke && this.stroke.toObject ? this.stroke.toObject() : this.stroke, strokeWidth: i(this.strokeWidth, d), strokeDashArray: this.strokeDashArray ? this.strokeDashArray.concat() : this.strokeDashArray, strokeLineCap: this.strokeLineCap, strokeDashOffset: this.strokeDashOffset, strokeLineJoin: this.strokeLineJoin, strokeUniform: this.strokeUniform, strokeMiterLimit: i(this.strokeMiterLimit, d), scaleX: i(this.scaleX, d), scaleY: i(this.scaleY, d), angle: i(this.angle, d), flipX: this.flipX, flipY: this.flipY, opacity: i(this.opacity, d), shadow: this.shadow && this.shadow.toObject ? this.shadow.toObject() : this.shadow, visible: this.visible, backgroundColor: this.backgroundColor, fillRule: this.fillRule, paintFirst: this.paintFirst, globalCompositeOperation: this.globalCompositeOperation, skewX: i(this.skewX, d), skewY: i(this.skewY, d) };
      return this.clipPath && !this.clipPath.excludeFromExport && (m.clipPath = this.clipPath.toObject(h), m.clipPath.inverted = this.clipPath.inverted, m.clipPath.absolutePositioned = this.clipPath.absolutePositioned), o.util.populateWithProperties(this, m, h), this.includeDefaultValues || (m = this._removeDefaultValues(m)), m;
    }, toDatalessObject: function(h) {
      return this.toObject(h);
    }, _removeDefaultValues: function(h) {
      var d = o.util.getKlass(h.type).prototype;
      return d.stateProperties.forEach(function(m) {
        m !== "left" && m !== "top" && (h[m] === d[m] && delete h[m], Object.prototype.toString.call(h[m]) === "[object Array]" && Object.prototype.toString.call(d[m]) === "[object Array]" && h[m].length === 0 && d[m].length === 0 && delete h[m]);
      }), h;
    }, toString: function() {
      return "#<fabric." + r(this.type) + ">";
    }, getObjectScaling: function() {
      if (!this.group) return { scaleX: this.scaleX, scaleY: this.scaleY };
      var h = o.util.qrDecompose(this.calcTransformMatrix());
      return { scaleX: Math.abs(h.scaleX), scaleY: Math.abs(h.scaleY) };
    }, getTotalObjectScaling: function() {
      var h = this.getObjectScaling(), d = h.scaleX, m = h.scaleY;
      if (this.canvas) {
        var y = this.canvas.getZoom(), b = this.canvas.getRetinaScaling();
        d *= y * b, m *= y * b;
      }
      return { scaleX: d, scaleY: m };
    }, getObjectOpacity: function() {
      var h = this.opacity;
      return this.group && (h *= this.group.getObjectOpacity()), h;
    }, _set: function(h, d) {
      var m = h === "scaleX" || h === "scaleY", y = this[h] !== d, b = !1;
      return m && (d = this._constrainScale(d)), h === "scaleX" && d < 0 ? (this.flipX = !this.flipX, d *= -1) : h === "scaleY" && d < 0 ? (this.flipY = !this.flipY, d *= -1) : h !== "shadow" || !d || d instanceof o.Shadow ? h === "dirty" && this.group && this.group.set("dirty", d) : d = new o.Shadow(d), this[h] = d, y && (b = this.group && this.group.isOnACache(), this.cacheProperties.indexOf(h) > -1 ? (this.dirty = !0, b && this.group.set("dirty", !0)) : b && this.stateProperties.indexOf(h) > -1 && this.group.set("dirty", !0)), this;
    }, setOnGroup: function() {
    }, getViewportTransform: function() {
      return this.canvas && this.canvas.viewportTransform ? this.canvas.viewportTransform : o.iMatrix.concat();
    }, isNotVisible: function() {
      return this.opacity === 0 || !this.width && !this.height && this.strokeWidth === 0 || !this.visible;
    }, render: function(h) {
      this.isNotVisible() || this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (h.save(), this._setupCompositeOperation(h), this.drawSelectionBackground(h), this.transform(h), this._setOpacity(h), this._setShadow(h, this), this.shouldCache() ? (this.renderCache(), this.drawCacheOnCanvas(h)) : (this._removeCacheCanvas(), this.dirty = !1, this.drawObject(h), this.objectCaching && this.statefullCache && this.saveState({ propertySet: "cacheProperties" })), h.restore());
    }, renderCache: function(h) {
      h = h || {}, this._cacheCanvas || this._createCacheCanvas(), this.isCacheDirty() && (this.statefullCache && this.saveState({ propertySet: "cacheProperties" }), this.drawObject(this._cacheContext, h.forClipping), this.dirty = !1);
    }, _removeCacheCanvas: function() {
      this._cacheCanvas = null, this.cacheWidth = 0, this.cacheHeight = 0;
    }, hasStroke: function() {
      return this.stroke && this.stroke !== "transparent" && this.strokeWidth !== 0;
    }, hasFill: function() {
      return this.fill && this.fill !== "transparent";
    }, needsItsOwnCache: function() {
      return !(this.paintFirst !== "stroke" || !this.hasFill() || !this.hasStroke() || typeof this.shadow != "object") || !!this.clipPath;
    }, shouldCache: function() {
      return this.ownCaching = this.needsItsOwnCache() || this.objectCaching && (!this.group || !this.group.isOnACache()), this.ownCaching;
    }, willDrawShadow: function() {
      return !!this.shadow && (this.shadow.offsetX !== 0 || this.shadow.offsetY !== 0);
    }, drawClipPathOnCache: function(h) {
      var d = this.clipPath;
      if (h.save(), d.inverted ? h.globalCompositeOperation = "destination-out" : h.globalCompositeOperation = "destination-in", d.absolutePositioned) {
        var m = o.util.invertTransform(this.calcTransformMatrix());
        h.transform(m[0], m[1], m[2], m[3], m[4], m[5]);
      }
      d.transform(h), h.scale(1 / d.zoomX, 1 / d.zoomY), h.drawImage(d._cacheCanvas, -d.cacheTranslationX, -d.cacheTranslationY), h.restore();
    }, drawObject: function(h, d) {
      var m = this.fill, y = this.stroke;
      d ? (this.fill = "black", this.stroke = "", this._setClippingProperties(h)) : this._renderBackground(h), this._render(h), this._drawClipPath(h), this.fill = m, this.stroke = y;
    }, _drawClipPath: function(h) {
      var d = this.clipPath;
      d && (d.canvas = this.canvas, d.shouldCache(), d._transformDone = !0, d.renderCache({ forClipping: !0 }), this.drawClipPathOnCache(h));
    }, drawCacheOnCanvas: function(h) {
      h.scale(1 / this.zoomX, 1 / this.zoomY), h.drawImage(this._cacheCanvas, -this.cacheTranslationX, -this.cacheTranslationY);
    }, isCacheDirty: function(h) {
      if (this.isNotVisible()) return !1;
      if (this._cacheCanvas && !h && this._updateCacheCanvas()) return !0;
      if (this.dirty || this.clipPath && this.clipPath.absolutePositioned || this.statefullCache && this.hasStateChanged("cacheProperties")) {
        if (this._cacheCanvas && !h) {
          var d = this.cacheWidth / this.zoomX, m = this.cacheHeight / this.zoomY;
          this._cacheContext.clearRect(-d / 2, -m / 2, d, m);
        }
        return !0;
      }
      return !1;
    }, _renderBackground: function(h) {
      if (this.backgroundColor) {
        var d = this._getNonTransformedDimensions();
        h.fillStyle = this.backgroundColor, h.fillRect(-d.x / 2, -d.y / 2, d.x, d.y), this._removeShadow(h);
      }
    }, _setOpacity: function(h) {
      this.group && !this.group._transformDone ? h.globalAlpha = this.getObjectOpacity() : h.globalAlpha *= this.opacity;
    }, _setStrokeStyles: function(h, d) {
      var m = d.stroke;
      m && (h.lineWidth = d.strokeWidth, h.lineCap = d.strokeLineCap, h.lineDashOffset = d.strokeDashOffset, h.lineJoin = d.strokeLineJoin, h.miterLimit = d.strokeMiterLimit, m.toLive ? m.gradientUnits === "percentage" || m.gradientTransform || m.patternTransform ? this._applyPatternForTransformedGradient(h, m) : (h.strokeStyle = m.toLive(h, this), this._applyPatternGradientTransform(h, m)) : h.strokeStyle = d.stroke);
    }, _setFillStyles: function(h, d) {
      var m = d.fill;
      m && (m.toLive ? (h.fillStyle = m.toLive(h, this), this._applyPatternGradientTransform(h, d.fill)) : h.fillStyle = m);
    }, _setClippingProperties: function(h) {
      h.globalAlpha = 1, h.strokeStyle = "transparent", h.fillStyle = "#000000";
    }, _setLineDash: function(h, d) {
      d && d.length !== 0 && (1 & d.length && d.push.apply(d, d), h.setLineDash(d));
    }, _renderControls: function(h, d) {
      var m, y, b, S = this.getViewportTransform(), E = this.calcTransformMatrix();
      y = (d = d || {}).hasBorders !== void 0 ? d.hasBorders : this.hasBorders, b = d.hasControls !== void 0 ? d.hasControls : this.hasControls, E = o.util.multiplyTransformMatrices(S, E), m = o.util.qrDecompose(E), h.save(), h.translate(m.translateX, m.translateY), h.lineWidth = 1 * this.borderScaleFactor, this.group || (h.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1), h.rotate(s(m.angle)), d.forActiveSelection || this.group ? y && this.drawBordersInGroup(h, m, d) : y && this.drawBorders(h, d), b && this.drawControls(h, d), h.restore();
    }, _setShadow: function(h) {
      if (this.shadow) {
        var d, m = this.shadow, y = this.canvas, b = y && y.viewportTransform[0] || 1, S = y && y.viewportTransform[3] || 1;
        d = m.nonScaling ? { scaleX: 1, scaleY: 1 } : this.getObjectScaling(), y && y._isRetinaScaling() && (b *= o.devicePixelRatio, S *= o.devicePixelRatio), h.shadowColor = m.color, h.shadowBlur = m.blur * o.browserShadowBlurConstant * (b + S) * (d.scaleX + d.scaleY) / 4, h.shadowOffsetX = m.offsetX * b * d.scaleX, h.shadowOffsetY = m.offsetY * S * d.scaleY;
      }
    }, _removeShadow: function(h) {
      this.shadow && (h.shadowColor = "", h.shadowBlur = h.shadowOffsetX = h.shadowOffsetY = 0);
    }, _applyPatternGradientTransform: function(h, d) {
      if (!d || !d.toLive) return { offsetX: 0, offsetY: 0 };
      var m = d.gradientTransform || d.patternTransform, y = -this.width / 2 + d.offsetX || 0, b = -this.height / 2 + d.offsetY || 0;
      return d.gradientUnits === "percentage" ? h.transform(this.width, 0, 0, this.height, y, b) : h.transform(1, 0, 0, 1, y, b), m && h.transform(m[0], m[1], m[2], m[3], m[4], m[5]), { offsetX: y, offsetY: b };
    }, _renderPaintInOrder: function(h) {
      this.paintFirst === "stroke" ? (this._renderStroke(h), this._renderFill(h)) : (this._renderFill(h), this._renderStroke(h));
    }, _render: function() {
    }, _renderFill: function(h) {
      this.fill && (h.save(), this._setFillStyles(h, this), this.fillRule === "evenodd" ? h.fill("evenodd") : h.fill(), h.restore());
    }, _renderStroke: function(h) {
      if (this.stroke && this.strokeWidth !== 0) {
        if (this.shadow && !this.shadow.affectStroke && this._removeShadow(h), h.save(), this.strokeUniform && this.group) {
          var d = this.getObjectScaling();
          h.scale(1 / d.scaleX, 1 / d.scaleY);
        } else this.strokeUniform && h.scale(1 / this.scaleX, 1 / this.scaleY);
        this._setLineDash(h, this.strokeDashArray), this._setStrokeStyles(h, this), h.stroke(), h.restore();
      }
    }, _applyPatternForTransformedGradient: function(h, d) {
      var m, y = this._limitCacheSize(this._getCacheCanvasDimensions()), b = o.util.createCanvasElement(), S = this.canvas.getRetinaScaling(), E = y.x / this.scaleX / S, A = y.y / this.scaleY / S;
      b.width = E, b.height = A, (m = b.getContext("2d")).beginPath(), m.moveTo(0, 0), m.lineTo(E, 0), m.lineTo(E, A), m.lineTo(0, A), m.closePath(), m.translate(E / 2, A / 2), m.scale(y.zoomX / this.scaleX / S, y.zoomY / this.scaleY / S), this._applyPatternGradientTransform(m, d), m.fillStyle = d.toLive(h), m.fill(), h.translate(-this.width / 2 - this.strokeWidth / 2, -this.height / 2 - this.strokeWidth / 2), h.scale(S * this.scaleX / y.zoomX, S * this.scaleY / y.zoomY), h.strokeStyle = m.createPattern(b, "no-repeat");
    }, _findCenterFromElement: function() {
      return { x: this.left + this.width / 2, y: this.top + this.height / 2 };
    }, _assignTransformMatrixProps: function() {
      if (this.transformMatrix) {
        var h = o.util.qrDecompose(this.transformMatrix);
        this.flipX = !1, this.flipY = !1, this.set("scaleX", h.scaleX), this.set("scaleY", h.scaleY), this.angle = h.angle, this.skewX = h.skewX, this.skewY = 0;
      }
    }, _removeTransformMatrix: function(h) {
      var d = this._findCenterFromElement();
      this.transformMatrix && (this._assignTransformMatrixProps(), d = o.util.transformPoint(d, this.transformMatrix)), this.transformMatrix = null, h && (this.scaleX *= h.scaleX, this.scaleY *= h.scaleY, this.cropX = h.cropX, this.cropY = h.cropY, d.x += h.offsetLeft, d.y += h.offsetTop, this.width = h.width, this.height = h.height), this.setPositionByOrigin(d, "center", "center");
    }, clone: function(h, d) {
      var m = this.toObject(d);
      this.constructor.fromObject ? this.constructor.fromObject(m, h) : o.Object._fromObject("Object", m, h);
    }, cloneAsImage: function(h, d) {
      var m = this.toCanvasElement(d);
      return h && h(new o.Image(m)), this;
    }, toCanvasElement: function(h) {
      h || (h = {});
      var d = o.util, m = d.saveObjectTransform(this), y = this.group, b = this.shadow, S = Math.abs, E = (h.multiplier || 1) * (h.enableRetinaScaling ? o.devicePixelRatio : 1);
      delete this.group, h.withoutTransform && d.resetObjectTransform(this), h.withoutShadow && (this.shadow = null);
      var A, M, C, O, N = o.util.createCanvasElement(), z = this.getBoundingRect(!0, !0), W = this.shadow, F = { x: 0, y: 0 };
      W && (M = W.blur, A = W.nonScaling ? { scaleX: 1, scaleY: 1 } : this.getObjectScaling(), F.x = 2 * Math.round(S(W.offsetX) + M) * S(A.scaleX), F.y = 2 * Math.round(S(W.offsetY) + M) * S(A.scaleY)), C = z.width + F.x, O = z.height + F.y, N.width = Math.ceil(C), N.height = Math.ceil(O);
      var k = new o.StaticCanvas(N, { enableRetinaScaling: !1, renderOnAddRemove: !1, skipOffscreen: !1 });
      h.format === "jpeg" && (k.backgroundColor = "#fff"), this.setPositionByOrigin(new o.Point(k.width / 2, k.height / 2), "center", "center");
      var B = this.canvas;
      k.add(this);
      var Z = k.toCanvasElement(E || 1, h);
      return this.shadow = b, this.set("canvas", B), y && (this.group = y), this.set(m).setCoords(), k._objects = [], k.dispose(), k = null, Z;
    }, toDataURL: function(h) {
      return h || (h = {}), o.util.toDataURL(this.toCanvasElement(h), h.format || "png", h.quality || 1);
    }, isType: function(h) {
      return this.type === h;
    }, complexity: function() {
      return 1;
    }, toJSON: function(h) {
      return this.toObject(h);
    }, rotate: function(h) {
      var d = (this.originX !== "center" || this.originY !== "center") && this.centeredRotation;
      return d && this._setOriginToCenter(), this.set("angle", h), d && this._resetOrigin(), this;
    }, centerH: function() {
      return this.canvas && this.canvas.centerObjectH(this), this;
    }, viewportCenterH: function() {
      return this.canvas && this.canvas.viewportCenterObjectH(this), this;
    }, centerV: function() {
      return this.canvas && this.canvas.centerObjectV(this), this;
    }, viewportCenterV: function() {
      return this.canvas && this.canvas.viewportCenterObjectV(this), this;
    }, center: function() {
      return this.canvas && this.canvas.centerObject(this), this;
    }, viewportCenter: function() {
      return this.canvas && this.canvas.viewportCenterObject(this), this;
    }, getLocalPointer: function(h, d) {
      d = d || this.canvas.getPointer(h);
      var m = new o.Point(d.x, d.y), y = this._getLeftTopCoords();
      return this.angle && (m = o.util.rotatePoint(m, y, s(-this.angle))), { x: m.x - y.x, y: m.y - y.y };
    }, _setupCompositeOperation: function(h) {
      this.globalCompositeOperation && (h.globalCompositeOperation = this.globalCompositeOperation);
    } }), o.util.createAccessors && o.util.createAccessors(o.Object), l(o.Object.prototype, o.Observable), o.Object.NUM_FRACTION_DIGITS = 2, o.Object._fromObject = function(h, d, m, y) {
      var b = o[h];
      d = f(d, !0), o.util.enlivenPatterns([d.fill, d.stroke], function(S) {
        S[0] !== void 0 && (d.fill = S[0]), S[1] !== void 0 && (d.stroke = S[1]), o.util.enlivenObjects([d.clipPath], function(E) {
          d.clipPath = E[0];
          var A = y ? new b(d[y], d) : new b(d);
          m && m(A);
        });
      });
    }, o.Object.__uid = 0);
  }(t), function() {
    var c = v.util.degreesToRadians, o = { left: -0.5, center: 0, right: 0.5 }, l = { top: -0.5, center: 0, bottom: 0.5 };
    v.util.object.extend(v.Object.prototype, { translateToGivenOrigin: function(f, i, r, s, u) {
      var h, d, m, y = f.x, b = f.y;
      return typeof i == "string" ? i = o[i] : i -= 0.5, typeof s == "string" ? s = o[s] : s -= 0.5, typeof r == "string" ? r = l[r] : r -= 0.5, typeof u == "string" ? u = l[u] : u -= 0.5, d = u - r, ((h = s - i) || d) && (m = this._getTransformedDimensions(), y = f.x + h * m.x, b = f.y + d * m.y), new v.Point(y, b);
    }, translateToCenterPoint: function(f, i, r) {
      var s = this.translateToGivenOrigin(f, i, r, "center", "center");
      return this.angle ? v.util.rotatePoint(s, f, c(this.angle)) : s;
    }, translateToOriginPoint: function(f, i, r) {
      var s = this.translateToGivenOrigin(f, "center", "center", i, r);
      return this.angle ? v.util.rotatePoint(s, f, c(this.angle)) : s;
    }, getCenterPoint: function() {
      var f = new v.Point(this.left, this.top);
      return this.translateToCenterPoint(f, this.originX, this.originY);
    }, getPointByOrigin: function(f, i) {
      var r = this.getCenterPoint();
      return this.translateToOriginPoint(r, f, i);
    }, toLocalPoint: function(f, i, r) {
      var s, u, h = this.getCenterPoint();
      return s = i !== void 0 && r !== void 0 ? this.translateToGivenOrigin(h, "center", "center", i, r) : new v.Point(this.left, this.top), u = new v.Point(f.x, f.y), this.angle && (u = v.util.rotatePoint(u, h, -c(this.angle))), u.subtractEquals(s);
    }, setPositionByOrigin: function(f, i, r) {
      var s = this.translateToCenterPoint(f, i, r), u = this.translateToOriginPoint(s, this.originX, this.originY);
      this.set("left", u.x), this.set("top", u.y);
    }, adjustPosition: function(f) {
      var i, r, s = c(this.angle), u = this.getScaledWidth(), h = v.util.cos(s) * u, d = v.util.sin(s) * u;
      i = typeof this.originX == "string" ? o[this.originX] : this.originX - 0.5, r = typeof f == "string" ? o[f] : f - 0.5, this.left += h * (r - i), this.top += d * (r - i), this.setCoords(), this.originX = f;
    }, _setOriginToCenter: function() {
      this._originalOriginX = this.originX, this._originalOriginY = this.originY;
      var f = this.getCenterPoint();
      this.originX = "center", this.originY = "center", this.left = f.x, this.top = f.y;
    }, _resetOrigin: function() {
      var f = this.translateToOriginPoint(this.getCenterPoint(), this._originalOriginX, this._originalOriginY);
      this.originX = this._originalOriginX, this.originY = this._originalOriginY, this.left = f.x, this.top = f.y, this._originalOriginX = null, this._originalOriginY = null;
    }, _getLeftTopCoords: function() {
      return this.translateToOriginPoint(this.getCenterPoint(), "left", "top");
    } });
  }(), function() {
    var c = v.util, o = c.degreesToRadians, l = c.multiplyTransformMatrices, f = c.transformPoint;
    c.object.extend(v.Object.prototype, { oCoords: null, aCoords: null, lineCoords: null, ownMatrixCache: null, matrixCache: null, controls: {}, _getCoords: function(i, r) {
      return r ? i ? this.calcACoords() : this.calcLineCoords() : (this.aCoords && this.lineCoords || this.setCoords(!0), i ? this.aCoords : this.lineCoords);
    }, getCoords: function(i, r) {
      return s = this._getCoords(i, r), [new v.Point(s.tl.x, s.tl.y), new v.Point(s.tr.x, s.tr.y), new v.Point(s.br.x, s.br.y), new v.Point(s.bl.x, s.bl.y)];
      var s;
    }, intersectsWithRect: function(i, r, s, u) {
      var h = this.getCoords(s, u);
      return v.Intersection.intersectPolygonRectangle(h, i, r).status === "Intersection";
    }, intersectsWithObject: function(i, r, s) {
      return v.Intersection.intersectPolygonPolygon(this.getCoords(r, s), i.getCoords(r, s)).status === "Intersection" || i.isContainedWithinObject(this, r, s) || this.isContainedWithinObject(i, r, s);
    }, isContainedWithinObject: function(i, r, s) {
      for (var u = this.getCoords(r, s), h = r ? i.aCoords : i.lineCoords, d = 0, m = i._getImageLines(h); d < 4; d++) if (!i.containsPoint(u[d], m)) return !1;
      return !0;
    }, isContainedWithinRect: function(i, r, s, u) {
      var h = this.getBoundingRect(s, u);
      return h.left >= i.x && h.left + h.width <= r.x && h.top >= i.y && h.top + h.height <= r.y;
    }, containsPoint: function(i, r, s, u) {
      var h = this._getCoords(s, u), d = (r = r || this._getImageLines(h), this._findCrossPoints(i, r));
      return d !== 0 && d % 2 == 1;
    }, isOnScreen: function(i) {
      if (!this.canvas) return !1;
      var r = this.canvas.vptCoords.tl, s = this.canvas.vptCoords.br;
      return !!this.getCoords(!0, i).some(function(u) {
        return u.x <= s.x && u.x >= r.x && u.y <= s.y && u.y >= r.y;
      }) || !!this.intersectsWithRect(r, s, !0, i) || this._containsCenterOfCanvas(r, s, i);
    }, _containsCenterOfCanvas: function(i, r, s) {
      var u = { x: (i.x + r.x) / 2, y: (i.y + r.y) / 2 };
      return !!this.containsPoint(u, null, !0, s);
    }, isPartiallyOnScreen: function(i) {
      if (!this.canvas) return !1;
      var r = this.canvas.vptCoords.tl, s = this.canvas.vptCoords.br;
      return !!this.intersectsWithRect(r, s, !0, i) || this.getCoords(!0, i).every(function(u) {
        return (u.x >= s.x || u.x <= r.x) && (u.y >= s.y || u.y <= r.y);
      }) && this._containsCenterOfCanvas(r, s, i);
    }, _getImageLines: function(i) {
      return { topline: { o: i.tl, d: i.tr }, rightline: { o: i.tr, d: i.br }, bottomline: { o: i.br, d: i.bl }, leftline: { o: i.bl, d: i.tl } };
    }, _findCrossPoints: function(i, r) {
      var s, u, h, d = 0;
      for (var m in r) if (!((h = r[m]).o.y < i.y && h.d.y < i.y || h.o.y >= i.y && h.d.y >= i.y || (h.o.x === h.d.x && h.o.x >= i.x ? u = h.o.x : (s = (h.d.y - h.o.y) / (h.d.x - h.o.x), u = -(i.y - 0 * i.x - (h.o.y - s * h.o.x)) / (0 - s)), u >= i.x && (d += 1), d !== 2))) break;
      return d;
    }, getBoundingRect: function(i, r) {
      var s = this.getCoords(i, r);
      return c.makeBoundingBoxFromPoints(s);
    }, getScaledWidth: function() {
      return this._getTransformedDimensions().x;
    }, getScaledHeight: function() {
      return this._getTransformedDimensions().y;
    }, _constrainScale: function(i) {
      return Math.abs(i) < this.minScaleLimit ? i < 0 ? -this.minScaleLimit : this.minScaleLimit : i === 0 ? 1e-4 : i;
    }, scale: function(i) {
      return this._set("scaleX", i), this._set("scaleY", i), this.setCoords();
    }, scaleToWidth: function(i, r) {
      var s = this.getBoundingRect(r).width / this.getScaledWidth();
      return this.scale(i / this.width / s);
    }, scaleToHeight: function(i, r) {
      var s = this.getBoundingRect(r).height / this.getScaledHeight();
      return this.scale(i / this.height / s);
    }, calcCoords: function(i) {
      return i ? this.calcACoords() : this.calcOCoords();
    }, calcLineCoords: function() {
      var i = this.getViewportTransform(), r = this.padding, s = o(this.angle), u = c.cos(s) * r, h = c.sin(s) * r, d = u + h, m = u - h, y = this.calcACoords(), b = { tl: f(y.tl, i), tr: f(y.tr, i), bl: f(y.bl, i), br: f(y.br, i) };
      return r && (b.tl.x -= m, b.tl.y -= d, b.tr.x += d, b.tr.y -= m, b.bl.x -= d, b.bl.y += m, b.br.x += m, b.br.y += d), b;
    }, calcOCoords: function() {
      var i = this._calcRotateMatrix(), r = this._calcTranslateMatrix(), s = this.getViewportTransform(), u = l(s, r), h = l(u, i), d = (h = l(h, [1 / s[0], 0, 0, 1 / s[3], 0, 0]), this._calculateCurrentDimensions()), m = {};
      return this.forEachControl(function(y, b, S) {
        m[b] = y.positionHandler(d, h, S);
      }), m;
    }, calcACoords: function() {
      var i = this._calcRotateMatrix(), r = this._calcTranslateMatrix(), s = l(r, i), u = this._getTransformedDimensions(), h = u.x / 2, d = u.y / 2;
      return { tl: f({ x: -h, y: -d }, s), tr: f({ x: h, y: -d }, s), bl: f({ x: -h, y: d }, s), br: f({ x: h, y: d }, s) };
    }, setCoords: function(i) {
      return this.aCoords = this.calcACoords(), this.lineCoords = this.group ? this.aCoords : this.calcLineCoords(), i || (this.oCoords = this.calcOCoords(), this._setCornerCoords && this._setCornerCoords()), this;
    }, _calcRotateMatrix: function() {
      return c.calcRotateMatrix(this);
    }, _calcTranslateMatrix: function() {
      var i = this.getCenterPoint();
      return [1, 0, 0, 1, i.x, i.y];
    }, transformMatrixKey: function(i) {
      var r = "_", s = "";
      return !i && this.group && (s = this.group.transformMatrixKey(i) + r), s + this.top + r + this.left + r + this.scaleX + r + this.scaleY + r + this.skewX + r + this.skewY + r + this.angle + r + this.originX + r + this.originY + r + this.width + r + this.height + r + this.strokeWidth + this.flipX + this.flipY;
    }, calcTransformMatrix: function(i) {
      var r = this.calcOwnMatrix();
      if (i || !this.group) return r;
      var s = this.transformMatrixKey(i), u = this.matrixCache || (this.matrixCache = {});
      return u.key === s ? u.value : (this.group && (r = l(this.group.calcTransformMatrix(!1), r)), u.key = s, u.value = r, r);
    }, calcOwnMatrix: function() {
      var i = this.transformMatrixKey(!0), r = this.ownMatrixCache || (this.ownMatrixCache = {});
      if (r.key === i) return r.value;
      var s = this._calcTranslateMatrix(), u = { angle: this.angle, translateX: s[4], translateY: s[5], scaleX: this.scaleX, scaleY: this.scaleY, skewX: this.skewX, skewY: this.skewY, flipX: this.flipX, flipY: this.flipY };
      return r.key = i, r.value = c.composeMatrix(u), r.value;
    }, _calcDimensionsTransformMatrix: function(i, r, s) {
      return c.calcDimensionsMatrix({ skewX: i, skewY: r, scaleX: this.scaleX * (s && this.flipX ? -1 : 1), scaleY: this.scaleY * (s && this.flipY ? -1 : 1) });
    }, _getNonTransformedDimensions: function() {
      var i = this.strokeWidth;
      return { x: this.width + i, y: this.height + i };
    }, _getTransformedDimensions: function(i, r) {
      i === void 0 && (i = this.skewX), r === void 0 && (r = this.skewY);
      var s, u, h, d = i === 0 && r === 0;
      if (this.strokeUniform ? (u = this.width, h = this.height) : (u = (s = this._getNonTransformedDimensions()).x, h = s.y), d) return this._finalizeDimensions(u * this.scaleX, h * this.scaleY);
      var m = c.sizeAfterTransform(u, h, { scaleX: this.scaleX, scaleY: this.scaleY, skewX: i, skewY: r });
      return this._finalizeDimensions(m.x, m.y);
    }, _finalizeDimensions: function(i, r) {
      return this.strokeUniform ? { x: i + this.strokeWidth, y: r + this.strokeWidth } : { x: i, y: r };
    }, _calculateCurrentDimensions: function() {
      var i = this.getViewportTransform(), r = this._getTransformedDimensions();
      return f(r, i, !0).scalarAdd(2 * this.padding);
    } });
  }(), v.util.object.extend(v.Object.prototype, { sendToBack: function() {
    return this.group ? v.StaticCanvas.prototype.sendToBack.call(this.group, this) : this.canvas && this.canvas.sendToBack(this), this;
  }, bringToFront: function() {
    return this.group ? v.StaticCanvas.prototype.bringToFront.call(this.group, this) : this.canvas && this.canvas.bringToFront(this), this;
  }, sendBackwards: function(c) {
    return this.group ? v.StaticCanvas.prototype.sendBackwards.call(this.group, this, c) : this.canvas && this.canvas.sendBackwards(this, c), this;
  }, bringForward: function(c) {
    return this.group ? v.StaticCanvas.prototype.bringForward.call(this.group, this, c) : this.canvas && this.canvas.bringForward(this, c), this;
  }, moveTo: function(c) {
    return this.group && this.group.type !== "activeSelection" ? v.StaticCanvas.prototype.moveTo.call(this.group, this, c) : this.canvas && this.canvas.moveTo(this, c), this;
  } }), function() {
    function c(l, f) {
      if (f) {
        if (f.toLive) return l + ": url(#SVGID_" + f.id + "); ";
        var i = new v.Color(f), r = l + ": " + i.toRgb() + "; ", s = i.getAlpha();
        return s !== 1 && (r += l + "-opacity: " + s.toString() + "; "), r;
      }
      return l + ": none; ";
    }
    var o = v.util.toFixed;
    v.util.object.extend(v.Object.prototype, { getSvgStyles: function(l) {
      var f = this.fillRule ? this.fillRule : "nonzero", i = this.strokeWidth ? this.strokeWidth : "0", r = this.strokeDashArray ? this.strokeDashArray.join(" ") : "none", s = this.strokeDashOffset ? this.strokeDashOffset : "0", u = this.strokeLineCap ? this.strokeLineCap : "butt", h = this.strokeLineJoin ? this.strokeLineJoin : "miter", d = this.strokeMiterLimit ? this.strokeMiterLimit : "4", m = this.opacity !== void 0 ? this.opacity : "1", y = this.visible ? "" : " visibility: hidden;", b = l ? "" : this.getSvgFilter(), S = c("fill", this.fill);
      return [c("stroke", this.stroke), "stroke-width: ", i, "; ", "stroke-dasharray: ", r, "; ", "stroke-linecap: ", u, "; ", "stroke-dashoffset: ", s, "; ", "stroke-linejoin: ", h, "; ", "stroke-miterlimit: ", d, "; ", S, "fill-rule: ", f, "; ", "opacity: ", m, ";", b, y].join("");
    }, getSvgSpanStyles: function(l, f) {
      var i = "; ", r = l.fontFamily ? "font-family: " + (l.fontFamily.indexOf("'") === -1 && l.fontFamily.indexOf('"') === -1 ? "'" + l.fontFamily + "'" : l.fontFamily) + i : "", s = l.strokeWidth ? "stroke-width: " + l.strokeWidth + i : "", u = (r = r, l.fontSize ? "font-size: " + l.fontSize + "px" + i : ""), h = l.fontStyle ? "font-style: " + l.fontStyle + i : "", d = l.fontWeight ? "font-weight: " + l.fontWeight + i : "", m = l.fill ? c("fill", l.fill) : "", y = l.stroke ? c("stroke", l.stroke) : "", b = this.getSvgTextDecoration(l);
      return b && (b = "text-decoration: " + b + i), [y, s, r, u, h, d, b, m, l.deltaY ? "baseline-shift: " + -l.deltaY + "; " : "", f ? "white-space: pre; " : ""].join("");
    }, getSvgTextDecoration: function(l) {
      return ["overline", "underline", "line-through"].filter(function(f) {
        return l[f.replace("-", "")];
      }).join(" ");
    }, getSvgFilter: function() {
      return this.shadow ? "filter: url(#SVGID_" + this.shadow.id + ");" : "";
    }, getSvgCommons: function() {
      return [this.id ? 'id="' + this.id + '" ' : "", this.clipPath ? 'clip-path="url(#' + this.clipPath.clipPathId + ')" ' : ""].join("");
    }, getSvgTransform: function(l, f) {
      var i = l ? this.calcTransformMatrix() : this.calcOwnMatrix();
      return 'transform="' + v.util.matrixToSVG(i) + (f || "") + '" ';
    }, _setSVGBg: function(l) {
      if (this.backgroundColor) {
        var f = v.Object.NUM_FRACTION_DIGITS;
        l.push("		<rect ", this._getFillAttributes(this.backgroundColor), ' x="', o(-this.width / 2, f), '" y="', o(-this.height / 2, f), '" width="', o(this.width, f), '" height="', o(this.height, f), `"></rect>
`);
      }
    }, toSVG: function(l) {
      return this._createBaseSVGMarkup(this._toSVG(l), { reviver: l });
    }, toClipPathSVG: function(l) {
      return "	" + this._createBaseClipPathSVGMarkup(this._toSVG(l), { reviver: l });
    }, _createBaseClipPathSVGMarkup: function(l, f) {
      var i = (f = f || {}).reviver, r = f.additionalTransform || "", s = [this.getSvgTransform(!0, r), this.getSvgCommons()].join(""), u = l.indexOf("COMMON_PARTS");
      return l[u] = s, i ? i(l.join("")) : l.join("");
    }, _createBaseSVGMarkup: function(l, f) {
      var i, r, s = (f = f || {}).noStyle, u = f.reviver, h = s ? "" : 'style="' + this.getSvgStyles() + '" ', d = f.withShadow ? 'style="' + this.getSvgFilter() + '" ' : "", m = this.clipPath, y = this.strokeUniform ? 'vector-effect="non-scaling-stroke" ' : "", b = m && m.absolutePositioned, S = this.stroke, E = this.fill, A = this.shadow, M = [], C = l.indexOf("COMMON_PARTS"), O = f.additionalTransform;
      return m && (m.clipPathId = "CLIPPATH_" + v.Object.__uid++, r = '<clipPath id="' + m.clipPathId + `" >
` + m.toClipPathSVG(u) + `</clipPath>
`), b && M.push("<g ", d, this.getSvgCommons(), ` >
`), M.push("<g ", this.getSvgTransform(!1), b ? "" : d + this.getSvgCommons(), ` >
`), i = [h, y, s ? "" : this.addPaintOrder(), " ", O ? 'transform="' + O + '" ' : ""].join(""), l[C] = i, E && E.toLive && M.push(E.toSVG(this)), S && S.toLive && M.push(S.toSVG(this)), A && M.push(A.toSVG(this)), m && M.push(r), M.push(l.join("")), M.push(`</g>
`), b && M.push(`</g>
`), u ? u(M.join("")) : M.join("");
    }, addPaintOrder: function() {
      return this.paintFirst !== "fill" ? ' paint-order="' + this.paintFirst + '" ' : "";
    } });
  }(), function() {
    var c = v.util.object.extend, o = "stateProperties";
    function l(i, r, s) {
      var u = {};
      s.forEach(function(h) {
        u[h] = i[h];
      }), c(i[r], u, !0);
    }
    function f(i, r, s) {
      if (i === r) return !0;
      if (Array.isArray(i)) {
        if (!Array.isArray(r) || i.length !== r.length) return !1;
        for (var u = 0, h = i.length; u < h; u++) if (!f(i[u], r[u])) return !1;
        return !0;
      }
      if (i && typeof i == "object") {
        var d, m = Object.keys(i);
        if (!r || typeof r != "object" || !s && m.length !== Object.keys(r).length) return !1;
        for (u = 0, h = m.length; u < h; u++) if ((d = m[u]) !== "canvas" && d !== "group" && !f(i[d], r[d])) return !1;
        return !0;
      }
    }
    v.util.object.extend(v.Object.prototype, { hasStateChanged: function(i) {
      var r = "_" + (i = i || o);
      return Object.keys(this[r]).length < this[i].length || !f(this[r], this, !0);
    }, saveState: function(i) {
      var r = i && i.propertySet || o, s = "_" + r;
      return this[s] ? (l(this, s, this[r]), i && i.stateProperties && l(this, s, i.stateProperties), this) : this.setupState(i);
    }, setupState: function(i) {
      var r = (i = i || {}).propertySet || o;
      return i.propertySet = r, this["_" + r] = {}, this.saveState(i), this;
    } });
  }(), function() {
    var c = v.util.degreesToRadians;
    v.util.object.extend(v.Object.prototype, { _findTargetCorner: function(o, l) {
      if (!this.hasControls || this.group || !this.canvas || this.canvas._activeObject !== this) return !1;
      var f, i, r, s = o.x, u = o.y, h = Object.keys(this.oCoords), d = h.length - 1;
      for (this.__corner = 0; d >= 0; d--) if (r = h[d], this.isControlVisible(r) && (i = this._getImageLines(l ? this.oCoords[r].touchCorner : this.oCoords[r].corner), (f = this._findCrossPoints({ x: s, y: u }, i)) !== 0 && f % 2 == 1)) return this.__corner = r, r;
      return !1;
    }, forEachControl: function(o) {
      for (var l in this.controls) o(this.controls[l], l, this);
    }, _setCornerCoords: function() {
      var o = this.oCoords;
      for (var l in o) {
        var f = this.controls[l];
        o[l].corner = f.calcCornerCoords(this.angle, this.cornerSize, o[l].x, o[l].y, !1), o[l].touchCorner = f.calcCornerCoords(this.angle, this.touchCornerSize, o[l].x, o[l].y, !0);
      }
    }, drawSelectionBackground: function(o) {
      if (!this.selectionBackgroundColor || this.canvas && !this.canvas.interactive || this.canvas && this.canvas._activeObject !== this) return this;
      o.save();
      var l = this.getCenterPoint(), f = this._calculateCurrentDimensions(), i = this.canvas.viewportTransform;
      return o.translate(l.x, l.y), o.scale(1 / i[0], 1 / i[3]), o.rotate(c(this.angle)), o.fillStyle = this.selectionBackgroundColor, o.fillRect(-f.x / 2, -f.y / 2, f.x, f.y), o.restore(), this;
    }, drawBorders: function(o, l) {
      l = l || {};
      var f = this._calculateCurrentDimensions(), i = this.borderScaleFactor, r = f.x + i, s = f.y + i, u = l.hasControls !== void 0 ? l.hasControls : this.hasControls, h = !1;
      return o.save(), o.strokeStyle = l.borderColor || this.borderColor, this._setLineDash(o, l.borderDashArray || this.borderDashArray), o.strokeRect(-r / 2, -s / 2, r, s), u && (o.beginPath(), this.forEachControl(function(d, m, y) {
        d.withConnection && d.getVisibility(y, m) && (h = !0, o.moveTo(d.x * r, d.y * s), o.lineTo(d.x * r + d.offsetX, d.y * s + d.offsetY));
      }), h && o.stroke()), o.restore(), this;
    }, drawBordersInGroup: function(o, l, f) {
      f = f || {};
      var i = v.util.sizeAfterTransform(this.width, this.height, l), r = this.strokeWidth, s = this.strokeUniform, u = this.borderScaleFactor, h = i.x + r * (s ? this.canvas.getZoom() : l.scaleX) + u, d = i.y + r * (s ? this.canvas.getZoom() : l.scaleY) + u;
      return o.save(), this._setLineDash(o, f.borderDashArray || this.borderDashArray), o.strokeStyle = f.borderColor || this.borderColor, o.strokeRect(-h / 2, -d / 2, h, d), o.restore(), this;
    }, drawControls: function(o, l) {
      l = l || {}, o.save();
      var f, i, r = this.canvas.getRetinaScaling();
      return o.setTransform(r, 0, 0, r, 0, 0), o.strokeStyle = o.fillStyle = l.cornerColor || this.cornerColor, this.transparentCorners || (o.strokeStyle = l.cornerStrokeColor || this.cornerStrokeColor), this._setLineDash(o, l.cornerDashArray || this.cornerDashArray), this.setCoords(), this.group && (f = this.group.calcTransformMatrix()), this.forEachControl(function(s, u, h) {
        i = h.oCoords[u], s.getVisibility(h, u) && (f && (i = v.util.transformPoint(i, f)), s.render(o, i.x, i.y, l, h));
      }), o.restore(), this;
    }, isControlVisible: function(o) {
      return this.controls[o] && this.controls[o].getVisibility(this, o);
    }, setControlVisible: function(o, l) {
      return this._controlsVisibility || (this._controlsVisibility = {}), this._controlsVisibility[o] = l, this;
    }, setControlsVisibility: function(o) {
      for (var l in o || (o = {}), o) this.setControlVisible(l, o[l]);
      return this;
    }, onDeselect: function() {
    }, onSelect: function() {
    } });
  }(), v.util.object.extend(v.StaticCanvas.prototype, { FX_DURATION: 500, fxCenterObjectH: function(c, o) {
    var l = function() {
    }, f = (o = o || {}).onComplete || l, i = o.onChange || l, r = this;
    return v.util.animate({ startValue: c.left, endValue: this.getCenter().left, duration: this.FX_DURATION, onChange: function(s) {
      c.set("left", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      c.setCoords(), f();
    } }), this;
  }, fxCenterObjectV: function(c, o) {
    var l = function() {
    }, f = (o = o || {}).onComplete || l, i = o.onChange || l, r = this;
    return v.util.animate({ startValue: c.top, endValue: this.getCenter().top, duration: this.FX_DURATION, onChange: function(s) {
      c.set("top", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      c.setCoords(), f();
    } }), this;
  }, fxRemove: function(c, o) {
    var l = function() {
    }, f = (o = o || {}).onComplete || l, i = o.onChange || l, r = this;
    return v.util.animate({ startValue: c.opacity, endValue: 0, duration: this.FX_DURATION, onChange: function(s) {
      c.set("opacity", s), r.requestRenderAll(), i();
    }, onComplete: function() {
      r.remove(c), f();
    } }), this;
  } }), v.util.object.extend(v.Object.prototype, { animate: function() {
    if (arguments[0] && typeof arguments[0] == "object") {
      var c, o, l = [];
      for (c in arguments[0]) l.push(c);
      for (var f = 0, i = l.length; f < i; f++) c = l[f], o = f !== i - 1, this._animate(c, arguments[0][c], arguments[1], o);
    } else this._animate.apply(this, arguments);
    return this;
  }, _animate: function(c, o, l, f) {
    var i, r = this;
    o = o.toString(), l = l ? v.util.object.clone(l) : {}, ~c.indexOf(".") && (i = c.split("."));
    var s = r.colorProperties.indexOf(c) > -1 || i && r.colorProperties.indexOf(i[1]) > -1, u = i ? this.get(i[0])[i[1]] : this.get(c);
    "from" in l || (l.from = u), s || (o = ~o.indexOf("=") ? u + parseFloat(o.replace("=", "")) : parseFloat(o));
    var h = { startValue: l.from, endValue: o, byValue: l.by, easing: l.easing, duration: l.duration, abort: l.abort && function(d, m, y) {
      return l.abort.call(r, d, m, y);
    }, onChange: function(d, m, y) {
      i ? r[i[0]][i[1]] = d : r.set(c, d), f || l.onChange && l.onChange(d, m, y);
    }, onComplete: function(d, m, y) {
      f || (r.setCoords(), l.onComplete && l.onComplete(d, m, y));
    } };
    return s ? v.util.animateColor(h.startValue, h.endValue, h.duration, h) : v.util.animate(h);
  } }), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.util.object.clone, i = { x1: 1, x2: 1, y1: 1, y2: 1 };
    function r(s, u) {
      var h = s.origin, d = s.axis1, m = s.axis2, y = s.dimension, b = u.nearest, S = u.center, E = u.farthest;
      return function() {
        switch (this.get(h)) {
          case b:
            return Math.min(this.get(d), this.get(m));
          case S:
            return Math.min(this.get(d), this.get(m)) + 0.5 * this.get(y);
          case E:
            return Math.max(this.get(d), this.get(m));
        }
      };
    }
    o.Line ? o.warn("fabric.Line is already defined") : (o.Line = o.util.createClass(o.Object, { type: "line", x1: 0, y1: 0, x2: 0, y2: 0, cacheProperties: o.Object.prototype.cacheProperties.concat("x1", "x2", "y1", "y2"), initialize: function(s, u) {
      s || (s = [0, 0, 0, 0]), this.callSuper("initialize", u), this.set("x1", s[0]), this.set("y1", s[1]), this.set("x2", s[2]), this.set("y2", s[3]), this._setWidthHeight(u);
    }, _setWidthHeight: function(s) {
      s || (s = {}), this.width = Math.abs(this.x2 - this.x1), this.height = Math.abs(this.y2 - this.y1), this.left = "left" in s ? s.left : this._getLeftToOriginX(), this.top = "top" in s ? s.top : this._getTopToOriginY();
    }, _set: function(s, u) {
      return this.callSuper("_set", s, u), i[s] !== void 0 && this._setWidthHeight(), this;
    }, _getLeftToOriginX: r({ origin: "originX", axis1: "x1", axis2: "x2", dimension: "width" }, { nearest: "left", center: "center", farthest: "right" }), _getTopToOriginY: r({ origin: "originY", axis1: "y1", axis2: "y2", dimension: "height" }, { nearest: "top", center: "center", farthest: "bottom" }), _render: function(s) {
      s.beginPath();
      var u = this.calcLinePoints();
      s.moveTo(u.x1, u.y1), s.lineTo(u.x2, u.y2), s.lineWidth = this.strokeWidth;
      var h = s.strokeStyle;
      s.strokeStyle = this.stroke || s.fillStyle, this.stroke && this._renderStroke(s), s.strokeStyle = h;
    }, _findCenterFromElement: function() {
      return { x: (this.x1 + this.x2) / 2, y: (this.y1 + this.y2) / 2 };
    }, toObject: function(s) {
      return l(this.callSuper("toObject", s), this.calcLinePoints());
    }, _getNonTransformedDimensions: function() {
      var s = this.callSuper("_getNonTransformedDimensions");
      return this.strokeLineCap === "butt" && (this.width === 0 && (s.y -= this.strokeWidth), this.height === 0 && (s.x -= this.strokeWidth)), s;
    }, calcLinePoints: function() {
      var s = this.x1 <= this.x2 ? -1 : 1, u = this.y1 <= this.y2 ? -1 : 1, h = s * this.width * 0.5, d = u * this.height * 0.5;
      return { x1: h, x2: s * this.width * -0.5, y1: d, y2: u * this.height * -0.5 };
    }, _toSVG: function() {
      var s = this.calcLinePoints();
      return ["<line ", "COMMON_PARTS", 'x1="', s.x1, '" y1="', s.y1, '" x2="', s.x2, '" y2="', s.y2, `" />
`];
    } }), o.Line.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat("x1 y1 x2 y2".split(" ")), o.Line.fromElement = function(s, u, h) {
      h = h || {};
      var d = o.parseAttributes(s, o.Line.ATTRIBUTE_NAMES), m = [d.x1 || 0, d.y1 || 0, d.x2 || 0, d.y2 || 0];
      u(new o.Line(m, l(d, h)));
    }, o.Line.fromObject = function(s, u) {
      var h = f(s, !0);
      h.points = [s.x1, s.y1, s.x2, s.y2], o.Object._fromObject("Line", h, function(d) {
        delete d.points, u && u(d);
      }, "points");
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = Math.PI;
    o.Circle ? o.warn("fabric.Circle is already defined.") : (o.Circle = o.util.createClass(o.Object, { type: "circle", radius: 0, startAngle: 0, endAngle: 2 * l, cacheProperties: o.Object.prototype.cacheProperties.concat("radius", "startAngle", "endAngle"), _set: function(f, i) {
      return this.callSuper("_set", f, i), f === "radius" && this.setRadius(i), this;
    }, toObject: function(f) {
      return this.callSuper("toObject", ["radius", "startAngle", "endAngle"].concat(f));
    }, _toSVG: function() {
      var f, i = (this.endAngle - this.startAngle) % (2 * l);
      if (i === 0) f = ["<circle ", "COMMON_PARTS", 'cx="0" cy="0" ', 'r="', this.radius, `" />
`];
      else {
        var r = o.util.cos(this.startAngle) * this.radius, s = o.util.sin(this.startAngle) * this.radius, u = o.util.cos(this.endAngle) * this.radius, h = o.util.sin(this.endAngle) * this.radius, d = i > l ? "1" : "0";
        f = ['<path d="M ' + r + " " + s, " A " + this.radius + " " + this.radius, " 0 ", +d + " 1", " " + u + " " + h, '" ', "COMMON_PARTS", ` />
`];
      }
      return f;
    }, _render: function(f) {
      f.beginPath(), f.arc(0, 0, this.radius, this.startAngle, this.endAngle, !1), this._renderPaintInOrder(f);
    }, getRadiusX: function() {
      return this.get("radius") * this.get("scaleX");
    }, getRadiusY: function() {
      return this.get("radius") * this.get("scaleY");
    }, setRadius: function(f) {
      return this.radius = f, this.set("width", 2 * f).set("height", 2 * f);
    } }), o.Circle.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat("cx cy r".split(" ")), o.Circle.fromElement = function(f, i) {
      var r, s = o.parseAttributes(f, o.Circle.ATTRIBUTE_NAMES);
      if (!("radius" in (r = s) && r.radius >= 0)) throw new Error("value of `r` attribute is required and can not be negative");
      s.left = (s.left || 0) - s.radius, s.top = (s.top || 0) - s.radius, i(new o.Circle(s));
    }, o.Circle.fromObject = function(f, i) {
      o.Object._fromObject("Circle", f, i);
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    o.Triangle ? o.warn("fabric.Triangle is already defined") : (o.Triangle = o.util.createClass(o.Object, { type: "triangle", width: 100, height: 100, _render: function(l) {
      var f = this.width / 2, i = this.height / 2;
      l.beginPath(), l.moveTo(-f, i), l.lineTo(0, -i), l.lineTo(f, i), l.closePath(), this._renderPaintInOrder(l);
    }, _toSVG: function() {
      var l = this.width / 2, f = this.height / 2;
      return ["<polygon ", "COMMON_PARTS", 'points="', [-l + " " + f, "0 " + -f, l + " " + f].join(","), '" />'];
    } }), o.Triangle.fromObject = function(l, f) {
      return o.Object._fromObject("Triangle", l, f);
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = 2 * Math.PI;
    o.Ellipse ? o.warn("fabric.Ellipse is already defined.") : (o.Ellipse = o.util.createClass(o.Object, { type: "ellipse", rx: 0, ry: 0, cacheProperties: o.Object.prototype.cacheProperties.concat("rx", "ry"), initialize: function(f) {
      this.callSuper("initialize", f), this.set("rx", f && f.rx || 0), this.set("ry", f && f.ry || 0);
    }, _set: function(f, i) {
      switch (this.callSuper("_set", f, i), f) {
        case "rx":
          this.rx = i, this.set("width", 2 * i);
          break;
        case "ry":
          this.ry = i, this.set("height", 2 * i);
      }
      return this;
    }, getRx: function() {
      return this.get("rx") * this.get("scaleX");
    }, getRy: function() {
      return this.get("ry") * this.get("scaleY");
    }, toObject: function(f) {
      return this.callSuper("toObject", ["rx", "ry"].concat(f));
    }, _toSVG: function() {
      return ["<ellipse ", "COMMON_PARTS", 'cx="0" cy="0" ', 'rx="', this.rx, '" ry="', this.ry, `" />
`];
    }, _render: function(f) {
      f.beginPath(), f.save(), f.transform(1, 0, 0, this.ry / this.rx, 0, 0), f.arc(0, 0, this.rx, 0, l, !1), f.restore(), this._renderPaintInOrder(f);
    } }), o.Ellipse.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat("cx cy rx ry".split(" ")), o.Ellipse.fromElement = function(f, i) {
      var r = o.parseAttributes(f, o.Ellipse.ATTRIBUTE_NAMES);
      r.left = (r.left || 0) - r.rx, r.top = (r.top || 0) - r.ry, i(new o.Ellipse(r));
    }, o.Ellipse.fromObject = function(f, i) {
      o.Object._fromObject("Ellipse", f, i);
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend;
    o.Rect ? o.warn("fabric.Rect is already defined") : (o.Rect = o.util.createClass(o.Object, { stateProperties: o.Object.prototype.stateProperties.concat("rx", "ry"), type: "rect", rx: 0, ry: 0, cacheProperties: o.Object.prototype.cacheProperties.concat("rx", "ry"), initialize: function(f) {
      this.callSuper("initialize", f), this._initRxRy();
    }, _initRxRy: function() {
      this.rx && !this.ry ? this.ry = this.rx : this.ry && !this.rx && (this.rx = this.ry);
    }, _render: function(f) {
      var i = this.rx ? Math.min(this.rx, this.width / 2) : 0, r = this.ry ? Math.min(this.ry, this.height / 2) : 0, s = this.width, u = this.height, h = -this.width / 2, d = -this.height / 2, m = i !== 0 || r !== 0, y = 0.4477152502;
      f.beginPath(), f.moveTo(h + i, d), f.lineTo(h + s - i, d), m && f.bezierCurveTo(h + s - y * i, d, h + s, d + y * r, h + s, d + r), f.lineTo(h + s, d + u - r), m && f.bezierCurveTo(h + s, d + u - y * r, h + s - y * i, d + u, h + s - i, d + u), f.lineTo(h + i, d + u), m && f.bezierCurveTo(h + y * i, d + u, h, d + u - y * r, h, d + u - r), f.lineTo(h, d + r), m && f.bezierCurveTo(h, d + y * r, h + y * i, d, h + i, d), f.closePath(), this._renderPaintInOrder(f);
    }, toObject: function(f) {
      return this.callSuper("toObject", ["rx", "ry"].concat(f));
    }, _toSVG: function() {
      return ["<rect ", "COMMON_PARTS", 'x="', -this.width / 2, '" y="', -this.height / 2, '" rx="', this.rx, '" ry="', this.ry, '" width="', this.width, '" height="', this.height, `" />
`];
    } }), o.Rect.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat("x y rx ry width height".split(" ")), o.Rect.fromElement = function(f, i, r) {
      if (!f) return i(null);
      r = r || {};
      var s = o.parseAttributes(f, o.Rect.ATTRIBUTE_NAMES);
      s.left = s.left || 0, s.top = s.top || 0, s.height = s.height || 0, s.width = s.width || 0;
      var u = new o.Rect(l(r ? o.util.object.clone(r) : {}, s));
      u.visible = u.visible && u.width > 0 && u.height > 0, i(u);
    }, o.Rect.fromObject = function(f, i) {
      return o.Object._fromObject("Rect", f, i);
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.util.array.min, i = o.util.array.max, r = o.util.toFixed;
    o.Polyline ? o.warn("fabric.Polyline is already defined") : (o.Polyline = o.util.createClass(o.Object, { type: "polyline", points: null, cacheProperties: o.Object.prototype.cacheProperties.concat("points"), initialize: function(s, u) {
      u = u || {}, this.points = s || [], this.callSuper("initialize", u), this._setPositionDimensions(u);
    }, _setPositionDimensions: function(s) {
      var u, h = this._calcDimensions(s);
      this.width = h.width, this.height = h.height, s.fromSVG || (u = this.translateToGivenOrigin({ x: h.left - this.strokeWidth / 2, y: h.top - this.strokeWidth / 2 }, "left", "top", this.originX, this.originY)), s.left === void 0 && (this.left = s.fromSVG ? h.left : u.x), s.top === void 0 && (this.top = s.fromSVG ? h.top : u.y), this.pathOffset = { x: h.left + this.width / 2, y: h.top + this.height / 2 };
    }, _calcDimensions: function() {
      var s = this.points, u = f(s, "x") || 0, h = f(s, "y") || 0;
      return { left: u, top: h, width: (i(s, "x") || 0) - u, height: (i(s, "y") || 0) - h };
    }, toObject: function(s) {
      return l(this.callSuper("toObject", s), { points: this.points.concat() });
    }, _toSVG: function() {
      for (var s = [], u = this.pathOffset.x, h = this.pathOffset.y, d = o.Object.NUM_FRACTION_DIGITS, m = 0, y = this.points.length; m < y; m++) s.push(r(this.points[m].x - u, d), ",", r(this.points[m].y - h, d), " ");
      return ["<" + this.type + " ", "COMMON_PARTS", 'points="', s.join(""), `" />
`];
    }, commonRender: function(s) {
      var u, h = this.points.length, d = this.pathOffset.x, m = this.pathOffset.y;
      if (!h || isNaN(this.points[h - 1].y)) return !1;
      s.beginPath(), s.moveTo(this.points[0].x - d, this.points[0].y - m);
      for (var y = 0; y < h; y++) u = this.points[y], s.lineTo(u.x - d, u.y - m);
      return !0;
    }, _render: function(s) {
      this.commonRender(s) && this._renderPaintInOrder(s);
    }, complexity: function() {
      return this.get("points").length;
    } }), o.Polyline.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat(), o.Polyline.fromElementGenerator = function(s) {
      return function(u, h, d) {
        if (!u) return h(null);
        d || (d = {});
        var m = o.parsePointsAttribute(u.getAttribute("points")), y = o.parseAttributes(u, o[s].ATTRIBUTE_NAMES);
        y.fromSVG = !0, h(new o[s](m, l(y, d)));
      };
    }, o.Polyline.fromElement = o.Polyline.fromElementGenerator("Polyline"), o.Polyline.fromObject = function(s, u) {
      return o.Object._fromObject("Polyline", s, u, "points");
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    o.Polygon ? o.warn("fabric.Polygon is already defined") : (o.Polygon = o.util.createClass(o.Polyline, { type: "polygon", _render: function(l) {
      this.commonRender(l) && (l.closePath(), this._renderPaintInOrder(l));
    } }), o.Polygon.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat(), o.Polygon.fromElement = o.Polyline.fromElementGenerator("Polygon"), o.Polygon.fromObject = function(l, f) {
      o.Object._fromObject("Polygon", l, f, "points");
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.array.min, f = o.util.array.max, i = o.util.object.extend, r = Object.prototype.toString, s = o.util.toFixed;
    o.Path ? o.warn("fabric.Path is already defined") : (o.Path = o.util.createClass(o.Object, { type: "path", path: null, cacheProperties: o.Object.prototype.cacheProperties.concat("path", "fillRule"), stateProperties: o.Object.prototype.stateProperties.concat("path"), initialize: function(u, h) {
      h = h || {}, this.callSuper("initialize", h), u || (u = []);
      var d = r.call(u) === "[object Array]";
      this.path = o.util.makePathSimpler(d ? u : o.util.parsePath(u)), this.path && o.Polyline.prototype._setPositionDimensions.call(this, h);
    }, _renderPathCommands: function(u) {
      var h, d = 0, m = 0, y = 0, b = 0, S = 0, E = 0, A = -this.pathOffset.x, M = -this.pathOffset.y;
      u.beginPath();
      for (var C = 0, O = this.path.length; C < O; ++C) switch ((h = this.path[C])[0]) {
        case "L":
          y = h[1], b = h[2], u.lineTo(y + A, b + M);
          break;
        case "M":
          d = y = h[1], m = b = h[2], u.moveTo(y + A, b + M);
          break;
        case "C":
          y = h[5], b = h[6], S = h[3], E = h[4], u.bezierCurveTo(h[1] + A, h[2] + M, S + A, E + M, y + A, b + M);
          break;
        case "Q":
          u.quadraticCurveTo(h[1] + A, h[2] + M, h[3] + A, h[4] + M), y = h[3], b = h[4], S = h[1], E = h[2];
          break;
        case "z":
        case "Z":
          y = d, b = m, u.closePath();
      }
    }, _render: function(u) {
      this._renderPathCommands(u), this._renderPaintInOrder(u);
    }, toString: function() {
      return "#<fabric.Path (" + this.complexity() + '): { "top": ' + this.top + ', "left": ' + this.left + " }>";
    }, toObject: function(u) {
      return i(this.callSuper("toObject", u), { path: this.path.map(function(h) {
        return h.slice();
      }) });
    }, toDatalessObject: function(u) {
      var h = this.toObject(["sourcePath"].concat(u));
      return h.sourcePath && delete h.path, h;
    }, _toSVG: function() {
      return ["<path ", "COMMON_PARTS", 'd="', o.util.joinPath(this.path), '" stroke-linecap="round" ', `/>
`];
    }, _getOffsetTransform: function() {
      var u = o.Object.NUM_FRACTION_DIGITS;
      return " translate(" + s(-this.pathOffset.x, u) + ", " + s(-this.pathOffset.y, u) + ")";
    }, toClipPathSVG: function(u) {
      var h = this._getOffsetTransform();
      return "	" + this._createBaseClipPathSVGMarkup(this._toSVG(), { reviver: u, additionalTransform: h });
    }, toSVG: function(u) {
      var h = this._getOffsetTransform();
      return this._createBaseSVGMarkup(this._toSVG(), { reviver: u, additionalTransform: h });
    }, complexity: function() {
      return this.path.length;
    }, _calcDimensions: function() {
      for (var u, h, d = [], m = [], y = 0, b = 0, S = 0, E = 0, A = 0, M = this.path.length; A < M; ++A) {
        switch ((u = this.path[A])[0]) {
          case "L":
            S = u[1], E = u[2], h = [];
            break;
          case "M":
            y = S = u[1], b = E = u[2], h = [];
            break;
          case "C":
            h = o.util.getBoundsOfCurve(S, E, u[1], u[2], u[3], u[4], u[5], u[6]), S = u[5], E = u[6];
            break;
          case "Q":
            h = o.util.getBoundsOfCurve(S, E, u[1], u[2], u[1], u[2], u[3], u[4]), S = u[3], E = u[4];
            break;
          case "z":
          case "Z":
            S = y, E = b;
        }
        h.forEach(function(N) {
          d.push(N.x), m.push(N.y);
        }), d.push(S), m.push(E);
      }
      var C = l(d) || 0, O = l(m) || 0;
      return { left: C, top: O, width: (f(d) || 0) - C, height: (f(m) || 0) - O };
    } }), o.Path.fromObject = function(u, h) {
      if (typeof u.sourcePath == "string") {
        var d = u.sourcePath;
        o.loadSVGFromURL(d, function(m) {
          var y = m[0];
          y.setOptions(u), h && h(y);
        });
      } else o.Object._fromObject("Path", u, h, "path");
    }, o.Path.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat(["d"]), o.Path.fromElement = function(u, h, d) {
      var m = o.parseAttributes(u, o.Path.ATTRIBUTE_NAMES);
      m.fromSVG = !0, h(new o.Path(m.d, i(m, d)));
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.array.min, f = o.util.array.max;
    o.Group || (o.Group = o.util.createClass(o.Object, o.Collection, { type: "group", strokeWidth: 0, subTargetCheck: !1, cacheProperties: [], useSetOnGroup: !1, initialize: function(i, r, s) {
      r = r || {}, this._objects = [], s && this.callSuper("initialize", r), this._objects = i || [];
      for (var u = this._objects.length; u--; ) this._objects[u].group = this;
      if (s) this._updateObjectsACoords();
      else {
        var h = r && r.centerPoint;
        r.originX !== void 0 && (this.originX = r.originX), r.originY !== void 0 && (this.originY = r.originY), h || this._calcBounds(), this._updateObjectsCoords(h), delete r.centerPoint, this.callSuper("initialize", r);
      }
      this.setCoords();
    }, _updateObjectsACoords: function() {
      for (var i = this._objects.length; i--; ) this._objects[i].setCoords(!0);
    }, _updateObjectsCoords: function(i) {
      i = i || this.getCenterPoint();
      for (var r = this._objects.length; r--; ) this._updateObjectCoords(this._objects[r], i);
    }, _updateObjectCoords: function(i, r) {
      var s = i.left, u = i.top;
      i.set({ left: s - r.x, top: u - r.y }), i.group = this, i.setCoords(!0);
    }, toString: function() {
      return "#<fabric.Group: (" + this.complexity() + ")>";
    }, addWithUpdate: function(i) {
      var r = !!this.group;
      return this._restoreObjectsState(), o.util.resetObjectTransform(this), i && (r && o.util.removeTransformFromObject(i, this.group.calcTransformMatrix()), this._objects.push(i), i.group = this, i._set("canvas", this.canvas)), this._calcBounds(), this._updateObjectsCoords(), this.dirty = !0, r ? this.group.addWithUpdate() : this.setCoords(), this;
    }, removeWithUpdate: function(i) {
      return this._restoreObjectsState(), o.util.resetObjectTransform(this), this.remove(i), this._calcBounds(), this._updateObjectsCoords(), this.setCoords(), this.dirty = !0, this;
    }, _onObjectAdded: function(i) {
      this.dirty = !0, i.group = this, i._set("canvas", this.canvas);
    }, _onObjectRemoved: function(i) {
      this.dirty = !0, delete i.group;
    }, _set: function(i, r) {
      var s = this._objects.length;
      if (this.useSetOnGroup) for (; s--; ) this._objects[s].setOnGroup(i, r);
      if (i === "canvas") for (; s--; ) this._objects[s]._set(i, r);
      o.Object.prototype._set.call(this, i, r);
    }, toObject: function(i) {
      var r = this.includeDefaultValues, s = this._objects.filter(function(h) {
        return !h.excludeFromExport;
      }).map(function(h) {
        var d = h.includeDefaultValues;
        h.includeDefaultValues = r;
        var m = h.toObject(i);
        return h.includeDefaultValues = d, m;
      }), u = o.Object.prototype.toObject.call(this, i);
      return u.objects = s, u;
    }, toDatalessObject: function(i) {
      var r, s = this.sourcePath;
      if (s) r = s;
      else {
        var u = this.includeDefaultValues;
        r = this._objects.map(function(d) {
          var m = d.includeDefaultValues;
          d.includeDefaultValues = u;
          var y = d.toDatalessObject(i);
          return d.includeDefaultValues = m, y;
        });
      }
      var h = o.Object.prototype.toDatalessObject.call(this, i);
      return h.objects = r, h;
    }, render: function(i) {
      this._transformDone = !0, this.callSuper("render", i), this._transformDone = !1;
    }, shouldCache: function() {
      var i = o.Object.prototype.shouldCache.call(this);
      if (i) {
        for (var r = 0, s = this._objects.length; r < s; r++) if (this._objects[r].willDrawShadow()) return this.ownCaching = !1, !1;
      }
      return i;
    }, willDrawShadow: function() {
      if (o.Object.prototype.willDrawShadow.call(this)) return !0;
      for (var i = 0, r = this._objects.length; i < r; i++) if (this._objects[i].willDrawShadow()) return !0;
      return !1;
    }, isOnACache: function() {
      return this.ownCaching || this.group && this.group.isOnACache();
    }, drawObject: function(i) {
      for (var r = 0, s = this._objects.length; r < s; r++) this._objects[r].render(i);
      this._drawClipPath(i);
    }, isCacheDirty: function(i) {
      if (this.callSuper("isCacheDirty", i)) return !0;
      if (!this.statefullCache) return !1;
      for (var r = 0, s = this._objects.length; r < s; r++) if (this._objects[r].isCacheDirty(!0)) {
        if (this._cacheCanvas) {
          var u = this.cacheWidth / this.zoomX, h = this.cacheHeight / this.zoomY;
          this._cacheContext.clearRect(-u / 2, -h / 2, u, h);
        }
        return !0;
      }
      return !1;
    }, _restoreObjectsState: function() {
      var i = this.calcOwnMatrix();
      return this._objects.forEach(function(r) {
        o.util.addTransformToObject(r, i), delete r.group, r.setCoords();
      }), this;
    }, realizeTransform: function(i, r) {
      return o.util.addTransformToObject(i, r), i;
    }, destroy: function() {
      return this._objects.forEach(function(i) {
        i.set("dirty", !0);
      }), this._restoreObjectsState();
    }, toActiveSelection: function() {
      if (this.canvas) {
        var i = this._objects, r = this.canvas;
        this._objects = [];
        var s = this.toObject();
        delete s.objects;
        var u = new o.ActiveSelection([]);
        return u.set(s), u.type = "activeSelection", r.remove(this), i.forEach(function(h) {
          h.group = u, h.dirty = !0, r.add(h);
        }), u.canvas = r, u._objects = i, r._activeObject = u, u.setCoords(), u;
      }
    }, ungroupOnCanvas: function() {
      return this._restoreObjectsState();
    }, setObjectsCoords: function() {
      return this.forEachObject(function(i) {
        i.setCoords(!0);
      }), this;
    }, _calcBounds: function(i) {
      for (var r, s, u, h, d = [], m = [], y = ["tr", "br", "bl", "tl"], b = 0, S = this._objects.length, E = y.length; b < S; ++b) {
        for (u = (r = this._objects[b]).calcACoords(), h = 0; h < E; h++) s = y[h], d.push(u[s].x), m.push(u[s].y);
        r.aCoords = u;
      }
      this._getBounds(d, m, i);
    }, _getBounds: function(i, r, s) {
      var u = new o.Point(l(i), l(r)), h = new o.Point(f(i), f(r)), d = u.y || 0, m = u.x || 0, y = h.x - u.x || 0, b = h.y - u.y || 0;
      this.width = y, this.height = b, s || this.setPositionByOrigin({ x: m, y: d }, "left", "top");
    }, _toSVG: function(i) {
      for (var r = ["<g ", "COMMON_PARTS", ` >
`], s = 0, u = this._objects.length; s < u; s++) r.push("		", this._objects[s].toSVG(i));
      return r.push(`</g>
`), r;
    }, getSvgStyles: function() {
      var i = this.opacity !== void 0 && this.opacity !== 1 ? "opacity: " + this.opacity + ";" : "", r = this.visible ? "" : " visibility: hidden;";
      return [i, this.getSvgFilter(), r].join("");
    }, toClipPathSVG: function(i) {
      for (var r = [], s = 0, u = this._objects.length; s < u; s++) r.push("	", this._objects[s].toClipPathSVG(i));
      return this._createBaseClipPathSVGMarkup(r, { reviver: i });
    } }), o.Group.fromObject = function(i, r) {
      var s = i.objects, u = o.util.object.clone(i, !0);
      delete u.objects, typeof s != "string" ? o.util.enlivenObjects(s, function(h) {
        o.util.enlivenObjects([i.clipPath], function(d) {
          var m = o.util.object.clone(i, !0);
          m.clipPath = d[0], delete m.objects, r && r(new o.Group(h, m, !0));
        });
      }) : o.loadSVGFromURL(s, function(h) {
        var d = o.util.groupSVGElements(h, i, s);
        d.set(u), r && r(d);
      });
    });
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {});
    o.ActiveSelection || (o.ActiveSelection = o.util.createClass(o.Group, { type: "activeSelection", initialize: function(l, f) {
      f = f || {}, this._objects = l || [];
      for (var i = this._objects.length; i--; ) this._objects[i].group = this;
      f.originX && (this.originX = f.originX), f.originY && (this.originY = f.originY), this._calcBounds(), this._updateObjectsCoords(), o.Object.prototype.initialize.call(this, f), this.setCoords();
    }, toGroup: function() {
      var l = this._objects.concat();
      this._objects = [];
      var f = o.Object.prototype.toObject.call(this), i = new o.Group([]);
      if (delete f.type, i.set(f), l.forEach(function(s) {
        s.canvas.remove(s), s.group = i;
      }), i._objects = l, !this.canvas) return i;
      var r = this.canvas;
      return r.add(i), r._activeObject = i, i.setCoords(), i;
    }, onDeselect: function() {
      return this.destroy(), !1;
    }, toString: function() {
      return "#<fabric.ActiveSelection: (" + this.complexity() + ")>";
    }, shouldCache: function() {
      return !1;
    }, isOnACache: function() {
      return !1;
    }, _renderControls: function(l, f, i) {
      l.save(), l.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1, this.callSuper("_renderControls", l, f), (i = i || {}).hasControls === void 0 && (i.hasControls = !1), i.forActiveSelection = !0;
      for (var r = 0, s = this._objects.length; r < s; r++) this._objects[r]._renderControls(l, i);
      l.restore();
    } }), o.ActiveSelection.fromObject = function(l, f) {
      o.util.enlivenObjects(l.objects, function(i) {
        delete l.objects, f && f(new o.ActiveSelection(i, l, !0));
      });
    });
  }(t), function(c) {
    var o = v.util.object.extend;
    c.fabric || (c.fabric = {}), c.fabric.Image ? v.warn("fabric.Image is already defined.") : (v.Image = v.util.createClass(v.Object, { type: "image", strokeWidth: 0, srcFromAttribute: !1, _lastScaleX: 1, _lastScaleY: 1, _filterScalingX: 1, _filterScalingY: 1, minimumScaleTrigger: 0.5, stateProperties: v.Object.prototype.stateProperties.concat("cropX", "cropY"), cacheProperties: v.Object.prototype.cacheProperties.concat("cropX", "cropY"), cacheKey: "", cropX: 0, cropY: 0, imageSmoothing: !0, initialize: function(l, f) {
      f || (f = {}), this.filters = [], this.cacheKey = "texture" + v.Object.__uid++, this.callSuper("initialize", f), this._initElement(l, f);
    }, getElement: function() {
      return this._element || {};
    }, setElement: function(l, f) {
      return this.removeTexture(this.cacheKey), this.removeTexture(this.cacheKey + "_filtered"), this._element = l, this._originalElement = l, this._initConfig(f), this.filters.length !== 0 && this.applyFilters(), this.resizeFilter && this.applyResizeFilters(), this;
    }, removeTexture: function(l) {
      var f = v.filterBackend;
      f && f.evictCachesForKey && f.evictCachesForKey(l);
    }, dispose: function() {
      this.removeTexture(this.cacheKey), this.removeTexture(this.cacheKey + "_filtered"), this._cacheContext = void 0, ["_originalElement", "_element", "_filteredEl", "_cacheCanvas"].forEach((function(l) {
        v.util.cleanUpJsdomNode(this[l]), this[l] = void 0;
      }).bind(this));
    }, getCrossOrigin: function() {
      return this._originalElement && (this._originalElement.crossOrigin || null);
    }, getOriginalSize: function() {
      var l = this.getElement();
      return { width: l.naturalWidth || l.width, height: l.naturalHeight || l.height };
    }, _stroke: function(l) {
      if (this.stroke && this.strokeWidth !== 0) {
        var f = this.width / 2, i = this.height / 2;
        l.beginPath(), l.moveTo(-f, -i), l.lineTo(f, -i), l.lineTo(f, i), l.lineTo(-f, i), l.lineTo(-f, -i), l.closePath();
      }
    }, toObject: function(l) {
      var f = [];
      this.filters.forEach(function(r) {
        r && f.push(r.toObject());
      });
      var i = o(this.callSuper("toObject", ["cropX", "cropY"].concat(l)), { src: this.getSrc(), crossOrigin: this.getCrossOrigin(), filters: f });
      return this.resizeFilter && (i.resizeFilter = this.resizeFilter.toObject()), i;
    }, hasCrop: function() {
      return this.cropX || this.cropY || this.width < this._element.width || this.height < this._element.height;
    }, _toSVG: function() {
      var l, f = [], i = [], r = this._element, s = -this.width / 2, u = -this.height / 2, h = "", d = "";
      if (!r) return [];
      if (this.hasCrop()) {
        var m = v.Object.__uid++;
        f.push('<clipPath id="imageCrop_' + m + `">
`, '	<rect x="' + s + '" y="' + u + '" width="' + this.width + '" height="' + this.height + `" />
`, `</clipPath>
`), h = ' clip-path="url(#imageCrop_' + m + ')" ';
      }
      if (this.imageSmoothing || (d = '" image-rendering="optimizeSpeed'), i.push("	<image ", "COMMON_PARTS", 'xlink:href="', this.getSvgSrc(!0), '" x="', s - this.cropX, '" y="', u - this.cropY, '" width="', r.width || r.naturalWidth, '" height="', r.height || r.height, d, '"', h, `></image>
`), this.stroke || this.strokeDashArray) {
        var y = this.fill;
        this.fill = null, l = ["	<rect ", 'x="', s, '" y="', u, '" width="', this.width, '" height="', this.height, '" style="', this.getSvgStyles(), `"/>
`], this.fill = y;
      }
      return f = this.paintFirst !== "fill" ? f.concat(l, i) : f.concat(i, l);
    }, getSrc: function(l) {
      var f = l ? this._element : this._originalElement;
      return f ? f.toDataURL ? f.toDataURL() : this.srcFromAttribute ? f.getAttribute("src") : f.src : this.src || "";
    }, setSrc: function(l, f, i) {
      return v.util.loadImage(l, function(r, s) {
        this.setElement(r, i), this._setWidthHeight(), f && f(this, s);
      }, this, i && i.crossOrigin), this;
    }, toString: function() {
      return '#<fabric.Image: { src: "' + this.getSrc() + '" }>';
    }, applyResizeFilters: function() {
      var l = this.resizeFilter, f = this.minimumScaleTrigger, i = this.getTotalObjectScaling(), r = i.scaleX, s = i.scaleY, u = this._filteredEl || this._originalElement;
      if (this.group && this.set("dirty", !0), !l || r > f && s > f) return this._element = u, this._filterScalingX = 1, this._filterScalingY = 1, this._lastScaleX = r, void (this._lastScaleY = s);
      v.filterBackend || (v.filterBackend = v.initFilterBackend());
      var h = v.util.createCanvasElement(), d = this._filteredEl ? this.cacheKey + "_filtered" : this.cacheKey, m = u.width, y = u.height;
      h.width = m, h.height = y, this._element = h, this._lastScaleX = l.scaleX = r, this._lastScaleY = l.scaleY = s, v.filterBackend.applyFilters([l], u, m, y, this._element, d), this._filterScalingX = h.width / this._originalElement.width, this._filterScalingY = h.height / this._originalElement.height;
    }, applyFilters: function(l) {
      if (l = (l = l || this.filters || []).filter(function(u) {
        return u && !u.isNeutralState();
      }), this.set("dirty", !0), this.removeTexture(this.cacheKey + "_filtered"), l.length === 0) return this._element = this._originalElement, this._filteredEl = null, this._filterScalingX = 1, this._filterScalingY = 1, this;
      var f = this._originalElement, i = f.naturalWidth || f.width, r = f.naturalHeight || f.height;
      if (this._element === this._originalElement) {
        var s = v.util.createCanvasElement();
        s.width = i, s.height = r, this._element = s, this._filteredEl = s;
      } else this._element = this._filteredEl, this._filteredEl.getContext("2d").clearRect(0, 0, i, r), this._lastScaleX = 1, this._lastScaleY = 1;
      return v.filterBackend || (v.filterBackend = v.initFilterBackend()), v.filterBackend.applyFilters(l, this._originalElement, i, r, this._element, this.cacheKey), this._originalElement.width === this._element.width && this._originalElement.height === this._element.height || (this._filterScalingX = this._element.width / this._originalElement.width, this._filterScalingY = this._element.height / this._originalElement.height), this;
    }, _render: function(l) {
      v.util.setImageSmoothing(l, this.imageSmoothing), this.isMoving !== !0 && this.resizeFilter && this._needsResize() && this.applyResizeFilters(), this._stroke(l), this._renderPaintInOrder(l);
    }, drawCacheOnCanvas: function(l) {
      v.util.setImageSmoothing(l, this.imageSmoothing), v.Object.prototype.drawCacheOnCanvas.call(this, l);
    }, shouldCache: function() {
      return this.needsItsOwnCache();
    }, _renderFill: function(l) {
      var f = this._element;
      if (f) {
        var i = this._filterScalingX, r = this._filterScalingY, s = this.width, u = this.height, h = Math.min, d = Math.max, m = d(this.cropX, 0), y = d(this.cropY, 0), b = f.naturalWidth || f.width, S = f.naturalHeight || f.height, E = m * i, A = y * r, M = h(s * i, b - E), C = h(u * r, S - A), O = -s / 2, N = -u / 2, z = h(s, b / i - m), W = h(u, S / r - y);
        f && l.drawImage(f, E, A, M, C, O, N, z, W);
      }
    }, _needsResize: function() {
      var l = this.getTotalObjectScaling();
      return l.scaleX !== this._lastScaleX || l.scaleY !== this._lastScaleY;
    }, _resetWidthHeight: function() {
      this.set(this.getOriginalSize());
    }, _initElement: function(l, f) {
      this.setElement(v.util.getById(l), f), v.util.addClass(this.getElement(), v.Image.CSS_CANVAS);
    }, _initConfig: function(l) {
      l || (l = {}), this.setOptions(l), this._setWidthHeight(l);
    }, _initFilters: function(l, f) {
      l && l.length ? v.util.enlivenObjects(l, function(i) {
        f && f(i);
      }, "fabric.Image.filters") : f && f();
    }, _setWidthHeight: function(l) {
      l || (l = {});
      var f = this.getElement();
      this.width = l.width || f.naturalWidth || f.width || 0, this.height = l.height || f.naturalHeight || f.height || 0;
    }, parsePreserveAspectRatioAttribute: function() {
      var l, f = v.util.parsePreserveAspectRatioAttribute(this.preserveAspectRatio || ""), i = this._element.width, r = this._element.height, s = 1, u = 1, h = 0, d = 0, m = 0, y = 0, b = this.width, S = this.height, E = { width: b, height: S };
      return !f || f.alignX === "none" && f.alignY === "none" ? (s = b / i, u = S / r) : (f.meetOrSlice === "meet" && (l = (b - i * (s = u = v.util.findScaleToFit(this._element, E))) / 2, f.alignX === "Min" && (h = -l), f.alignX === "Max" && (h = l), l = (S - r * u) / 2, f.alignY === "Min" && (d = -l), f.alignY === "Max" && (d = l)), f.meetOrSlice === "slice" && (l = i - b / (s = u = v.util.findScaleToCover(this._element, E)), f.alignX === "Mid" && (m = l / 2), f.alignX === "Max" && (m = l), l = r - S / u, f.alignY === "Mid" && (y = l / 2), f.alignY === "Max" && (y = l), i = b / s, r = S / u)), { width: i, height: r, scaleX: s, scaleY: u, offsetLeft: h, offsetTop: d, cropX: m, cropY: y };
    } }), v.Image.CSS_CANVAS = "canvas-img", v.Image.prototype.getSvgSrc = v.Image.prototype.getSrc, v.Image.fromObject = function(l, f) {
      var i = v.util.object.clone(l);
      v.util.loadImage(i.src, function(r, s) {
        s ? f && f(null, !0) : v.Image.prototype._initFilters.call(i, i.filters, function(u) {
          i.filters = u || [], v.Image.prototype._initFilters.call(i, [i.resizeFilter], function(h) {
            i.resizeFilter = h[0], v.util.enlivenObjects([i.clipPath], function(d) {
              i.clipPath = d[0];
              var m = new v.Image(r, i);
              f(m, !1);
            });
          });
        });
      }, null, i.crossOrigin);
    }, v.Image.fromURL = function(l, f, i) {
      v.util.loadImage(l, function(r, s) {
        f && f(new v.Image(r, i), s);
      }, null, i && i.crossOrigin);
    }, v.Image.ATTRIBUTE_NAMES = v.SHARED_ATTRIBUTES.concat("x y width height preserveAspectRatio xlink:href crossOrigin image-rendering".split(" ")), v.Image.fromElement = function(l, f, i) {
      var r = v.parseAttributes(l, v.Image.ATTRIBUTE_NAMES);
      v.Image.fromURL(r["xlink:href"], f, o(i ? v.util.object.clone(i) : {}, r));
    });
  }(t), v.util.object.extend(v.Object.prototype, { _getAngleValueForStraighten: function() {
    var c = this.angle % 360;
    return c > 0 ? 90 * Math.round((c - 1) / 90) : 90 * Math.round(c / 90);
  }, straighten: function() {
    return this.rotate(this._getAngleValueForStraighten()), this;
  }, fxStraighten: function(c) {
    var o = function() {
    }, l = (c = c || {}).onComplete || o, f = c.onChange || o, i = this;
    return v.util.animate({ startValue: this.get("angle"), endValue: this._getAngleValueForStraighten(), duration: this.FX_DURATION, onChange: function(r) {
      i.rotate(r), f();
    }, onComplete: function() {
      i.setCoords(), l();
    } }), this;
  } }), v.util.object.extend(v.StaticCanvas.prototype, { straightenObject: function(c) {
    return c.straighten(), this.requestRenderAll(), this;
  }, fxStraightenObject: function(c) {
    return c.fxStraighten({ onChange: this.requestRenderAllBound }), this;
  } }), function() {
    function c(l, f) {
      var i = "precision " + f + ` float;
void main(){}`, r = l.createShader(l.FRAGMENT_SHADER);
      return l.shaderSource(r, i), l.compileShader(r), !!l.getShaderParameter(r, l.COMPILE_STATUS);
    }
    function o(l) {
      l && l.tileSize && (this.tileSize = l.tileSize), this.setupGLContext(this.tileSize, this.tileSize), this.captureGPUInfo();
    }
    v.isWebglSupported = function(l) {
      if (v.isLikelyNode) return !1;
      l = l || v.WebglFilterBackend.prototype.tileSize;
      var f = document.createElement("canvas"), i = f.getContext("webgl") || f.getContext("experimental-webgl"), r = !1;
      if (i) {
        v.maxTextureSize = i.getParameter(i.MAX_TEXTURE_SIZE), r = v.maxTextureSize >= l;
        for (var s = ["highp", "mediump", "lowp"], u = 0; u < 3; u++) if (c(i, s[u])) {
          v.webGlPrecision = s[u];
          break;
        }
      }
      return this.isSupported = r, r;
    }, v.WebglFilterBackend = o, o.prototype = { tileSize: 2048, resources: {}, setupGLContext: function(l, f) {
      this.dispose(), this.createWebGLCanvas(l, f), this.aPosition = new Float32Array([0, 0, 0, 1, 1, 0, 1, 1]), this.chooseFastestCopyGLTo2DMethod(l, f);
    }, chooseFastestCopyGLTo2DMethod: function(l, f) {
      var i, r = window.performance !== void 0;
      try {
        new ImageData(1, 1), i = !0;
      } catch {
        i = !1;
      }
      var s = typeof ArrayBuffer < "u", u = typeof Uint8ClampedArray < "u";
      if (r && i && s && u) {
        var h = v.util.createCanvasElement(), d = new ArrayBuffer(l * f * 4);
        if (v.forceGLPutImageData) return this.imageBuffer = d, void (this.copyGLTo2D = zt);
        var m, y, b = { imageBuffer: d, destinationWidth: l, destinationHeight: f, targetCanvas: h };
        h.width = l, h.height = f, m = window.performance.now(), Xt.call(b, this.gl, b), y = window.performance.now() - m, m = window.performance.now(), zt.call(b, this.gl, b), y > window.performance.now() - m ? (this.imageBuffer = d, this.copyGLTo2D = zt) : this.copyGLTo2D = Xt;
      }
    }, createWebGLCanvas: function(l, f) {
      var i = v.util.createCanvasElement();
      i.width = l, i.height = f;
      var r = { alpha: !0, premultipliedAlpha: !1, depth: !1, stencil: !1, antialias: !1 }, s = i.getContext("webgl", r);
      s || (s = i.getContext("experimental-webgl", r)), s && (s.clearColor(0, 0, 0, 0), this.canvas = i, this.gl = s);
    }, applyFilters: function(l, f, i, r, s, u) {
      var h, d = this.gl;
      u && (h = this.getCachedTexture(u, f));
      var m = { originalWidth: f.width || f.originalWidth, originalHeight: f.height || f.originalHeight, sourceWidth: i, sourceHeight: r, destinationWidth: i, destinationHeight: r, context: d, sourceTexture: this.createTexture(d, i, r, !h && f), targetTexture: this.createTexture(d, i, r), originalTexture: h || this.createTexture(d, i, r, !h && f), passes: l.length, webgl: !0, aPosition: this.aPosition, programCache: this.programCache, pass: 0, filterBackend: this, targetCanvas: s }, y = d.createFramebuffer();
      return d.bindFramebuffer(d.FRAMEBUFFER, y), l.forEach(function(b) {
        b && b.applyTo(m);
      }), function(b) {
        var S = b.targetCanvas, E = S.width, A = S.height, M = b.destinationWidth, C = b.destinationHeight;
        E === M && A === C || (S.width = M, S.height = C);
      }(m), this.copyGLTo2D(d, m), d.bindTexture(d.TEXTURE_2D, null), d.deleteTexture(m.sourceTexture), d.deleteTexture(m.targetTexture), d.deleteFramebuffer(y), s.getContext("2d").setTransform(1, 0, 0, 1, 0, 0), m;
    }, dispose: function() {
      this.canvas && (this.canvas = null, this.gl = null), this.clearWebGLCaches();
    }, clearWebGLCaches: function() {
      this.programCache = {}, this.textureCache = {};
    }, createTexture: function(l, f, i, r) {
      var s = l.createTexture();
      return l.bindTexture(l.TEXTURE_2D, s), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_MAG_FILTER, l.NEAREST), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_MIN_FILTER, l.NEAREST), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_WRAP_S, l.CLAMP_TO_EDGE), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_WRAP_T, l.CLAMP_TO_EDGE), r ? l.texImage2D(l.TEXTURE_2D, 0, l.RGBA, l.RGBA, l.UNSIGNED_BYTE, r) : l.texImage2D(l.TEXTURE_2D, 0, l.RGBA, f, i, 0, l.RGBA, l.UNSIGNED_BYTE, null), s;
    }, getCachedTexture: function(l, f) {
      if (this.textureCache[l]) return this.textureCache[l];
      var i = this.createTexture(this.gl, f.width, f.height, f);
      return this.textureCache[l] = i, i;
    }, evictCachesForKey: function(l) {
      this.textureCache[l] && (this.gl.deleteTexture(this.textureCache[l]), delete this.textureCache[l]);
    }, copyGLTo2D: Xt, captureGPUInfo: function() {
      if (this.gpuInfo) return this.gpuInfo;
      var l = this.gl, f = { renderer: "", vendor: "" };
      if (!l) return f;
      var i = l.getExtension("WEBGL_debug_renderer_info");
      if (i) {
        var r = l.getParameter(i.UNMASKED_RENDERER_WEBGL), s = l.getParameter(i.UNMASKED_VENDOR_WEBGL);
        r && (f.renderer = r.toLowerCase()), s && (f.vendor = s.toLowerCase());
      }
      return this.gpuInfo = f, f;
    } };
  }(), function() {
    var c = function() {
    };
    function o() {
    }
    v.Canvas2dFilterBackend = o, o.prototype = { evictCachesForKey: c, dispose: c, clearWebGLCaches: c, resources: {}, applyFilters: function(l, f, i, r, s) {
      var u = s.getContext("2d");
      u.drawImage(f, 0, 0, i, r);
      var h = { sourceWidth: i, sourceHeight: r, imageData: u.getImageData(0, 0, i, r), originalEl: f, originalImageData: u.getImageData(0, 0, i, r), canvasEl: s, ctx: u, filterBackend: this };
      return l.forEach(function(d) {
        d.applyTo(h);
      }), h.imageData.width === i && h.imageData.height === r || (s.width = h.imageData.width, s.height = h.imageData.height), u.putImageData(h.imageData, 0, 0), h;
    } };
  }(), v.Image = v.Image || {}, v.Image.filters = v.Image.filters || {}, v.Image.filters.BaseFilter = v.util.createClass({ type: "BaseFilter", vertexSource: `attribute vec2 aPosition;
varying vec2 vTexCoord;
void main() {
vTexCoord = aPosition;
gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
}`, fragmentSource: `precision highp float;
varying vec2 vTexCoord;
uniform sampler2D uTexture;
void main() {
gl_FragColor = texture2D(uTexture, vTexCoord);
}`, initialize: function(c) {
    c && this.setOptions(c);
  }, setOptions: function(c) {
    for (var o in c) this[o] = c[o];
  }, createProgram: function(c, o, l) {
    o = o || this.fragmentSource, l = l || this.vertexSource, v.webGlPrecision !== "highp" && (o = o.replace(/precision highp float/g, "precision " + v.webGlPrecision + " float"));
    var f = c.createShader(c.VERTEX_SHADER);
    if (c.shaderSource(f, l), c.compileShader(f), !c.getShaderParameter(f, c.COMPILE_STATUS)) throw new Error("Vertex shader compile error for " + this.type + ": " + c.getShaderInfoLog(f));
    var i = c.createShader(c.FRAGMENT_SHADER);
    if (c.shaderSource(i, o), c.compileShader(i), !c.getShaderParameter(i, c.COMPILE_STATUS)) throw new Error("Fragment shader compile error for " + this.type + ": " + c.getShaderInfoLog(i));
    var r = c.createProgram();
    if (c.attachShader(r, f), c.attachShader(r, i), c.linkProgram(r), !c.getProgramParameter(r, c.LINK_STATUS)) throw new Error('Shader link error for "${this.type}" ' + c.getProgramInfoLog(r));
    var s = this.getAttributeLocations(c, r), u = this.getUniformLocations(c, r) || {};
    return u.uStepW = c.getUniformLocation(r, "uStepW"), u.uStepH = c.getUniformLocation(r, "uStepH"), { program: r, attributeLocations: s, uniformLocations: u };
  }, getAttributeLocations: function(c, o) {
    return { aPosition: c.getAttribLocation(o, "aPosition") };
  }, getUniformLocations: function() {
    return {};
  }, sendAttributeData: function(c, o, l) {
    var f = o.aPosition, i = c.createBuffer();
    c.bindBuffer(c.ARRAY_BUFFER, i), c.enableVertexAttribArray(f), c.vertexAttribPointer(f, 2, c.FLOAT, !1, 0, 0), c.bufferData(c.ARRAY_BUFFER, l, c.STATIC_DRAW);
  }, _setupFrameBuffer: function(c) {
    var o, l, f = c.context;
    c.passes > 1 ? (o = c.destinationWidth, l = c.destinationHeight, c.sourceWidth === o && c.sourceHeight === l || (f.deleteTexture(c.targetTexture), c.targetTexture = c.filterBackend.createTexture(f, o, l)), f.framebufferTexture2D(f.FRAMEBUFFER, f.COLOR_ATTACHMENT0, f.TEXTURE_2D, c.targetTexture, 0)) : (f.bindFramebuffer(f.FRAMEBUFFER, null), f.finish());
  }, _swapTextures: function(c) {
    c.passes--, c.pass++;
    var o = c.targetTexture;
    c.targetTexture = c.sourceTexture, c.sourceTexture = o;
  }, isNeutralState: function() {
    var c = this.mainParameter, o = v.Image.filters[this.type].prototype;
    if (c) {
      if (Array.isArray(o[c])) {
        for (var l = o[c].length; l--; ) if (this[c][l] !== o[c][l]) return !1;
        return !0;
      }
      return o[c] === this[c];
    }
    return !1;
  }, applyTo: function(c) {
    c.webgl ? (this._setupFrameBuffer(c), this.applyToWebGL(c), this._swapTextures(c)) : this.applyTo2d(c);
  }, retrieveShader: function(c) {
    return c.programCache.hasOwnProperty(this.type) || (c.programCache[this.type] = this.createProgram(c.context)), c.programCache[this.type];
  }, applyToWebGL: function(c) {
    var o = c.context, l = this.retrieveShader(c);
    c.pass === 0 && c.originalTexture ? o.bindTexture(o.TEXTURE_2D, c.originalTexture) : o.bindTexture(o.TEXTURE_2D, c.sourceTexture), o.useProgram(l.program), this.sendAttributeData(o, l.attributeLocations, c.aPosition), o.uniform1f(l.uniformLocations.uStepW, 1 / c.sourceWidth), o.uniform1f(l.uniformLocations.uStepH, 1 / c.sourceHeight), this.sendUniformData(o, l.uniformLocations), o.viewport(0, 0, c.destinationWidth, c.destinationHeight), o.drawArrays(o.TRIANGLE_STRIP, 0, 4);
  }, bindAdditionalTexture: function(c, o, l) {
    c.activeTexture(l), c.bindTexture(c.TEXTURE_2D, o), c.activeTexture(c.TEXTURE0);
  }, unbindAdditionalTexture: function(c, o) {
    c.activeTexture(o), c.bindTexture(c.TEXTURE_2D, null), c.activeTexture(c.TEXTURE0);
  }, getMainParameter: function() {
    return this[this.mainParameter];
  }, setMainParameter: function(c) {
    this[this.mainParameter] = c;
  }, sendUniformData: function() {
  }, createHelpLayer: function(c) {
    if (!c.helpLayer) {
      var o = document.createElement("canvas");
      o.width = c.sourceWidth, o.height = c.sourceHeight, c.helpLayer = o;
    }
  }, toObject: function() {
    var c = { type: this.type }, o = this.mainParameter;
    return o && (c[o] = this[o]), c;
  }, toJSON: function() {
    return this.toObject();
  } }), v.Image.filters.BaseFilter.fromObject = function(c, o) {
    var l = new v.Image.filters[c.type](c);
    return o && o(l), l;
  }, function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.ColorMatrix = f(l.BaseFilter, { type: "ColorMatrix", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
uniform mat4 uColorMatrix;
uniform vec4 uConstants;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color *= uColorMatrix;
color += uConstants;
gl_FragColor = color;
}`, matrix: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0], mainParameter: "matrix", colorsOnly: !0, initialize: function(i) {
      this.callSuper("initialize", i), this.matrix = this.matrix.slice(0);
    }, applyTo2d: function(i) {
      var r, s, u, h, d, m = i.imageData.data, y = m.length, b = this.matrix, S = this.colorsOnly;
      for (d = 0; d < y; d += 4) r = m[d], s = m[d + 1], u = m[d + 2], S ? (m[d] = r * b[0] + s * b[1] + u * b[2] + 255 * b[4], m[d + 1] = r * b[5] + s * b[6] + u * b[7] + 255 * b[9], m[d + 2] = r * b[10] + s * b[11] + u * b[12] + 255 * b[14]) : (h = m[d + 3], m[d] = r * b[0] + s * b[1] + u * b[2] + h * b[3] + 255 * b[4], m[d + 1] = r * b[5] + s * b[6] + u * b[7] + h * b[8] + 255 * b[9], m[d + 2] = r * b[10] + s * b[11] + u * b[12] + h * b[13] + 255 * b[14], m[d + 3] = r * b[15] + s * b[16] + u * b[17] + h * b[18] + 255 * b[19]);
    }, getUniformLocations: function(i, r) {
      return { uColorMatrix: i.getUniformLocation(r, "uColorMatrix"), uConstants: i.getUniformLocation(r, "uConstants") };
    }, sendUniformData: function(i, r) {
      var s = this.matrix, u = [s[0], s[1], s[2], s[3], s[5], s[6], s[7], s[8], s[10], s[11], s[12], s[13], s[15], s[16], s[17], s[18]], h = [s[4], s[9], s[14], s[19]];
      i.uniformMatrix4fv(r.uColorMatrix, !1, u), i.uniform4fv(r.uConstants, h);
    } }), o.Image.filters.ColorMatrix.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Brightness = f(l.BaseFilter, { type: "Brightness", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uBrightness;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color.rgb += uBrightness;
gl_FragColor = color;
}`, brightness: 0, mainParameter: "brightness", applyTo2d: function(i) {
      if (this.brightness !== 0) {
        var r, s = i.imageData.data, u = s.length, h = Math.round(255 * this.brightness);
        for (r = 0; r < u; r += 4) s[r] = s[r] + h, s[r + 1] = s[r + 1] + h, s[r + 2] = s[r + 2] + h;
      }
    }, getUniformLocations: function(i, r) {
      return { uBrightness: i.getUniformLocation(r, "uBrightness") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uBrightness, this.brightness);
    } }), o.Image.filters.Brightness.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.Image.filters, i = o.util.createClass;
    f.Convolute = i(f.BaseFilter, { type: "Convolute", opaque: !1, matrix: [0, 0, 0, 0, 1, 0, 0, 0, 0], fragmentSource: { Convolute_3_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[9];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 3.0; h+=1.0) {
for (float w = 0.0; w < 3.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 1), uStepH * (h - 1));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 3.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_3_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[9];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 3.0; h+=1.0) {
for (float w = 0.0; w < 3.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 1.0), uStepH * (h - 1.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 3.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_5_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[25];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 5.0; h+=1.0) {
for (float w = 0.0; w < 5.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 5.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_5_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[25];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 5.0; h+=1.0) {
for (float w = 0.0; w < 5.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 5.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_7_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[49];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 7.0; h+=1.0) {
for (float w = 0.0; w < 7.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 7.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_7_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[49];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 7.0; h+=1.0) {
for (float w = 0.0; w < 7.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 7.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}`, Convolute_9_1: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[81];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 0);
for (float h = 0.0; h < 9.0; h+=1.0) {
for (float w = 0.0; w < 9.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 9.0 + w)];
}
}
gl_FragColor = color;
}`, Convolute_9_0: `precision highp float;
uniform sampler2D uTexture;
uniform float uMatrix[81];
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
vec4 color = vec4(0, 0, 0, 1);
for (float h = 0.0; h < 9.0; h+=1.0) {
for (float w = 0.0; w < 9.0; w+=1.0) {
vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 9.0 + w)];
}
}
float alpha = texture2D(uTexture, vTexCoord).a;
gl_FragColor = color;
gl_FragColor.a = alpha;
}` }, retrieveShader: function(r) {
      var s = Math.sqrt(this.matrix.length), u = this.type + "_" + s + "_" + (this.opaque ? 1 : 0), h = this.fragmentSource[u];
      return r.programCache.hasOwnProperty(u) || (r.programCache[u] = this.createProgram(r.context, h)), r.programCache[u];
    }, applyTo2d: function(r) {
      var s, u, h, d, m, y, b, S, E, A, M, C, O, N = r.imageData, z = N.data, W = this.matrix, F = Math.round(Math.sqrt(W.length)), k = Math.floor(F / 2), B = N.width, Z = N.height, K = r.ctx.createImageData(B, Z), U = K.data, R = this.opaque ? 1 : 0;
      for (M = 0; M < Z; M++) for (A = 0; A < B; A++) {
        for (m = 4 * (M * B + A), s = 0, u = 0, h = 0, d = 0, O = 0; O < F; O++) for (C = 0; C < F; C++) y = A + C - k, (b = M + O - k) < 0 || b >= Z || y < 0 || y >= B || (S = 4 * (b * B + y), E = W[O * F + C], s += z[S] * E, u += z[S + 1] * E, h += z[S + 2] * E, R || (d += z[S + 3] * E));
        U[m] = s, U[m + 1] = u, U[m + 2] = h, U[m + 3] = R ? z[m + 3] : d;
      }
      r.imageData = K;
    }, getUniformLocations: function(r, s) {
      return { uMatrix: r.getUniformLocation(s, "uMatrix"), uOpaque: r.getUniformLocation(s, "uOpaque"), uHalfSize: r.getUniformLocation(s, "uHalfSize"), uSize: r.getUniformLocation(s, "uSize") };
    }, sendUniformData: function(r, s) {
      r.uniform1fv(s.uMatrix, this.matrix);
    }, toObject: function() {
      return l(this.callSuper("toObject"), { opaque: this.opaque, matrix: this.matrix });
    } }), o.Image.filters.Convolute.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Grayscale = f(l.BaseFilter, { type: "Grayscale", fragmentSource: { average: `precision highp float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float average = (color.r + color.b + color.g) / 3.0;
gl_FragColor = vec4(average, average, average, color.a);
}`, lightness: `precision highp float;
uniform sampler2D uTexture;
uniform int uMode;
varying vec2 vTexCoord;
void main() {
vec4 col = texture2D(uTexture, vTexCoord);
float average = (max(max(col.r, col.g),col.b) + min(min(col.r, col.g),col.b)) / 2.0;
gl_FragColor = vec4(average, average, average, col.a);
}`, luminosity: `precision highp float;
uniform sampler2D uTexture;
uniform int uMode;
varying vec2 vTexCoord;
void main() {
vec4 col = texture2D(uTexture, vTexCoord);
float average = 0.21 * col.r + 0.72 * col.g + 0.07 * col.b;
gl_FragColor = vec4(average, average, average, col.a);
}` }, mode: "average", mainParameter: "mode", applyTo2d: function(i) {
      var r, s, u = i.imageData.data, h = u.length, d = this.mode;
      for (r = 0; r < h; r += 4) d === "average" ? s = (u[r] + u[r + 1] + u[r + 2]) / 3 : d === "lightness" ? s = (Math.min(u[r], u[r + 1], u[r + 2]) + Math.max(u[r], u[r + 1], u[r + 2])) / 2 : d === "luminosity" && (s = 0.21 * u[r] + 0.72 * u[r + 1] + 0.07 * u[r + 2]), u[r] = s, u[r + 1] = s, u[r + 2] = s;
    }, retrieveShader: function(i) {
      var r = this.type + "_" + this.mode;
      if (!i.programCache.hasOwnProperty(r)) {
        var s = this.fragmentSource[this.mode];
        i.programCache[r] = this.createProgram(i.context, s);
      }
      return i.programCache[r];
    }, getUniformLocations: function(i, r) {
      return { uMode: i.getUniformLocation(r, "uMode") };
    }, sendUniformData: function(i, r) {
      i.uniform1i(r.uMode, 1);
    }, isNeutralState: function() {
      return !1;
    } }), o.Image.filters.Grayscale.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Invert = f(l.BaseFilter, { type: "Invert", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform int uInvert;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
if (uInvert == 1) {
gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,color.a);
} else {
gl_FragColor = color;
}
}`, invert: !0, mainParameter: "invert", applyTo2d: function(i) {
      var r, s = i.imageData.data, u = s.length;
      for (r = 0; r < u; r += 4) s[r] = 255 - s[r], s[r + 1] = 255 - s[r + 1], s[r + 2] = 255 - s[r + 2];
    }, isNeutralState: function() {
      return !this.invert;
    }, getUniformLocations: function(i, r) {
      return { uInvert: i.getUniformLocation(r, "uInvert") };
    }, sendUniformData: function(i, r) {
      i.uniform1i(r.uInvert, this.invert);
    } }), o.Image.filters.Invert.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.Image.filters, i = o.util.createClass;
    f.Noise = i(f.BaseFilter, { type: "Noise", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uStepH;
uniform float uNoise;
uniform float uSeed;
varying vec2 vTexCoord;
float rand(vec2 co, float seed, float vScale) {
return fract(sin(dot(co.xy * vScale ,vec2(12.9898 , 78.233))) * 43758.5453 * (seed + 0.01) / 2.0);
}
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
color.rgb += (0.5 - rand(vTexCoord, uSeed, 0.1 / uStepH)) * uNoise;
gl_FragColor = color;
}`, mainParameter: "noise", noise: 0, applyTo2d: function(r) {
      if (this.noise !== 0) {
        var s, u, h = r.imageData.data, d = h.length, m = this.noise;
        for (s = 0, d = h.length; s < d; s += 4) u = (0.5 - Math.random()) * m, h[s] += u, h[s + 1] += u, h[s + 2] += u;
      }
    }, getUniformLocations: function(r, s) {
      return { uNoise: r.getUniformLocation(s, "uNoise"), uSeed: r.getUniformLocation(s, "uSeed") };
    }, sendUniformData: function(r, s) {
      r.uniform1f(s.uNoise, this.noise / 255), r.uniform1f(s.uSeed, Math.random());
    }, toObject: function() {
      return l(this.callSuper("toObject"), { noise: this.noise });
    } }), o.Image.filters.Noise.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Pixelate = f(l.BaseFilter, { type: "Pixelate", blocksize: 4, mainParameter: "blocksize", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uBlocksize;
uniform float uStepW;
uniform float uStepH;
varying vec2 vTexCoord;
void main() {
float blockW = uBlocksize * uStepW;
float blockH = uBlocksize * uStepW;
int posX = int(vTexCoord.x / blockW);
int posY = int(vTexCoord.y / blockH);
float fposX = float(posX);
float fposY = float(posY);
vec2 squareCoords = vec2(fposX * blockW, fposY * blockH);
vec4 color = texture2D(uTexture, squareCoords);
gl_FragColor = color;
}`, applyTo2d: function(i) {
      var r, s, u, h, d, m, y, b, S, E, A, M = i.imageData, C = M.data, O = M.height, N = M.width;
      for (s = 0; s < O; s += this.blocksize) for (u = 0; u < N; u += this.blocksize) for (h = C[r = 4 * s * N + 4 * u], d = C[r + 1], m = C[r + 2], y = C[r + 3], E = Math.min(s + this.blocksize, O), A = Math.min(u + this.blocksize, N), b = s; b < E; b++) for (S = u; S < A; S++) C[r = 4 * b * N + 4 * S] = h, C[r + 1] = d, C[r + 2] = m, C[r + 3] = y;
    }, isNeutralState: function() {
      return this.blocksize === 1;
    }, getUniformLocations: function(i, r) {
      return { uBlocksize: i.getUniformLocation(r, "uBlocksize"), uStepW: i.getUniformLocation(r, "uStepW"), uStepH: i.getUniformLocation(r, "uStepH") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uBlocksize, this.blocksize);
    } }), o.Image.filters.Pixelate.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.extend, f = o.Image.filters, i = o.util.createClass;
    f.RemoveColor = i(f.BaseFilter, { type: "RemoveColor", color: "#FFFFFF", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec4 uLow;
uniform vec4 uHigh;
varying vec2 vTexCoord;
void main() {
gl_FragColor = texture2D(uTexture, vTexCoord);
if(all(greaterThan(gl_FragColor.rgb,uLow.rgb)) && all(greaterThan(uHigh.rgb,gl_FragColor.rgb))) {
gl_FragColor.a = 0.0;
}
}`, distance: 0.02, useAlpha: !1, applyTo2d: function(r) {
      var s, u, h, d, m = r.imageData.data, y = 255 * this.distance, b = new o.Color(this.color).getSource(), S = [b[0] - y, b[1] - y, b[2] - y], E = [b[0] + y, b[1] + y, b[2] + y];
      for (s = 0; s < m.length; s += 4) u = m[s], h = m[s + 1], d = m[s + 2], u > S[0] && h > S[1] && d > S[2] && u < E[0] && h < E[1] && d < E[2] && (m[s + 3] = 0);
    }, getUniformLocations: function(r, s) {
      return { uLow: r.getUniformLocation(s, "uLow"), uHigh: r.getUniformLocation(s, "uHigh") };
    }, sendUniformData: function(r, s) {
      var u = new o.Color(this.color).getSource(), h = parseFloat(this.distance), d = [0 + u[0] / 255 - h, 0 + u[1] / 255 - h, 0 + u[2] / 255 - h, 1], m = [u[0] / 255 + h, u[1] / 255 + h, u[2] / 255 + h, 1];
      r.uniform4fv(s.uLow, d), r.uniform4fv(s.uHigh, m);
    }, toObject: function() {
      return l(this.callSuper("toObject"), { color: this.color, distance: this.distance });
    } }), o.Image.filters.RemoveColor.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass, i = { Brownie: [0.5997, 0.34553, -0.27082, 0, 0.186, -0.0377, 0.86095, 0.15059, 0, -0.1449, 0.24113, -0.07441, 0.44972, 0, -0.02965, 0, 0, 0, 1, 0], Vintage: [0.62793, 0.32021, -0.03965, 0, 0.03784, 0.02578, 0.64411, 0.03259, 0, 0.02926, 0.0466, -0.08512, 0.52416, 0, 0.02023, 0, 0, 0, 1, 0], Kodachrome: [1.12855, -0.39673, -0.03992, 0, 0.24991, -0.16404, 1.08352, -0.05498, 0, 0.09698, -0.16786, -0.56034, 1.60148, 0, 0.13972, 0, 0, 0, 1, 0], Technicolor: [1.91252, -0.85453, -0.09155, 0, 0.04624, -0.30878, 1.76589, -0.10601, 0, -0.27589, -0.2311, -0.75018, 1.84759, 0, 0.12137, 0, 0, 0, 1, 0], Polaroid: [1.438, -0.062, -0.062, 0, 0, -0.122, 1.378, -0.122, 0, 0, -0.016, -0.016, 1.483, 0, 0, 0, 0, 0, 1, 0], Sepia: [0.393, 0.769, 0.189, 0, 0, 0.349, 0.686, 0.168, 0, 0, 0.272, 0.534, 0.131, 0, 0, 0, 0, 0, 1, 0], BlackWhite: [1.5, 1.5, 1.5, 0, -1, 1.5, 1.5, 1.5, 0, -1, 1.5, 1.5, 1.5, 0, -1, 0, 0, 0, 1, 0] };
    for (var r in i) l[r] = f(l.ColorMatrix, { type: r, matrix: i[r], mainParameter: !1, colorsOnly: !0 }), o.Image.filters[r].fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric, l = o.Image.filters, f = o.util.createClass;
    l.BlendColor = f(l.BaseFilter, { type: "BlendColor", color: "#F95C63", mode: "multiply", alpha: 1, fragmentSource: { multiply: `gl_FragColor.rgb *= uColor.rgb;
`, screen: `gl_FragColor.rgb = 1.0 - (1.0 - gl_FragColor.rgb) * (1.0 - uColor.rgb);
`, add: `gl_FragColor.rgb += uColor.rgb;
`, diff: `gl_FragColor.rgb = abs(gl_FragColor.rgb - uColor.rgb);
`, subtract: `gl_FragColor.rgb -= uColor.rgb;
`, lighten: `gl_FragColor.rgb = max(gl_FragColor.rgb, uColor.rgb);
`, darken: `gl_FragColor.rgb = min(gl_FragColor.rgb, uColor.rgb);
`, exclusion: `gl_FragColor.rgb += uColor.rgb - 2.0 * (uColor.rgb * gl_FragColor.rgb);
`, overlay: `if (uColor.r < 0.5) {
gl_FragColor.r *= 2.0 * uColor.r;
} else {
gl_FragColor.r = 1.0 - 2.0 * (1.0 - gl_FragColor.r) * (1.0 - uColor.r);
}
if (uColor.g < 0.5) {
gl_FragColor.g *= 2.0 * uColor.g;
} else {
gl_FragColor.g = 1.0 - 2.0 * (1.0 - gl_FragColor.g) * (1.0 - uColor.g);
}
if (uColor.b < 0.5) {
gl_FragColor.b *= 2.0 * uColor.b;
} else {
gl_FragColor.b = 1.0 - 2.0 * (1.0 - gl_FragColor.b) * (1.0 - uColor.b);
}
`, tint: `gl_FragColor.rgb *= (1.0 - uColor.a);
gl_FragColor.rgb += uColor.rgb;
` }, buildSource: function(i) {
      return `precision highp float;
uniform sampler2D uTexture;
uniform vec4 uColor;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
gl_FragColor = color;
if (color.a > 0.0) {
` + this.fragmentSource[i] + `}
}`;
    }, retrieveShader: function(i) {
      var r, s = this.type + "_" + this.mode;
      return i.programCache.hasOwnProperty(s) || (r = this.buildSource(this.mode), i.programCache[s] = this.createProgram(i.context, r)), i.programCache[s];
    }, applyTo2d: function(i) {
      var r, s, u, h, d, m, y, b = i.imageData.data, S = b.length, E = 1 - this.alpha;
      r = (y = new o.Color(this.color).getSource())[0] * this.alpha, s = y[1] * this.alpha, u = y[2] * this.alpha;
      for (var A = 0; A < S; A += 4) switch (h = b[A], d = b[A + 1], m = b[A + 2], this.mode) {
        case "multiply":
          b[A] = h * r / 255, b[A + 1] = d * s / 255, b[A + 2] = m * u / 255;
          break;
        case "screen":
          b[A] = 255 - (255 - h) * (255 - r) / 255, b[A + 1] = 255 - (255 - d) * (255 - s) / 255, b[A + 2] = 255 - (255 - m) * (255 - u) / 255;
          break;
        case "add":
          b[A] = h + r, b[A + 1] = d + s, b[A + 2] = m + u;
          break;
        case "diff":
        case "difference":
          b[A] = Math.abs(h - r), b[A + 1] = Math.abs(d - s), b[A + 2] = Math.abs(m - u);
          break;
        case "subtract":
          b[A] = h - r, b[A + 1] = d - s, b[A + 2] = m - u;
          break;
        case "darken":
          b[A] = Math.min(h, r), b[A + 1] = Math.min(d, s), b[A + 2] = Math.min(m, u);
          break;
        case "lighten":
          b[A] = Math.max(h, r), b[A + 1] = Math.max(d, s), b[A + 2] = Math.max(m, u);
          break;
        case "overlay":
          b[A] = r < 128 ? 2 * h * r / 255 : 255 - 2 * (255 - h) * (255 - r) / 255, b[A + 1] = s < 128 ? 2 * d * s / 255 : 255 - 2 * (255 - d) * (255 - s) / 255, b[A + 2] = u < 128 ? 2 * m * u / 255 : 255 - 2 * (255 - m) * (255 - u) / 255;
          break;
        case "exclusion":
          b[A] = r + h - 2 * r * h / 255, b[A + 1] = s + d - 2 * s * d / 255, b[A + 2] = u + m - 2 * u * m / 255;
          break;
        case "tint":
          b[A] = r + h * E, b[A + 1] = s + d * E, b[A + 2] = u + m * E;
      }
    }, getUniformLocations: function(i, r) {
      return { uColor: i.getUniformLocation(r, "uColor") };
    }, sendUniformData: function(i, r) {
      var s = new o.Color(this.color).getSource();
      s[0] = this.alpha * s[0] / 255, s[1] = this.alpha * s[1] / 255, s[2] = this.alpha * s[2] / 255, s[3] = this.alpha, i.uniform4fv(r.uColor, s);
    }, toObject: function() {
      return { type: this.type, color: this.color, mode: this.mode, alpha: this.alpha };
    } }), o.Image.filters.BlendColor.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric, l = o.Image.filters, f = o.util.createClass;
    l.BlendImage = f(l.BaseFilter, { type: "BlendImage", image: null, mode: "multiply", alpha: 1, vertexSource: `attribute vec2 aPosition;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
uniform mat3 uTransformMatrix;
void main() {
vTexCoord = aPosition;
vTexCoord2 = (uTransformMatrix * vec3(aPosition, 1.0)).xy;
gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
}`, fragmentSource: { multiply: `precision highp float;
uniform sampler2D uTexture;
uniform sampler2D uImage;
uniform vec4 uColor;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec4 color2 = texture2D(uImage, vTexCoord2);
color.rgba *= color2.rgba;
gl_FragColor = color;
}`, mask: `precision highp float;
uniform sampler2D uTexture;
uniform sampler2D uImage;
uniform vec4 uColor;
varying vec2 vTexCoord;
varying vec2 vTexCoord2;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec4 color2 = texture2D(uImage, vTexCoord2);
color.a = color2.a;
gl_FragColor = color;
}` }, retrieveShader: function(i) {
      var r = this.type + "_" + this.mode, s = this.fragmentSource[this.mode];
      return i.programCache.hasOwnProperty(r) || (i.programCache[r] = this.createProgram(i.context, s)), i.programCache[r];
    }, applyToWebGL: function(i) {
      var r = i.context, s = this.createTexture(i.filterBackend, this.image);
      this.bindAdditionalTexture(r, s, r.TEXTURE1), this.callSuper("applyToWebGL", i), this.unbindAdditionalTexture(r, r.TEXTURE1);
    }, createTexture: function(i, r) {
      return i.getCachedTexture(r.cacheKey, r._element);
    }, calculateMatrix: function() {
      var i = this.image, r = i._element.width, s = i._element.height;
      return [1 / i.scaleX, 0, 0, 0, 1 / i.scaleY, 0, -i.left / r, -i.top / s, 1];
    }, applyTo2d: function(i) {
      var r, s, u, h, d, m, y, b, S, E, A, M = i.imageData, C = i.filterBackend.resources, O = M.data, N = O.length, z = M.width, W = M.height, F = this.image;
      C.blendImage || (C.blendImage = o.util.createCanvasElement()), E = (S = C.blendImage).getContext("2d"), S.width !== z || S.height !== W ? (S.width = z, S.height = W) : E.clearRect(0, 0, z, W), E.setTransform(F.scaleX, 0, 0, F.scaleY, F.left, F.top), E.drawImage(F._element, 0, 0, z, W), A = E.getImageData(0, 0, z, W).data;
      for (var k = 0; k < N; k += 4) switch (d = O[k], m = O[k + 1], y = O[k + 2], b = O[k + 3], r = A[k], s = A[k + 1], u = A[k + 2], h = A[k + 3], this.mode) {
        case "multiply":
          O[k] = d * r / 255, O[k + 1] = m * s / 255, O[k + 2] = y * u / 255, O[k + 3] = b * h / 255;
          break;
        case "mask":
          O[k + 3] = h;
      }
    }, getUniformLocations: function(i, r) {
      return { uTransformMatrix: i.getUniformLocation(r, "uTransformMatrix"), uImage: i.getUniformLocation(r, "uImage") };
    }, sendUniformData: function(i, r) {
      var s = this.calculateMatrix();
      i.uniform1i(r.uImage, 1), i.uniformMatrix3fv(r.uTransformMatrix, !1, s);
    }, toObject: function() {
      return { type: this.type, image: this.image && this.image.toObject(), mode: this.mode, alpha: this.alpha };
    } }), o.Image.filters.BlendImage.fromObject = function(i, r) {
      o.Image.fromObject(i.image, function(s) {
        var u = o.util.object.clone(i);
        u.image = s, r(new o.Image.filters.BlendImage(u));
      });
    };
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = Math.pow, f = Math.floor, i = Math.sqrt, r = Math.abs, s = Math.round, u = Math.sin, h = Math.ceil, d = o.Image.filters, m = o.util.createClass;
    d.Resize = m(d.BaseFilter, { type: "Resize", resizeType: "hermite", scaleX: 1, scaleY: 1, lanczosLobes: 3, getUniformLocations: function(y, b) {
      return { uDelta: y.getUniformLocation(b, "uDelta"), uTaps: y.getUniformLocation(b, "uTaps") };
    }, sendUniformData: function(y, b) {
      y.uniform2fv(b.uDelta, this.horizontal ? [1 / this.width, 0] : [0, 1 / this.height]), y.uniform1fv(b.uTaps, this.taps);
    }, retrieveShader: function(y) {
      var b = this.getFilterWindow(), S = this.type + "_" + b;
      if (!y.programCache.hasOwnProperty(S)) {
        var E = this.generateShader(b);
        y.programCache[S] = this.createProgram(y.context, E);
      }
      return y.programCache[S];
    }, getFilterWindow: function() {
      var y = this.tempScale;
      return Math.ceil(this.lanczosLobes / y);
    }, getTaps: function() {
      for (var y = this.lanczosCreate(this.lanczosLobes), b = this.tempScale, S = this.getFilterWindow(), E = new Array(S), A = 1; A <= S; A++) E[A - 1] = y(A * b);
      return E;
    }, generateShader: function(y) {
      for (var b = new Array(y), S = this.fragmentSourceTOP, E = 1; E <= y; E++) b[E - 1] = E + ".0 * uDelta";
      return S += "uniform float uTaps[" + y + `];
`, S += `void main() {
`, S += `  vec4 color = texture2D(uTexture, vTexCoord);
`, S += `  float sum = 1.0;
`, b.forEach(function(A, M) {
        S += "  color += texture2D(uTexture, vTexCoord + " + A + ") * uTaps[" + M + `];
`, S += "  color += texture2D(uTexture, vTexCoord - " + A + ") * uTaps[" + M + `];
`, S += "  sum += 2.0 * uTaps[" + M + `];
`;
      }), S += `  gl_FragColor = color / sum;
`, S += "}";
    }, fragmentSourceTOP: `precision highp float;
uniform sampler2D uTexture;
uniform vec2 uDelta;
varying vec2 vTexCoord;
`, applyTo: function(y) {
      y.webgl ? (y.passes++, this.width = y.sourceWidth, this.horizontal = !0, this.dW = Math.round(this.width * this.scaleX), this.dH = y.sourceHeight, this.tempScale = this.dW / this.width, this.taps = this.getTaps(), y.destinationWidth = this.dW, this._setupFrameBuffer(y), this.applyToWebGL(y), this._swapTextures(y), y.sourceWidth = y.destinationWidth, this.height = y.sourceHeight, this.horizontal = !1, this.dH = Math.round(this.height * this.scaleY), this.tempScale = this.dH / this.height, this.taps = this.getTaps(), y.destinationHeight = this.dH, this._setupFrameBuffer(y), this.applyToWebGL(y), this._swapTextures(y), y.sourceHeight = y.destinationHeight) : this.applyTo2d(y);
    }, isNeutralState: function() {
      return this.scaleX === 1 && this.scaleY === 1;
    }, lanczosCreate: function(y) {
      return function(b) {
        if (b >= y || b <= -y) return 0;
        if (b < 11920929e-14 && b > -11920929e-14) return 1;
        var S = (b *= Math.PI) / y;
        return u(b) / b * u(S) / S;
      };
    }, applyTo2d: function(y) {
      var b = y.imageData, S = this.scaleX, E = this.scaleY;
      this.rcpScaleX = 1 / S, this.rcpScaleY = 1 / E;
      var A, M = b.width, C = b.height, O = s(M * S), N = s(C * E);
      this.resizeType === "sliceHack" ? A = this.sliceByTwo(y, M, C, O, N) : this.resizeType === "hermite" ? A = this.hermiteFastResize(y, M, C, O, N) : this.resizeType === "bilinear" ? A = this.bilinearFiltering(y, M, C, O, N) : this.resizeType === "lanczos" && (A = this.lanczosResize(y, M, C, O, N)), y.imageData = A;
    }, sliceByTwo: function(y, b, S, E, A) {
      var M, C, O = y.imageData, N = 0.5, z = !1, W = !1, F = b * N, k = S * N, B = o.filterBackend.resources, Z = 0, K = 0, U = b, R = 0;
      for (B.sliceByTwo || (B.sliceByTwo = document.createElement("canvas")), ((M = B.sliceByTwo).width < 1.5 * b || M.height < S) && (M.width = 1.5 * b, M.height = S), (C = M.getContext("2d")).clearRect(0, 0, 1.5 * b, S), C.putImageData(O, 0, 0), E = f(E), A = f(A); !z || !W; ) b = F, S = k, E < f(F * N) ? F = f(F * N) : (F = E, z = !0), A < f(k * N) ? k = f(k * N) : (k = A, W = !0), C.drawImage(M, Z, K, b, S, U, R, F, k), Z = U, K = R, R += k;
      return C.getImageData(Z, K, E, A);
    }, lanczosResize: function(y, b, S, E, A) {
      var M = y.imageData.data, C = y.ctx.createImageData(E, A), O = C.data, N = this.lanczosCreate(this.lanczosLobes), z = this.rcpScaleX, W = this.rcpScaleY, F = 2 / this.rcpScaleX, k = 2 / this.rcpScaleY, B = h(z * this.lanczosLobes / 2), Z = h(W * this.lanczosLobes / 2), K = {}, U = {}, R = {};
      return function H(q) {
        var Q, nt, gt, ct, ft, st, lt, at, yt, mt, Mt;
        for (U.x = (q + 0.5) * z, R.x = f(U.x), Q = 0; Q < A; Q++) {
          for (U.y = (Q + 0.5) * W, R.y = f(U.y), ft = 0, st = 0, lt = 0, at = 0, yt = 0, nt = R.x - B; nt <= R.x + B; nt++) if (!(nt < 0 || nt >= b)) {
            mt = f(1e3 * r(nt - U.x)), K[mt] || (K[mt] = {});
            for (var Ot = R.y - Z; Ot <= R.y + Z; Ot++) Ot < 0 || Ot >= S || (Mt = f(1e3 * r(Ot - U.y)), K[mt][Mt] || (K[mt][Mt] = N(i(l(mt * F, 2) + l(Mt * k, 2)) / 1e3)), (gt = K[mt][Mt]) > 0 && (ft += gt, st += gt * M[ct = 4 * (Ot * b + nt)], lt += gt * M[ct + 1], at += gt * M[ct + 2], yt += gt * M[ct + 3]));
          }
          O[ct = 4 * (Q * E + q)] = st / ft, O[ct + 1] = lt / ft, O[ct + 2] = at / ft, O[ct + 3] = yt / ft;
        }
        return ++q < E ? H(q) : C;
      }(0);
    }, bilinearFiltering: function(y, b, S, E, A) {
      var M, C, O, N, z, W, F, k, B, Z = 0, K = this.rcpScaleX, U = this.rcpScaleY, R = 4 * (b - 1), H = y.imageData.data, q = y.ctx.createImageData(E, A), Q = q.data;
      for (O = 0; O < A; O++) for (N = 0; N < E; N++) for (z = K * N - (M = f(K * N)), W = U * O - (C = f(U * O)), B = 4 * (C * b + M), F = 0; F < 4; F++) k = H[B + F] * (1 - z) * (1 - W) + H[B + 4 + F] * z * (1 - W) + H[B + R + F] * W * (1 - z) + H[B + R + 4 + F] * z * W, Q[Z++] = k;
      return q;
    }, hermiteFastResize: function(y, b, S, E, A) {
      for (var M = this.rcpScaleX, C = this.rcpScaleY, O = h(M / 2), N = h(C / 2), z = y.imageData.data, W = y.ctx.createImageData(E, A), F = W.data, k = 0; k < A; k++) for (var B = 0; B < E; B++) {
        for (var Z = 4 * (B + k * E), K = 0, U = 0, R = 0, H = 0, q = 0, Q = 0, nt = 0, gt = (k + 0.5) * C, ct = f(k * C); ct < (k + 1) * C; ct++) for (var ft = r(gt - (ct + 0.5)) / N, st = (B + 0.5) * M, lt = ft * ft, at = f(B * M); at < (B + 1) * M; at++) {
          var yt = r(st - (at + 0.5)) / O, mt = i(lt + yt * yt);
          mt > 1 && mt < -1 || (K = 2 * mt * mt * mt - 3 * mt * mt + 1) > 0 && (nt += K * z[(yt = 4 * (at + ct * b)) + 3], R += K, z[yt + 3] < 255 && (K = K * z[yt + 3] / 250), H += K * z[yt], q += K * z[yt + 1], Q += K * z[yt + 2], U += K);
        }
        F[Z] = H / U, F[Z + 1] = q / U, F[Z + 2] = Q / U, F[Z + 3] = nt / R;
      }
      return W;
    }, toObject: function() {
      return { type: this.type, scaleX: this.scaleX, scaleY: this.scaleY, resizeType: this.resizeType, lanczosLobes: this.lanczosLobes };
    } }), o.Image.filters.Resize.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Contrast = f(l.BaseFilter, { type: "Contrast", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uContrast;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float contrastF = 1.015 * (uContrast + 1.0) / (1.0 * (1.015 - uContrast));
color.rgb = contrastF * (color.rgb - 0.5) + 0.5;
gl_FragColor = color;
}`, contrast: 0, mainParameter: "contrast", applyTo2d: function(i) {
      if (this.contrast !== 0) {
        var r, s = i.imageData.data, u = s.length, h = Math.floor(255 * this.contrast), d = 259 * (h + 255) / (255 * (259 - h));
        for (r = 0; r < u; r += 4) s[r] = d * (s[r] - 128) + 128, s[r + 1] = d * (s[r + 1] - 128) + 128, s[r + 2] = d * (s[r + 2] - 128) + 128;
      }
    }, getUniformLocations: function(i, r) {
      return { uContrast: i.getUniformLocation(r, "uContrast") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uContrast, this.contrast);
    } }), o.Image.filters.Contrast.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Saturation = f(l.BaseFilter, { type: "Saturation", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uSaturation;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float rgMax = max(color.r, color.g);
float rgbMax = max(rgMax, color.b);
color.r += rgbMax != color.r ? (rgbMax - color.r) * uSaturation : 0.00;
color.g += rgbMax != color.g ? (rgbMax - color.g) * uSaturation : 0.00;
color.b += rgbMax != color.b ? (rgbMax - color.b) * uSaturation : 0.00;
gl_FragColor = color;
}`, saturation: 0, mainParameter: "saturation", applyTo2d: function(i) {
      if (this.saturation !== 0) {
        var r, s, u = i.imageData.data, h = u.length, d = -this.saturation;
        for (r = 0; r < h; r += 4) s = Math.max(u[r], u[r + 1], u[r + 2]), u[r] += s !== u[r] ? (s - u[r]) * d : 0, u[r + 1] += s !== u[r + 1] ? (s - u[r + 1]) * d : 0, u[r + 2] += s !== u[r + 2] ? (s - u[r + 2]) * d : 0;
      }
    }, getUniformLocations: function(i, r) {
      return { uSaturation: i.getUniformLocation(r, "uSaturation") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uSaturation, -this.saturation);
    } }), o.Image.filters.Saturation.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Vibrance = f(l.BaseFilter, { type: "Vibrance", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform float uVibrance;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
float max = max(color.r, max(color.g, color.b));
float avg = (color.r + color.g + color.b) / 3.0;
float amt = (abs(max - avg) * 2.0) * uVibrance;
color.r += max != color.r ? (max - color.r) * amt : 0.00;
color.g += max != color.g ? (max - color.g) * amt : 0.00;
color.b += max != color.b ? (max - color.b) * amt : 0.00;
gl_FragColor = color;
}`, vibrance: 0, mainParameter: "vibrance", applyTo2d: function(i) {
      if (this.vibrance !== 0) {
        var r, s, u, h, d = i.imageData.data, m = d.length, y = -this.vibrance;
        for (r = 0; r < m; r += 4) s = Math.max(d[r], d[r + 1], d[r + 2]), u = (d[r] + d[r + 1] + d[r + 2]) / 3, h = 2 * Math.abs(s - u) / 255 * y, d[r] += s !== d[r] ? (s - d[r]) * h : 0, d[r + 1] += s !== d[r + 1] ? (s - d[r + 1]) * h : 0, d[r + 2] += s !== d[r + 2] ? (s - d[r + 2]) * h : 0;
      }
    }, getUniformLocations: function(i, r) {
      return { uVibrance: i.getUniformLocation(r, "uVibrance") };
    }, sendUniformData: function(i, r) {
      i.uniform1f(r.uVibrance, -this.vibrance);
    } }), o.Image.filters.Vibrance.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Blur = f(l.BaseFilter, { type: "Blur", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec2 uDelta;
varying vec2 vTexCoord;
const float nSamples = 15.0;
vec3 v3offset = vec3(12.9898, 78.233, 151.7182);
float random(vec3 scale) {
return fract(sin(dot(gl_FragCoord.xyz, scale)) * 43758.5453);
}
void main() {
vec4 color = vec4(0.0);
float total = 0.0;
float offset = random(v3offset);
for (float t = -nSamples; t <= nSamples; t++) {
float percent = (t + offset - 0.5) / nSamples;
float weight = 1.0 - abs(percent);
color += texture2D(uTexture, vTexCoord + uDelta * percent) * weight;
total += weight;
}
gl_FragColor = color / total;
}`, blur: 0, mainParameter: "blur", applyTo: function(i) {
      i.webgl ? (this.aspectRatio = i.sourceWidth / i.sourceHeight, i.passes++, this._setupFrameBuffer(i), this.horizontal = !0, this.applyToWebGL(i), this._swapTextures(i), this._setupFrameBuffer(i), this.horizontal = !1, this.applyToWebGL(i), this._swapTextures(i)) : this.applyTo2d(i);
    }, applyTo2d: function(i) {
      i.imageData = this.simpleBlur(i);
    }, simpleBlur: function(i) {
      var r, s, u = i.filterBackend.resources, h = i.imageData.width, d = i.imageData.height;
      u.blurLayer1 || (u.blurLayer1 = o.util.createCanvasElement(), u.blurLayer2 = o.util.createCanvasElement()), r = u.blurLayer1, s = u.blurLayer2, r.width === h && r.height === d || (s.width = r.width = h, s.height = r.height = d);
      var m, y, b, S, E = r.getContext("2d"), A = s.getContext("2d"), M = 15, C = 0.06 * this.blur * 0.5;
      for (E.putImageData(i.imageData, 0, 0), A.clearRect(0, 0, h, d), S = -15; S <= M; S++) b = C * (y = S / M) * h + (m = (Math.random() - 0.5) / 4), A.globalAlpha = 1 - Math.abs(y), A.drawImage(r, b, m), E.drawImage(s, 0, 0), A.globalAlpha = 1, A.clearRect(0, 0, s.width, s.height);
      for (S = -15; S <= M; S++) b = C * (y = S / M) * d + (m = (Math.random() - 0.5) / 4), A.globalAlpha = 1 - Math.abs(y), A.drawImage(r, m, b), E.drawImage(s, 0, 0), A.globalAlpha = 1, A.clearRect(0, 0, s.width, s.height);
      i.ctx.drawImage(r, 0, 0);
      var O = i.ctx.getImageData(0, 0, r.width, r.height);
      return E.globalAlpha = 1, E.clearRect(0, 0, r.width, r.height), O;
    }, getUniformLocations: function(i, r) {
      return { delta: i.getUniformLocation(r, "uDelta") };
    }, sendUniformData: function(i, r) {
      var s = this.chooseRightDelta();
      i.uniform2fv(r.delta, s);
    }, chooseRightDelta: function() {
      var i, r = 1, s = [0, 0];
      return this.horizontal ? this.aspectRatio > 1 && (r = 1 / this.aspectRatio) : this.aspectRatio < 1 && (r = this.aspectRatio), i = r * this.blur * 0.12, this.horizontal ? s[0] = i : s[1] = i, s;
    } }), l.Blur.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Gamma = f(l.BaseFilter, { type: "Gamma", fragmentSource: `precision highp float;
uniform sampler2D uTexture;
uniform vec3 uGamma;
varying vec2 vTexCoord;
void main() {
vec4 color = texture2D(uTexture, vTexCoord);
vec3 correction = (1.0 / uGamma);
color.r = pow(color.r, correction.r);
color.g = pow(color.g, correction.g);
color.b = pow(color.b, correction.b);
gl_FragColor = color;
gl_FragColor.rgb *= color.a;
}`, gamma: [1, 1, 1], mainParameter: "gamma", initialize: function(i) {
      this.gamma = [1, 1, 1], l.BaseFilter.prototype.initialize.call(this, i);
    }, applyTo2d: function(i) {
      var r, s = i.imageData.data, u = this.gamma, h = s.length, d = 1 / u[0], m = 1 / u[1], y = 1 / u[2];
      for (this.rVals || (this.rVals = new Uint8Array(256), this.gVals = new Uint8Array(256), this.bVals = new Uint8Array(256)), r = 0, h = 256; r < h; r++) this.rVals[r] = 255 * Math.pow(r / 255, d), this.gVals[r] = 255 * Math.pow(r / 255, m), this.bVals[r] = 255 * Math.pow(r / 255, y);
      for (r = 0, h = s.length; r < h; r += 4) s[r] = this.rVals[s[r]], s[r + 1] = this.gVals[s[r + 1]], s[r + 2] = this.bVals[s[r + 2]];
    }, getUniformLocations: function(i, r) {
      return { uGamma: i.getUniformLocation(r, "uGamma") };
    }, sendUniformData: function(i, r) {
      i.uniform3fv(r.uGamma, this.gamma);
    } }), o.Image.filters.Gamma.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.Composed = f(l.BaseFilter, { type: "Composed", subFilters: [], initialize: function(i) {
      this.callSuper("initialize", i), this.subFilters = this.subFilters.slice(0);
    }, applyTo: function(i) {
      i.passes += this.subFilters.length - 1, this.subFilters.forEach(function(r) {
        r.applyTo(i);
      });
    }, toObject: function() {
      return o.util.object.extend(this.callSuper("toObject"), { subFilters: this.subFilters.map(function(i) {
        return i.toObject();
      }) });
    }, isNeutralState: function() {
      return !this.subFilters.some(function(i) {
        return !i.isNeutralState();
      });
    } }), o.Image.filters.Composed.fromObject = function(i, r) {
      var s = (i.subFilters || []).map(function(h) {
        return new o.Image.filters[h.type](h);
      }), u = new o.Image.filters.Composed({ subFilters: s });
      return r && r(u), u;
    };
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.Image.filters, f = o.util.createClass;
    l.HueRotation = f(l.ColorMatrix, { type: "HueRotation", rotation: 0, mainParameter: "rotation", calculateMatrix: function() {
      var i = this.rotation * Math.PI, r = o.util.cos(i), s = o.util.sin(i), u = 1 / 3, h = Math.sqrt(u) * s, d = 1 - r;
      this.matrix = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0], this.matrix[0] = r + d / 3, this.matrix[1] = u * d - h, this.matrix[2] = u * d + h, this.matrix[5] = u * d + h, this.matrix[6] = r + u * d, this.matrix[7] = u * d - h, this.matrix[10] = u * d - h, this.matrix[11] = u * d + h, this.matrix[12] = r + u * d;
    }, isNeutralState: function(i) {
      return this.calculateMatrix(), l.BaseFilter.prototype.isNeutralState.call(this, i);
    }, applyTo: function(i) {
      this.calculateMatrix(), l.BaseFilter.prototype.applyTo.call(this, i);
    } }), o.Image.filters.HueRotation.fromObject = o.Image.filters.BaseFilter.fromObject;
  }(t), function(c) {
    var o = c.fabric || (c.fabric = {}), l = o.util.object.clone;
    if (o.Text) o.warn("fabric.Text is already defined");
    else {
      var f = "fontFamily fontWeight fontSize text underline overline linethrough textAlign fontStyle lineHeight textBackgroundColor charSpacing styles direction path pathStartOffset pathSide".split(" ");
      o.Text = o.util.createClass(o.Object, { _dimensionAffectingProps: ["fontSize", "fontWeight", "fontFamily", "fontStyle", "lineHeight", "text", "charSpacing", "textAlign", "styles", "path", "pathStartOffset", "pathSide"], _reNewline: /\r?\n/, _reSpacesAndTabs: /[ \t\r]/g, _reSpaceAndTab: /[ \t\r]/, _reWords: /\S+/g, type: "text", fontSize: 40, fontWeight: "normal", fontFamily: "Times New Roman", underline: !1, overline: !1, linethrough: !1, textAlign: "left", fontStyle: "normal", lineHeight: 1.16, superscript: { size: 0.6, baseline: -0.35 }, subscript: { size: 0.6, baseline: 0.11 }, textBackgroundColor: "", stateProperties: o.Object.prototype.stateProperties.concat(f), cacheProperties: o.Object.prototype.cacheProperties.concat(f), stroke: null, shadow: null, path: null, pathStartOffset: 0, pathSide: "left", _fontSizeFraction: 0.222, offsets: { underline: 0.1, linethrough: -0.315, overline: -0.88 }, _fontSizeMult: 1.13, charSpacing: 0, styles: null, _measuringContext: null, deltaY: 0, direction: "ltr", _styleProperties: ["stroke", "strokeWidth", "fill", "fontFamily", "fontSize", "fontWeight", "fontStyle", "underline", "overline", "linethrough", "deltaY", "textBackgroundColor"], __charBounds: [], CACHE_FONT_SIZE: 400, MIN_TEXT_WIDTH: 2, initialize: function(i, r) {
        this.styles = r && r.styles || {}, this.text = i, this.__skipDimension = !0, this.callSuper("initialize", r), this.path && this.setPathInfo(), this.__skipDimension = !1, this.initDimensions(), this.setCoords(), this.setupState({ propertySet: "_dimensionAffectingProps" });
      }, setPathInfo: function() {
        var i = this.path;
        i && (i.segmentsInfo = o.util.getPathSegmentsInfo(i.path));
      }, getMeasuringContext: function() {
        return o._measuringContext || (o._measuringContext = this.canvas && this.canvas.contextCache || o.util.createCanvasElement().getContext("2d")), o._measuringContext;
      }, _splitText: function() {
        var i = this._splitTextIntoLines(this.text);
        return this.textLines = i.lines, this._textLines = i.graphemeLines, this._unwrappedTextLines = i._unwrappedLines, this._text = i.graphemeText, i;
      }, initDimensions: function() {
        this.__skipDimension || (this._splitText(), this._clearCache(), this.path ? (this.width = this.path.width, this.height = this.path.height) : (this.width = this.calcTextWidth() || this.cursorWidth || this.MIN_TEXT_WIDTH, this.height = this.calcTextHeight()), this.textAlign.indexOf("justify") !== -1 && this.enlargeSpaces(), this.saveState({ propertySet: "_dimensionAffectingProps" }));
      }, enlargeSpaces: function() {
        for (var i, r, s, u, h, d, m, y = 0, b = this._textLines.length; y < b; y++) if ((this.textAlign === "justify" || y !== b - 1 && !this.isEndOfWrapping(y)) && (u = 0, h = this._textLines[y], (r = this.getLineWidth(y)) < this.width && (m = this.textLines[y].match(this._reSpacesAndTabs)))) {
          s = m.length, i = (this.width - r) / s;
          for (var S = 0, E = h.length; S <= E; S++) d = this.__charBounds[y][S], this._reSpaceAndTab.test(h[S]) ? (d.width += i, d.kernedWidth += i, d.left += u, u += i) : d.left += u;
        }
      }, isEndOfWrapping: function(i) {
        return i === this._textLines.length - 1;
      }, missingNewlineOffset: function() {
        return 1;
      }, toString: function() {
        return "#<fabric.Text (" + this.complexity() + '): { "text": "' + this.text + '", "fontFamily": "' + this.fontFamily + '" }>';
      }, _getCacheCanvasDimensions: function() {
        var i = this.callSuper("_getCacheCanvasDimensions"), r = this.fontSize;
        return i.width += r * i.zoomX, i.height += r * i.zoomY, i;
      }, _render: function(i) {
        var r = this.path;
        r && !r.isNotVisible() && r._render(i), this._setTextStyles(i), this._renderTextLinesBackground(i), this._renderTextDecoration(i, "underline"), this._renderText(i), this._renderTextDecoration(i, "overline"), this._renderTextDecoration(i, "linethrough");
      }, _renderText: function(i) {
        this.paintFirst === "stroke" ? (this._renderTextStroke(i), this._renderTextFill(i)) : (this._renderTextFill(i), this._renderTextStroke(i));
      }, _setTextStyles: function(i, r, s) {
        i.textBaseline = "alphabetic", i.font = this._getFontDeclaration(r, s);
      }, calcTextWidth: function() {
        for (var i = this.getLineWidth(0), r = 1, s = this._textLines.length; r < s; r++) {
          var u = this.getLineWidth(r);
          u > i && (i = u);
        }
        return i;
      }, _renderTextLine: function(i, r, s, u, h, d) {
        this._renderChars(i, r, s, u, h, d);
      }, _renderTextLinesBackground: function(i) {
        if (this.textBackgroundColor || this.styleHas("textBackgroundColor")) {
          for (var r, s, u, h, d, m, y, b = i.fillStyle, S = this._getLeftOffset(), E = this._getTopOffset(), A = 0, M = 0, C = this.path, O = 0, N = this._textLines.length; O < N; O++) if (r = this.getHeightOfLine(O), this.textBackgroundColor || this.styleHas("textBackgroundColor", O)) {
            u = this._textLines[O], s = this._getLineLeftOffset(O), M = 0, A = 0, h = this.getValueOfPropertyAt(O, 0, "textBackgroundColor");
            for (var z = 0, W = u.length; z < W; z++) d = this.__charBounds[O][z], m = this.getValueOfPropertyAt(O, z, "textBackgroundColor"), C ? (i.save(), i.translate(d.renderLeft, d.renderTop), i.rotate(d.angle), i.fillStyle = m, m && i.fillRect(-d.width / 2, -r / this.lineHeight * (1 - this._fontSizeFraction), d.width, r / this.lineHeight), i.restore()) : m !== h ? (y = S + s + A, this.direction === "rtl" && (y = this.width - y - M), i.fillStyle = h, h && i.fillRect(y, E, M, r / this.lineHeight), A = d.left, M = d.width, h = m) : M += d.kernedWidth;
            m && !C && (y = S + s + A, this.direction === "rtl" && (y = this.width - y - M), i.fillStyle = m, i.fillRect(y, E, M, r / this.lineHeight)), E += r;
          } else E += r;
          i.fillStyle = b, this._removeShadow(i);
        }
      }, getFontCache: function(i) {
        var r = i.fontFamily.toLowerCase();
        o.charWidthsCache[r] || (o.charWidthsCache[r] = {});
        var s = o.charWidthsCache[r], u = i.fontStyle.toLowerCase() + "_" + (i.fontWeight + "").toLowerCase();
        return s[u] || (s[u] = {}), s[u];
      }, _measureChar: function(i, r, s, u) {
        var h, d, m, y, b = this.getFontCache(r), S = s + i, E = this._getFontDeclaration(r) === this._getFontDeclaration(u), A = r.fontSize / this.CACHE_FONT_SIZE;
        if (s && b[s] !== void 0 && (m = b[s]), b[i] !== void 0 && (y = h = b[i]), E && b[S] !== void 0 && (y = (d = b[S]) - m), h === void 0 || m === void 0 || d === void 0) {
          var M = this.getMeasuringContext();
          this._setTextStyles(M, r, !0);
        }
        return h === void 0 && (y = h = M.measureText(i).width, b[i] = h), m === void 0 && E && s && (m = M.measureText(s).width, b[s] = m), E && d === void 0 && (d = M.measureText(S).width, b[S] = d, y = d - m), { width: h * A, kernedWidth: y * A };
      }, getHeightOfChar: function(i, r) {
        return this.getValueOfPropertyAt(i, r, "fontSize");
      }, measureLine: function(i) {
        var r = this._measureLine(i);
        return this.charSpacing !== 0 && (r.width -= this._getWidthOfCharSpacing()), r.width < 0 && (r.width = 0), r;
      }, _measureLine: function(i) {
        var r, s, u, h, d, m, y = 0, b = this._textLines[i], S = new Array(b.length), E = 0, A = this.path, M = this.pathSide === "right";
        for (this.__charBounds[i] = S, r = 0; r < b.length; r++) s = b[r], h = this._getGraphemeBox(s, i, r, u), S[r] = h, y += h.kernedWidth, u = s;
        if (S[r] = { left: h ? h.left + h.width : 0, width: 0, kernedWidth: 0, height: this.fontSize }, A) {
          switch (m = A.segmentsInfo[A.segmentsInfo.length - 1].length, (d = o.util.getPointOnPath(A.path, 0, A.segmentsInfo)).x += A.pathOffset.x, d.y += A.pathOffset.y, this.textAlign) {
            case "left":
              E = M ? m - y : 0;
              break;
            case "center":
              E = (m - y) / 2;
              break;
            case "right":
              E = M ? 0 : m - y;
          }
          for (E += this.pathStartOffset * (M ? -1 : 1), r = M ? b.length - 1 : 0; M ? r >= 0 : r < b.length; M ? r-- : r++) h = S[r], E > m ? E %= m : E < 0 && (E += m), this._setGraphemeOnPath(E, h, d), E += h.kernedWidth;
        }
        return { width: y, numOfSpaces: 0 };
      }, _setGraphemeOnPath: function(i, r, s) {
        var u = i + r.kernedWidth / 2, h = this.path, d = o.util.getPointOnPath(h.path, u, h.segmentsInfo);
        r.renderLeft = d.x - s.x, r.renderTop = d.y - s.y, r.angle = d.angle + (this.pathSide === "right" ? Math.PI : 0);
      }, _getGraphemeBox: function(i, r, s, u, h) {
        var d, m = this.getCompleteStyleDeclaration(r, s), y = u ? this.getCompleteStyleDeclaration(r, s - 1) : {}, b = this._measureChar(i, m, u, y), S = b.kernedWidth, E = b.width;
        this.charSpacing !== 0 && (E += d = this._getWidthOfCharSpacing(), S += d);
        var A = { width: E, left: 0, height: m.fontSize, kernedWidth: S, deltaY: m.deltaY };
        if (s > 0 && !h) {
          var M = this.__charBounds[r][s - 1];
          A.left = M.left + M.width + b.kernedWidth - b.width;
        }
        return A;
      }, getHeightOfLine: function(i) {
        if (this.__lineHeights[i]) return this.__lineHeights[i];
        for (var r = this._textLines[i], s = this.getHeightOfChar(i, 0), u = 1, h = r.length; u < h; u++) s = Math.max(this.getHeightOfChar(i, u), s);
        return this.__lineHeights[i] = s * this.lineHeight * this._fontSizeMult;
      }, calcTextHeight: function() {
        for (var i, r = 0, s = 0, u = this._textLines.length; s < u; s++) i = this.getHeightOfLine(s), r += s === u - 1 ? i / this.lineHeight : i;
        return r;
      }, _getLeftOffset: function() {
        return this.direction === "ltr" ? -this.width / 2 : this.width / 2;
      }, _getTopOffset: function() {
        return -this.height / 2;
      }, _renderTextCommon: function(i, r) {
        i.save();
        for (var s = 0, u = this._getLeftOffset(), h = this._getTopOffset(), d = 0, m = this._textLines.length; d < m; d++) {
          var y = this.getHeightOfLine(d), b = y / this.lineHeight, S = this._getLineLeftOffset(d);
          this._renderTextLine(r, i, this._textLines[d], u + S, h + s + b, d), s += y;
        }
        i.restore();
      }, _renderTextFill: function(i) {
        (this.fill || this.styleHas("fill")) && this._renderTextCommon(i, "fillText");
      }, _renderTextStroke: function(i) {
        (this.stroke && this.strokeWidth !== 0 || !this.isEmptyStyles()) && (this.shadow && !this.shadow.affectStroke && this._removeShadow(i), i.save(), this._setLineDash(i, this.strokeDashArray), i.beginPath(), this._renderTextCommon(i, "strokeText"), i.closePath(), i.restore());
      }, _renderChars: function(i, r, s, u, h, d) {
        var m, y, b, S, E, A = this.getHeightOfLine(d), M = this.textAlign.indexOf("justify") !== -1, C = "", O = 0, N = this.path, z = !M && this.charSpacing === 0 && this.isEmptyStyles(d) && !N, W = this.direction === "ltr", F = this.direction === "ltr" ? 1 : -1;
        if (r.save(), h -= A * this._fontSizeFraction / this.lineHeight, z) return r.canvas.setAttribute("dir", W ? "ltr" : "rtl"), r.direction = W ? "ltr" : "rtl", r.textAlign = W ? "left" : "right", this._renderChar(i, r, d, 0, s.join(""), u, h, A), void r.restore();
        for (var k = 0, B = s.length - 1; k <= B; k++) S = k === B || this.charSpacing || N, C += s[k], b = this.__charBounds[d][k], O === 0 ? (u += F * (b.kernedWidth - b.width), O += b.width) : O += b.kernedWidth, M && !S && this._reSpaceAndTab.test(s[k]) && (S = !0), S || (m = m || this.getCompleteStyleDeclaration(d, k), y = this.getCompleteStyleDeclaration(d, k + 1), S = this._hasStyleChanged(m, y)), S && (N ? (r.save(), r.translate(b.renderLeft, b.renderTop), r.rotate(b.angle), this._renderChar(i, r, d, k, C, -O / 2, 0, A), r.restore()) : (E = u, r.canvas.setAttribute("dir", W ? "ltr" : "rtl"), r.direction = W ? "ltr" : "rtl", r.textAlign = W ? "left" : "right", this._renderChar(i, r, d, k, C, E, h, A)), C = "", m = y, u += F * O, O = 0);
        r.restore();
      }, _applyPatternGradientTransformText: function(i) {
        var r, s = o.util.createCanvasElement(), u = this.width + this.strokeWidth, h = this.height + this.strokeWidth;
        return s.width = u, s.height = h, (r = s.getContext("2d")).beginPath(), r.moveTo(0, 0), r.lineTo(u, 0), r.lineTo(u, h), r.lineTo(0, h), r.closePath(), r.translate(u / 2, h / 2), r.fillStyle = i.toLive(r), this._applyPatternGradientTransform(r, i), r.fill(), r.createPattern(s, "no-repeat");
      }, handleFiller: function(i, r, s) {
        var u, h;
        return s.toLive ? s.gradientUnits === "percentage" || s.gradientTransform || s.patternTransform ? (u = -this.width / 2, h = -this.height / 2, i.translate(u, h), i[r] = this._applyPatternGradientTransformText(s), { offsetX: u, offsetY: h }) : (i[r] = s.toLive(i, this), this._applyPatternGradientTransform(i, s)) : (i[r] = s, { offsetX: 0, offsetY: 0 });
      }, _setStrokeStyles: function(i, r) {
        return i.lineWidth = r.strokeWidth, i.lineCap = this.strokeLineCap, i.lineDashOffset = this.strokeDashOffset, i.lineJoin = this.strokeLineJoin, i.miterLimit = this.strokeMiterLimit, this.handleFiller(i, "strokeStyle", r.stroke);
      }, _setFillStyles: function(i, r) {
        return this.handleFiller(i, "fillStyle", r.fill);
      }, _renderChar: function(i, r, s, u, h, d, m) {
        var y, b, S = this._getStyleDeclaration(s, u), E = this.getCompleteStyleDeclaration(s, u), A = i === "fillText" && E.fill, M = i === "strokeText" && E.stroke && E.strokeWidth;
        (M || A) && (r.save(), A && (y = this._setFillStyles(r, E)), M && (b = this._setStrokeStyles(r, E)), r.font = this._getFontDeclaration(E), S && S.textBackgroundColor && this._removeShadow(r), S && S.deltaY && (m += S.deltaY), A && r.fillText(h, d - y.offsetX, m - y.offsetY), M && r.strokeText(h, d - b.offsetX, m - b.offsetY), r.restore());
      }, setSuperscript: function(i, r) {
        return this._setScript(i, r, this.superscript);
      }, setSubscript: function(i, r) {
        return this._setScript(i, r, this.subscript);
      }, _setScript: function(i, r, s) {
        var u = this.get2DCursorLocation(i, !0), h = this.getValueOfPropertyAt(u.lineIndex, u.charIndex, "fontSize"), d = this.getValueOfPropertyAt(u.lineIndex, u.charIndex, "deltaY"), m = { fontSize: h * s.size, deltaY: d + h * s.baseline };
        return this.setSelectionStyles(m, i, r), this;
      }, _hasStyleChanged: function(i, r) {
        return i.fill !== r.fill || i.stroke !== r.stroke || i.strokeWidth !== r.strokeWidth || i.fontSize !== r.fontSize || i.fontFamily !== r.fontFamily || i.fontWeight !== r.fontWeight || i.fontStyle !== r.fontStyle || i.deltaY !== r.deltaY;
      }, _hasStyleChangedForSvg: function(i, r) {
        return this._hasStyleChanged(i, r) || i.overline !== r.overline || i.underline !== r.underline || i.linethrough !== r.linethrough;
      }, _getLineLeftOffset: function(i) {
        var r = this.getLineWidth(i), s = this.width - r, u = this.textAlign, h = this.direction, d = 0, m = this.isEndOfWrapping(i);
        return u === "justify" || u === "justify-center" && !m || u === "justify-right" && !m || u === "justify-left" && !m ? 0 : (u === "center" && (d = s / 2), u === "right" && (d = s), u === "justify-center" && (d = s / 2), u === "justify-right" && (d = s), h === "rtl" && (d -= s), d);
      }, _clearCache: function() {
        this.__lineWidths = [], this.__lineHeights = [], this.__charBounds = [];
      }, _shouldClearDimensionCache: function() {
        var i = this._forceClearCache;
        return i || (i = this.hasStateChanged("_dimensionAffectingProps")), i && (this.dirty = !0, this._forceClearCache = !1), i;
      }, getLineWidth: function(i) {
        return this.__lineWidths[i] ? this.__lineWidths[i] : (r = this._textLines[i] === "" ? 0 : this.measureLine(i).width, this.__lineWidths[i] = r, r);
        var r;
      }, _getWidthOfCharSpacing: function() {
        return this.charSpacing !== 0 ? this.fontSize * this.charSpacing / 1e3 : 0;
      }, getValueOfPropertyAt: function(i, r, s) {
        var u = this._getStyleDeclaration(i, r);
        return u && u[s] !== void 0 ? u[s] : this[s];
      }, _renderTextDecoration: function(i, r) {
        if (this[r] || this.styleHas(r)) {
          for (var s, u, h, d, m, y, b, S, E, A, M, C, O, N, z, W, F = this._getLeftOffset(), k = this._getTopOffset(), B = this.path, Z = this._getWidthOfCharSpacing(), K = this.offsets[r], U = 0, R = this._textLines.length; U < R; U++) if (s = this.getHeightOfLine(U), this[r] || this.styleHas(r, U)) {
            b = this._textLines[U], N = s / this.lineHeight, d = this._getLineLeftOffset(U), A = 0, M = 0, S = this.getValueOfPropertyAt(U, 0, r), W = this.getValueOfPropertyAt(U, 0, "fill"), E = k + N * (1 - this._fontSizeFraction), u = this.getHeightOfChar(U, 0), m = this.getValueOfPropertyAt(U, 0, "deltaY");
            for (var H = 0, q = b.length; H < q; H++) if (C = this.__charBounds[U][H], O = this.getValueOfPropertyAt(U, H, r), z = this.getValueOfPropertyAt(U, H, "fill"), h = this.getHeightOfChar(U, H), y = this.getValueOfPropertyAt(U, H, "deltaY"), B && O && z) i.save(), i.fillStyle = W, i.translate(C.renderLeft, C.renderTop), i.rotate(C.angle), i.fillRect(-C.kernedWidth / 2, K * h + y, C.kernedWidth, this.fontSize / 15), i.restore();
            else if ((O !== S || z !== W || h !== u || y !== m) && M > 0) {
              var Q = F + d + A;
              this.direction === "rtl" && (Q = this.width - Q - M), S && W && (i.fillStyle = W, i.fillRect(Q, E + K * u + m, M, this.fontSize / 15)), A = C.left, M = C.width, S = O, W = z, u = h, m = y;
            } else M += C.kernedWidth;
            Q = F + d + A, this.direction === "rtl" && (Q = this.width - Q - M), i.fillStyle = z, O && z && i.fillRect(Q, E + K * u + m, M - Z, this.fontSize / 15), k += s;
          } else k += s;
          this._removeShadow(i);
        }
      }, _getFontDeclaration: function(i, r) {
        var s = i || this, u = this.fontFamily, h = o.Text.genericFonts.indexOf(u.toLowerCase()) > -1, d = u === void 0 || u.indexOf("'") > -1 || u.indexOf(",") > -1 || u.indexOf('"') > -1 || h ? s.fontFamily : '"' + s.fontFamily + '"';
        return [o.isLikelyNode ? s.fontWeight : s.fontStyle, o.isLikelyNode ? s.fontStyle : s.fontWeight, r ? this.CACHE_FONT_SIZE + "px" : s.fontSize + "px", d].join(" ");
      }, render: function(i) {
        this.visible && (this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (this._shouldClearDimensionCache() && this.initDimensions(), this.callSuper("render", i)));
      }, _splitTextIntoLines: function(i) {
        for (var r = i.split(this._reNewline), s = new Array(r.length), u = [`
`], h = [], d = 0; d < r.length; d++) s[d] = o.util.string.graphemeSplit(r[d]), h = h.concat(s[d], u);
        return h.pop(), { _unwrappedLines: s, lines: r, graphemeText: h, graphemeLines: s };
      }, toObject: function(i) {
        var r = f.concat(i), s = this.callSuper("toObject", r);
        return s.styles = l(this.styles, !0), s.path && (s.path = this.path.toObject()), s;
      }, set: function(i, r) {
        this.callSuper("set", i, r);
        var s = !1, u = !1;
        if (typeof i == "object") for (var h in i) h === "path" && this.setPathInfo(), s = s || this._dimensionAffectingProps.indexOf(h) !== -1, u = u || h === "path";
        else s = this._dimensionAffectingProps.indexOf(i) !== -1, u = i === "path";
        return u && this.setPathInfo(), s && (this.initDimensions(), this.setCoords()), this;
      }, complexity: function() {
        return 1;
      } }), o.Text.ATTRIBUTE_NAMES = o.SHARED_ATTRIBUTES.concat("x y dx dy font-family font-style font-weight font-size letter-spacing text-decoration text-anchor".split(" ")), o.Text.DEFAULT_SVG_FONT_SIZE = 16, o.Text.fromElement = function(i, r, s) {
        if (!i) return r(null);
        var u = o.parseAttributes(i, o.Text.ATTRIBUTE_NAMES), h = u.textAnchor || "left";
        if ((s = o.util.object.extend(s ? l(s) : {}, u)).top = s.top || 0, s.left = s.left || 0, u.textDecoration) {
          var d = u.textDecoration;
          d.indexOf("underline") !== -1 && (s.underline = !0), d.indexOf("overline") !== -1 && (s.overline = !0), d.indexOf("line-through") !== -1 && (s.linethrough = !0), delete s.textDecoration;
        }
        "dx" in u && (s.left += u.dx), "dy" in u && (s.top += u.dy), "fontSize" in s || (s.fontSize = o.Text.DEFAULT_SVG_FONT_SIZE);
        var m = "";
        "textContent" in i ? m = i.textContent : "firstChild" in i && i.firstChild !== null && "data" in i.firstChild && i.firstChild.data !== null && (m = i.firstChild.data), m = m.replace(/^\s+|\s+$|\n+/g, "").replace(/\s+/g, " ");
        var y = s.strokeWidth;
        s.strokeWidth = 0;
        var b = new o.Text(m, s), S = b.getScaledHeight() / b.height, E = ((b.height + b.strokeWidth) * b.lineHeight - b.height) * S, A = b.getScaledHeight() + E, M = 0;
        h === "center" && (M = b.getScaledWidth() / 2), h === "right" && (M = b.getScaledWidth()), b.set({ left: b.left - M, top: b.top - (A - b.fontSize * (0.07 + b._fontSizeFraction)) / b.lineHeight, strokeWidth: y !== void 0 ? y : 1 }), r(b);
      }, o.Text.fromObject = function(i, r) {
        var s = l(i), u = i.path;
        return delete s.path, o.Object._fromObject("Text", s, function(h) {
          u ? o.Object._fromObject("Path", u, function(d) {
            h.set("path", d), r(h);
          }, "path") : r(h);
        }, "text");
      }, o.Text.genericFonts = ["sans-serif", "serif", "cursive", "fantasy", "monospace"], o.util.createAccessors && o.util.createAccessors(o.Text);
    }
  }(t), v.util.object.extend(v.Text.prototype, { isEmptyStyles: function(c) {
    if (!this.styles || c !== void 0 && !this.styles[c]) return !0;
    var o = c === void 0 ? this.styles : { line: this.styles[c] };
    for (var l in o) for (var f in o[l]) for (var i in o[l][f]) return !1;
    return !0;
  }, styleHas: function(c, o) {
    if (!this.styles || !c || c === "" || o !== void 0 && !this.styles[o]) return !1;
    var l = o === void 0 ? this.styles : { 0: this.styles[o] };
    for (var f in l) for (var i in l[f]) if (l[f][i][c] !== void 0) return !0;
    return !1;
  }, cleanStyle: function(c) {
    if (!this.styles || !c || c === "") return !1;
    var o, l, f = this.styles, i = 0, r = !0, s = 0;
    for (var u in f) {
      for (var h in o = 0, f[u]) {
        var d;
        i++, (d = f[u][h]).hasOwnProperty(c) ? (l ? d[c] !== l && (r = !1) : l = d[c], d[c] === this[c] && delete d[c]) : r = !1, Object.keys(d).length !== 0 ? o++ : delete f[u][h];
      }
      o === 0 && delete f[u];
    }
    for (var m = 0; m < this._textLines.length; m++) s += this._textLines[m].length;
    r && i === s && (this[c] = l, this.removeStyle(c));
  }, removeStyle: function(c) {
    if (this.styles && c && c !== "") {
      var o, l, f, i = this.styles;
      for (l in i) {
        for (f in o = i[l]) delete o[f][c], Object.keys(o[f]).length === 0 && delete o[f];
        Object.keys(o).length === 0 && delete i[l];
      }
    }
  }, _extendStyles: function(c, o) {
    var l = this.get2DCursorLocation(c);
    this._getLineStyle(l.lineIndex) || this._setLineStyle(l.lineIndex), this._getStyleDeclaration(l.lineIndex, l.charIndex) || this._setStyleDeclaration(l.lineIndex, l.charIndex, {}), v.util.object.extend(this._getStyleDeclaration(l.lineIndex, l.charIndex), o);
  }, get2DCursorLocation: function(c, o) {
    c === void 0 && (c = this.selectionStart);
    for (var l = o ? this._unwrappedTextLines : this._textLines, f = l.length, i = 0; i < f; i++) {
      if (c <= l[i].length) return { lineIndex: i, charIndex: c };
      c -= l[i].length + this.missingNewlineOffset(i);
    }
    return { lineIndex: i - 1, charIndex: l[i - 1].length < c ? l[i - 1].length : c };
  }, getSelectionStyles: function(c, o, l) {
    c === void 0 && (c = this.selectionStart || 0), o === void 0 && (o = this.selectionEnd || c);
    for (var f = [], i = c; i < o; i++) f.push(this.getStyleAtPosition(i, l));
    return f;
  }, getStyleAtPosition: function(c, o) {
    var l = this.get2DCursorLocation(c);
    return (o ? this.getCompleteStyleDeclaration(l.lineIndex, l.charIndex) : this._getStyleDeclaration(l.lineIndex, l.charIndex)) || {};
  }, setSelectionStyles: function(c, o, l) {
    o === void 0 && (o = this.selectionStart || 0), l === void 0 && (l = this.selectionEnd || o);
    for (var f = o; f < l; f++) this._extendStyles(f, c);
    return this._forceClearCache = !0, this;
  }, _getStyleDeclaration: function(c, o) {
    var l = this.styles && this.styles[c];
    return l ? l[o] : null;
  }, getCompleteStyleDeclaration: function(c, o) {
    for (var l, f = this._getStyleDeclaration(c, o) || {}, i = {}, r = 0; r < this._styleProperties.length; r++) i[l = this._styleProperties[r]] = f[l] === void 0 ? this[l] : f[l];
    return i;
  }, _setStyleDeclaration: function(c, o, l) {
    this.styles[c][o] = l;
  }, _deleteStyleDeclaration: function(c, o) {
    delete this.styles[c][o];
  }, _getLineStyle: function(c) {
    return !!this.styles[c];
  }, _setLineStyle: function(c) {
    this.styles[c] = {};
  }, _deleteLineStyle: function(c) {
    delete this.styles[c];
  } }), function() {
    function c(o) {
      o.textDecoration && (o.textDecoration.indexOf("underline") > -1 && (o.underline = !0), o.textDecoration.indexOf("line-through") > -1 && (o.linethrough = !0), o.textDecoration.indexOf("overline") > -1 && (o.overline = !0), delete o.textDecoration);
    }
    v.IText = v.util.createClass(v.Text, v.Observable, { type: "i-text", selectionStart: 0, selectionEnd: 0, selectionColor: "rgba(17,119,255,0.3)", isEditing: !1, editable: !0, editingBorderColor: "rgba(102,153,255,0.25)", cursorWidth: 2, cursorColor: "", cursorDelay: 1e3, cursorDuration: 600, caching: !0, hiddenTextareaContainer: null, _reSpace: /\s|\n/, _currentCursorOpacity: 0, _selectionDirection: null, _abortCursorAnimation: !1, __widthOfSpace: [], inCompositionMode: !1, initialize: function(o, l) {
      this.callSuper("initialize", o, l), this.initBehavior();
    }, setSelectionStart: function(o) {
      o = Math.max(o, 0), this._updateAndFire("selectionStart", o);
    }, setSelectionEnd: function(o) {
      o = Math.min(o, this.text.length), this._updateAndFire("selectionEnd", o);
    }, _updateAndFire: function(o, l) {
      this[o] !== l && (this._fireSelectionChanged(), this[o] = l), this._updateTextarea();
    }, _fireSelectionChanged: function() {
      this.fire("selection:changed"), this.canvas && this.canvas.fire("text:selection:changed", { target: this });
    }, initDimensions: function() {
      this.isEditing && this.initDelayedCursor(), this.clearContextTop(), this.callSuper("initDimensions");
    }, render: function(o) {
      this.clearContextTop(), this.callSuper("render", o), this.cursorOffsetCache = {}, this.renderCursorOrSelection();
    }, _render: function(o) {
      this.callSuper("_render", o);
    }, clearContextTop: function(o) {
      if (this.isEditing && this.canvas && this.canvas.contextTop) {
        var l = this.canvas.contextTop, f = this.canvas.viewportTransform;
        l.save(), l.transform(f[0], f[1], f[2], f[3], f[4], f[5]), this.transform(l), this._clearTextArea(l), o || l.restore();
      }
    }, renderCursorOrSelection: function() {
      if (this.isEditing && this.canvas && this.canvas.contextTop) {
        var o = this._getCursorBoundaries(), l = this.canvas.contextTop;
        this.clearContextTop(!0), this.selectionStart === this.selectionEnd ? this.renderCursor(o, l) : this.renderSelection(o, l), l.restore();
      }
    }, _clearTextArea: function(o) {
      var l = this.width + 4, f = this.height + 4;
      o.clearRect(-l / 2, -f / 2, l, f);
    }, _getCursorBoundaries: function(o) {
      o === void 0 && (o = this.selectionStart);
      var l = this._getLeftOffset(), f = this._getTopOffset(), i = this._getCursorBoundariesOffsets(o);
      return { left: l, top: f, leftOffset: i.left, topOffset: i.top };
    }, _getCursorBoundariesOffsets: function(o) {
      if (this.cursorOffsetCache && "top" in this.cursorOffsetCache) return this.cursorOffsetCache;
      var l, f, i, r, s = 0, u = 0, h = this.get2DCursorLocation(o);
      i = h.charIndex, f = h.lineIndex;
      for (var d = 0; d < f; d++) s += this.getHeightOfLine(d);
      l = this._getLineLeftOffset(f);
      var m = this.__charBounds[f][i];
      return m && (u = m.left), this.charSpacing !== 0 && i === this._textLines[f].length && (u -= this._getWidthOfCharSpacing()), r = { top: s, left: l + (u > 0 ? u : 0) }, this.direction === "rtl" && (r.left *= -1), this.cursorOffsetCache = r, this.cursorOffsetCache;
    }, renderCursor: function(o, l) {
      var f = this.get2DCursorLocation(), i = f.lineIndex, r = f.charIndex > 0 ? f.charIndex - 1 : 0, s = this.getValueOfPropertyAt(i, r, "fontSize"), u = this.scaleX * this.canvas.getZoom(), h = this.cursorWidth / u, d = o.topOffset, m = this.getValueOfPropertyAt(i, r, "deltaY");
      d += (1 - this._fontSizeFraction) * this.getHeightOfLine(i) / this.lineHeight - s * (1 - this._fontSizeFraction), this.inCompositionMode && this.renderSelection(o, l), l.fillStyle = this.cursorColor || this.getValueOfPropertyAt(i, r, "fill"), l.globalAlpha = this.__isMousedown ? 1 : this._currentCursorOpacity, l.fillRect(o.left + o.leftOffset - h / 2, d + o.top + m, h, s);
    }, renderSelection: function(o, l) {
      for (var f = this.inCompositionMode ? this.hiddenTextarea.selectionStart : this.selectionStart, i = this.inCompositionMode ? this.hiddenTextarea.selectionEnd : this.selectionEnd, r = this.textAlign.indexOf("justify") !== -1, s = this.get2DCursorLocation(f), u = this.get2DCursorLocation(i), h = s.lineIndex, d = u.lineIndex, m = s.charIndex < 0 ? 0 : s.charIndex, y = u.charIndex < 0 ? 0 : u.charIndex, b = h; b <= d; b++) {
        var S, E = this._getLineLeftOffset(b) || 0, A = this.getHeightOfLine(b), M = 0, C = 0;
        if (b === h && (M = this.__charBounds[h][m].left), b >= h && b < d) C = r && !this.isEndOfWrapping(b) ? this.width : this.getLineWidth(b) || 5;
        else if (b === d) if (y === 0) C = this.__charBounds[d][y].left;
        else {
          var O = this._getWidthOfCharSpacing();
          C = this.__charBounds[d][y - 1].left + this.__charBounds[d][y - 1].width - O;
        }
        S = A, (this.lineHeight < 1 || b === d && this.lineHeight > 1) && (A /= this.lineHeight);
        var N = o.left + E + M, z = C - M, W = A, F = 0;
        this.inCompositionMode ? (l.fillStyle = this.compositionColor || "black", W = 1, F = A) : l.fillStyle = this.selectionColor, this.direction === "rtl" && (N = this.width - N - z), l.fillRect(N, o.top + o.topOffset + F, z, W), o.topOffset += S;
      }
    }, getCurrentCharFontSize: function() {
      var o = this._getCurrentCharIndex();
      return this.getValueOfPropertyAt(o.l, o.c, "fontSize");
    }, getCurrentCharColor: function() {
      var o = this._getCurrentCharIndex();
      return this.getValueOfPropertyAt(o.l, o.c, "fill");
    }, _getCurrentCharIndex: function() {
      var o = this.get2DCursorLocation(this.selectionStart, !0), l = o.charIndex > 0 ? o.charIndex - 1 : 0;
      return { l: o.lineIndex, c: l };
    } }), v.IText.fromObject = function(o, l) {
      if (c(o), o.styles) for (var f in o.styles) for (var i in o.styles[f]) c(o.styles[f][i]);
      v.Object._fromObject("IText", o, l, "text");
    };
  }(), dt = v.util.object.clone, v.util.object.extend(v.IText.prototype, { initBehavior: function() {
    this.initAddedHandler(), this.initRemovedHandler(), this.initCursorSelectionHandlers(), this.initDoubleClickSimulation(), this.mouseMoveHandler = this.mouseMoveHandler.bind(this);
  }, onDeselect: function() {
    this.isEditing && this.exitEditing(), this.selected = !1;
  }, initAddedHandler: function() {
    var c = this;
    this.on("added", function() {
      var o = c.canvas;
      o && (o._hasITextHandlers || (o._hasITextHandlers = !0, c._initCanvasHandlers(o)), o._iTextInstances = o._iTextInstances || [], o._iTextInstances.push(c));
    });
  }, initRemovedHandler: function() {
    var c = this;
    this.on("removed", function() {
      var o = c.canvas;
      o && (o._iTextInstances = o._iTextInstances || [], v.util.removeFromArray(o._iTextInstances, c), o._iTextInstances.length === 0 && (o._hasITextHandlers = !1, c._removeCanvasHandlers(o)));
    });
  }, _initCanvasHandlers: function(c) {
    c._mouseUpITextHandler = function() {
      c._iTextInstances && c._iTextInstances.forEach(function(o) {
        o.__isMousedown = !1;
      });
    }, c.on("mouse:up", c._mouseUpITextHandler);
  }, _removeCanvasHandlers: function(c) {
    c.off("mouse:up", c._mouseUpITextHandler);
  }, _tick: function() {
    this._currentTickState = this._animateCursor(this, 1, this.cursorDuration, "_onTickComplete");
  }, _animateCursor: function(c, o, l, f) {
    var i;
    return i = { isAborted: !1, abort: function() {
      this.isAborted = !0;
    } }, c.animate("_currentCursorOpacity", o, { duration: l, onComplete: function() {
      i.isAborted || c[f]();
    }, onChange: function() {
      c.canvas && c.selectionStart === c.selectionEnd && c.renderCursorOrSelection();
    }, abort: function() {
      return i.isAborted;
    } }), i;
  }, _onTickComplete: function() {
    var c = this;
    this._cursorTimeout1 && clearTimeout(this._cursorTimeout1), this._cursorTimeout1 = setTimeout(function() {
      c._currentTickCompleteState = c._animateCursor(c, 0, this.cursorDuration / 2, "_tick");
    }, 100);
  }, initDelayedCursor: function(c) {
    var o = this, l = c ? 0 : this.cursorDelay;
    this.abortCursorAnimation(), this._currentCursorOpacity = 1, this._cursorTimeout2 = setTimeout(function() {
      o._tick();
    }, l);
  }, abortCursorAnimation: function() {
    var c = this._currentTickState || this._currentTickCompleteState, o = this.canvas;
    this._currentTickState && this._currentTickState.abort(), this._currentTickCompleteState && this._currentTickCompleteState.abort(), clearTimeout(this._cursorTimeout1), clearTimeout(this._cursorTimeout2), this._currentCursorOpacity = 0, c && o && o.clearContext(o.contextTop || o.contextContainer);
  }, selectAll: function() {
    return this.selectionStart = 0, this.selectionEnd = this._text.length, this._fireSelectionChanged(), this._updateTextarea(), this;
  }, getSelectedText: function() {
    return this._text.slice(this.selectionStart, this.selectionEnd).join("");
  }, findWordBoundaryLeft: function(c) {
    var o = 0, l = c - 1;
    if (this._reSpace.test(this._text[l])) for (; this._reSpace.test(this._text[l]); ) o++, l--;
    for (; /\S/.test(this._text[l]) && l > -1; ) o++, l--;
    return c - o;
  }, findWordBoundaryRight: function(c) {
    var o = 0, l = c;
    if (this._reSpace.test(this._text[l])) for (; this._reSpace.test(this._text[l]); ) o++, l++;
    for (; /\S/.test(this._text[l]) && l < this._text.length; ) o++, l++;
    return c + o;
  }, findLineBoundaryLeft: function(c) {
    for (var o = 0, l = c - 1; !/\n/.test(this._text[l]) && l > -1; ) o++, l--;
    return c - o;
  }, findLineBoundaryRight: function(c) {
    for (var o = 0, l = c; !/\n/.test(this._text[l]) && l < this._text.length; ) o++, l++;
    return c + o;
  }, searchWordBoundary: function(c, o) {
    for (var l = this._text, f = this._reSpace.test(l[c]) ? c - 1 : c, i = l[f], r = v.reNonWord; !r.test(i) && f > 0 && f < l.length; ) i = l[f += o];
    return r.test(i) && (f += o === 1 ? 0 : 1), f;
  }, selectWord: function(c) {
    c = c || this.selectionStart;
    var o = this.searchWordBoundary(c, -1), l = this.searchWordBoundary(c, 1);
    this.selectionStart = o, this.selectionEnd = l, this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection();
  }, selectLine: function(c) {
    c = c || this.selectionStart;
    var o = this.findLineBoundaryLeft(c), l = this.findLineBoundaryRight(c);
    return this.selectionStart = o, this.selectionEnd = l, this._fireSelectionChanged(), this._updateTextarea(), this;
  }, enterEditing: function(c) {
    if (!this.isEditing && this.editable) return this.canvas && (this.canvas.calcOffset(), this.exitEditingOnOthers(this.canvas)), this.isEditing = !0, this.initHiddenTextarea(c), this.hiddenTextarea.focus(), this.hiddenTextarea.value = this.text, this._updateTextarea(), this._saveEditingProps(), this._setEditingProps(), this._textBeforeEdit = this.text, this._tick(), this.fire("editing:entered"), this._fireSelectionChanged(), this.canvas ? (this.canvas.fire("text:editing:entered", { target: this }), this.initMouseMoveHandler(), this.canvas.requestRenderAll(), this) : this;
  }, exitEditingOnOthers: function(c) {
    c._iTextInstances && c._iTextInstances.forEach(function(o) {
      o.selected = !1, o.isEditing && o.exitEditing();
    });
  }, initMouseMoveHandler: function() {
    this.canvas.on("mouse:move", this.mouseMoveHandler);
  }, mouseMoveHandler: function(c) {
    if (this.__isMousedown && this.isEditing) {
      var o = this.getSelectionStartFromPointer(c.e), l = this.selectionStart, f = this.selectionEnd;
      (o === this.__selectionStartOnMouseDown && l !== f || l !== o && f !== o) && (o > this.__selectionStartOnMouseDown ? (this.selectionStart = this.__selectionStartOnMouseDown, this.selectionEnd = o) : (this.selectionStart = o, this.selectionEnd = this.__selectionStartOnMouseDown), this.selectionStart === l && this.selectionEnd === f || (this.restartCursorIfNeeded(), this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection()));
    }
  }, _setEditingProps: function() {
    this.hoverCursor = "text", this.canvas && (this.canvas.defaultCursor = this.canvas.moveCursor = "text"), this.borderColor = this.editingBorderColor, this.hasControls = this.selectable = !1, this.lockMovementX = this.lockMovementY = !0;
  }, fromStringToGraphemeSelection: function(c, o, l) {
    var f = l.slice(0, c), i = v.util.string.graphemeSplit(f).length;
    if (c === o) return { selectionStart: i, selectionEnd: i };
    var r = l.slice(c, o);
    return { selectionStart: i, selectionEnd: i + v.util.string.graphemeSplit(r).length };
  }, fromGraphemeToStringSelection: function(c, o, l) {
    var f = l.slice(0, c).join("").length;
    return c === o ? { selectionStart: f, selectionEnd: f } : { selectionStart: f, selectionEnd: f + l.slice(c, o).join("").length };
  }, _updateTextarea: function() {
    if (this.cursorOffsetCache = {}, this.hiddenTextarea) {
      if (!this.inCompositionMode) {
        var c = this.fromGraphemeToStringSelection(this.selectionStart, this.selectionEnd, this._text);
        this.hiddenTextarea.selectionStart = c.selectionStart, this.hiddenTextarea.selectionEnd = c.selectionEnd;
      }
      this.updateTextareaPosition();
    }
  }, updateFromTextArea: function() {
    if (this.hiddenTextarea) {
      this.cursorOffsetCache = {}, this.text = this.hiddenTextarea.value, this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords());
      var c = this.fromStringToGraphemeSelection(this.hiddenTextarea.selectionStart, this.hiddenTextarea.selectionEnd, this.hiddenTextarea.value);
      this.selectionEnd = this.selectionStart = c.selectionEnd, this.inCompositionMode || (this.selectionStart = c.selectionStart), this.updateTextareaPosition();
    }
  }, updateTextareaPosition: function() {
    if (this.selectionStart === this.selectionEnd) {
      var c = this._calcTextareaPosition();
      this.hiddenTextarea.style.left = c.left, this.hiddenTextarea.style.top = c.top;
    }
  }, _calcTextareaPosition: function() {
    if (!this.canvas) return { x: 1, y: 1 };
    var c = this.inCompositionMode ? this.compositionStart : this.selectionStart, o = this._getCursorBoundaries(c), l = this.get2DCursorLocation(c), f = l.lineIndex, i = l.charIndex, r = this.getValueOfPropertyAt(f, i, "fontSize") * this.lineHeight, s = o.leftOffset, u = this.calcTransformMatrix(), h = { x: o.left + s, y: o.top + o.topOffset + r }, d = this.canvas.getRetinaScaling(), m = this.canvas.upperCanvasEl, y = m.width / d, b = m.height / d, S = y - r, E = b - r, A = m.clientWidth / y, M = m.clientHeight / b;
    return h = v.util.transformPoint(h, u), (h = v.util.transformPoint(h, this.canvas.viewportTransform)).x *= A, h.y *= M, h.x < 0 && (h.x = 0), h.x > S && (h.x = S), h.y < 0 && (h.y = 0), h.y > E && (h.y = E), h.x += this.canvas._offset.left, h.y += this.canvas._offset.top, { left: h.x + "px", top: h.y + "px", fontSize: r + "px", charHeight: r };
  }, _saveEditingProps: function() {
    this._savedProps = { hasControls: this.hasControls, borderColor: this.borderColor, lockMovementX: this.lockMovementX, lockMovementY: this.lockMovementY, hoverCursor: this.hoverCursor, selectable: this.selectable, defaultCursor: this.canvas && this.canvas.defaultCursor, moveCursor: this.canvas && this.canvas.moveCursor };
  }, _restoreEditingProps: function() {
    this._savedProps && (this.hoverCursor = this._savedProps.hoverCursor, this.hasControls = this._savedProps.hasControls, this.borderColor = this._savedProps.borderColor, this.selectable = this._savedProps.selectable, this.lockMovementX = this._savedProps.lockMovementX, this.lockMovementY = this._savedProps.lockMovementY, this.canvas && (this.canvas.defaultCursor = this._savedProps.defaultCursor, this.canvas.moveCursor = this._savedProps.moveCursor));
  }, exitEditing: function() {
    var c = this._textBeforeEdit !== this.text, o = this.hiddenTextarea;
    return this.selected = !1, this.isEditing = !1, this.selectionEnd = this.selectionStart, o && (o.blur && o.blur(), o.parentNode && o.parentNode.removeChild(o)), this.hiddenTextarea = null, this.abortCursorAnimation(), this._restoreEditingProps(), this._currentCursorOpacity = 0, this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this.fire("editing:exited"), c && this.fire("modified"), this.canvas && (this.canvas.off("mouse:move", this.mouseMoveHandler), this.canvas.fire("text:editing:exited", { target: this }), c && this.canvas.fire("object:modified", { target: this })), this;
  }, _removeExtraneousStyles: function() {
    for (var c in this.styles) this._textLines[c] || delete this.styles[c];
  }, removeStyleFromTo: function(c, o) {
    var l, f, i = this.get2DCursorLocation(c, !0), r = this.get2DCursorLocation(o, !0), s = i.lineIndex, u = i.charIndex, h = r.lineIndex, d = r.charIndex;
    if (s !== h) {
      if (this.styles[s]) for (l = u; l < this._unwrappedTextLines[s].length; l++) delete this.styles[s][l];
      if (this.styles[h]) for (l = d; l < this._unwrappedTextLines[h].length; l++) (f = this.styles[h][l]) && (this.styles[s] || (this.styles[s] = {}), this.styles[s][u + l - d] = f);
      for (l = s + 1; l <= h; l++) delete this.styles[l];
      this.shiftLineStyles(h, s - h);
    } else if (this.styles[s]) {
      f = this.styles[s];
      var m, y, b = d - u;
      for (l = u; l < d; l++) delete f[l];
      for (y in this.styles[s]) (m = parseInt(y, 10)) >= d && (f[m - b] = f[y], delete f[y]);
    }
  }, shiftLineStyles: function(c, o) {
    var l = dt(this.styles);
    for (var f in this.styles) {
      var i = parseInt(f, 10);
      i > c && (this.styles[i + o] = l[i], l[i - o] || delete this.styles[i]);
    }
  }, restartCursorIfNeeded: function() {
    this._currentTickState && !this._currentTickState.isAborted && this._currentTickCompleteState && !this._currentTickCompleteState.isAborted || this.initDelayedCursor();
  }, insertNewlineStyleObject: function(c, o, l, f) {
    var i, r = {}, s = !1, u = this._unwrappedTextLines[c].length === o;
    for (var h in l || (l = 1), this.shiftLineStyles(c, l), this.styles[c] && (i = this.styles[c][o === 0 ? o : o - 1]), this.styles[c]) {
      var d = parseInt(h, 10);
      d >= o && (s = !0, r[d - o] = this.styles[c][h], u && o === 0 || delete this.styles[c][h]);
    }
    var m = !1;
    for (s && !u && (this.styles[c + l] = r, m = !0), m && l--; l > 0; ) f && f[l - 1] ? this.styles[c + l] = { 0: dt(f[l - 1]) } : i ? this.styles[c + l] = { 0: dt(i) } : delete this.styles[c + l], l--;
    this._forceClearCache = !0;
  }, insertCharStyleObject: function(c, o, l, f) {
    this.styles || (this.styles = {});
    var i = this.styles[c], r = i ? dt(i) : {};
    for (var s in l || (l = 1), r) {
      var u = parseInt(s, 10);
      u >= o && (i[u + l] = r[u], r[u - l] || delete i[u]);
    }
    if (this._forceClearCache = !0, f) for (; l--; ) Object.keys(f[l]).length && (this.styles[c] || (this.styles[c] = {}), this.styles[c][o + l] = dt(f[l]));
    else if (i) for (var h = i[o ? o - 1 : 1]; h && l--; ) this.styles[c][o + l] = dt(h);
  }, insertNewStyleBlock: function(c, o, l) {
    for (var f = this.get2DCursorLocation(o, !0), i = [0], r = 0, s = 0; s < c.length; s++) c[s] === `
` ? i[++r] = 0 : i[r]++;
    for (i[0] > 0 && (this.insertCharStyleObject(f.lineIndex, f.charIndex, i[0], l), l = l && l.slice(i[0] + 1)), r && this.insertNewlineStyleObject(f.lineIndex, f.charIndex + i[0], r), s = 1; s < r; s++) i[s] > 0 ? this.insertCharStyleObject(f.lineIndex + s, 0, i[s], l) : l && (this.styles[f.lineIndex + s][0] = l[0]), l = l && l.slice(i[s] + 1);
    i[s] > 0 && this.insertCharStyleObject(f.lineIndex + s, 0, i[s], l);
  }, setSelectionStartEndWithShift: function(c, o, l) {
    l <= c ? (o === c ? this._selectionDirection = "left" : this._selectionDirection === "right" && (this._selectionDirection = "left", this.selectionEnd = c), this.selectionStart = l) : l > c && l < o ? this._selectionDirection === "right" ? this.selectionEnd = l : this.selectionStart = l : (o === c ? this._selectionDirection = "right" : this._selectionDirection === "left" && (this._selectionDirection = "right", this.selectionStart = o), this.selectionEnd = l);
  }, setSelectionInBoundaries: function() {
    var c = this.text.length;
    this.selectionStart > c ? this.selectionStart = c : this.selectionStart < 0 && (this.selectionStart = 0), this.selectionEnd > c ? this.selectionEnd = c : this.selectionEnd < 0 && (this.selectionEnd = 0);
  } }), v.util.object.extend(v.IText.prototype, { initDoubleClickSimulation: function() {
    this.__lastClickTime = +/* @__PURE__ */ new Date(), this.__lastLastClickTime = +/* @__PURE__ */ new Date(), this.__lastPointer = {}, this.on("mousedown", this.onMouseDown);
  }, onMouseDown: function(c) {
    if (this.canvas) {
      this.__newClickTime = +/* @__PURE__ */ new Date();
      var o = c.pointer;
      this.isTripleClick(o) && (this.fire("tripleclick", c), this._stopEvent(c.e)), this.__lastLastClickTime = this.__lastClickTime, this.__lastClickTime = this.__newClickTime, this.__lastPointer = o, this.__lastIsEditing = this.isEditing, this.__lastSelected = this.selected;
    }
  }, isTripleClick: function(c) {
    return this.__newClickTime - this.__lastClickTime < 500 && this.__lastClickTime - this.__lastLastClickTime < 500 && this.__lastPointer.x === c.x && this.__lastPointer.y === c.y;
  }, _stopEvent: function(c) {
    c.preventDefault && c.preventDefault(), c.stopPropagation && c.stopPropagation();
  }, initCursorSelectionHandlers: function() {
    this.initMousedownHandler(), this.initMouseupHandler(), this.initClicks();
  }, doubleClickHandler: function(c) {
    this.isEditing && this.selectWord(this.getSelectionStartFromPointer(c.e));
  }, tripleClickHandler: function(c) {
    this.isEditing && this.selectLine(this.getSelectionStartFromPointer(c.e));
  }, initClicks: function() {
    this.on("mousedblclick", this.doubleClickHandler), this.on("tripleclick", this.tripleClickHandler);
  }, _mouseDownHandler: function(c) {
    !this.canvas || !this.editable || c.e.button && c.e.button !== 1 || (this.__isMousedown = !0, this.selected && (this.inCompositionMode = !1, this.setCursorByClick(c.e)), this.isEditing && (this.__selectionStartOnMouseDown = this.selectionStart, this.selectionStart === this.selectionEnd && this.abortCursorAnimation(), this.renderCursorOrSelection()));
  }, _mouseDownHandlerBefore: function(c) {
    !this.canvas || !this.editable || c.e.button && c.e.button !== 1 || (this.selected = this === this.canvas._activeObject);
  }, initMousedownHandler: function() {
    this.on("mousedown", this._mouseDownHandler), this.on("mousedown:before", this._mouseDownHandlerBefore);
  }, initMouseupHandler: function() {
    this.on("mouseup", this.mouseUpHandler);
  }, mouseUpHandler: function(c) {
    if (this.__isMousedown = !1, !(!this.editable || this.group || c.transform && c.transform.actionPerformed || c.e.button && c.e.button !== 1)) {
      if (this.canvas) {
        var o = this.canvas._activeObject;
        if (o && o !== this) return;
      }
      this.__lastSelected && !this.__corner ? (this.selected = !1, this.__lastSelected = !1, this.enterEditing(c.e), this.selectionStart === this.selectionEnd ? this.initDelayedCursor(!0) : this.renderCursorOrSelection()) : this.selected = !0;
    }
  }, setCursorByClick: function(c) {
    var o = this.getSelectionStartFromPointer(c), l = this.selectionStart, f = this.selectionEnd;
    c.shiftKey ? this.setSelectionStartEndWithShift(l, f, o) : (this.selectionStart = o, this.selectionEnd = o), this.isEditing && (this._fireSelectionChanged(), this._updateTextarea());
  }, getSelectionStartFromPointer: function(c) {
    for (var o, l = this.getLocalPointer(c), f = 0, i = 0, r = 0, s = 0, u = 0, h = 0, d = this._textLines.length; h < d && r <= l.y; h++) r += this.getHeightOfLine(h) * this.scaleY, u = h, h > 0 && (s += this._textLines[h - 1].length + this.missingNewlineOffset(h - 1));
    i = this._getLineLeftOffset(u) * this.scaleX, o = this._textLines[u], this.direction === "rtl" && (l.x = this.width * this.scaleX - l.x + i);
    for (var m = 0, y = o.length; m < y && (f = i, (i += this.__charBounds[u][m].kernedWidth * this.scaleX) <= l.x); m++) s++;
    return this._getNewSelectionStartFromOffset(l, f, i, s, y);
  }, _getNewSelectionStartFromOffset: function(c, o, l, f, i) {
    var r = c.x - o, s = l - c.x, u = f + (s > r || s < 0 ? 0 : 1);
    return this.flipX && (u = i - u), u > this._text.length && (u = this._text.length), u;
  } }), v.util.object.extend(v.IText.prototype, { initHiddenTextarea: function() {
    this.hiddenTextarea = v.document.createElement("textarea"), this.hiddenTextarea.setAttribute("autocapitalize", "off"), this.hiddenTextarea.setAttribute("autocorrect", "off"), this.hiddenTextarea.setAttribute("autocomplete", "off"), this.hiddenTextarea.setAttribute("spellcheck", "false"), this.hiddenTextarea.setAttribute("data-fabric-hiddentextarea", ""), this.hiddenTextarea.setAttribute("wrap", "off");
    var c = this._calcTextareaPosition();
    this.hiddenTextarea.style.cssText = "position: absolute; top: " + c.top + "; left: " + c.left + "; z-index: -999; opacity: 0; width: 1px; height: 1px; font-size: 1px; paddingｰtop: " + c.fontSize + ";", this.hiddenTextareaContainer ? this.hiddenTextareaContainer.appendChild(this.hiddenTextarea) : v.document.body.appendChild(this.hiddenTextarea), v.util.addListener(this.hiddenTextarea, "keydown", this.onKeyDown.bind(this)), v.util.addListener(this.hiddenTextarea, "keyup", this.onKeyUp.bind(this)), v.util.addListener(this.hiddenTextarea, "input", this.onInput.bind(this)), v.util.addListener(this.hiddenTextarea, "copy", this.copy.bind(this)), v.util.addListener(this.hiddenTextarea, "cut", this.copy.bind(this)), v.util.addListener(this.hiddenTextarea, "paste", this.paste.bind(this)), v.util.addListener(this.hiddenTextarea, "compositionstart", this.onCompositionStart.bind(this)), v.util.addListener(this.hiddenTextarea, "compositionupdate", this.onCompositionUpdate.bind(this)), v.util.addListener(this.hiddenTextarea, "compositionend", this.onCompositionEnd.bind(this)), !this._clickHandlerInitialized && this.canvas && (v.util.addListener(this.canvas.upperCanvasEl, "click", this.onClick.bind(this)), this._clickHandlerInitialized = !0);
  }, keysMap: { 9: "exitEditing", 27: "exitEditing", 33: "moveCursorUp", 34: "moveCursorDown", 35: "moveCursorRight", 36: "moveCursorLeft", 37: "moveCursorLeft", 38: "moveCursorUp", 39: "moveCursorRight", 40: "moveCursorDown" }, keysMapRtl: { 9: "exitEditing", 27: "exitEditing", 33: "moveCursorUp", 34: "moveCursorDown", 35: "moveCursorLeft", 36: "moveCursorRight", 37: "moveCursorRight", 38: "moveCursorUp", 39: "moveCursorLeft", 40: "moveCursorDown" }, ctrlKeysMapUp: { 67: "copy", 88: "cut" }, ctrlKeysMapDown: { 65: "selectAll" }, onClick: function() {
    this.hiddenTextarea && this.hiddenTextarea.focus();
  }, onKeyDown: function(c) {
    if (this.isEditing) {
      var o = this.direction === "rtl" ? this.keysMapRtl : this.keysMap;
      if (c.keyCode in o) this[o[c.keyCode]](c);
      else {
        if (!(c.keyCode in this.ctrlKeysMapDown) || !c.ctrlKey && !c.metaKey) return;
        this[this.ctrlKeysMapDown[c.keyCode]](c);
      }
      c.stopImmediatePropagation(), c.preventDefault(), c.keyCode >= 33 && c.keyCode <= 40 ? (this.inCompositionMode = !1, this.clearContextTop(), this.renderCursorOrSelection()) : this.canvas && this.canvas.requestRenderAll();
    }
  }, onKeyUp: function(c) {
    !this.isEditing || this._copyDone || this.inCompositionMode ? this._copyDone = !1 : c.keyCode in this.ctrlKeysMapUp && (c.ctrlKey || c.metaKey) && (this[this.ctrlKeysMapUp[c.keyCode]](c), c.stopImmediatePropagation(), c.preventDefault(), this.canvas && this.canvas.requestRenderAll());
  }, onInput: function(c) {
    var o = this.fromPaste;
    if (this.fromPaste = !1, c && c.stopPropagation(), this.isEditing) {
      var l, f, i, r, s, u = this._splitTextIntoLines(this.hiddenTextarea.value).graphemeText, h = this._text.length, d = u.length, m = d - h, y = this.selectionStart, b = this.selectionEnd, S = y !== b;
      if (this.hiddenTextarea.value === "") return this.styles = {}, this.updateFromTextArea(), this.fire("changed"), void (this.canvas && (this.canvas.fire("text:changed", { target: this }), this.canvas.requestRenderAll()));
      var E = this.fromStringToGraphemeSelection(this.hiddenTextarea.selectionStart, this.hiddenTextarea.selectionEnd, this.hiddenTextarea.value), A = y > E.selectionStart;
      S ? (l = this._text.slice(y, b), m += b - y) : d < h && (l = A ? this._text.slice(b + m, b) : this._text.slice(y, y - m)), f = u.slice(E.selectionEnd - m, E.selectionEnd), l && l.length && (f.length && (i = this.getSelectionStyles(y, y + 1, !1), i = f.map(function() {
        return i[0];
      })), S ? (r = y, s = b) : A ? (r = b - l.length, s = b) : (r = b, s = b + l.length), this.removeStyleFromTo(r, s)), f.length && (o && f.join("") === v.copiedText && !v.disableStyleCopyPaste && (i = v.copiedTextStyle), this.insertNewStyleBlock(f, y, i)), this.updateFromTextArea(), this.fire("changed"), this.canvas && (this.canvas.fire("text:changed", { target: this }), this.canvas.requestRenderAll());
    }
  }, onCompositionStart: function() {
    this.inCompositionMode = !0;
  }, onCompositionEnd: function() {
    this.inCompositionMode = !1;
  }, onCompositionUpdate: function(c) {
    this.compositionStart = c.target.selectionStart, this.compositionEnd = c.target.selectionEnd, this.updateTextareaPosition();
  }, copy: function() {
    this.selectionStart !== this.selectionEnd && (v.copiedText = this.getSelectedText(), v.disableStyleCopyPaste ? v.copiedTextStyle = null : v.copiedTextStyle = this.getSelectionStyles(this.selectionStart, this.selectionEnd, !0), this._copyDone = !0);
  }, paste: function() {
    this.fromPaste = !0;
  }, _getClipboardData: function(c) {
    return c && c.clipboardData || v.window.clipboardData;
  }, _getWidthBeforeCursor: function(c, o) {
    var l, f = this._getLineLeftOffset(c);
    return o > 0 && (f += (l = this.__charBounds[c][o - 1]).left + l.width), f;
  }, getDownCursorOffset: function(c, o) {
    var l = this._getSelectionForOffset(c, o), f = this.get2DCursorLocation(l), i = f.lineIndex;
    if (i === this._textLines.length - 1 || c.metaKey || c.keyCode === 34) return this._text.length - l;
    var r = f.charIndex, s = this._getWidthBeforeCursor(i, r), u = this._getIndexOnLine(i + 1, s);
    return this._textLines[i].slice(r).length + u + 1 + this.missingNewlineOffset(i);
  }, _getSelectionForOffset: function(c, o) {
    return c.shiftKey && this.selectionStart !== this.selectionEnd && o ? this.selectionEnd : this.selectionStart;
  }, getUpCursorOffset: function(c, o) {
    var l = this._getSelectionForOffset(c, o), f = this.get2DCursorLocation(l), i = f.lineIndex;
    if (i === 0 || c.metaKey || c.keyCode === 33) return -l;
    var r = f.charIndex, s = this._getWidthBeforeCursor(i, r), u = this._getIndexOnLine(i - 1, s), h = this._textLines[i].slice(0, r), d = this.missingNewlineOffset(i - 1);
    return -this._textLines[i - 1].length + u - h.length + (1 - d);
  }, _getIndexOnLine: function(c, o) {
    for (var l, f, i = this._textLines[c], r = this._getLineLeftOffset(c), s = 0, u = 0, h = i.length; u < h; u++) if ((r += l = this.__charBounds[c][u].width) > o) {
      f = !0;
      var d = r - l, m = r, y = Math.abs(d - o);
      s = Math.abs(m - o) < y ? u : u - 1;
      break;
    }
    return f || (s = i.length - 1), s;
  }, moveCursorDown: function(c) {
    this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorUpOrDown("Down", c);
  }, moveCursorUp: function(c) {
    this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorUpOrDown("Up", c);
  }, _moveCursorUpOrDown: function(c, o) {
    var l = this["get" + c + "CursorOffset"](o, this._selectionDirection === "right");
    o.shiftKey ? this.moveCursorWithShift(l) : this.moveCursorWithoutShift(l), l !== 0 && (this.setSelectionInBoundaries(), this.abortCursorAnimation(), this._currentCursorOpacity = 1, this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
  }, moveCursorWithShift: function(c) {
    var o = this._selectionDirection === "left" ? this.selectionStart + c : this.selectionEnd + c;
    return this.setSelectionStartEndWithShift(this.selectionStart, this.selectionEnd, o), c !== 0;
  }, moveCursorWithoutShift: function(c) {
    return c < 0 ? (this.selectionStart += c, this.selectionEnd = this.selectionStart) : (this.selectionEnd += c, this.selectionStart = this.selectionEnd), c !== 0;
  }, moveCursorLeft: function(c) {
    this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorLeftOrRight("Left", c);
  }, _move: function(c, o, l) {
    var f;
    if (c.altKey) f = this["findWordBoundary" + l](this[o]);
    else {
      if (!c.metaKey && c.keyCode !== 35 && c.keyCode !== 36) return this[o] += l === "Left" ? -1 : 1, !0;
      f = this["findLineBoundary" + l](this[o]);
    }
    if (typeof f !== void 0 && this[o] !== f) return this[o] = f, !0;
  }, _moveLeft: function(c, o) {
    return this._move(c, o, "Left");
  }, _moveRight: function(c, o) {
    return this._move(c, o, "Right");
  }, moveCursorLeftWithoutShift: function(c) {
    var o = !0;
    return this._selectionDirection = "left", this.selectionEnd === this.selectionStart && this.selectionStart !== 0 && (o = this._moveLeft(c, "selectionStart")), this.selectionEnd = this.selectionStart, o;
  }, moveCursorLeftWithShift: function(c) {
    return this._selectionDirection === "right" && this.selectionStart !== this.selectionEnd ? this._moveLeft(c, "selectionEnd") : this.selectionStart !== 0 ? (this._selectionDirection = "left", this._moveLeft(c, "selectionStart")) : void 0;
  }, moveCursorRight: function(c) {
    this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorLeftOrRight("Right", c);
  }, _moveCursorLeftOrRight: function(c, o) {
    var l = "moveCursor" + c + "With";
    this._currentCursorOpacity = 1, o.shiftKey ? l += "Shift" : l += "outShift", this[l](o) && (this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
  }, moveCursorRightWithShift: function(c) {
    return this._selectionDirection === "left" && this.selectionStart !== this.selectionEnd ? this._moveRight(c, "selectionStart") : this.selectionEnd !== this._text.length ? (this._selectionDirection = "right", this._moveRight(c, "selectionEnd")) : void 0;
  }, moveCursorRightWithoutShift: function(c) {
    var o = !0;
    return this._selectionDirection = "right", this.selectionStart === this.selectionEnd ? (o = this._moveRight(c, "selectionStart"), this.selectionEnd = this.selectionStart) : this.selectionStart = this.selectionEnd, o;
  }, removeChars: function(c, o) {
    o === void 0 && (o = c + 1), this.removeStyleFromTo(c, o), this._text.splice(c, o - c), this.text = this._text.join(""), this.set("dirty", !0), this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this._removeExtraneousStyles();
  }, insertChars: function(c, o, l, f) {
    f === void 0 && (f = l), f > l && this.removeStyleFromTo(l, f);
    var i = v.util.string.graphemeSplit(c);
    this.insertNewStyleBlock(i, l, o), this._text = [].concat(this._text.slice(0, l), i, this._text.slice(f)), this.text = this._text.join(""), this.set("dirty", !0), this._shouldClearDimensionCache() && (this.initDimensions(), this.setCoords()), this._removeExtraneousStyles();
  } }), function() {
    var c = v.util.toFixed, o = /  +/g;
    v.util.object.extend(v.Text.prototype, { _toSVG: function() {
      var l = this._getSVGLeftTopOffsets(), f = this._getSVGTextAndBg(l.textTop, l.textLeft);
      return this._wrapSVGTextAndBg(f);
    }, toSVG: function(l) {
      return this._createBaseSVGMarkup(this._toSVG(), { reviver: l, noStyle: !0, withShadow: !0 });
    }, _getSVGLeftTopOffsets: function() {
      return { textLeft: -this.width / 2, textTop: -this.height / 2, lineTop: this.getHeightOfLine(0) };
    }, _wrapSVGTextAndBg: function(l) {
      var f = this.getSvgTextDecoration(this);
      return [l.textBgRects.join(""), '		<text xml:space="preserve" ', this.fontFamily ? 'font-family="' + this.fontFamily.replace(/"/g, "'") + '" ' : "", this.fontSize ? 'font-size="' + this.fontSize + '" ' : "", this.fontStyle ? 'font-style="' + this.fontStyle + '" ' : "", this.fontWeight ? 'font-weight="' + this.fontWeight + '" ' : "", f ? 'text-decoration="' + f + '" ' : "", 'style="', this.getSvgStyles(!0), '"', this.addPaintOrder(), " >", l.textSpans.join(""), `</text>
`];
    }, _getSVGTextAndBg: function(l, f) {
      var i, r = [], s = [], u = l;
      this._setSVGBg(s);
      for (var h = 0, d = this._textLines.length; h < d; h++) i = this._getLineLeftOffset(h), (this.textBackgroundColor || this.styleHas("textBackgroundColor", h)) && this._setSVGTextLineBg(s, h, f + i, u), this._setSVGTextLineText(r, h, f + i, u), u += this.getHeightOfLine(h);
      return { textSpans: r, textBgRects: s };
    }, _createTextCharSpan: function(l, f, i, r) {
      var s = l !== l.trim() || l.match(o), u = this.getSvgSpanStyles(f, s), h = u ? 'style="' + u + '"' : "", d = f.deltaY, m = "", y = v.Object.NUM_FRACTION_DIGITS;
      return d && (m = ' dy="' + c(d, y) + '" '), ['<tspan x="', c(i, y), '" y="', c(r, y), '" ', m, h, ">", v.util.string.escapeXml(l), "</tspan>"].join("");
    }, _setSVGTextLineText: function(l, f, i, r) {
      var s, u, h, d, m, y = this.getHeightOfLine(f), b = this.textAlign.indexOf("justify") !== -1, S = "", E = 0, A = this._textLines[f];
      r += y * (1 - this._fontSizeFraction) / this.lineHeight;
      for (var M = 0, C = A.length - 1; M <= C; M++) m = M === C || this.charSpacing, S += A[M], h = this.__charBounds[f][M], E === 0 ? (i += h.kernedWidth - h.width, E += h.width) : E += h.kernedWidth, b && !m && this._reSpaceAndTab.test(A[M]) && (m = !0), m || (s = s || this.getCompleteStyleDeclaration(f, M), u = this.getCompleteStyleDeclaration(f, M + 1), m = this._hasStyleChangedForSvg(s, u)), m && (d = this._getStyleDeclaration(f, M) || {}, l.push(this._createTextCharSpan(S, d, i, r)), S = "", s = u, i += E, E = 0);
    }, _pushTextBgRect: function(l, f, i, r, s, u) {
      var h = v.Object.NUM_FRACTION_DIGITS;
      l.push("		<rect ", this._getFillAttributes(f), ' x="', c(i, h), '" y="', c(r, h), '" width="', c(s, h), '" height="', c(u, h), `"></rect>
`);
    }, _setSVGTextLineBg: function(l, f, i, r) {
      for (var s, u, h = this._textLines[f], d = this.getHeightOfLine(f) / this.lineHeight, m = 0, y = 0, b = this.getValueOfPropertyAt(f, 0, "textBackgroundColor"), S = 0, E = h.length; S < E; S++) s = this.__charBounds[f][S], (u = this.getValueOfPropertyAt(f, S, "textBackgroundColor")) !== b ? (b && this._pushTextBgRect(l, b, i + y, r, m, d), y = s.left, m = s.width, b = u) : m += s.kernedWidth;
      u && this._pushTextBgRect(l, u, i + y, r, m, d);
    }, _getFillAttributes: function(l) {
      var f = l && typeof l == "string" ? new v.Color(l) : "";
      return f && f.getSource() && f.getAlpha() !== 1 ? 'opacity="' + f.getAlpha() + '" fill="' + f.setAlpha(1).toRgb() + '"' : 'fill="' + l + '"';
    }, _getSVGLineTopOffset: function(l) {
      for (var f, i = 0, r = 0; r < l; r++) i += this.getHeightOfLine(r);
      return f = this.getHeightOfLine(r), { lineTop: i, offset: (this._fontSizeMult - this._fontSizeFraction) * f / (this.lineHeight * this._fontSizeMult) };
    }, getSvgStyles: function(l) {
      return v.Object.prototype.getSvgStyles.call(this, l) + " white-space: pre;";
    } });
  }(), function(c) {
    var o = c.fabric || (c.fabric = {});
    o.Textbox = o.util.createClass(o.IText, o.Observable, { type: "textbox", minWidth: 20, dynamicMinWidth: 2, __cachedLines: null, lockScalingFlip: !0, noScaleCache: !1, _dimensionAffectingProps: o.Text.prototype._dimensionAffectingProps.concat("width"), _wordJoiners: /[ \t\r]/, splitByGrapheme: !1, initDimensions: function() {
      this.__skipDimension || (this.isEditing && this.initDelayedCursor(), this.clearContextTop(), this._clearCache(), this.dynamicMinWidth = 0, this._styleMap = this._generateStyleMap(this._splitText()), this.dynamicMinWidth > this.width && this._set("width", this.dynamicMinWidth), this.textAlign.indexOf("justify") !== -1 && this.enlargeSpaces(), this.height = this.calcTextHeight(), this.saveState({ propertySet: "_dimensionAffectingProps" }));
    }, _generateStyleMap: function(l) {
      for (var f = 0, i = 0, r = 0, s = {}, u = 0; u < l.graphemeLines.length; u++) l.graphemeText[r] === `
` && u > 0 ? (i = 0, r++, f++) : !this.splitByGrapheme && this._reSpaceAndTab.test(l.graphemeText[r]) && u > 0 && (i++, r++), s[u] = { line: f, offset: i }, r += l.graphemeLines[u].length, i += l.graphemeLines[u].length;
      return s;
    }, styleHas: function(l, f) {
      if (this._styleMap && !this.isWrapping) {
        var i = this._styleMap[f];
        i && (f = i.line);
      }
      return o.Text.prototype.styleHas.call(this, l, f);
    }, isEmptyStyles: function(l) {
      if (!this.styles) return !0;
      var f, i, r = 0, s = !1, u = this._styleMap[l], h = this._styleMap[l + 1];
      for (var d in u && (l = u.line, r = u.offset), h && (s = h.line === l, f = h.offset), i = l === void 0 ? this.styles : { line: this.styles[l] }) for (var m in i[d]) if (m >= r && (!s || m < f)) for (var y in i[d][m]) return !1;
      return !0;
    }, _getStyleDeclaration: function(l, f) {
      if (this._styleMap && !this.isWrapping) {
        var i = this._styleMap[l];
        if (!i) return null;
        l = i.line, f = i.offset + f;
      }
      return this.callSuper("_getStyleDeclaration", l, f);
    }, _setStyleDeclaration: function(l, f, i) {
      var r = this._styleMap[l];
      l = r.line, f = r.offset + f, this.styles[l][f] = i;
    }, _deleteStyleDeclaration: function(l, f) {
      var i = this._styleMap[l];
      l = i.line, f = i.offset + f, delete this.styles[l][f];
    }, _getLineStyle: function(l) {
      var f = this._styleMap[l];
      return !!this.styles[f.line];
    }, _setLineStyle: function(l) {
      var f = this._styleMap[l];
      this.styles[f.line] = {};
    }, _wrapText: function(l, f) {
      var i, r = [];
      for (this.isWrapping = !0, i = 0; i < l.length; i++) r = r.concat(this._wrapLine(l[i], i, f));
      return this.isWrapping = !1, r;
    }, _measureWord: function(l, f, i) {
      var r, s = 0;
      i = i || 0;
      for (var u = 0, h = l.length; u < h; u++)
        s += this._getGraphemeBox(l[u], f, u + i, r, !0).kernedWidth, r = l[u];
      return s;
    }, _wrapLine: function(l, f, i, r) {
      var s = 0, u = this.splitByGrapheme, h = [], d = [], m = u ? o.util.string.graphemeSplit(l) : l.split(this._wordJoiners), y = "", b = 0, S = u ? "" : " ", E = 0, A = 0, M = 0, C = !0, O = this._getWidthOfCharSpacing();
      r = r || 0, m.length === 0 && m.push([]), i -= r;
      for (var N = 0; N < m.length; N++) y = u ? m[N] : o.util.string.graphemeSplit(m[N]), E = this._measureWord(y, f, b), b += y.length, (s += A + E - O) > i && !C ? (h.push(d), d = [], s = E, C = !0) : s += O, C || u || d.push(S), d = d.concat(y), A = u ? 0 : this._measureWord([S], f, b), b++, C = !1, E > M && (M = E);
      return N && h.push(d), M + r > this.dynamicMinWidth && (this.dynamicMinWidth = M - O + r), h;
    }, isEndOfWrapping: function(l) {
      return !this._styleMap[l + 1] || this._styleMap[l + 1].line !== this._styleMap[l].line;
    }, missingNewlineOffset: function(l) {
      return this.splitByGrapheme ? this.isEndOfWrapping(l) ? 1 : 0 : 1;
    }, _splitTextIntoLines: function(l) {
      for (var f = o.Text.prototype._splitTextIntoLines.call(this, l), i = this._wrapText(f.lines, this.width), r = new Array(i.length), s = 0; s < i.length; s++) r[s] = i[s].join("");
      return f.lines = r, f.graphemeLines = i, f;
    }, getMinWidth: function() {
      return Math.max(this.minWidth, this.dynamicMinWidth);
    }, _removeExtraneousStyles: function() {
      var l = {};
      for (var f in this._styleMap) this._textLines[f] && (l[this._styleMap[f].line] = 1);
      for (var f in this.styles) l[f] || delete this.styles[f];
    }, toObject: function(l) {
      return this.callSuper("toObject", ["minWidth", "splitByGrapheme"].concat(l));
    } }), o.Textbox.fromObject = function(l, f) {
      return o.Object._fromObject("Textbox", l, f, "text");
    };
  }(t), function() {
    var c = v.controlsUtils, o = c.scaleSkewCursorStyleHandler, l = c.scaleCursorStyleHandler, f = c.scalingEqually, i = c.scalingYOrSkewingX, r = c.scalingXOrSkewingY, s = c.scaleOrSkewActionName, u = v.Object.prototype.controls;
    if (u.ml = new v.Control({ x: -0.5, y: 0, cursorStyleHandler: o, actionHandler: r, getActionName: s }), u.mr = new v.Control({ x: 0.5, y: 0, cursorStyleHandler: o, actionHandler: r, getActionName: s }), u.mb = new v.Control({ x: 0, y: 0.5, cursorStyleHandler: o, actionHandler: i, getActionName: s }), u.mt = new v.Control({ x: 0, y: -0.5, cursorStyleHandler: o, actionHandler: i, getActionName: s }), u.tl = new v.Control({ x: -0.5, y: -0.5, cursorStyleHandler: l, actionHandler: f }), u.tr = new v.Control({ x: 0.5, y: -0.5, cursorStyleHandler: l, actionHandler: f }), u.bl = new v.Control({ x: -0.5, y: 0.5, cursorStyleHandler: l, actionHandler: f }), u.br = new v.Control({ x: 0.5, y: 0.5, cursorStyleHandler: l, actionHandler: f }), u.mtr = new v.Control({ x: 0, y: -0.5, actionHandler: c.rotationWithSnapping, cursorStyleHandler: c.rotationStyleHandler, offsetY: -40, withConnection: !0, actionName: "rotate" }), v.Textbox) {
      var h = v.Textbox.prototype.controls = {};
      h.mtr = u.mtr, h.tr = u.tr, h.br = u.br, h.tl = u.tl, h.bl = u.bl, h.mt = u.mt, h.mb = u.mb, h.mr = new v.Control({ x: 0.5, y: 0, actionHandler: c.changeWidth, cursorStyleHandler: o, actionName: "resizing" }), h.ml = new v.Control({ x: -0.5, y: 0, actionHandler: c.changeWidth, cursorStyleHandler: o, actionName: "resizing" });
    }
  }(), function() {
    var c = v.Object.prototype._set, o = v.Object.prototype.render, l = v.Object.prototype.toObject, f = v.Object.prototype._createBaseSVGMarkup;
    v.util.object.extend(v.Object.prototype, { erasable: !0, getEraser: function() {
      return this.clipPath && this.clipPath.eraser ? this.clipPath : void 0;
    }, getClipPath: function() {
      var u = this.getEraser();
      return u ? u._objects[0].clipPath : this.clipPath;
    }, setClipPath: function(u) {
      var h = this.getEraser();
      (h ? h._objects[0] : this).set("clipPath", u), this.set("dirty", !0);
    }, _updateEraserDimensions: function(u, h) {
      var d = this.getEraser();
      if (d) {
        var m = d._objects[0], y = { width: m.width, height: m.height }, b = this._getNonTransformedDimensions(), S = v.util.object.extend({ width: b.x, height: b.y }, u);
        if (y.width === S.width && y.height === S.height) return;
        var E = new v.Point((y.width - S.width) / 2, (y.height - S.height) / 2);
        d.set(S), d.setPositionByOrigin(new v.Point(0, 0), "center", "center"), m.set(S), d.set("dirty", !0), h || d.getObjects("path").forEach(function(A) {
          A.setPositionByOrigin(A.getCenterPoint().add(E), "center", "center");
        }), this.setCoords();
      }
    }, _set: function(u, h) {
      return c.call(this, u, h), u !== "width" && u !== "height" || this._updateEraserDimensions(), this;
    }, render: function(u) {
      this._updateEraserDimensions(), o.call(this, u);
    }, toObject: function(u) {
      return l.call(this, ["erasable"].concat(u));
    }, eraserToSVG: function(u) {
      var h = this.getEraser();
      if (h) {
        var d = h._objects[0].fill;
        h._objects[0].fill = "white", h.clipPathId = "CLIPPATH_" + v.Object.__uid++;
        var m = ["<defs>", "<mask " + ['id="' + h.clipPathId + '"'].join(" ") + " >", h.toSVG(u.reviver), "</mask>", "</defs>"];
        return h._objects[0].fill = d, m.join(`
`);
      }
      return "";
    }, _createBaseSVGMarkup: function(u, h) {
      var d = this.getEraser();
      if (d) {
        var m = this.eraserToSVG(h);
        this.clipPath = null;
        var y = f.call(this, u, h);
        return this.clipPath = d, [m, y.replace(">", 'mask="url(#' + d.clipPathId + ')" >')].join(`
`);
      }
      return f.call(this, u, h);
    } });
    var i = v.Group.prototype._restoreObjectsState, r = v.Group.prototype.toObject, s = v.Group.prototype._getBounds;
    v.util.object.extend(v.Group.prototype, { _getBounds: function(u, h, d) {
      if (this.eraser) return this.width = this._objects[0].width, void (this.height = this._objects[0].height);
      s.call(this, u, h, d);
    }, _addEraserPathToObjects: function(u) {
      this._objects.forEach(function(h) {
        v.EraserBrush.prototype._addPathToObjectEraser.call(v.EraserBrush.prototype, h, u);
      });
    }, applyEraserToObjects: function() {
      var u = this;
      if (this.getEraser()) {
        var h = u.calcTransformMatrix();
        u.getEraser().clone(function(d) {
          var m = d._objects[0].clipPath;
          u.clipPath = m || void 0, d.getObjects("path").forEach(function(y) {
            var b = v.util.multiplyTransformMatrices(h, y.calcTransformMatrix());
            v.util.applyTransformToObject(y, b), m ? m.clone(function(S) {
              v.EraserBrush.prototype.applyClipPathToPath.call(v.EraserBrush.prototype, y, S, h), u._addEraserPathToObjects(y);
            }) : u._addEraserPathToObjects(y);
          });
        });
      }
    }, _restoreObjectsState: function() {
      return this.erasable === !0 && this.applyEraserToObjects(), i.call(this);
    }, toObject: function(u) {
      return r.call(this, ["eraser"].concat(u));
    } }), v.util.object.extend(v.Canvas.prototype, { isErasing: function() {
      return this.isDrawingMode && this.freeDrawingBrush && this.freeDrawingBrush.type === "eraser" && this.freeDrawingBrush._isErasing;
    }, renderAll: function() {
      if (!this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), !this.isErasing()) {
        this.hasLostContext && this.renderTopLayer(this.contextTop);
        var u = this.contextContainer;
        return this.renderCanvas(u, this._chooseObjectsToRender()), this;
      }
      this.freeDrawingBrush._render();
    } }), v.EraserBrush = v.util.createClass(v.PencilBrush, { type: "eraser", _ready: !1, _drawOverlayOnTop: !1, _isErasing: !1, initialize: function(u) {
      this.callSuper("initialize", u), this._renderBound = this._render.bind(this), this.render = this.render.bind(this);
    }, hideObject: function(u) {
      u && (u._originalOpacity = u.opacity, u.set({ opacity: 0 }));
    }, restoreObjectVisibility: function(u) {
      u && u._originalOpacity && (u.set({ opacity: u._originalOpacity }), u._originalOpacity = void 0);
    }, _isErasable: function(u) {
      return u.erasable !== !1;
    }, prepareCanvasBackgroundForLayer: function(u) {
      if (u !== "overlay") {
        var h = this.canvas.backgroundImage, d = u === "top";
        h && this._isErasable(h) === !d && this.hideObject(h);
      }
    }, prepareCanvasOverlayForLayer: function(u) {
      var h = this.canvas, d = h.overlayImage, m = !!h.overlayColor;
      if (h.overlayColor && u !== "overlay" && (this.__overlayColor = h.overlayColor, delete h.overlayColor), u === "bottom") return this.hideObject(d), !1;
      var y = u === "top", b = d && !this._isErasable(d) || m;
      return d && this._isErasable(d) === !y && this.hideObject(d), b;
    }, restoreCanvasDrawables: function() {
      var u = this.canvas;
      this.__overlayColor && (u.overlayColor = this.__overlayColor, delete this.__overlayColor), this.restoreObjectVisibility(u.backgroundImage), this.restoreObjectVisibility(u.overlayImage);
    }, prepareCollectionTraversal: function(u) {
      var h = this;
      u.forEachObject(function(d) {
        d.forEachObject && d.erasable === "deep" ? h.prepareCollectionTraversal(d) : d.erasable && h.hideObject(d);
      });
    }, restoreCollectionTraversal: function(u) {
      var h = this;
      u.forEachObject(function(d) {
        d.forEachObject && d.erasable === "deep" ? h.restoreCollectionTraversal(d) : h.restoreObjectVisibility(d);
      });
    }, prepareCanvasObjectsForLayer: function(u) {
      u === "bottom" && this.prepareCollectionTraversal(this.canvas);
    }, restoreCanvasObjectsFromLayer: function(u) {
      u === "bottom" && this.restoreCollectionTraversal(this.canvas);
    }, prepareCanvasForLayer: function(u) {
      return this.prepareCanvasBackgroundForLayer(u), this.prepareCanvasObjectsForLayer(u), this.prepareCanvasOverlayForLayer(u);
    }, restoreCanvasFromLayer: function(u) {
      this.restoreCanvasDrawables(), this.restoreCanvasObjectsFromLayer(u);
    }, renderBottomLayer: function() {
      var u = this.canvas;
      this.prepareCanvasForLayer("bottom"), u.renderCanvas(u.getContext(), u.getObjects().filter(function(h) {
        return !h.erasable || h.forEachObject;
      })), this.restoreCanvasFromLayer("bottom");
    }, renderTopLayer: function() {
      var u = this.canvas;
      this._drawOverlayOnTop = this.prepareCanvasForLayer("top"), u.renderCanvas(u.contextTop, u.getObjects()), this.callSuper("_render"), this.restoreCanvasFromLayer("top");
    }, renderOverlay: function() {
      this.prepareCanvasForLayer("overlay");
      var u = this.canvas, h = u.contextTop;
      u._renderOverlay(h), this.restoreCanvasFromLayer("overlay");
    }, _saveAndTransform: function(u) {
      this.callSuper("_saveAndTransform", u), u.globalCompositeOperation = "destination-out";
    }, needsFullRender: function() {
      return this.callSuper("needsFullRender") || this._drawOverlayOnTop;
    }, onMouseDown: function(u, h) {
      this.canvas._isMainEvent(h.e) && (this._prepareForDrawing(u), this._captureDrawingPath(u), this._isErasing = !0, this.canvas.fire("erasing:start"), this._ready = !0, this._render());
    }, _render: function() {
      this._ready && (this.isRendering = 1, this.renderBottomLayer(), this.renderTopLayer(), this.renderOverlay(), this.isRendering = 0);
    }, render: function() {
      return !!this._isErasing && (this.isRendering ? this.isRendering = v.util.requestAnimFrame(this._renderBound) : this._render(), !0);
    }, applyClipPathToPath: function(u, h, d) {
      var m = u.calcTransformMatrix(), y = h.calcTransformMatrix(), b = v.util.multiplyTransformMatrices(v.util.invertTransform(m), d);
      return v.util.applyTransformToObject(h, v.util.multiplyTransformMatrices(b, y)), u.clipPath = h, u;
    }, clonePathWithClipPath: function(u, h, d) {
      var m = h.calcTransformMatrix(), y = h.getClipPath(), b = this;
      u.clone(function(S) {
        y.clone(function(E) {
          d(b.applyClipPathToPath(S, E, m));
        });
      });
    }, _addPathToObjectEraser: function(u, h) {
      var d, m = this;
      if (u.forEachObject && u.erasable === "deep") {
        var y = u._objects.filter(function(E) {
          return E.erasable;
        });
        y.length > 0 && u.clipPath ? this.clonePathWithClipPath(h, u, function(E) {
          y.forEach(function(A) {
            m._addPathToObjectEraser(A, E);
          });
        }) : y.length > 0 && y.forEach(function(E) {
          m._addPathToObjectEraser(E, h);
        });
      } else {
        if (u.getEraser()) d = u.clipPath;
        else {
          var b = u._getNonTransformedDimensions(), S = new v.Rect({ fill: "rgb(0,0,0)", width: b.x, height: b.y, clipPath: u.clipPath, originX: "center", originY: "center" });
          d = new v.Group([S], { eraser: !0 });
        }
        h.clone(function(E) {
          E.globalCompositeOperation = "destination-out";
          var A = v.util.multiplyTransformMatrices(v.util.invertTransform(u.calcTransformMatrix()), E.calcTransformMatrix());
          v.util.applyTransformToObject(E, A), d.addWithUpdate(E), u.set({ clipPath: d, dirty: !0 }), u.fire("erasing:end", { path: E }), u.group && Array.isArray(m.__subTargets) && m.__subTargets.push(u);
        });
      }
    }, applyEraserToCanvas: function(u) {
      var h = this.canvas, d = {};
      return ["backgroundImage", "overlayImage"].forEach(function(m) {
        var y = h[m];
        y && y.erasable && (this._addPathToObjectEraser(y, u), d[m] = y);
      }, this), d;
    }, _finalizeAndAddPath: function() {
      var u = this.canvas.contextTop, h = this.canvas;
      u.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate)), h.clearContext(h.contextTop), this._isErasing = !1;
      var d = this._points && this._points.length > 1 ? this.convertPointsToSVGPath(this._points) : null;
      if (!d || this._isEmptySVGPath(d)) return h.fire("erasing:end"), void h.requestRenderAll();
      var m = this.createPath(d);
      m.setCoords(), h.fire("before:path:created", { path: m });
      var y = this.applyEraserToCanvas(m), b = this;
      this.__subTargets = [];
      var S = [];
      h.forEachObject(function(E) {
        E.erasable && E.intersectsWithObject(m, !0, !0) && (b._addPathToObjectEraser(E, m), S.push(E));
      }), h.fire("erasing:end", { path: m, targets: S, subTargets: this.__subTargets, drawables: y }), delete this.__subTargets, h.requestRenderAll(), m.setCoords(), this._resetShadow(), h.fire("path:created", { path: m });
    } });
  }();
})(y0);
var Pn = y0.fabric;
const Ch = (t, e = 1) => {
  let n = t.match(/[^#]./g);
  return n ? `rgba(${n.map((a) => parseInt(a, 16)).join(", ")}, ${e})` : t;
}, ev = (t) => function(e, n, a, p, g) {
  var _ = this.cornerSize;
  e.save(), e.translate(n, a), e.rotate(fabric.util.degreesToRadians(g.angle)), e.drawImage(t, -_ / 2, -_ / 2, _, _), e.restore();
}, nv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721638678524, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 6714, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M955.769524 734.466768c-0.13917 0-4.313236-8.118911-9.275247-18.036795L816.444339 456.344422c-4.962012-9.923-18.093077-18.035772-29.181623-18.030655l-107.787912 0.033769c-11.089569 0.004093-20.163225 9.080819-20.163225 20.174482l0 34.266431c0 11.089569 9.073656 20.170388 20.163225 20.181645l34.267455 0.023536c11.094686 0.002047 24.193005 8.146541 29.116131 18.085914l92.175329 186.263218c4.916986 9.943466-0.128937 18.077727-11.224646 18.077727L677.409772 735.420489c-11.094686 0-20.169365 9.075703-20.169365 20.164249l0 105.501846c0 11.089569-9.074679 20.163225-20.167319 20.163225L383.359666 881.249809c-11.093662 0-20.169365-9.073656-20.169365-20.163225L363.190301 755.585761c0-11.088546-9.074679-20.164249-20.163225-20.164249L193.657116 735.421512c-11.094686 0-16.003486-8.066723-10.918677-17.923208l96.398514-186.870038c5.087878-9.856485 18.319228-17.911952 29.408797-17.906835l33.378202 0.022513c11.095709 0.005117 20.169365-9.063423 20.169365-20.151969l0-33.967626c0-11.095709-9.073656-20.164249-20.169365-20.164249l-107.283422 0.039909c-11.094686 0-24.242124 8.112772-29.226648 18.024515L74.71926 716.616214c-4.978385 9.907651-8.933463 18.014282-8.792247 18.014282 0.14224 0 0.260943 9.074679 0.260943 20.169365l0 183.128831c0 11.094686 9.067516 20.169365 20.162202 20.169365l849.507874 0c11.096732 0 20.169365-9.074679 20.169365-20.169365L956.027397 754.629993C956.020234 743.532237 955.908694 734.466768 955.769524 734.466768L955.769524 734.466768zM326.291926 294.249651l110.674659 0L436.966585 659.44205 585.181231 659.44205 585.181231 294.249651l116.595508 0c11.097756 0 14.150278-6.79373 6.794753-15.093766L524.899286 71.90875c-7.355525-8.299013-19.308765-8.226359-26.567076 0.158612L319.322188 278.997272C312.063877 287.388383 315.20338 294.249651 326.291926 294.249651L326.291926 294.249651zM326.291926 294.249651", "p-id": 6715 })), iv = D.forwardRef(nv), rv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("style", null, `
        .small {
        font: 280px sans-serif;
        font-weight: bold;
        }
    `), /* @__PURE__ */ D.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ D.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ D.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ D.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ D.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ D.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ D.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ D.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ D.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ D.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ D.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ D.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ D.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ D.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ D.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ D.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ D.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ D.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ D.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ D.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ D.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ D.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ D.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ D.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ D.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ D.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ D.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ D.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ D.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ D.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ D.createElement("text", { x: 440, y: 960, className: "small" }, "RGB")), ov = D.forwardRef(rv), av = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ D.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ D.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ D.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ D.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ D.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ D.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ D.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ D.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ D.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ D.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ D.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ D.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ D.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ D.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ D.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ D.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ D.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ D.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ D.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ D.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ D.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ D.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ D.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ D.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ D.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ D.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ D.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ D.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ D.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ D.createElement("rect", { x: 770, y: 610, width: 120, height: 360 }), /* @__PURE__ */ D.createElement("rect", { x: 650, y: 730, width: 360, height: 120 })), sv = D.forwardRef(av), lv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1726464554433, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1550, ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M32.935673 0.998051 32.935673 1023.001949 32.935673 0.998051Z", opacity: 0.3, "p-id": 1551 }), /* @__PURE__ */ D.createElement("path", { d: "M64.873294 0.998051 64.873294 1023.001949 64.873294 0.998051Z", opacity: 1, "p-id": 1552 }), /* @__PURE__ */ D.createElement("path", { d: "M96.810916 0.998051 96.810916 1023.001949 96.810916 0.998051Z", opacity: 0.3, "p-id": 1553 }), /* @__PURE__ */ D.createElement("path", { d: "M128.748538 0.998051 128.748538 1023.001949 128.748538 0.998051Z", opacity: 1, "p-id": 1554 }), /* @__PURE__ */ D.createElement("path", { d: "M160.68616 0.998051 160.68616 1023.001949 160.68616 0.998051Z", opacity: 0.3, "p-id": 1555 }), /* @__PURE__ */ D.createElement("path", { d: "M192.623782 0.998051 192.623782 1023.001949 192.623782 0.998051Z", opacity: 1, "p-id": 1556 }), /* @__PURE__ */ D.createElement("path", { d: "M224.561404 0.998051 224.561404 1023.001949 224.561404 0.998051Z", opacity: 0.3, "p-id": 1557 }), /* @__PURE__ */ D.createElement("path", { d: "M256.499025 0.998051 256.499025 1023.001949 256.499025 0.998051Z", opacity: 1, "p-id": 1558 }), /* @__PURE__ */ D.createElement("path", { d: "M288.436647 0.998051 288.436647 1023.001949 288.436647 0.998051Z", opacity: 0.3, "p-id": 1559 }), /* @__PURE__ */ D.createElement("path", { d: "M320.374269 0.998051 320.374269 1023.001949 320.374269 0.998051Z", opacity: 1, "p-id": 1560 }), /* @__PURE__ */ D.createElement("path", { d: "M352.311891 0.998051 352.311891 1023.001949 352.311891 0.998051Z", opacity: 0.3, "p-id": 1561 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 0.998051 384.249513 1023.001949 384.249513 0.998051Z", opacity: 1, "p-id": 1562 }), /* @__PURE__ */ D.createElement("path", { d: "M416.187135 0.998051 416.187135 1023.001949 416.187135 0.998051Z", opacity: 0.3, "p-id": 1563 }), /* @__PURE__ */ D.createElement("path", { d: "M448.124756 0.998051 448.124756 1023.001949 448.124756 0.998051Z", opacity: 1, "p-id": 1564 }), /* @__PURE__ */ D.createElement("path", { d: "M480.062378 0.998051 480.062378 1023.001949 480.062378 0.998051Z", opacity: 0.3, "p-id": 1565 }), /* @__PURE__ */ D.createElement("path", { d: "M512 0.998051 512 1023.001949 512 0.998051Z", opacity: 1, "p-id": 1566 }), /* @__PURE__ */ D.createElement("path", { d: "M543.937622 0.998051 543.937622 1023.001949 543.937622 0.998051Z", opacity: 0.3, "p-id": 1567 }), /* @__PURE__ */ D.createElement("path", { d: "M575.875244 0.998051 575.875244 1023.001949 575.875244 0.998051Z", opacity: 1, "p-id": 1568 }), /* @__PURE__ */ D.createElement("path", { d: "M607.812865 0.998051 607.812865 1023.001949 607.812865 0.998051Z", opacity: 0.3, "p-id": 1569 }), /* @__PURE__ */ D.createElement("path", { d: "M639.750487 0.998051 639.750487 1023.001949 639.750487 0.998051Z", opacity: 1, "p-id": 1570 }), /* @__PURE__ */ D.createElement("path", { d: "M671.688109 0.998051 671.688109 1023.001949 671.688109 0.998051Z", opacity: 0.3, "p-id": 1571 }), /* @__PURE__ */ D.createElement("path", { d: "M703.625731 0.998051 703.625731 1023.001949 703.625731 0.998051Z", opacity: 1, "p-id": 1572 }), /* @__PURE__ */ D.createElement("path", { d: "M735.563353 0.998051 735.563353 1023.001949 735.563353 0.998051Z", opacity: 0.3, "p-id": 1573 }), /* @__PURE__ */ D.createElement("path", { d: "M767.500975 0.998051 767.500975 1023.001949 767.500975 0.998051Z", opacity: 1, "p-id": 1574 }), /* @__PURE__ */ D.createElement("path", { d: "M799.438596 0.998051 799.438596 1023.001949 799.438596 0.998051Z", opacity: 0.3, "p-id": 1575 }), /* @__PURE__ */ D.createElement("path", { d: "M831.376218 0.998051 831.376218 1023.001949 831.376218 0.998051Z", opacity: 1, "p-id": 1576 }), /* @__PURE__ */ D.createElement("path", { d: "M863.31384 0.998051 863.31384 1023.001949 863.31384 0.998051Z", opacity: 0.3, "p-id": 1577 }), /* @__PURE__ */ D.createElement("path", { d: "M895.251462 0.998051 895.251462 1023.001949 895.251462 0.998051Z", opacity: 1, "p-id": 1578 }), /* @__PURE__ */ D.createElement("path", { d: "M927.189084 0.998051 927.189084 1023.001949 927.189084 0.998051Z", opacity: 0.3, "p-id": 1579 }), /* @__PURE__ */ D.createElement("path", { d: "M959.126706 0.998051 959.126706 1023.001949 959.126706 0.998051Z", opacity: 1, "p-id": 1580 }), /* @__PURE__ */ D.createElement("path", { d: "M991.064327 0.998051 991.064327 1023.001949 991.064327 0.998051Z", opacity: 0.3, "p-id": 1581 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 32.935673 1023.001949 32.935673 0.998051 32.935673Z", opacity: 0.3, "p-id": 1582 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 64.873294 1023.001949 64.873294 0.998051 64.873294Z", opacity: 1, "p-id": 1583 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 96.810916 1023.001949 96.810916 0.998051 96.810916Z", opacity: 0.3, "p-id": 1584 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 128.748538 1023.001949 128.748538 0.998051 128.748538Z", opacity: 1, "p-id": 1585 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 160.68616 1023.001949 160.68616 0.998051 160.68616Z", opacity: 0.3, "p-id": 1586 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 192.623782 1023.001949 192.623782 0.998051 192.623782Z", opacity: 1, "p-id": 1587 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 224.561404 1023.001949 224.561404 0.998051 224.561404Z", opacity: 0.3, "p-id": 1588 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 256.499025 1023.001949 256.499025 0.998051 256.499025Z", opacity: 1, "p-id": 1589 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 288.436647 1023.001949 288.436647 0.998051 288.436647Z", opacity: 0.3, "p-id": 1590 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 320.374269 1023.001949 320.374269 0.998051 320.374269Z", opacity: 1, "p-id": 1591 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 352.311891 1023.001949 352.311891 0.998051 352.311891Z", opacity: 0.3, "p-id": 1592 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 384.249513 1023.001949 384.249513 0.998051 384.249513Z", opacity: 1, "p-id": 1593 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 416.187135 1023.001949 416.187135 0.998051 416.187135Z", opacity: 0.3, "p-id": 1594 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 448.124756 1023.001949 448.124756 0.998051 448.124756Z", opacity: 1, "p-id": 1595 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 480.062378 1023.001949 480.062378 0.998051 480.062378Z", opacity: 0.3, "p-id": 1596 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 512 1023.001949 512 0.998051 512Z", opacity: 1, "p-id": 1597 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 543.937622 1023.001949 543.937622 0.998051 543.937622Z", opacity: 0.3, "p-id": 1598 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 575.875244 1023.001949 575.875244 0.998051 575.875244Z", opacity: 1, "p-id": 1599 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 607.812865 1023.001949 607.812865 0.998051 607.812865Z", opacity: 0.3, "p-id": 1600 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 639.750487 1023.001949 639.750487 0.998051 639.750487Z", opacity: 1, "p-id": 1601 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 671.688109 1023.001949 671.688109 0.998051 671.688109Z", opacity: 0.3, "p-id": 1602 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 703.625731 1023.001949 703.625731 0.998051 703.625731Z", opacity: 1, "p-id": 1603 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 735.563353 1023.001949 735.563353 0.998051 735.563353Z", opacity: 0.3, "p-id": 1604 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 767.500975 1023.001949 767.500975 0.998051 767.500975Z", opacity: 1, "p-id": 1605 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 799.438596 1023.001949 799.438596 0.998051 799.438596Z", opacity: 0.3, "p-id": 1606 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 831.376218 1023.001949 831.376218 0.998051 831.376218Z", opacity: 1, "p-id": 1607 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 863.31384 1023.001949 863.31384 0.998051 863.31384Z", opacity: 0.3, "p-id": 1608 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 895.251462 1023.001949 895.251462 0.998051 895.251462Z", opacity: 1, "p-id": 1609 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 927.189084 1023.001949 927.189084 0.998051 927.189084Z", opacity: 0.3, "p-id": 1610 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 959.126706 1023.001949 959.126706 0.998051 959.126706Z", opacity: 1, "p-id": 1611 }), /* @__PURE__ */ D.createElement("path", { d: "M0.998051 991.064327 1023.001949 991.064327 0.998051 991.064327Z", opacity: 0.3, "p-id": 1612 }), /* @__PURE__ */ D.createElement("path", { d: "M384.249513 586.520452c0 0 203.546448-122.121481 318.144624-73.8817 23.755602-36.197302 47.155899-75.189146 70.065154-114.997396-112.107041-27.466355-260.45929-2.746635-260.45929-2.746635s189.841216-113.89954 306.068211-78.247173c23.304483-42.025918 45.964226-83.478955 67.823532-122.065591-92.59515-6.255782-182.266012 8.687033-182.266012 8.687033s118.915743-71.348647 226.136327-83.435041c33.732117-54.75306 65.042963-97.689201 93.239891-118.835899-559.906433 0-894.253411 638.752437-1022.003899 1022.003899l63.875244 0 191.625731-319.376218c0 0 63.875244 63.875244 255.500975 0 45.385357-15.128452 90.770713-57.140398 135.307727-113.711906-112.396476-28.498339-263.058214-3.393372-263.058214-3.393372z", "p-id": 1613 }), /* @__PURE__ */ D.createElement("rect", { x: 650, y: 730, width: 360, height: 120 })), cv = D.forwardRef(lv), uv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1720327293062, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 2436, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M128 938.666667c-25.6 0-42.666667-17.066667-42.666667-42.666667s17.066667-42.666667 42.666667-42.666667h132.266667l-140.8-140.8c-34.133333-34.133333-34.133333-85.333333 0-119.466666L601.6 110.933333c34.133333-34.133333 85.333333-34.133333 119.466667 0l179.2 179.2c34.133333 34.133333 34.133333 85.333333 0 119.466667L460.8 853.333333H896c25.6 0 42.666667 17.066667 42.666667 42.666667s-17.066667 42.666667-42.666667 42.666667H128z m68.266667-298.666667c-8.533333 8.533333-8.533333 21.333333 0 29.866667l106.666666 106.666666c34.133333 34.133333 85.333333 34.133333 119.466667 0l119.466667-119.466666-179.2-179.2L196.266667 640z", "p-id": 2437 })), hv = D.forwardRef(uv), fv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721638183200, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1448, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M607.274667 612.992l88.661333 190.122667a21.333333 21.333333 0 0 1-10.325333 28.373333l-77.312 36.053333a21.333333 21.333333 0 0 1-28.373334-10.325333l-90.666666-194.474667-111.488 111.488A21.333333 21.333333 0 0 1 341.333333 759.168V218.88a21.333333 21.333333 0 0 1 35.669334-15.786667l397.056 360.96a21.333333 21.333333 0 0 1-12.714667 37.077334l-154.069333 11.861333z", "p-id": 1449 })), dv = D.forwardRef(fv), pv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 576 512", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M234.7 42.7L197 56.8c-3 1.1-5 4-5 7.2s2 6.1 5 7.2l37.7 14.1L248.8 123c1.1 3 4 5 7.2 5s6.1-2 7.2-5l14.1-37.7L315 71.2c3-1.1 5-4 5-7.2s-2-6.1-5-7.2L277.3 42.7 263.2 5c-1.1-3-4-5-7.2-5s-6.1 2-7.2 5L234.7 42.7zM46.1 395.4c-18.7 18.7-18.7 49.1 0 67.9l34.6 34.6c18.7 18.7 49.1 18.7 67.9 0L529.9 116.5c18.7-18.7 18.7-49.1 0-67.9L495.3 14.1c-18.7-18.7-49.1-18.7-67.9 0L46.1 395.4zM484.6 82.6l-105 105-23.3-23.3 105-105 23.3 23.3zM7.5 117.2C3 118.9 0 123.2 0 128s3 9.1 7.5 10.8L64 160l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L128 160l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L128 96 106.8 39.5C105.1 35 100.8 32 96 32s-9.1 3-10.8 7.5L64 96 7.5 117.2zm352 256c-4.5 1.7-7.5 6-7.5 10.8s3 9.1 7.5 10.8L416 416l21.2 56.5c1.7 4.5 6 7.5 10.8 7.5s9.1-3 10.8-7.5L480 416l56.5-21.2c4.5-1.7 7.5-6 7.5-10.8s-3-9.1-7.5-10.8L480 352l-21.2-56.5c-1.7-4.5-6-7.5-10.8-7.5s-9.1 3-10.8 7.5L416 352l-56.5 21.2z" })), gv = D.forwardRef(pv), mv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721704033853, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4365, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M512 324.266667V136.533333c0-6.826667-3.413333-13.653333-10.24-13.653333-6.826667-3.413333-13.653333-3.413333-17.066667 0l-477.866666 307.2c-3.413333 3.413333-6.826667 6.826667-6.826667 13.653333s3.413333 10.24 6.826667 13.653334l477.866666 341.333333c6.826667 3.413333 13.653333 3.413333 17.066667 0 6.826667-3.413333 10.24-10.24 10.24-13.653333v-187.733334c249.173333 10.24 474.453333 235.52 477.866667 290.133334 0 10.24 6.826667 17.066667 17.066666 17.066666s17.066667-6.826667 17.066667-17.066666c-3.413333-225.28-170.666667-552.96-512-563.2z", "p-id": 4366 })), vv = D.forwardRef(mv), yv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721704049355, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4547, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M1017.173333 430.08l-477.866666-307.2c-6.826667-3.413333-13.653333-3.413333-17.066667 0-6.826667 3.413333-10.24 6.826667-10.24 13.653333v187.733334C170.666667 334.506667 3.413333 662.186667 0 887.466667v3.413333c0 6.826667 6.826667 13.653333 17.066667 13.653333s17.066667-6.826667 17.066666-17.066666c3.413333-51.2 228.693333-279.893333 477.866667-290.133334V785.066667c0 6.826667 3.413333 13.653333 10.24 13.653333 6.826667 3.413333 13.653333 3.413333 17.066667 0l477.866666-341.333333c3.413333-3.413333 6.826667-10.24 6.826667-13.653334s-3.413333-10.24-6.826667-13.653333z", "p-id": 4548 })), _v = D.forwardRef(yv), bv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721712684369, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1463, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M369.792 704.32L930.304 128 1024 223.616 369.984 896l-20.288-20.864-0.128 0.128L0 516.8 96.128 423.68l273.664 280.64z", "p-id": 1464 })), wv = D.forwardRef(bv), Cv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1721712695744, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 4043, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M960 154.24L869.76 64 512 421.76 154.24 64 64 154.24 421.76 512 64 869.76 154.24 960 512 602.24 869.76 960 960 869.76 602.24 512z", "p-id": 4044 })), xv = D.forwardRef(Cv), Sv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1722477182503, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 8793, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M360 184h-8c4.4 0 8-3.6 8-8v8h304v-8c0 4.4 3.6 8 8 8h-8v72h72v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80h72v-72z", "p-id": 8794 }), /* @__PURE__ */ D.createElement("path", { d: "M864 256H160c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h60.4l24.7 523c1.6 34.1 29.8 61 63.9 61h454c34.2 0 62.3-26.8 63.9-61l24.7-523H888c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM731.3 840H292.7l-24.2-512h487l-24.2 512z", "p-id": 8795 })), xh = D.forwardRef(Sv), Tv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1722477192628, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 8976, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M942.3 486.4l-0.1-0.1-0.1-0.1c-36.4-76.7-80-138.7-130.7-186L760.7 351c43.7 40.2 81.5 93.7 114.1 160.9C791.5 684.2 673.4 766 512 766c-51.3 0-98.3-8.3-141.2-25.1l-54.7 54.7C374.6 823.8 439.8 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0.1-51.3zM878.3 154.2l-42.4-42.4c-3.1-3.1-8.2-3.1-11.3 0L707.8 228.5C649.4 200.2 584.2 186 512 186c-192.2 0-335.4 100.5-430.2 300.3v0.1c-7.7 16.2-7.7 35.2 0 51.5 36.4 76.7 80 138.7 130.7 186.1L111.8 824.5c-3.1 3.1-3.1 8.2 0 11.3l42.4 42.4c3.1 3.1 8.2 3.1 11.3 0l712.8-712.8c3.1-3 3.1-8.1 0-11.2zM398.9 537.4c-1.9-8.2-2.9-16.7-2.9-25.4 0-61.9 50.1-112 112-112 8.7 0 17.3 1 25.4 2.9L398.9 537.4z m184.5-184.5C560.5 342.1 535 336 508 336c-97.2 0-176 78.8-176 176 0 27 6.1 52.5 16.9 75.4L263.3 673c-43.7-40.2-81.5-93.7-114.1-160.9C232.6 339.8 350.7 258 512 258c51.3 0 98.3 8.3 141.2 25.1l-69.8 69.8z", "p-id": 8977 }), /* @__PURE__ */ D.createElement("path", { d: "M508 624c-6.4 0-12.7-0.5-18.8-1.6l-51.1 51.1c21.4 9.3 45.1 14.4 69.9 14.4 97.2 0 176-78.8 176-176 0-24.8-5.1-48.5-14.4-69.9l-51.1 51.1c1 6.1 1.6 12.4 1.6 18.8C620 573.9 569.9 624 508 624z", "p-id": 8978 })), Ev = D.forwardRef(Tv), kv = ({
  title: t,
  titleId: e,
  ...n
}, a) => /* @__PURE__ */ D.createElement("svg", { t: 1722154899261, className: "icon", viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg", "p-id": 1632, xmlnsXlink: "http://www.w3.org/1999/xlink", ref: a, "aria-labelledby": e, ...n }, t ? /* @__PURE__ */ D.createElement("title", { id: e }, t) : null, /* @__PURE__ */ D.createElement("path", { d: "M512 74.666667c-17.066667 0-32 14.933333-32 32v149.333333c0 17.066667 14.933333 32 32 32s32-14.933333 32-32V106.666667c0-17.066667-14.933333-32-32-32zM693.333333 362.666667c8.533333 0 17.066667-2.133333 23.466667-8.533334l104.533333-104.533333c12.8-12.8 12.8-32 0-44.8-12.8-12.8-32-12.8-44.8 0l-104.533333 104.533333c-12.8 12.8-12.8 32 0 44.8 4.266667 6.4 12.8 8.533333 21.333333 8.533334zM917.333333 480h-149.333333c-17.066667 0-32 14.933333-32 32s14.933333 32 32 32h149.333333c17.066667 0 32-14.933333 32-32s-14.933333-32-32-32zM714.666667 669.866667c-12.8-12.8-32-12.8-44.8 0s-12.8 32 0 44.8l104.533333 104.533333c6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333c12.8-12.8 12.8-32 0-44.8l-106.666666-104.533333zM512 736c-17.066667 0-32 14.933333-32 32v149.333333c0 17.066667 14.933333 32 32 32s32-14.933333 32-32v-149.333333c0-17.066667-14.933333-32-32-32zM309.333333 669.866667l-104.533333 104.533333c-12.8 12.8-12.8 32 0 44.8 6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333l104.533334-104.533333c12.8-12.8 12.8-32 0-44.8s-36.266667-12.8-46.933334 0zM288 512c0-17.066667-14.933333-32-32-32H106.666667c-17.066667 0-32 14.933333-32 32s14.933333 32 32 32h149.333333c17.066667 0 32-14.933333 32-32zM247.466667 202.666667c-12.8-12.8-32-12.8-44.8 0-12.8 12.8-12.8 32 0 44.8l104.533333 104.533333c6.4 6.4 14.933333 8.533333 23.466667 8.533333s17.066667-2.133333 23.466666-8.533333c12.8-12.8 12.8-32 0-44.8l-106.666666-104.533333z", "p-id": 1633 })), Ov = D.forwardRef(kv), Mv = "data:image/svg+xml,%3Csvg version='1.1' id='Ebene_1' x='0px' y='0px' width='595.275px' height='595.275px' viewBox='200 215 230 470' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3C/defs%3E%3Crect x='125.3' y='264.6' width='350.378' height='349.569' style='fill: rgb(237, 0, 0); stroke: rgb(197, 2, 2);' rx='58.194' ry='58.194'%3E%3C/rect%3E%3Cg%3E%3Crect x='267.162' y='307.978' transform='matrix(0.7071 -0.7071 0.7071 0.7071 -222.6202 340.6915)' style='fill:white;' width='65.545' height='262.18' rx='32.772' ry='32.772'%3E%3C/rect%3E%3Crect x='266.988' y='308.153' transform='matrix(0.7071 0.7071 -0.7071 0.7071 398.3889 -83.3116)' style='fill:white;' width='65.544' height='262.179' rx='32.772' ry='32.772'%3E%3C/rect%3E%3C/g%3E%3C/svg%3E", Pv = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Av = [{ title: "Load", icon: iv, disabledInMode: null }, { title: "Add Edge Brush", icon: sv, disabledInMode: "COLOR" }, { title: "Remove Edge Brush", icon: cv, disabledInMode: "COLOR" }, { title: "Brush", icon: ov, disabledInMode: "EDGE" }, { title: "Erase", icon: hv, disabledInMode: null }, { title: "Select", icon: dv, disabledInMode: null }], Dv = D.forwardRef(({
  theme: t = "system",
  autoAdaptToPhone: e = !0,
  changeDimensionCallBack: n,
  uploadImgCallBack: a,
  uploadOriginalImgCallBack: p,
  uploadAddEdgeMaskCallBack: g,
  uploadRemoveEdgeMaskCallBack: _,
  uploadColoredImgCallBack: w,
  uploadTotalMaskCallBack: x,
  uploadBackgroundImgCallBack: T,
  guessPromptCallBack: L,
  updatePromptCallBack: X
}, G) => {
  D.useEffect(() => {
    if ((t === "dark" || t === "light") && document.body.setAttribute("data-theme", t), t === "system") {
      const tt = window.matchMedia(
        "(prefers-color-scheme: dark)"
      );
      tt.matches && document.body.setAttribute("data-theme", "dark"), tt.addEventListener("change", (_t) => document.body.setAttribute("data-theme", _t.matches ? "dark" : "light"));
    }
  }, [t]);
  const J = D.useRef(0), et = D.useRef(null), rt = D.useRef(null), vt = D.useRef(null), Y = D.useRef(null), j = D.useRef(null), P = D.useRef(null), $ = D.useRef(null), ht = D.useRef(null), it = D.useRef(null), dt = D.useRef(null), [v, Tt] = D.useState(!1), [I, Et] = D.useState("Brush"), Xt = D.useRef(I), [zt, c] = D.useState({
    Brush: 5,
    Erase: 5,
    "Add Edge Brush": 5,
    "Remove Edge Brush": 5
  }), o = D.useRef({
    add_edge: !1,
    remove_edge: !1,
    color: !1
  }), [l, f] = D.useState(150), [i, r] = D.useState(5), [s, u] = D.useState("#FFFFFF"), [h, d] = D.useState(1), [m, y] = D.useState(""), [b, S] = D.useState(!0), E = D.useRef(b);
  D.useEffect(() => {
    E.current = b;
  }, [b]);
  const [A, M] = D.useState(0), C = D.useRef(A);
  D.useEffect(() => {
    C.current = A;
  }, [A]);
  const [O, N] = D.useState(!1), z = D.useRef(O);
  D.useEffect(() => {
    z.current = O;
  }, [O]);
  const [W, F] = D.useState([]), k = D.useRef([]), B = D.useRef([]), [Z, K] = D.useState(!1), [U, R] = D.useState(!1), [H, q] = D.useState(!1);
  D.useEffect(() => {
    console.log(I), !(!P.current || !P.current.lowerCanvasEl) && (I === "Select" || I === "Load" || (Xt.current = I, r(zt[I]), P.current.freeDrawingBrush.width = zt[I], I === "Brush" && (P.current.freeDrawingBrush.color = Ch(
      s,
      h
    )), gt()));
  }, [I]);
  const Q = (tt, _t) => {
    var kt = _t.target, xt = kt.canvas;
    kt._objects ? (xt.remove(...kt._objects), xt.discardActiveObject()) : xt.remove(kt), xt.requestRenderAll(), On(), Ie(), yt();
  }, nt = (tt) => {
    const _t = Math.min(P.current.width, P.current.height), kt = document.createElement("img");
    kt.src = Mv, tt.hasOwnProperty("controls") || (tt.cornerSize = _t / 30, tt.controls.removeControl = new Pn.Control({
      x: 0.5,
      y: -0.5,
      offsetY: -16,
      offsetX: 16,
      cursorStyle: "pointer",
      mouseUpHandler: Q.bind(void 0),
      render: ev(kt),
      cornerSize: _t / 25
    }));
  }, gt = () => {
    let tt = P.current.freeDrawingBrush.width;
    P.current.lowerCanvasEl.clientWidth && (tt = tt * P.current.lowerCanvasEl.clientWidth / P.current.getWidth());
    const _t = P.current.freeDrawingBrush.color, kt = Xt.current;
    let xt;
    kt === "Brush" ? xt = `
      <svg
        height="${tt}"
        viewBox="0 0 ${tt * 2} ${tt * 2}"
        width="${tt}"
        xmlns="http://www.w3.org/2000/svg"
      >
      <circle
        cx="50%"
        cy="50%"
        r="${tt}"
        fill="${_t}"
        opacity="0.7"
      />
      </svg>
    ` : xt = `
      <svg
        height="${tt}"
        viewBox="0 0 ${tt * 2} ${tt * 2}"
        width="${tt}"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="50%"
          cy="50%"
          r="${tt}"
          fill="#ffffff"
          opacity="0.7"
        />
        <circle
          cx="50%"
          cy="50%"
          r="${tt * 0.9}"
          fill="#000000"
          opacity="0.7"
        />
      </svg>
    `;
    const Pt = `data:image/svg+xml;base64,${window.btoa(xt)}`;
    P.current.freeDrawingCursor = `url(${Pt}) ${tt / 2} ${tt / 2}, crosshair`;
  }, ct = (tt, _t) => {
    const kt = et.current.clientWidth <= 600 && e;
    $.current.style.flexDirection = kt ? "column" : "row", console.log(et.current.style), (!tt || !_t) && (tt = $.current.clientWidth, kt || (tt /= 2), _t = tt), P.current.setWidth(tt), P.current.setHeight(_t);
    let xt;
    kt ? xt = $.current.clientWidth : xt = $.current.clientWidth / 2;
    const Pt = _t / tt * xt;
    j.current.children[0].style.width = xt + "px", j.current.children[0].style.height = Pt + "px", j.current.children[0].children[0].style.width = xt + "px", j.current.children[0].children[0].style.height = Pt + "px", j.current.children[0].children[1].style.width = xt + "px", j.current.children[0].children[1].style.height = Pt + "px", ht.current.style.width = xt + "px", ht.current.style.height = Pt + "px", vt.current.style.height = kt ? Pt * 2 : Pt + "px";
    const Ht = Pt + rt.current.clientHeight, Ai = rt.current.clientWidth;
    n({ height: Ht, width: Ai }), ft();
  }, ft = () => {
    const tt = Math.min(P.current.width, P.current.height);
    if (tt === 0)
      return;
    const _t = Math.floor(tt * 0.1), kt = Math.floor(_t / 5) * 5, xt = Math.max(25, Math.min(kt, 150));
    f(xt);
    const Pt = Math.floor(kt / 5 / 3) * 5;
    r(Pt), Object.keys(zt).forEach((Ht) => zt[Ht] = Pt), c(zt);
  }, st = async (tt) => {
    const _t = await new Promise((kt) => Pn.Image.fromURL(tt, kt));
    P.current.clear(), Pi(null), mt(), fr(), _t.set({ erasable: !1 }), P.current.setBackgroundImage(
      _t,
      () => {
        P.current.renderAll(), On(!0);
      }
    ), Ie(), ct(_t.width, _t.height), yt();
  }, lt = () => {
    let tt = !z.current;
    P.current.discardActiveObject(), P.current.getObjects().forEach((_t) => {
      _t.set("visible", !tt);
    }), N(tt), P.current.renderAll();
  }, at = () => {
    k.current.length > 1 ? K(!0) : K(!1), B.current.length > 0 ? R(!0) : R(!1);
  }, yt = () => {
    const tt = P.current.toJSON(["brushType"]);
    k.current.push(tt), B.current = [], at();
  }, mt = () => {
    k.current = [], B.current = [], at();
  }, Mt = (tt) => {
    let _t = tt.target.files[0], kt = new FileReader();
    kt.onload = (xt) => {
      q(!1);
      let Pt = xt.target.result;
      Ot(Pt);
    }, kt.readAsDataURL(_t);
  }, Ot = async (tt) => {
    fi(!0);
    const _t = await T(tt);
    _t && st(_t), fi(!1);
  }, Lt = () => {
    if (k.current.length > 1) {
      const tt = k.current.pop();
      B.current.push(tt);
      const _t = k.current[k.current.length - 1];
      P.current.loadFromJSON(_t, () => {
        P.current.renderAll(), On(), Ie();
      });
    }
    at();
  }, re = () => {
    if (B.current.length > 0) {
      const tt = B.current.pop();
      k.current.push(tt), P.current.loadFromJSON(tt, () => {
        P.current.renderAll(), On(), Ie();
      });
    }
    at();
  }, Ut = () => new Promise(
    (tt) => P.current.clone(tt, ["enableRetinaScaling", "brushType"])
  ), Ft = async () => {
    const tt = await Ut();
    return tt.setHeight(P.current.height), tt.setWidth(P.current.width), tt.renderAll(), new Promise((_t) => tt.lowerCanvasEl.toBlob(_t, "image/png"));
  }, oe = async () => {
    const tt = await Ut();
    return tt.setHeight(P.current.height), tt.setWidth(P.current.width), tt.remove(...tt.getObjects()), tt.renderAll(), new Promise((_t) => tt.lowerCanvasEl.toBlob(_t, "image/png"));
  }, Rt = async (tt = "all") => {
    const _t = await Ut();
    return _t.setHeight(P.current.height), _t.setWidth(P.current.width), _t.getObjects().forEach((kt) => {
      kt.type === "path" && (tt === "Add Edge Brush" || tt === "Remove Edge Brush") && kt.set("visible", kt.brushType === tt), kt.fill && kt.set("fill", "rgb(0,0,0)"), kt.stroke && kt.set("stroke", "rgb(0,0,0)"), kt.set("globalCompositeOperation", "destination-out");
    }), _t.setBackgroundImage(null), _t.setBackgroundColor("black"), _t.renderAll(), new Promise((kt) => _t.lowerCanvasEl.toBlob(kt, "image/png"));
  }, te = async () => {
    const tt = await Ut();
    return tt.setHeight(P.current.height), tt.setWidth(P.current.width), tt.remove(...tt.getObjects().filter((_t) => ["Add Edge Brush", "Remove Edge Brush"].includes(_t.brushType))), tt.renderAll(), new Promise((_t) => tt.lowerCanvasEl.toBlob(_t, "image/png"));
  }, hi = () => {
    const tt = P.current.getObjects().filter((Ht) => Ht.type === "path" && Ht.brushType === "Add Edge Brush"), _t = P.current.getObjects().filter((Ht) => Ht.type === "path" && Ht.brushType === "Remove Edge Brush"), kt = P.current.getObjects().filter((Ht) => Ht.type === "path" && Ht.brushType !== "Add Edge Brush" && Ht.brushType !== "Remove Edge Brush"), xt = {
      add_edge: tt.length > 0,
      remove_edge: _t.length > 0,
      color: kt.length > 0
    }, Pt = {
      add_edge: o.current.add_edge || xt.add_edge,
      remove_edge: o.current.remove_edge || xt.remove_edge,
      color: o.current.color || xt.color
    };
    return o.current = Pt, Pt;
  }, fr = () => {
    y(""), X("");
  }, dr = (tt) => {
    y(tt), X(tt);
  }, ho = D.useCallback(async () => {
    if (E.current)
      try {
        dt.current.classList.remove("shining"), dt.current.classList.add("blinking");
        const tt = await L();
        dt.current.classList.remove("blinking"), !tt.error && tt.prompt && tt.prompt !== "" ? tt.prompt != m && (dt.current.classList.add("shining"), setTimeout(() => dt.current.classList.remove("shining"), 1500), y(tt.prompt)) : fr();
      } catch (tt) {
        console.log(tt);
      }
  }, [b]), fi = (tt) => {
    tt === !0 ? C.current = C.current + 1 : C.current = Math.max(0, C.current - 1), M(C.current);
  }, [pr, Pi] = D.useState(null);
  D.useImperativeHandle(G, () => ({
    updateGeneratedImg(tt) {
      Pi("data:image/png;base64," + tt);
    }
  }));
  const fo = () => {
    st(pr);
  }, On = async (tt = !1) => {
    z.current && lt(), fi(!0);
    try {
      const _t = await Ft(), kt = await a(_t);
      if (tt) {
        const Ht = await oe();
        await p(Ht);
      }
      const xt = hi();
      if (xt.add_edge || tt) {
        const Ht = await Rt("Add Edge Brush");
        await g(Ht);
      }
      if (xt.remove_edge || tt) {
        const Ht = await Rt("Remove Edge Brush");
        await _(Ht);
      }
      if (xt.color || tt) {
        const Ht = await te();
        await w(Ht);
      }
      (xt.add_edge || xt.color) && !tt && (P.current.getObjects().length === 0 ? y("") : await ho());
      const Pt = await Rt();
      await x(Pt);
    } catch (_t) {
      console.error("Error in uploadPaintFile:", _t), alert("An error occurred while uploading the file.");
    } finally {
      fi(!1);
    }
  }, Ye = () => {
    P.current.discardActiveObject(), P.current.remove(...P.current.getObjects()), P.current.renderAll(), On(), yt(), Ie();
  }, Xn = (tt) => {
    if (P.current.discardActiveObject(), tt !== "Load" && Et(tt), tt.includes("Brush")) {
      if (tt === "Brush")
        P.current.freeDrawingBrush = new Pn.PencilBrush(P.current);
      else if (tt === "Add Edge Brush" || tt === "Remove Edge Brush") {
        const _t = tt === "Add Edge Brush", kt = new Pn.PatternBrush(P.current);
        kt.getPatternSrc = function() {
          const xt = Pn.document.createElement("canvas");
          xt.width = xt.height = 15;
          const Pt = xt.getContext("2d");
          return Pt.fillStyle = _t ? "white" : "black", Pt.fillRect(0, 0, 15, 15), new Pn.Rect({
            width: 10,
            height: 10 / 3,
            fill: _t ? "black" : "white",
            left: 5 / 2,
            top: (15 - 10 / 3) / 2
          }).render(Pt), _t && new Pn.Rect({
            width: 3.3333333333333335,
            height: 10,
            fill: "black",
            left: 5.833333333333333,
            top: 2.5
          }).render(Pt), xt;
        }, kt.source = kt.getPatternSrc(), P.current.freeDrawingBrush = kt;
      }
      P.current.isDrawingMode = !0;
    } else tt === "Erase" ? (P.current.freeDrawingBrush = new Pn.EraserBrush(P.current), P.current.isDrawingMode = !0) : tt === "Select" ? P.current.isDrawingMode = !1 : tt === "Load" && it.current.click();
  }, Ie = () => {
    let tt = [], _t = !1, kt = !1;
    const xt = P.current.getObjects().map((Pt, Ht) => {
      const Ai = Pt.type;
      let Mn;
      Ai === "path" && (Pt.brushType === "Add Edge Brush" ? (Mn = "+ edge", _t = !0) : Pt.brushType === "Remove Edge Brush" ? (Mn = "- edge", _t = !0) : (Mn = "color", kt = !0));
      let Ga = tt.filter((V) => V === Mn).length + 1;
      const Ct = Mn + ` ${Ga}`;
      return tt.unshift(Mn), {
        name: Ct,
        setActiveFunc: () => {
          P.current.discardActiveObject(), nt(Pt), P.current.setActiveObject(Pt), P.current.renderAll();
        },
        removeFunc: (V) => {
          Q(null, { target: Pt }), V.stopPropagation();
        },
        isActive: P.current.getActiveObjects().includes(Pt)
      };
    });
    Tt(_t ? "EDGE" : kt ? "COLOR" : "NONE"), F(xt.reverse());
  };
  return D.useEffect(() => {
    if ($.current && Y.current) {
      const kt = new Pn.Canvas(Y.current, {
        isDrawingMode: !0,
        backgroundColor: "transparent",
        enablePointerEvents: !0,
        enableRetinaScaling: !1
      });
      kt.backgroundColor = "#000000", kt.on({
        "selection:created": (xt) => {
          Et("Select"), P.current.isDrawingMode = !1, Ie();
        },
        "selection:updated": (xt) => {
          Ie();
        },
        "selection:cleared": (xt) => {
          Et("Select"), Ie();
        },
        "object:modified": (xt) => {
          On(), yt(), Ie();
        },
        "mouse:up": (xt) => {
          P.current.getActiveObjects().forEach((Pt) => {
            nt(Pt);
          }), P.current.isDrawingMode && (On(), yt());
        },
        "path:created": ({ path: xt }) => {
          xt.brushType = Xt.current, Xt.current === "Remove Edge Brush" && P.current.getObjects().forEach((Pt) => {
            Pt.type === "path" && Pt.brushType === "Remove Edge Brush" || xt.sendBackwards();
          }), Ie();
        }
      }), P.current = kt, ct(null, null), q(!0), Xn("Add Edge Brush"), yt();
    }
    const tt = (kt) => {
      for (let xt of kt) {
        let Pt = xt.contentRect.width;
        Pt !== J.current && (J.current = Pt, !P.current.width || !P.current.height ? ct(Pt, Pt) : ct(P.current.width, P.current.height));
      }
    }, _t = new ResizeObserver(tt);
    return et.current && _t.observe(et.current), () => {
      et.current && _t.unobserve(et.current), P.current && P.current.dispose();
    };
  }, []), D.useEffect(() => {
    P.current && (P.current.freeDrawingBrush.color = Ch(
      s,
      h
    ), gt());
  }, [s, h]), D.useEffect(() => {
    P.current && (P.current.freeDrawingBrush.width = Number(i), zt[I] = Number(i), c(zt), gt());
  }, [i]), /* @__PURE__ */ St.jsxs("div", { style: { height: "100%", width: "100%" }, ref: et, children: [
    /* @__PURE__ */ St.jsxs("div", { className: "top-bar", ref: rt, children: [
      /* @__PURE__ */ St.jsxs("div", { id: "prompt-input-box", children: [
        /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon", children: /* @__PURE__ */ St.jsx(
          gv,
          {
            id: "wand-icon",
            ref: dt,
            className: b ? "active" : "",
            title: "Guess prompt: " + (b ? "on" : "off"),
            onClick: () => S(!b)
          }
        ) }),
        /* @__PURE__ */ St.jsx("input", { id: "prompt-input", placeholder: "Brush your canvas to tell us what you'd like to create!", onChange: (tt) => dr(tt.target.value), value: m })
      ] }),
      /* @__PURE__ */ St.jsxs("div", { id: "tool-bar", children: [
        /* @__PURE__ */ St.jsxs("div", { id: "essential-tool-box", children: [
          /* @__PURE__ */ St.jsx("input", { type: "file", accept: "image/jpeg,image/png,image/webp", hidden: !0, ref: it, onChange: (tt) => Mt(tt) }),
          Av.map((tt) => {
            const _t = tt.icon;
            return /* @__PURE__ */ St.jsx(
              "div",
              {
                className: "painter-tool-icon" + (v === tt.disabledInMode ? " disabled" : ""),
                title: tt.title,
                onClick: () => {
                  tt.disabledInMode !== v && Xn(tt.title);
                },
                children: /* @__PURE__ */ St.jsx(_t, { className: I === tt.title ? "active" : "" })
              },
              tt.title
            );
          })
        ] }),
        /* @__PURE__ */ St.jsxs("div", { id: "stroke-size-box", children: [
          /* @__PURE__ */ St.jsx("div", { className: "separator" }),
          /* @__PURE__ */ St.jsx("input", { type: "range", id: "stroke-width-slider", min: "1", max: l, value: i, step: "1", title: "Stroke width", onChange: (tt) => r(tt.target.value) }),
          /* @__PURE__ */ St.jsx("div", { id: "stroke-width-value", children: i })
        ] }),
        /* @__PURE__ */ St.jsxs("div", { id: "color-and-alpha-box", children: [
          /* @__PURE__ */ St.jsx("div", { className: "separator" }),
          I === "Brush" && /* @__PURE__ */ St.jsxs(St.Fragment, { children: [
            /* @__PURE__ */ St.jsx("input", { id: "stroke-color", type: "color", value: s, title: "Stroke color", onChange: (tt) => u(tt.target.value) }),
            /* @__PURE__ */ St.jsx("input", { id: "stroke-color-transparent", type: "number", max: "1.0", min: "0.1", step: "0.05", value: h, title: "Stroke alpha value", onChange: (tt) => d(tt.target.value) })
          ] }),
          /* @__PURE__ */ St.jsxs("div", { id: "painter-history-panel", children: [
            /* @__PURE__ */ St.jsx("div", { className: "separator" }),
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon" + (Z ? "" : " disabled"), title: "Undo", children: /* @__PURE__ */ St.jsx(vv, { title: "Undo", onClick: () => Lt() }) }),
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon" + (U ? "" : " disabled"), title: "Redo", children: /* @__PURE__ */ St.jsx(_v, { title: "Redo", onClick: () => re() }) })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ St.jsxs("div", { className: "lower-area", ref: vt, children: [
      /* @__PURE__ */ St.jsxs("div", { className: "side-bar", children: [
        /* @__PURE__ */ St.jsxs("div", { className: "layer-box", children: [
          /* @__PURE__ */ St.jsxs("div", { className: "layer-operation-box", children: [
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon", title: "Remove All", id: "layer-remove-button", children: /* @__PURE__ */ St.jsx(xh, { title: "Remove All", onClick: () => Ye() }) }),
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon", title: "Hide All", id: "layer-hide-button", onClick: () => lt(), children: /* @__PURE__ */ St.jsx(Ev, { className: O ? "active" : "", title: "Hide All" }) })
          ] }),
          /* @__PURE__ */ St.jsx("div", { className: "layer-item-list", children: W.map((tt) => /* @__PURE__ */ St.jsxs("div", { className: "layer-item-container" + (tt.isActive ? " active" : ""), onClick: () => tt.setActiveFunc(), children: [
            /* @__PURE__ */ St.jsx("div", { className: "layer-item", children: tt.name }),
            /* @__PURE__ */ St.jsx(xh, { className: "layer-item-remove", title: "Remove", onClick: (_t) => tt.removeFunc(_t) })
          ] }, tt.name)) })
        ] }),
        /* @__PURE__ */ St.jsx("div", { id: "loading-status", hidden: A === 0, children: /* @__PURE__ */ St.jsx(Ov, { className: "rotating" }) })
      ] }),
      /* @__PURE__ */ St.jsxs("div", { id: "output-area", ref: $, children: [
        /* @__PURE__ */ St.jsxs("div", { id: "left-box", children: [
          H && /* @__PURE__ */ St.jsx("div", { id: "bg-reminder", onClick: () => Xn("Load"), children: /* @__PURE__ */ St.jsx("div", { id: "bg-reminder-text", children: "Click here to upload an image" }) }),
          /* @__PURE__ */ St.jsx("div", { id: "canvas-box", ref: j, children: /* @__PURE__ */ St.jsx("canvas", { ref: Y }) })
        ] }),
        /* @__PURE__ */ St.jsxs("div", { id: "output-img-box", ref: ht, children: [
          pr && /* @__PURE__ */ St.jsxs("div", { id: "output-operation-box", children: [
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon", title: "Accept", onClick: () => fo(), children: /* @__PURE__ */ St.jsx(wv, { title: "Accept", style: { fill: "#507B58" } }) }),
            /* @__PURE__ */ St.jsx("div", { className: "painter-tool-icon", title: "Discard", onClick: () => Pi(null), children: /* @__PURE__ */ St.jsx(xv, { title: "Discard", style: { fill: "#AB3131" } }) })
          ] }),
          /* @__PURE__ */ St.jsx("img", { id: "output-img", src: pr || Pv })
        ] })
      ] })
    ] })
  ] });
}), Lv = (t, e) => {
  console.log(t, e, "embedMagicSketch");
  const n = Math.random().toString(36).substring(7);
  if (!t)
    throw "DOM element not found.";
  const a = Sg.createRef();
  return window.updateGeneratedImg || (window.updateGeneratedImg = {}), window.updateGeneratedImg[n] = (p) => {
    a.current && a.current.updateGeneratedImg(p);
  }, Fm.render(
    // <React.StrictMode>
    /* @__PURE__ */ St.jsx(Dv, { ...e, ref: a }),
    // </React.StrictMode>,
    t
  ), n;
}, {
  SvelteComponent: jv,
  assign: Iv,
  binding_callbacks: Fv,
  check_outros: Rv,
  create_component: _0,
  destroy_component: b0,
  detach: Sh,
  element: Bv,
  flush: No,
  get_spread_object: Nv,
  get_spread_update: Uv,
  group_outros: zv,
  init: Wv,
  insert: Th,
  mount_component: w0,
  safe_not_equal: Xv,
  space: Yv,
  transition_in: Wr,
  transition_out: ka
} = window.__gradio__svelte__internal, { onMount: Gv } = window.__gradio__svelte__internal;
function Eh(t) {
  let e, n;
  const a = [
    { i18n: "" },
    { autoscroll: !0 },
    { translucent: !0 },
    /*loading_status*/
    t[0]
  ];
  let p = {};
  for (let g = 0; g < a.length; g += 1)
    p = Iv(p, a[g]);
  return e = new Xp({ props: p }), {
    c() {
      _0(e.$$.fragment);
    },
    m(g, _) {
      w0(e, g, _), n = !0;
    },
    p(g, _) {
      const w = _ & /*loading_status*/
      1 ? Uv(a, [
        a[0],
        a[1],
        a[2],
        Nv(
          /*loading_status*/
          g[0]
        )
      ]) : {};
      e.$set(w);
    },
    i(g) {
      n || (Wr(e.$$.fragment, g), n = !0);
    },
    o(g) {
      ka(e.$$.fragment, g), n = !1;
    },
    d(g) {
      b0(e, g);
    }
  };
}
function Hv(t) {
  let e, n, a, p = (
    /*loading_status*/
    t[0] && Eh(t)
  );
  return {
    c() {
      p && p.c(), e = Yv(), n = Bv("div");
    },
    m(g, _) {
      p && p.m(g, _), Th(g, e, _), Th(g, n, _), t[5](n), a = !0;
    },
    p(g, _) {
      /*loading_status*/
      g[0] ? p ? (p.p(g, _), _ & /*loading_status*/
      1 && Wr(p, 1)) : (p = Eh(g), p.c(), Wr(p, 1), p.m(e.parentNode, e)) : p && (zv(), ka(p, 1, 1, () => {
        p = null;
      }), Rv());
    },
    i(g) {
      a || (Wr(p), a = !0);
    },
    o(g) {
      ka(p), a = !1;
    },
    d(g) {
      g && (Sh(e), Sh(n)), p && p.d(g), t[5](null);
    }
  };
}
function Vv(t) {
  let e, n;
  return e = new R0({
    props: {
      $$slots: { default: [Hv] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      _0(e.$$.fragment);
    },
    m(a, p) {
      w0(e, a, p), n = !0;
    },
    p(a, [p]) {
      const g = {};
      p & /*$$scope, el, loading_status*/
      2097155 && (g.$$scope = { dirty: p, ctx: a }), e.$set(g);
    },
    i(a) {
      n || (Wr(e.$$.fragment, a), n = !0);
    },
    o(a) {
      ka(e.$$.fragment, a), n = !1;
    },
    d(a) {
      b0(e, a);
    }
  };
}
function Zv(t, e, n) {
  var a = this && this.__awaiter || function(v, Tt, I, Et) {
    function Xt(zt) {
      return zt instanceof I ? zt : new I(function(c) {
        c(zt);
      });
    }
    return new (I || (I = Promise))(function(zt, c) {
      function o(i) {
        try {
          f(Et.next(i));
        } catch (r) {
          c(r);
        }
      }
      function l(i) {
        try {
          f(Et.throw(i));
        } catch (r) {
          c(r);
        }
      }
      function f(i) {
        i.done ? zt(i.value) : Xt(i.value).then(o, l);
      }
      f((Et = Et.apply(v, Tt || [])).next());
    });
  };
  let { value: p = {
    from_frontend: {
      img: null,
      original_image: null,
      add_edge_image: null,
      remove_edge_image: null,
      add_color_image: null,
      total_mask: null
    },
    from_backend: { prompt: null, generated_image: null }
  } } = e, { loading_status: g = void 0 } = e, _ = null, { theme: w = "system" } = e, { url: x = void 0 } = e, T, L;
  function X() {
    if (p.from_backend !== void 0 && p.from_backend.generated_image !== null && p.from_backend.generated_image !== _ && window.updateGeneratedImg && window.updateGeneratedImg[L]) {
      const v = window.updateGeneratedImg[L];
      v(p.from_backend.generated_image), _ = p.from_backend.generated_image;
    }
  }
  const G = (v) => new Promise((Tt, I) => {
    const Et = new FileReader();
    Et.onloadend = () => Tt(Et.result), Et.readAsDataURL(v);
  }), J = (v) => console.log(v), et = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.img = Tt, p);
  }), rt = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.original_image = Tt, p);
  }), vt = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.add_edge_image = Tt, p);
  }), Y = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.remove_edge_image = Tt, p);
  }), j = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.add_color_image = Tt, p);
  }), P = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield G(v);
    n(2, p.from_frontend.total_mask = Tt, p);
  }), $ = (v) => a(void 0, void 0, void 0, function* () {
    return yield fetch(`${x || ""}/magic_quill/process_background_img`, {
      method: "POST",
      body: JSON.stringify(v),
      headers: { "content-type": "application/json" }
    }).then((I) => I.json());
  }), ht = (v) => a(void 0, void 0, void 0, function* () {
    const Tt = yield fetch(`${x || ""}/magic_quill/guess_prompt`, {
      method: "POST",
      body: JSON.stringify(p.from_frontend),
      headers: { "content-type": "application/json" }
    }).then((I) => I.json());
    return n(2, p.from_backend.prompt = Tt, p), { error: !1, prompt: Tt };
  }), it = (v) => {
    n(2, p.from_backend.prompt = v, p);
  };
  Gv(() => {
    L = Lv(T, {
      theme: w,
      changeDimensionCallBack: J,
      uploadImgCallBack: et,
      uploadOriginalImgCallBack: rt,
      uploadAddEdgeMaskCallBack: vt,
      uploadRemoveEdgeMaskCallBack: Y,
      uploadColoredImgCallBack: j,
      uploadTotalMaskCallBack: P,
      uploadBackgroundImgCallBack: $,
      guessPromptCallBack: ht,
      updatePromptCallBack: it
    });
  });
  function dt(v) {
    Fv[v ? "unshift" : "push"](() => {
      T = v, n(1, T);
    });
  }
  return t.$$set = (v) => {
    "value" in v && n(2, p = v.value), "loading_status" in v && n(0, g = v.loading_status), "theme" in v && n(3, w = v.theme), "url" in v && n(4, x = v.url);
  }, t.$$.update = () => {
    t.$$.dirty & /*value*/
    4 && p === null && n(2, p = {
      from_frontend: {
        img: null,
        original_image: null,
        add_edge_image: null,
        remove_edge_image: null,
        add_color_image: null,
        total_mask: null
      },
      from_backend: { prompt: null, generated_image: null }
    }), t.$$.dirty & /*value*/
    4 && X();
  }, [g, T, p, w, x, dt];
}
class qv extends jv {
  constructor(e) {
    super(), Wv(this, e, Zv, Vv, Xv, {
      value: 2,
      loading_status: 0,
      theme: 3,
      url: 4
    });
  }
  get value() {
    return this.$$.ctx[2];
  }
  set value(e) {
    this.$$set({ value: e }), No();
  }
  get loading_status() {
    return this.$$.ctx[0];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), No();
  }
  get theme() {
    return this.$$.ctx[3];
  }
  set theme(e) {
    this.$$set({ theme: e }), No();
  }
  get url() {
    return this.$$.ctx[4];
  }
  set url(e) {
    this.$$set({ url: e }), No();
  }
}
export {
  qv as default
};
